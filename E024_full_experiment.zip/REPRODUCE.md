# E024 云机复跑入口

使用已有 A2 CANN 9.0 环境；不要在共享 NPU 上并行计时。归档不包含账号配置、SSH私钥、输入张量或编译二进制。

解压后在此归档根目录运行（按实际安装设置 `ASCEND_HOME_PATH`）：

```sh
export ASCEND_HOME_PATH=/home/developer/Ascend/cann-9.0.0
bash cloud_bench/with_cann.sh python3 experiments/E024_small_batch/run_round.py build BASE TINY SHORTR2 TINY2 FLAT COMBO ONEROW ONEINV HALFSTATIC
bash cloud_bench/with_cann.sh python3 experiments/E024_small_batch/run_round.py halfquick
bash cloud_bench/with_cann.sh python3 experiments/E024_small_batch/half_validate.py
```

`run_round.py` 的数据/结果目录沿用原云机 `/mnt/workspace/addrms_results/E024`。若原结果仍存在，会复用已有记录；做新的测量应在隔离环境修改 OUT 路径，避免把复用记录当新试验。

驱动会优先用原 E021/E023 输入；不存在则按固定种子生成自建输入。新环境的复跑是新对照实验，不保证重现历史微秒值和官方分数。`BASE` 是归档 M6 完整源码。FP16/BF16 strict判断与正式网站判定分开保存。

查看 `experiments/E024_small_batch/报告.md`、`audit_summary.json` 以及 `cloud_reports.zip`。官方原始页面与观察排名保存于各个正式候选目录。
