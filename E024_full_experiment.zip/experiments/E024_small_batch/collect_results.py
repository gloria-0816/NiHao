import json,zipfile
from pathlib import Path
p=Path('/mnt/workspace/addrms_results/E024')
summary={}
for f in p.glob('*/complete.json'):
 summary[f.parent.name]=json.loads(f.read_text())
for f in p.glob('*/summary.json'):
 summary[f.parent.name]=json.loads(f.read_text())
records=[]
for f in p.rglob('record.json'):
 r=json.loads(f.read_text())
 if 'case_id' in r:
  records.append(dict(path=str(f.relative_to(p)),case_id=r['case_id'],variant=r['variant'],status=r['status'],strict_pass=r.get('strict',{}).get('pass'),median_us=r.get('median_us'),kernel_sha256=r['kernel_sha256'],runner_sha256=r['runner_sha256'],shape=r.get('shape'),dtype=r.get('dtype'),output_sha256=r.get('output_sha256'),failed_elements=r.get('strict',{}).get('failed_elements'),vector_cores=r.get('benchmark',{}).get('vector_cores')))
summary['records']=records
(p/'audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
with zipfile.ZipFile(p/'reports.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in p.rglob('*'):
  if f.is_file() and f.suffix in ['.json','.csv','.log','.txt'] and 'inputs' not in f.parts and 'case' not in f.parts:
   z.write(f,f.relative_to(p))
print(json.dumps({k:v for k,v in summary.items() if k!='records'},ensure_ascii=False))
print('runs',len(records),'bytes',(p/'reports.zip').stat().st_size)
