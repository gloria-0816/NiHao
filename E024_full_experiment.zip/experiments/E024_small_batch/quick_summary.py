import json
from pathlib import Path
p=Path('/mnt/workspace/addrms_results/E024')
a=[json.loads(f.read_text()) for f in p.glob('tiny_special_*/complete.json')]
print('special',dict(groups=len(a),cases=sum(x['cases'] for x in a),runs=sum(x['runs'] for x in a),strict_fail=sum(x['strict_fail'] for x in a)))
for group in ['tiny2_pairs','tiny_boundary','combo_pairs','combo_boundary']:
 for filename in ['summary.json','complete.json']:
  f=p/group/filename
  if f.exists():print(group,json.loads(f.read_text()))
