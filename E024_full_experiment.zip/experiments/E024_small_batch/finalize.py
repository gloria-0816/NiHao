import hashlib
import json
import re
import shutil
import statistics
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
P = Path(__file__).resolve().parent

def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def usec(value):
    if value.endswith('ms'):
        return float(value[:-2]) * 1000
    assert value.endswith('μs'), value
    return float(value[:-2])

baseline = json.loads((ROOT/'experiments/E023_performance_rewrite/selected/selection.json').read_text(encoding='utf-8'))['official_result']
results = []
for name in ['TINY2','COMBO','HALFSTATIC','HALFSTATIC_RETEST']:
    d = P/name
    if not (d/'official_dom.txt').exists() or not (d/'ranking_dom.txt').exists():
        continue
    dom = (d/'official_dom.txt').read_text(encoding='utf-8')
    rank = (d/'ranking_dom.txt').read_text(encoding='utf-8')
    matches = re.findall(r'row "(\d+) Pass ([\d.]+)% ([\d.]+(?:μs|ms)) ([\d.]+(?:μs|ms))"', dom)
    assert len(matches) == 15, (name, len(matches))
    assert [int(x[0]) for x in matches] == list(range(1,16))
    ranking = re.search(r'row "(\d+) 我 .*?gem_1210 Pass ([\d.]+) (\d{4}/\d+/\d+ \d+:\d+:\d+)', rank)
    assert ranking, name
    source = (d/'code/kernel.asc').read_bytes()
    editor = (d/'editor_verified.asc').read_bytes()
    assert source.replace(b'\r\n',b'\n') == editor, name
    meta = json.loads((d/'manifest.json').read_text(encoding='utf-8'))
    assert sha(source) == meta['source_sha256']
    rec = dict(variant=name, submission_id=int(re.search(r'提交 ID：(\d+)',dom)[1]),
               submitted_at=re.search(r'提交时间：([^\n]+)',dom)[1],
               url=(d/'submitted_url.txt').read_text(encoding='utf-8').strip(),
               pass_cases=15,total_cases=15,score=float(ranking[2]),rank=int(ranking[1]),
               time_us=[usec(x[2]) for x in matches],tbest_us=[usec(x[3]) for x in matches],
               error_pct=[float(x[1]) for x in matches],source_sha256=sha(source),editor_sha256=sha(editor),editor_normalization='CRLF to LF only')
    build_name = 'HALFSTATIC' if name == 'HALFSTATIC_RETEST' else name
    build = json.loads((P/'cloud_results'/('build_'+build_name)/'record.json').read_text(encoding='utf-8'))
    assert build['returncode'] == 0 and build['source_sha256'] == sha(source)
    rec['runner_sha256'] = build['runner_sha256']
    files = sorted(f for f in (d/'code').rglob('*') if f.is_file())
    assert len(files) == 8, (name, len(files))
    with zipfile.ZipFile(d/'project.zip','w',zipfile.ZIP_DEFLATED) as z:
        for f in files:
            z.write(f,f.relative_to(d/'code').as_posix())
    with zipfile.ZipFile(d/'project.zip') as z:
        assert z.testzip() is None
        for f in files:
            assert z.read(f.relative_to(d/'code').as_posix()) == f.read_bytes()
        assert sha(z.read('kernel.asc')) == sha(source)
    rec['project_sha256'] = sha((d/'project.zip').read_bytes())
    rec['gain_vs_E023_pct'] = [100*(b-t)/b for b,t in zip(baseline['time_us'],rec['time_us'])]
    save(d/'official_result.json',rec)
    meta.update(status='official_pass',submission_id=rec['submission_id'],official_score=rec['score'],runner_sha256=rec['runner_sha256'])
    save(d/'manifest.json',meta)
    results.append(rec)

assert results
best = max([baseline]+results, key=lambda r: (r['score'],-r['submission_id']))
best_dir = ROOT/'experiments/E023_performance_rewrite/M6' if best['variant']=='M6' else P/best['variant']
latest = max(results, key=lambda r:r['submission_id'])
selected = P/'selected'
selected.mkdir(exist_ok=True)
shutil.copytree(best_dir/'code',selected/'code',dirs_exist_ok=True)
shutil.copy2(best_dir/'project.zip',selected/'project.zip')
shutil.copy2(best_dir/'editor_verified.asc',selected/'editor_verified.asc')
selection = dict(selected=best['variant'],reason='Highest observed complete official score in E024; retain source as next-round parent. No per-case result splicing.',
                 source_sha256=best['source_sha256'],runner_sha256=best['runner_sha256'],
                 official_result=best,latest_official_result=latest,
                 historical_best_score=best['score'],stable_total_score_improvement_proven=False)
save(selected/'selection.json',selection)
save(P/'official_results.json',dict(E023_baseline=baseline,submissions=results,selection=selection))
assert sha((selected/'code/kernel.asc').read_bytes()) == best['source_sha256']
assert sha((selected/'editor_verified.asc').read_bytes()) == best.get('editor_sha256',best['source_sha256'])
with zipfile.ZipFile(selected/'project.zip') as z:
    assert sha(z.read('kernel.asc')) == best['source_sha256']

audit=json.loads((P/'audit_summary.json').read_text(encoding='utf-8'))
special=[v for k,v in audit.items() if k.startswith('tiny_special_')]
half_audit=json.loads((P/'half_numerical_audit.json').read_text(encoding='utf-8'))
special_summary=dict(groups=len(special),cases=sum(v['cases'] for v in special),
                     runs=sum(v['runs'] for v in special),strict_fail=sum(v['strict_fail'] for v in special))
save(P/'verification.json',dict(selected=best['variant'],source_sha256=best['source_sha256'],
     verified_editor=True,editor_normalization='CRLF to LF only',editor_sha256=best.get('editor_sha256',best['source_sha256']),verified_zip_files=8,special_values=special_summary,half_numerical_audit={k:v for k,v in half_audit.items() if k!='records'}))
lines=[
 '# E024 小行批量与 FP16 整块转换优化报告', '',
 '2026-10-11。以 E023 最高分 M6 的完整源码为基线，查阅公开 RMSNorm 实现和 Ascend C API，独立改写数据流并以云机及比赛网页验证。', '',
 f"**最高完整提交：{best['variant']}，{best['score']:.2f} 分，15/15 Pass，观察排名 {best['rank']}。** 相对 M6 的 {baseline['score']:.2f} 分，历史最高分提高 {best['score']-baseline['score']:+.2f} 分。排名为当时快照，单次计时不是稳定总分收益保证。", '',
 f"最后提交 {latest['variant']} / {latest['submission_id']}：{latest['score']:.2f} 分，观察排名 {latest['rank']}。排行榜按最后提交显示；历史最高分单独记录。", '',
 '[后续完整源码](selected/code/kernel.asc) · [工程包](selected/project.zip) · [选择记录](selected/selection.json) · [正式结构化结果](official_results.json)', '',
 f"本地测试源码 SHA256：`{best['source_sha256']}`；云机 runner SHA256：`{best['runner_sha256']}`。", '',
 f"网页编辑器完整文本 SHA256：`{best.get('editor_sha256',best['source_sha256'])}`。若本地使用 CRLF，网页为 LF，两者仅统一换行符后逐字节一致。", '',
 '## 资料与实际方法', '',
 '参考 [Ascend C RmsNorm API](https://asc.gitcode.com/api/SIMD-API/adv_api/normalization/RmsNorm.html) 的多行、列对齐与向量化思路，以及 [vLLM Ascend AddRmsNormBias 实现](https://github.com/vllm-project/vllm-ascend/blob/main/csrc/moe/add_rms_norm_bias/op_kernel/add_rms_norm_bias.h) 的参数常驻和逐行逆 RMS 归一化。本轮采用独立实现，未复制这些项目的源码。', '',
 'TINY：FP32 短行每核最多 4 行，使用 22560 B 静态 UB，四个输入 DMA 共用一次完成等待；输入直接成为计算和输出区。一次 [BlockReduceSum](https://www.hiascend.com/doc_center/source/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0084.html) 加一次跨行 WholeReduceSum 得到每行平方和；只对每行 RMS 计算一次倒数，通过 Brcb 广播并批量归一化和仿射。清零仅作用于归约中的无效尾部。', '',
 'TINY 首次测量中 s3 明显加速而 s2 回退，所以 TINY2 将入口限制为 FP32、D≤512、行数在可用核数的 2～4 倍之间。不会在每核只有一行时启用。SHORTR2 是另一个对照，只降低旧批量路径的入口门槛；它的收益低于新静态内核。', '',
 'FLAT：FP16 非对齐行使用两次整块 Cast，替代按每列 64 元素循环启动的 Cast。先计算残差和，再用跨行 mask 清零尾部，避免全块清零两个 FP32 区。初测 s6/s7 正向、s4 没有明确收益，所以 COMBO 只在 D=321..1023 采用整块转换；较窄行保留 M6 数据流。该计数式向量优化方向来自 [Ascend C 最佳实践](https://www.hiascend.com/doc_center/source/zh/CANNCommunityEdition/82RC1alpha001/opdevg/ascendcbestP/CANN%E7%A4%BE%E5%8C%BA%E7%89%88%208.2.RC1.alpha001%20Ascend%20C%E6%9C%80%E4%BD%B3%E5%AE%9E%E8%B7%B5%2001.pdf)，实际收益以测量决定。', '',
 'COMBO 从 TINY2 完整源码合并上述 FP16 改动。两个入口只依赖真实 dtype、shape 和可用核数，计算读取完整输入；没有按测试点 ID 选择或预存输出。', '',
 'ONEROW：FP32、D≤512、每核恰好一行时，将四个 DMA 合并到一次 MTE2_V 完成等待，并直接复用 x/residual 的 UB。仍采用旧单行归约和向量 Div。两组交错测得 s2 仅快约 0.9%，未直接提交。ONEINV 在该数据流上将向量 Div 改成每行一个逆 RMS，再广播相乘。同步合并参考 [SetFlag/WaitFlag 官方文档](https://www.hiascend.com/document/detail/zh/CANNCommunityEdition/910/API/ascendcopapi/docs/api/SIMD-API/基础API/同步控制/核内同步/SetFlag-WaitFlag.md)，在云机 CANN9.0、A2 上编译验证，资料中的 9.1 新架构内容不直接套用。', '',
 'HALFSTATIC：针对 FP16 D≤256、每核 4～32 行的完整分区，一次装入 106880 B 静态 UB。采用两个整块输入 Cast、参数转换、沿用 COMBO 的两级 WholeReduceSum、RMS 倒数及 FMA；以残差输入区作为最终 FP16 输出区。入口只依赖 shape/dtype/核数，不影响其他内核。静态内存管理方法参考 [官方静态 Tensor 范式](https://www.hiascend.com/document/detail/zh/canncommercial/83RC1/opdevg/Ascendcopdevg/atlas_ascendc_10_00019.html)。', '',
 '## 云机对照', '',
 '910B3，40 AIV，CANN 9.0.0。每进程 10 次热身、20 次计时，取 msprof 最后 20 个 kernel task duration 中位数；主要候选每点按 A-B-B-A 一组交错运行；ONEROW/ONEINV/HALFSTATIC 各两组，第二组反向。BASE 是完整 M6，单行及 HALFSTATIC 候选与完整 COMBO 比较。云机数据不能代替官方时间。', '',
 '|候选|代表用例|对照中位 μs|候选中位 μs|耗时减少|',
 '|---|---|---:|---:|---:|',
]
for group in ['tiny_pairs','shortr2_pairs','tiny2_pairs','flat_pairs','combo_pairs','one_pairs','inv_pairs','half_pairs']:
 for cid,r in audit.get(group,{}).items():
  lines.append(f"|{r['candidate']}|{cid}|{statistics.median(r['base_us']):.3f}|{statistics.median(r['candidate_us']):.3f}|{r['gain_pct']:+.2f}%|")
lines += ['', 's3 为云机 128×256 FP32，s6 为 1513×577 FP16，s7 为 3113×397 FP16。官方对应编号的实际收益另列，不假设云机与比赛机器计时条件相同。', '',
 '## 正式网站完整提交', '',
 'HALFSTATIC 首次官方第4点改善约10.9%，但未改动的第3点从3.52波动到3.77 μs，完整总分低于 COMBO。因此额外保留一次同源码官方复测；这不是新方法，首次结果与复测结果都记录，不作逐点拼接。', '', '|版本|提交|通过|分数|观察排名|','|---|---|---|---:|---:|',
 f"|M6|[{baseline['submission_id']}]({baseline['url']})|15/15|{baseline['score']:.2f}|{baseline['rank']}|"]
for r in results:
 lines.append(f"|{r['variant']}|[{r['submission_id']}]({r['url']})|15/15|{r['score']:.2f}|{r['rank']}|")
lines += ['', '下表单位 μs，网页 ms 按 1000 换算。每列保留同一份完整提交的 15 点，没有拼接最好点。TBest 使用最高分提交当时的页面值。', '',
 '|点|M6|'+'|'.join(r['variant'] for r in results)+'|最高分版 TBest|最高分版耗时减少|',
 '|---|'+'---:|'*(len(results)+3)]
for i in range(15):
 gain=100*(baseline['time_us'][i]-best['time_us'][i])/baseline['time_us'][i]
 vals=[str(i+1),f"{baseline['time_us'][i]:.2f}"]+[f"{r['time_us'][i]:.2f}" for r in results]+[f"{best['tbest_us'][i]:.2f}",f"{gain:+.2f}%"]
 lines.append('|'+ '|'.join(vals)+'|')
lines += ['', '## 校验与取舍', '', '|检查组|用例数|运行数|strict 未通过次数|','|---|---:|---:|---:|']
for name in ['tiny_check','tiny2_check','tiny_boundary','flat_check','combo_check','combo_boundary','one_check','inv_check','inv_boundary','half_check','half_boundary']:
 c=audit.get(name)
 if c:lines.append(f"|{name}|{c['cases']}|{c['runs']}|{c['strict_fail']}|")
lines += [f"|TINY2 特殊值合计|{special_summary['cases']}|{special_summary['runs']}|{special_summary['strict_fail']}|", '',
 'TINY2 归约顺序及倒数乘法与 M6 不完全逐位相同，因此按数值容差及 NaN/Inf 分类验证；没有把逐位一致当成必需条件阻止优化。特殊值包括零值、抵消、交错符号、宽数值范围、NaN/Inf 及尾部脉冲。', '',
 '含整套场景的组中 6 次 strict 未通过来自 3 个 BF16 缩小场景的基线与候选各一次，继承差异单独保留。被改写的 FP32/FP16 域是否通过可从 records 逐项核对，正式提交以网站 15/15 判定记录。', '',
 '早期独立数值审计确认：TINY2/COMBO 的 128 次 FP16/FP32 非性能检查全部 strict 通过；41 次 COMBO FP16 检查与 M6 输出逐位相同。6 次候选 BF16 未通过与配对基线输出 SHA256、失败元素数完全一致。[逐记录数值审计](numerical_audit.json)。', '',
 f"HALFSTATIC 的 {half_audit['cases']} 个数值用例、{half_audit['runs']} 次对照运行全部与 COMBO 输出逐位一致。候选 FP16 {half_audit['fp16_strict_pass']} 次、FP32 {half_audit['fp32_strict_pass']} 次全部 strict 通过；{half_audit['inherited_bf16_fail']} 个继承 BF16 未通过与基线一致。其中特殊值 {half_audit['special_cases']} 例、{half_audit['special_runs']} 次运行，新增失败 0。[静态 FP16 数值审计](half_numerical_audit.json)。", '',
 '首次 tinybounds 生成了公开 D≥64 范围外的 D=1 用例，CPU 数据生成器拒绝，未启动该用例的 NPU。已将边界集修正为公开范围并完成正常运行；这次尝试不计作精度失败或有效性能样本。', '',
 f"归档包含 {len(audit['records'])} 个运行记录：[云机汇总](audit_summary.json)、[原始档案](cloud_reports.zip)。所有正式提交都经网页全选复制、仅统一 CRLF→LF 后与测试源码逐字节核对；交付工程包 8 个文件的内容及 CRC 已核对。", '',
 '后续从 selected 的最高分完整版本继续。第3点的小行瓶颈优先用批量搬运/归约解决；第6/7点保留有收益的整块转换。HALFSTATIC 第4点的收益单独记录，是否进入下一轮基线按完整官方总分选择；未证明有收益的 ONEROW/ONEINV 与较低收益的 SHORTR2 不进入最终版本。仍有场景未追平 TBest。下一轮方法优先针对大规模 FP32 非对齐行和 BF16 内存吞吐；先做单一数据流对照，再与最高分完整版本合并并测量，不同时改变归约和搬运参数。',
]
if (best_dir/'official_score.png').exists():
 shutil.copy2(best_dir/'official_score.png',selected/'official_score.png')
 lines += ['', '![正式成绩截图](selected/official_score.png)']
if (best_dir/'official_score_visible.png').exists():
 shutil.copy2(best_dir/'official_score_visible.png',selected/'official_score_visible.png')
 lines += ['', '![正式分数截图](selected/official_score_visible.png)']
(P/'报告.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
(ROOT/'docs/小行批量与整块转换优化交接_E024_2026-10-11.md').write_text(
 f"# E024 优化交接\n\n最佳完整提交 {best['variant']}：{best['score']:.2f} 分，15/15 Pass，观察排名 {best['rank']}。\n\n[完整报告](../experiments/E024_small_batch/报告.md) · [完整源码](../experiments/E024_small_batch/selected/code/kernel.asc) · [工程包](../experiments/E024_small_batch/selected/project.zip) · [选择记录](../experiments/E024_small_batch/selected/selection.json)。\n\n源码 SHA256：`{best['source_sha256']}`。\n",encoding='utf-8')
print(json.dumps(dict(best=best['variant'],score=best['score'],latest=latest['variant'],latest_score=latest['score'],
                     delta=best['score']-baseline['score'],special_values=special_summary,records=len(audit['records']),verified_zip_files=8),ensure_ascii=False))
