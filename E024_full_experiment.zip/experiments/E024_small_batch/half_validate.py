import sys,runpy
from pathlib import Path
f=Path(__file__).with_name('run_round.py')
for mode in ['halfbounds','halfspecial']:
 sys.argv=[str(f),mode]
 runpy.run_path(str(f),run_name='__main__')
