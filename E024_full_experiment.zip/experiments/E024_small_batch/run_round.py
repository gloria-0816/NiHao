import sys,json,hashlib,subprocess,statistics,csv,time,os,importlib.util
from pathlib import Path
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[1]
spec=importlib.util.spec_from_file_location('core',ROOT/'experiments/E006A_probe/cloud_driver.py');core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
core.PROTOCOL=dict(timeout_ms=30000,process_timeout_s=240)
OUT=Path('/mnt/workspace/addrms_results/E024');OUT.mkdir(exist_ok=True)
def source(v):
 if v=='BASE':return ROOT/'experiments/E023_performance_rewrite/M6/code/kernel.asc'
 return ROOT/'experiments/E014_crossrow_cast/source/C/kernel.asc' if v=='C' else HERE/v/'code/kernel.asc'
def runner(v):
 if v=='BASE':return ROOT/'experiments/E023_performance_rewrite/build_M6/cloud_addrmsnormbias'
 return ROOT/'experiments/E014_crossrow_cast/build_C/cloud_addrmsnormbias' if v=='C' else HERE/f'build_{v}/cloud_addrmsnormbias'
core.version=lambda v:(runner(v),core.sha(source(v)))
core.origin=lambda cid: next((q/cid for q in [Path('/mnt/workspace/addrms_results/E021/inputs'),Path('/mnt/workspace/addrms_results/E023/inputs')] if (q/cid/'meta.json').exists()),OUT/'inputs'/cid)
orig=core.run_logged
def logged(cmd,*a,**k):
 if '--case-dir' in cmd:cmd.extend(['--max-device-bytes','8589934592'])
 return orig(cmd,*a,**k)
core.run_logged=logged

def build(names):
 for v in names:
  folder=OUT/f'build_{v}';folder.mkdir(exist_ok=True)
  cmd=['env','ASCEND_HOME_PATH=/home/developer/Ascend/cann-9.0.0','KERNEL_SOURCE='+str(source(v)),'BUILD_DIR='+str(runner(v).parent),'bash',str(ROOT/'cloud_bench/build.sh')]
  r=orig(cmd,folder/'stdout.log',folder/'stderr.log',600);r.update(source_sha256=core.sha(source(v)))
  if r['returncode']==0:r['runner_sha256']=core.sha(runner(v))
  core.save(folder/'record.json',r);print(v,r,flush=True)
  assert r['returncode']==0

def case(cid,r,d,dt,pattern='uniform'):
 dest=core.origin(cid)
 if not dest.exists():
  dest.parent.mkdir(exist_ok=True);core.case_data.generate(dest,[1,r,d],dt,seed=42,pattern=pattern,case_id=cid,max_tensor_mib=2048)
 return cid

def run(cid,v,folder,profile=False):
 rec=core.run_case(folder,cid,v,dict(warmup=10 if profile else 0,repeats=1,batch=20 if profile else 1,timing='host'),'ordinary' if profile else None)
 assert rec['status'] in ('measured_strict_pass','measured_strict_fail_retained'),rec
 # Retain all numerical outcomes, including the approximate Rsqrt probe.
 if profile:
  rows=[]
  for f in (folder/'profile').rglob('op_summary*.csv'):
   with f.open(encoding='utf-8-sig') as h:rows+=list(csv.DictReader(h))
  rows.sort(key=lambda x:float(x['Task Start Time(us)']));assert len(rows)==31,len(rows)
  rec['task_times_us']=[float(x['Task Duration(us)']) for x in rows[-20:]];rec['median_us']=statistics.median(rec['task_times_us'])
  core.save(folder/'record.json',rec)
 return rec

def check(group,items,variants):
 dest=OUT/group;dest.mkdir(exist_ok=True);records=[]
 for cid,r,d,dt in items:
  case(cid,r,d,dt);pair=[]
  for v in variants:
   f=dest/f'{cid}_{v}'
   rec=json.loads((f/'record.json').read_text()) if (f/'record.json').exists() else run(cid,v,f)
   pair.append(rec);records.append(rec)
  
  for x in pair:x['bitwise_equal_parent']=x['output_sha256']==pair[0]['output_sha256']
  core.save(dest/'records.json',records)
 core.save(dest/'complete.json',dict(cases=len(items),runs=len(records),bitwise_equal=all(x.get('bitwise_equal_parent',True) for x in records),strict_fail=sum(not x['strict']['pass'] for x in records)))

def pairs(group,items,base,cand,blocks=2):
 dest=OUT/group;dest.mkdir(exist_ok=True);records=[]
 for block in range(blocks):
  for cid,r,d,dt in items:
   case(cid,r,d,dt)
   for pos,v in enumerate([base,cand,cand,base] if block%2==0 else [cand,base,base,cand]):
    f=dest/f'b{block}_{cid}_{pos}_{v}'
    rec=json.loads((f/'record.json').read_text()) if (f/'record.json').exists() else run(cid,v,f,True)
    records.append(rec);core.save(dest/'records.json',records)
 summary={}
 for cid,*_ in items:
  b=[x['median_us'] for x in records if x['case_id']==cid and x['variant']==base];c=[x['median_us'] for x in records if x['case_id']==cid and x['variant']==cand]
  summary[cid]=dict(base=base,candidate=cand,base_us=b,candidate_us=c,gain_pct=100*(statistics.median(b)-statistics.median(c))/statistics.median(b))
 core.save(dest/'summary.json',summary);print(json.dumps(summary),flush=True)

small=[('s1',1,64,'float16'),('s2',7,197,'float32'),('s3',128,256,'float32'),('s4',767,193,'float16'),('s5',8,32768,'float16'),('s6',1513,577,'float16'),('s7',3113,397,'float16'),('s8',10240,512,'float16'),('s9',4096,1536,'float32'),('s10',8192,1024,'float16'),('s11',3749,3083,'float32'),('s12',3408,4096,'bfloat16'),('s13',10300,3079,'float32'),('s14_reduced',3841,128,'bfloat16'),('s15_reduced',161,8192,'bfloat16')]


mode=sys.argv[1]
if mode=='build':build(sys.argv[2:])
if mode=='tinyquick':
 check('tiny_check',small[1:3],['BASE','TINY','SHORTR2'])
 pairs('tiny_pairs',small[1:3],'BASE','TINY',blocks=1)
 pairs('shortr2_pairs',[small[2]],'BASE','SHORTR2',blocks=1)
if mode=='tinybounds':
 items=[(f'tiny_{r}_{d}',r,d,'float32') for r,d in [(2,64),(7,64),(80,64),(7,65),(7,197),(39,193),(40,255),(41,256),(79,256),(80,256),(81,256),(127,256),(128,256),(159,256),(160,256),(161,256),(159,511),(159,512),(159,513)]]
 check('tiny_boundary',items+small,['BASE',sys.argv[2]])
if mode=='tinyspecial':
 for d in [64,197,256,511,512]:
  for pattern in ['zeros','cancel','checkerboard','wide_range','specials','tail_impulse']:
   cid=f'tiny_special_{d}_{pattern}';case(cid,128,d,'float32',pattern)
   check('tiny_special_'+cid,[(cid,128,d,'float32')],['BASE',sys.argv[2]])

if mode=='flatquick':
 check('flat_check',[small[i] for i in [3,5,6,7,9]],['BASE','FLAT'])
 pairs('flat_pairs',[small[i] for i in [3,5,6]],'BASE','FLAT',blocks=1)
if mode=='flatbounds':
 items=[(f'flat_{r}_{d}',r,d,'float16') for r,d in [(159,193),(160,193),(161,193),(767,65),(767,127),(767,129),(767,193),(767,255),(767,257),(767,321),(767,397),(767,447),(767,511),(767,512),(161,513),(161,575),(479,576),(479,577),(481,639),(481,640),(201,641),(201,767),(201,768),(201,769),(201,1023),(201,1024),(201,1025)]]
 check('flat_boundary',items+small,['BASE',sys.argv[2]])

if mode=='tiny2quick':
 check('tiny2_check',[small[2]],['BASE','TINY2'])
 pairs('tiny2_pairs',[small[2]],'BASE','TINY2',blocks=1)

if mode=='comboquick':
 check('combo_check',[small[i] for i in [2,3,5,6,7,9]],['BASE','COMBO'])
 pairs('combo_pairs',[small[i] for i in [2,5,6]],'BASE','COMBO',blocks=1)
if mode=='combobounds':
 items=[(f'combo_fp32_{r}_{d}',r,d,'float32') for r,d in [(80,64),(80,65),(80,197),(80,255),(80,256),(80,511),(80,512),(80,513),(159,64),(159,197),(159,256),(159,511),(159,512),(160,256),(161,256)]]
 items+=[(f'combo_fp16_{r}_{d}',r,d,'float16') for r,d in [(159,193),(160,193),(161,193),(767,65),(767,193),(767,319),(767,320),(767,321),(767,397),(767,447),(767,511),(767,512),(161,513),(161,575),(479,576),(479,577),(481,639),(481,640),(201,641),(201,767),(201,768),(201,769),(201,1023),(201,1024),(201,1025)]]
 check('combo_boundary',items+small,['BASE','COMBO'])

if mode=='onequick':
 check('one_check',[small[1]],['COMBO','ONEROW'])
 pairs('one_pairs',[small[1]],'COMBO','ONEROW',blocks=2)
if mode=='onebounds':
 items=[(f'one_{r}_{d}',r,d,'float32') for r,d in [(2,64),(7,64),(7,65),(7,127),(7,128),(7,193),(7,197),(7,255),(7,256),(7,511),(7,512),(7,513),(39,197),(40,197),(41,197)]]
 check('one_boundary',items+small,['COMBO','ONEROW'])
if mode=='onespecial':
 for d in [64,197,512]:
  for pattern in ['zeros','cancel','checkerboard','wide_range','specials','tail_impulse']:
   cid=f'one_special_{d}_{pattern}';case(cid,7,d,'float32',pattern)
   check('one_special_'+cid,[(cid,7,d,'float32')],['COMBO','ONEROW'])

if mode=='invquick':
 check('inv_check',[small[1]],['COMBO','ONEINV'])
 pairs('inv_pairs',[small[1]],'COMBO','ONEINV',blocks=2)
if mode=='invbounds':
 items=[(f'one_{r}_{d}',r,d,'float32') for r,d in [(2,64),(7,64),(7,65),(7,127),(7,128),(7,193),(7,197),(7,255),(7,256),(7,511),(7,512),(7,513),(39,197),(40,197),(41,197)]]
 check('inv_boundary',items+small,['COMBO','ONEINV'])
if mode=='invspecial':
 for d in [64,197,512]:
  for pattern in ['zeros','cancel','checkerboard','wide_range','specials','tail_impulse']:
   cid=f'one_special_{d}_{pattern}';case(cid,7,d,'float32',pattern)
   check('inv_special_'+cid,[(cid,7,d,'float32')],['COMBO','ONEINV'])

if mode=='halfquick':
 check('half_check',[small[3]],['COMBO','HALFSTATIC'])
 pairs('half_pairs',[small[3]],'COMBO','HALFSTATIC',blocks=2)
if mode=='halfbounds':
 items=[(f'half_{r}_{d}',r,d,'float16') for r,d in [(159,193),(160,193),(161,193),(767,64),(767,65),(767,127),(767,128),(767,129),(767,191),(767,192),(767,193),(767,255),(767,256),(767,257),(1279,193),(1280,193),(1281,193)]]
 check('half_boundary',items+small,['COMBO','HALFSTATIC'])
if mode=='halfspecial':
 for d in [64,193,256]:
  for pattern in ['zeros','cancel','checkerboard','wide_range','specials','tail_impulse']:
   cid=f'half_special_{d}_{pattern}';case(cid,767,d,'float16',pattern)
   check('half_special_'+cid,[(cid,767,d,'float16')],['COMBO','HALFSTATIC'])
