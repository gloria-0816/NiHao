#!/usr/bin/env python3
"""Package only cloud benchmark source and the immutable baseline kernel."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import tempfile
import zipfile


BASELINE_REL = "snapshots/addrmsnormbias_submission_681290/code/kernel.asc"
BASELINE_SHA256 = "5e48f7f6c505f140e0e9ead0ac90457600323a21e55e182e560142f55dd447e3"
ARCHIVE_ROOT = "huawei-CANN/"
MANIFEST_MEMBER = ARCHIVE_ROOT + "cloud_bench_bundle_manifest.json"
EXCLUDED_DIRS = {"build", "results", "__pycache__", ".git", ".venv", "venv", "node_modules"}
SOURCE_EXTENSIONS = {".asc", ".cpp", ".h", ".hpp", ".json", ".md", ".sh", ".py"}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(value: dict) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def collect_sources(repo_root: Path) -> dict[str, bytes]:
    bench_root = repo_root / "cloud_bench"
    if not bench_root.is_dir():
        raise FileNotFoundError(f"Missing cloud benchmark directory: {bench_root}")
    sources: dict[str, bytes] = {}
    for directory, dirs, files in os.walk(bench_root, followlinks=False):
        dirs[:] = sorted(name for name in dirs if name not in EXCLUDED_DIRS and not name.startswith("build"))
        for name in sorted(files):
            path = Path(directory) / name
            if name != "CMakeLists.txt" and path.suffix.lower() not in SOURCE_EXTENSIONS:
                continue
            if path.is_symlink():
                raise ValueError(f"Symlink source is not allowed: {path}")
            resolved = path.resolve(strict=True)
            resolved.relative_to(repo_root)
            relative = path.relative_to(repo_root).as_posix()
            sources[relative] = path.read_bytes()
    for relative in ("docs/cloud_harness_design.md", BASELINE_REL):
        path = repo_root / relative
        if path.is_symlink():
            raise ValueError(f"Symlink source is not allowed: {path}")
        path.resolve(strict=True).relative_to(repo_root)
        sources[relative] = path.read_bytes()
    baseline_actual = sha256(sources[BASELINE_REL])
    if baseline_actual != BASELINE_SHA256:
        raise ValueError(f"Baseline kernel changed: expected {BASELINE_SHA256}, got {baseline_actual}")
    return dict(sorted(sources.items()))


def archive_info(name: str, executable: bool = False) -> zipfile.ZipInfo:
    # Fixed metadata makes identical sources produce a deterministic archive.
    info = zipfile.ZipInfo(name, date_time=(2026, 10, 9, 0, 0, 0))
    info.create_system = 3
    info.external_attr = ((0o100755 if executable else 0o100644) << 16)
    info.compress_type = zipfile.ZIP_DEFLATED
    return info


def verify_archive(path: Path, repo_root: Path, expected_manifest: dict, manifest_data: bytes) -> None:
    records = expected_manifest["files"]
    expected_names = {ARCHIVE_ROOT + record["path"] for record in records} | {MANIFEST_MEMBER}
    with zipfile.ZipFile(path, "r") as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or set(names) != expected_names:
            raise ValueError("Archive contains duplicate, missing, or unexpected members")
        bad_member = archive.testzip()
        if bad_member is not None:
            raise ValueError(f"ZIP CRC verification failed: {bad_member}")
        if archive.read(MANIFEST_MEMBER) != manifest_data:
            raise ValueError("Archive manifest differs from the prepared manifest")
        for record in records:
            relative = record["path"]
            payload = archive.read(ARCHIVE_ROOT + relative)
            if len(payload) != record["bytes"] or sha256(payload) != record["sha256"]:
                raise ValueError(f"Archive size/SHA mismatch: {relative}")
            original = (repo_root / relative).read_bytes()
            if original != payload:
                raise ValueError(f"Source changed during packaging or archive mismatch: {relative}")
        if sha256(archive.read(ARCHIVE_ROOT + BASELINE_REL)) != BASELINE_SHA256:
            raise ValueError("Archived baseline kernel SHA mismatch")


def prepare_bundle(repo_root: Path, output: Path) -> dict:
    repo_root = repo_root.resolve(strict=True)
    output = output.resolve()
    # The default and custom output must remain in this project's packages directory.
    packages_root = (repo_root / "packages").resolve()
    output.relative_to(packages_root)
    if output.suffix.lower() != ".zip":
        raise ValueError("Output must have a .zip extension")
    output.parent.mkdir(parents=True, exist_ok=True)
    sources = collect_sources(repo_root)
    records = [
        {"path": relative, "bytes": len(data), "sha256": sha256(data)}
        for relative, data in sources.items()
    ]
    manifest = {
        "schema_version": 1,
        "purpose": "A2 cloud benchmark source; no NPU build or execution result is implied",
        "archive_root": ARCHIVE_ROOT,
        "baseline_path": BASELINE_REL,
        "baseline_sha256": BASELINE_SHA256,
        "file_count": len(records),
        "uncompressed_source_bytes": sum(record["bytes"] for record in records),
        "files": records,
        "manifest_self_hash": "excluded to avoid a recursive hash dependency",
    }
    manifest_data = json_bytes(manifest)
    handle, temp_name = tempfile.mkstemp(prefix=".cloud_bundle_", suffix=".zip", dir=output.parent)
    os.close(handle)
    temporary = Path(temp_name)
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for relative, data in sources.items():
                archive.writestr(archive_info(ARCHIVE_ROOT + relative, relative.endswith(".sh")), data)
            archive.writestr(archive_info(MANIFEST_MEMBER), manifest_data)
        verify_archive(temporary, repo_root, manifest, manifest_data)
        os.replace(temporary, output)
    finally:
        if temporary.exists():
            temporary.unlink()
    # The manifest is also available without extracting the ZIP.
    sidecar = output.with_suffix(".manifest.json")
    sidecar.write_bytes(manifest_data)
    verify_archive(output, repo_root, manifest, manifest_data)
    return {
        "archive": str(output),
        "archive_bytes": output.stat().st_size,
        "archive_sha256": sha256(output.read_bytes()),
        "manifest": str(sidecar),
        "source_file_count": len(records),
        "zip_member_count": len(records) + 1,
        "baseline_sha256": BASELINE_SHA256,
        "verification": "CRC, member inventory, all source bytes/SHA256, and baseline SHA256 matched",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    output = args.output or args.repo_root / "packages/cloud_bench_A2_20261009.zip"
    print(json.dumps(prepare_bundle(args.repo_root, output), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
