#!/usr/bin/env python3
"""CPU-only exporter checks using report fixtures explicitly marked unexecuted.

This test never launches an NPU kernel and fabricates no successful NPU result.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

import export_evidence as exporter


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path)
    parser.add_argument("--tmp-root", type=Path, default=Path(__file__).resolve().parent / "results")
    args = parser.parse_args(argv)
    args.tmp_root = args.tmp_root.expanduser().resolve()
    args.tmp_root.mkdir(parents=True, exist_ok=True)
    checks = []

    def check(label, action):
        try:
            action()
            checks.append({"check": label, "status": "check_passed"})
        except Exception as exc:
            checks.append({"check": label, "status": "check_failed", "error": f"{type(exc).__name__}: {exc}"})

    def rejected(action):
        try:
            action()
        except (exporter.ExportError, OSError, ValueError, zipfile.BadZipFile):
            return
        raise AssertionError("unsafe/incomplete input was accepted")

    with tempfile.TemporaryDirectory(prefix="export-selftest-", dir=args.tmp_root) as temporary:
        workspace = Path(temporary).resolve()
        if workspace.parent != args.tmp_root or not workspace.name.startswith("export-selftest-"):
            raise RuntimeError("temporary workspace escaped its intended root")
        suite = workspace / "suite"
        suite.mkdir()
        summary = {"schema_version": 1, "status": "planned", "run_id": "CPU-export-fixture",
                   "dry_run": True, "executed_cases": 0, "source": "exporter fixture; no NPU execution"}
        (suite / "summary.json").write_text(json.dumps(summary), encoding="utf-8")
        (suite / "run_meta.json").write_text(json.dumps({"run_id": summary["run_id"], "dry_run": True}), encoding="utf-8")
        (suite / "results.jsonl").write_text('{"status":"planned","executed":false}\n', encoding="utf-8")
        (suite / "results.csv").write_text("case_id,status\nCPU_fixture,planned\n", encoding="utf-8")
        nested = suite / "data/CPU_fixture"
        nested.mkdir(parents=True)
        (nested / "meta.json").write_text('{"source":"CPU fixture","executed":false}', encoding="utf-8")
        (nested / "tensor.bin").write_bytes(b"excluded fixture, not an NPU tensor")
        (suite / "data.npz").write_bytes(b"excluded fixture")
        (suite / "runner.exe").write_bytes(b"MZexcluded executable fixture")
        (suite / "renamed_binary.log").write_bytes(b"\x7fELFexcluded executable fixture")
        ssh = suite / ".ssh"
        ssh.mkdir()
        # This is an isolated fixture; the exporter must not read this subtree.
        (ssh / "fixture.txt").write_text("must never be exported", encoding="utf-8")
        profile = workspace / "profile"
        profile.mkdir()
        (profile / "notes.md").write_text("CPU exporter fixture; profiler not run", encoding="utf-8")
        (profile / "report.txt").write_text("no NPU performance measurements", encoding="utf-8")
        extra1, extra2 = workspace / "one/notes.log", workspace / "two/notes.log"
        for number, path in enumerate((extra1, extra2)):
            path.parent.mkdir()
            path.write_text(f"CPU fixture {number}", encoding="utf-8")
        output = workspace / "evidence.zip"
        before = {str(path): exporter.sha256_file(path)
                  for path in (suite / "summary.json", suite / "results.csv", extra1, extra2)}

        def successful_roundtrip():
            result = exporter.export([suite], [profile], [extra1, extra2], output)
            assert result["status"] == "exported_and_verified" and not result["source_files_deleted"]
            assert result["zip_sha256"] == exporter.sha256_file(output)
            with zipfile.ZipFile(output) as archive:
                assert archive.testzip() is None
                manifest_raw = archive.read("manifest.json")
                assert hashlib.sha256(manifest_raw).hexdigest() == result["manifest_sha256"]
                manifest = json.loads(manifest_raw)
                names = set(archive.namelist())
                assert "suite_0/data/CPU_fixture/meta.json" in names
                assert "profile_0/notes.md" in names
                assert "extra/file_0/notes.log" in names and "extra/file_1/notes.log" in names
                assert not any(".ssh/" in name or name.endswith((".bin", ".npz", ".exe")) for name in names)
                assert "suite_0/renamed_binary.log" not in names
                for record in manifest["files"]:
                    content = archive.read(record["archive_path"])
                    assert len(content) == record["bytes"]
                    assert hashlib.sha256(content).hexdigest() == record["sha256"]
                assert next(root for root in manifest["input_roots"] if root["role"] == "suite_0")["summary_status"] == "planned"
                assert "completion not asserted" in next(root for root in manifest["input_roots"] if root["role"] == "profile_0")["completeness"]
            assert all(exporter.sha256_file(path) == digest for path, digest in before.items())

        def cli_roundtrip():
            destination = workspace / "cli.zip"
            child = subprocess.run([sys.executable, str(Path(exporter.__file__)), "--suite-dir", str(suite),
                                    "--profile-dir", str(profile), "--extra-file", str(extra1),
                                    "--extra-file", str(extra2), "--output", str(destination)],
                                   capture_output=True, text=True, timeout=30)
            assert child.returncode == 0, child.stderr
            assert json.loads(child.stdout)["status"] == "exported_and_verified"

        def incomplete_suites():
            missing = workspace / "missing"
            missing.mkdir()
            rejected(lambda: exporter.export([missing], [], [], workspace / "missing.zip"))
            active = workspace / "active"
            active.mkdir()
            (active / "summary.json").write_text('{"status":"running"}', encoding="utf-8")
            rejected(lambda: exporter.export([active], [], [], workspace / "active.zip"))
            (active / "summary.json").write_text('{"status":"planned","run_id":"old"}', encoding="utf-8")
            (active / "run_meta.json").write_text('{"run_id":"new"}', encoding="utf-8")
            rejected(lambda: exporter.export([active], [], [], workspace / "stale.zip"))

        def unsafe_scope():
            rejected(lambda: exporter.inspect_path(Path.home(), "directory"))
            rejected(lambda: exporter.inspect_path(Path(Path.home().anchor), "directory"))
            rejected(lambda: exporter.export([], [], [ssh / "fixture.txt"], workspace / "ssh.zip"))
            rejected(lambda: exporter.export([], [], [], workspace / "empty.zip"))
            rejected(lambda: exporter.export([suite], [], [], workspace / "not-a-zip.json"))

        def changed_source():
            destination = workspace / "preserve.zip"
            destination.write_bytes(b"old output must remain on export failure")
            writer = workspace / "writing"
            writer.mkdir()
            target = writer / "report.log"
            target.write_text("initial CPU-only fixture", encoding="utf-8")
            original = exporter.copy_payload
            def copying_with_writer(archive, item):
                value = original(archive, item)
                with item["path"].open("a", encoding="utf-8") as handle:
                    handle.write("\nwriter changed this file")
                return value
            try:
                exporter.copy_payload = copying_with_writer
                rejected(lambda: exporter.export([], [writer], [], destination))
            finally:
                exporter.copy_payload = original
            assert destination.read_bytes() == b"old output must remain on export failure"
            assert target.exists()
            assert not list(workspace.glob(".preserve.zip-*.tmp"))

        def sha_rejection():
            wrong = workspace / "wrong-sha.zip"
            manifest = b"{}"
            with zipfile.ZipFile(wrong, "w") as archive:
                archive.writestr("profile_0/report.txt", b"actual generic fixture")
                archive.writestr("manifest.json", manifest)
            wanted = [{"archive_path": "profile_0/report.txt", "bytes": len(b"actual generic fixture"),
                       "sha256": hashlib.sha256(b"different generic fixture").hexdigest()}]
            rejected(lambda: exporter.verify_zip(wrong, wanted, manifest))

        check("CRC/SHA roundtrip, role paths, exclusions and unchanged sources", successful_roundtrip)
        check("real CLI with repeated extra arguments", cli_roundtrip)
        check("missing/running/stale suite summary rejected", incomplete_suites)
        check("home/filesystem/SSH scope and invalid output rejected", unsafe_scope)
        check("concurrent write fails without deleting source or replacing old ZIP", changed_source)
        check("SHA mismatch rejected even when ZIP CRC is valid", sha_rejection)

    result = {"schema_version": 1, "status": "checks_passed" if all(item["status"] == "check_passed" for item in checks) else "checks_failed",
              "npu_kernel_executions": 0, "npu_precision_pass_claimed": False,
              "source": "CPU-only exporter fixtures explicitly unexecuted; no NPU timing data", "checks": checks}
    if args.report:
        args.report = args.report.expanduser().resolve()
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "checks_passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
