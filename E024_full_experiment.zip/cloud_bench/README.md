# AddRmsNormBias 云端自测

本目录提供独立执行器、代表性测试矩阵和批量精度/性能报告。测试矩阵是我们依据公开范围构造的用例，**不是官方 15 个隐藏测试点的复现**。当前基线为官方提交 **681290，52.58 分，Pass 15/15**，内核 SHA256 为 `5e48f7f6c505f140e0e9ead0ac90457600323a21e55e182e560142f55dd447e3`。

2026-10-09 已在用户的 A2 云机上完成首次真实编译，并通过公开模板 `[1,64] / FP16` 的逐元素校验。芯片实测为 910B3，ACL 查询 40 个向量核，CANN 安装元数据为 9.0.0。其他自建矩阵的通过范围以各次运行报告为准；官方分数以 CANNJudge 为准。

## 环境与首次运行

在用户已启动的 NPU A2 环境中，将仓库放在 `/mnt/workspace`。先加载实际安装的 CANN 环境，再采集设备与工具版本：

```sh
cd /mnt/workspace/addrms_cloudbench/huawei-CANN
export ASCEND_HOME_PATH=/home/developer/Ascend/cann-9.0.0
source "${ASCEND_HOME_PATH}/set_env.sh"
bash cloud_bench/collect_env.sh /mnt/workspace/addrms_env.txt
python3 cloud_bench/scripts/selftest.py
python3 cloud_bench/selftest_suite.py \
  --report /mnt/workspace/addrms_results/selftest_suite.json
bash cloud_bench/build.sh
```

`collect_env.sh` 只采集 OS、NPU 信息、选定工具路径/版本及三个 CANN 路径变量；不会导出完整环境变量、密码、令牌或 SSH 密钥。以报告核实实际芯片、驱动、CANN 和可用向量核数量。构建默认架构为 `dav-2201`，须与实际设备核对；A2 名称本身不能证明与评测机器的所有配置相同。构建支持 `NPU_ARCH`、`KERNEL_SOURCE`、`BUILD_DIR`、`BUILD_JOBS` 环境变量，详细行为以 `build.sh` 为准。

`selftest_suite.py` 在独占的临时目录中复查 dry-run、缺失 runner、真实 Python 子进程非零退出/超时、partial 文件与缺失输出、正则选择和错误 JSON；结束后清理该临时目录。它不执行 NPU kernel，不构造成功 NPU 结果。`--report` 可保留这份 CPU 编排检查证据。

先运行公开模板一个用例，再扩展 smoke：

```sh
python3 cloud_bench/run_suite.py \
  --manifest cloud_bench/cases/smoke.json \
  --case-regex '^public_template_fp16_1x64$' \
  --run-dir /mnt/workspace/addrms_results/template_baseline \
  --environment-report /mnt/workspace/addrms_env.txt

python3 cloud_bench/run_suite.py \
  --manifest cloud_bench/cases/smoke.json \
  --run-dir /mnt/workspace/addrms_results/smoke_baseline \
  --device 0 --warmup 10 --repeats 7 --batch 100 --timing both
```

每个用例依次生成数据、启动一个独立进程、逐元素校验、校验性能报告元信息，失败后继续收集其余用例。最终退出码：0 表示全部选择用例通过（或仅计划成功）；1 表示存在执行/精度/报告失败；2 表示配置或报告 IO 错误。`--dry-run` 的状态固定为 `planned`、通过数量为 0，不生成张量、不启动 NPU、不记为精度通过。

```sh
python3 cloud_bench/run_suite.py --dry-run --limit 5 \
  --run-dir /mnt/workspace/addrms_results/plan
```

## 选择用例和控制资源

`--case-regex` 使用 Python 正则搜索用例 ID；`--limit N` 在筛选后取前 N 个。不同清单可独立运行：

```sh
python3 cloud_bench/run_suite.py \
  --manifest cloud_bench/cases/correctness.json \
  --run-dir /mnt/workspace/addrms_results/correctness_baseline \
  --warmup 0 --repeats 1 --batch 1 --timing host

python3 cloud_bench/run_suite.py \
  --manifest cloud_bench/cases/stress.json \
  --run-dir /mnt/workspace/addrms_results/stress_baseline \
  --discard-case-data --batch 10 --timeout-s 600
```

stress 最大单张量为 256 MiB，但输入、多个 golden 和输出合计远大于这个值。`--discard-case-data` 在每个用例结束后仅删除已知二进制数据文件，保留元数据、日志、校验与性能报告，避免全部 stress 数据累积；删除后需要重新生成数据才能复查输出。默认保留所有数据。

`--max-tensor-mib` 默认 256 限制单 tensor 文件；`--max-work-mib` 默认 128 控制 Python 临时数组预算；`--chunk-rows` 默认 256。`--max-device-bytes` 默认 2147483648 限制 runner 设备缓冲区总量，runner 还检查实际可用 HBM。`--timeout-ms` 默认 30000 是每次流同步上限；`--timeout-s` 默认 180 是完整用例进程的总墙钟上限，大用例或 profiler 运行应相应调整。

runner 记录实测向量核数后，可按该数量生成额外分核边界清单：

```sh
# 将 40 替换为首次 benchmark.json 中的实际 vector_cores。
python3 cloud_bench/scripts/make_matrix.py manifests --vector-cores 40
python3 cloud_bench/run_suite.py \
  --manifest cloud_bench/cases/core_boundaries.json \
  --run-dir /mnt/workspace/addrms_results/core_boundaries_baseline
```

## 精度与报告契约

生成/校验的数学顺序、BF16 编码、随机数、特殊值和误差定义见 [scripts/README.md](scripts/README.md)。suite 始终启用输入/golden 哈希校验，缺失输出、长度不符、有限值超差或 NaN/Inf 类别不符均失败。每个用例运行前删除该目录内旧 `output.bin`、`benchmark.json`、校验报告和 runner 日志。进程超时或非零退出时不会读取其输出或 benchmark，避免将旧文件误记作本次通过。

报告包含：

- `run_meta.json`：源码与 runner 二进制 SHA256、清单 SHA256、选择的用例、Python/NumPy 版本、计时参数，可选环境报告的路径与 SHA256。
- `results.jsonl`：每用例一条记录，包含完整生成元数据、输入/golden SHA256、精度结果、性能数据及独立状态。
- `results.csv`：适合比较的状态、形状、类型、误差和延迟列；未执行/失败的 timing 保持为空。
- `summary.json`：选择数量、计划/通过/失败数量、状态统计、报告位置。不会计算或伪造官方分数。
- `data/<case_id>/`：本次数据、`runner.stdout.log`/`runner.stderr.log`、`verification.json`、`benchmark.json`。

只有精度通过，且 `benchmark.json` 的内核 SHA、形状、数据类型、epsilon、设备、warmup/repeats/batch/计时方式一致，计时数组完整有效时，suite 才记为 `passed`。进程正常退出的 runner 原始状态是 `executed_not_yet_verified`，不能单独解释为精度通过。

同一 `--run-dir` 再次运行会重写汇总，并重新生成选择用例。建议每个候选和每次复测使用新的目录，便于保留审计证据。

## 计时含义

runner 将数据上传、内存分配、输出下载和 golden 校验放在计时区间之外。预热后，连续向同一流提交 `batch` 次，重复 `repeats` 组，使用同一组缓冲区，缓存状态为 `same_buffers_warm`。

- `host_queued_batch_*_us`：CPU 墙钟从提交这一组开始到流同步结束的时间除以 launch 数量，包含 host 提交、事件记录（启用时）和最终同步。
- `event_queued_batch_*_us`：流中首尾事件的跨度除以 launch 数量，仍可能包含 host 供给不足造成的队列间隙。
- `--timing host` 不创建事件；`both` 与 `event` 都记录事件，runner 同时提供 host 跨度供诊断。

两种跨度都不是 profiler 提取的单个 kernel task 纯执行时长，也不是 CANNJudge 的完整计时协议。尤其微秒级小用例需要结合设备 profiler 判断提交开销；大用例需要关注相同 buffer 的缓存复用。比较候选应使用同一设备、相同清单/随机数和计时参数，并重复基线与候选。官方 15 点仍用于确认最终得分。

suite 另外记录 `runner_process_elapsed_s`（单进程从初始化到退出，含传输与所有重复）、`case_workflow_elapsed_s`（含数据生成与校验），以及两种批量计时的样本数、min/max、IQR、MAD。进程与完整流程的总时间不能作为一次 kernel 的时间。Profiling 运行有额外开销，其 runner host 时间不能与未开启采集的计时直接比较。

从非交互 SSH 运行时，可使用 `ASCEND_HOME_PATH=<实际安装路径> bash cloud_bench/with_cann.sh <命令> <参数>` 加载相同 CANN 环境。研究流程和完整结果记录要求见 [云机实验规范](../docs/云机实验规范.md)。

## 对比候选

候选源码与编译二进制必须对应。更换 `KERNEL_SOURCE` 构建，然后在 suite 指定相同源码：

```sh
KERNEL_SOURCE=/mnt/workspace/candidate/kernel.asc \
  BUILD_DIR=/mnt/workspace/candidate/build bash cloud_bench/build.sh
python3 cloud_bench/run_suite.py \
  --runner /mnt/workspace/candidate/build/cloud_addrmsnormbias \
  --kernel-source /mnt/workspace/candidate/kernel.asc \
  --manifest cloud_bench/cases/smoke.json \
  --run-dir /mnt/workspace/addrms_results/smoke_candidate
```

不要用候选源码的 SHA 给未重编译的基线二进制贴标签；suite 会通过 runner 编译内置的 SHA 拒绝这种不匹配。
