from pathlib import Path
import hashlib,json,shutil
H=Path(__file__).resolve().parent
base=(H/'BASE/code/kernel.asc').read_text(encoding='utf-8')
assert hashlib.sha256(base.encode()).hexdigest()=='bc62917a0b4e5a6155b188e5f829f32590832ba1e06345deb50564beacef356b'
kernel=(H/'float_resident.inc').read_text(encoding='utf-8')
anchor='class FloatBroadTripleKernel {'
code=base.replace(anchor,kernel+'\n'+anchor)
anchor='    if(input.dtype==1 && d>8192 && d<=32768) {'
guard='''    if(input.dtype==0 && d>4096 && d<=8192) {
        float_resident8_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert code.count(anchor)==1
code=code.replace(anchor,guard+anchor)
dest=H/'FRES8/code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'FRES8/manifest.json').write_text(json.dumps(dict(variant='FRES8',parent='FACC',source_sha256=hashlib.sha256(code.encode()).hexdigest(),numerical_change=True,change='FP32 D4097..8192 static resident rows with cached parameters, two X/output slots and one residual/square tile; two-level block reduction and FP32 affine FMA',ub_end_bytes=169248),indent=2)+'\n')
driver=H/'run_round.py';text=driver.read_text(encoding='utf-8')
if "if mode=='fres8':" not in text:
 text+='''
if mode=='fres8':
 items=[(f'e027_fres_{r}_{d}',r,d,'float32') for r,d in [(1,4097),(7,4097),(81,5001),(161,6144),(161,8191),(128,8192),(17,4096)]]
 check('fres8_check',items,['BASE','FRES8'])
 edges=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_fres_edge_'+pattern;case(cid,81,5001,'float32',pattern);edges.append((cid,81,5001,'float32'))
 check('fres8_edge_check',edges,['BASE','FRES8'])
 pairs('fres8_pairs',[(f'e027_fres_perf_{r}_{d}',r,d,'float32') for r,d in [(1024,4097),(1024,8192)]],'BASE','FRES8',blocks=2)
'''
 driver.write_text(text,encoding='utf-8',newline='\n')
print(hashlib.sha256(code.encode()).hexdigest())
