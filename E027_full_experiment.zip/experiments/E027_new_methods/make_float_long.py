from pathlib import Path
import hashlib,json,shutil
H=Path(__file__).resolve().parent
base=(H/'BASE/code/kernel.asc').read_text(encoding='utf-8')
assert hashlib.sha256(base.encode()).hexdigest()=='bc62917a0b4e5a6155b188e5f829f32590832ba1e06345deb50564beacef356b'
kernel=(H/'float_resident_long.inc').read_text(encoding='utf-8')
anchor='class FloatBroadTripleKernel {'
code=base.replace(anchor,kernel+'\n'+anchor)
anchor='    if(input.dtype==1 && d>8192 && d<=32768) {'
guard='''    if(input.dtype==0 && d>8192 && d<=32768) {
        float_resident_long_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert code.count(anchor)==1
code=code.replace(anchor,guard+anchor)
dest=H/'FRESLONG/code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'FRESLONG/manifest.json').write_text(json.dumps(dict(variant='FRESLONG',parent='FACC',source_sha256=hashlib.sha256(code.encode()).hexdigest(),numerical_change=True,change='FP32 D8193..32768 static retained residual row, direct DMA into final Y, paired residual/square slots and streamed affine FMA; remove TPipe queues and raw-X/cast copies',ub_end_bytes=168992),indent=2)+'\n')
driver=H/'run_round.py';text=driver.read_text(encoding='utf-8')
if "if mode=='freslong':" not in text:
 text+='''
if mode=='freslong':
 items=[(f'e027_flong_{r}_{d}',r,d,'float32') for r,d in [(1,8193),(7,16383),(81,16384),(81,24575),(161,32767),(128,32768),(17,8192)]]
 check('freslong_check',items,['BASE','FRESLONG'])
 edges=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_flong_edge_'+pattern;case(cid,81,16383,'float32',pattern);edges.append((cid,81,16383,'float32'))
 check('freslong_edge_check',edges,['BASE','FRESLONG'])
 pairs('freslong_pairs',[(f'e027_flong_perf_{r}_{d}',r,d,'float32') for r,d in [(1024,16384),(1024,32768)]],'BASE','FRESLONG',blocks=2)
'''
 driver.write_text(text,encoding='utf-8',newline='\n')
print(hashlib.sha256(code.encode()).hexdigest())
