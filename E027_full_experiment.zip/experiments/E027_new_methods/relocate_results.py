from pathlib import Path
import hashlib, json, os, shutil, time

source=Path('/mnt/workspace/addrms_results/E027')
target=Path('/home/developer/addrms_experiments/E027')
assert source.resolve()==source and source.is_dir()
assert str(target.resolve())=='/home/developer/addrms_experiments/E027'
assert not target.exists(), 'Target already exists; inspect previous migration before retrying'
target.parent.mkdir(exist_ok=True)
copies={}
def preserve_links(src,dst):
    st=os.stat(src)
    key=(st.st_dev,st.st_ino)
    if key in copies:
        os.link(copies[key],dst)
    else:
        shutil.copy2(src,dst)
        copies[key]=dst
    return dst
print('copying current experiment results, preserving input hardlinks',flush=True)
shutil.copytree(source,target,symlinks=True,copy_function=preserve_links)
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8<<20),b''):h.update(b)
    return h.hexdigest()
seen=set();files=0
for p in source.rglob('*'):
    if not p.is_file() or p.is_symlink():continue
    q=target/p.relative_to(source)
    st=p.stat();key=(st.st_dev,st.st_ino)
    assert st.st_size==q.stat().st_size
    if key not in seen:
        assert digest(p)==digest(q),str(p)
        seen.add(key)
    files+=1
print('all copied files verified',files,'unique files',len(seen),flush=True)
# Remove only the verified original location of this newly created experiment.
# Existing E021/E023/E026 input data and results are outside this directory.
shutil.rmtree(source)
incomplete=target/'incomplete_attempts';incomplete.mkdir(exist_ok=True)
rescued=[]
for d in list((target/'tree_pairs').iterdir()):
    if not d.is_dir():continue
    p=d/'record.json'
    try:rec=json.loads(p.read_text())
    except Exception:rec={}
    if 'median_us' not in rec:
        dest=incomplete/(d.name+'_'+str(int(time.time())))
        d.rename(dest);rescued.append(str(dest))
record=dict(old_directory=str(source),new_directory=str(target),verified_files=files,
            unique_verified_files=len(seen),preserved_input_hardlinks=True,
            incomplete_attempts_preserved=rescued,free_bytes=shutil.disk_usage(target).free)
(target/'relocation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
