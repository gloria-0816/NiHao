from pathlib import Path
import hashlib,json,shutil
H=Path(__file__).resolve().parent
base=(H/'FRESLONG/code/kernel.asc').read_text(encoding='utf-8')
hv=(H/'HVAR128/code/kernel.asc').read_text(encoding='utf-8')
a=hv.index('class PipelineBatch9Kernel {');z=hv.index('template <typename T,bool BlockReduction>\n__global__',a)
s=hv[a:z].replace('class PipelineBatch9Kernel {','class FastHalfVarianceKernel {\n    using T=half;')
p=s.index('    __aicore__ inline void Process()');e=s.index('\nprivate:',p)
process='''    __aicore__ inline void Process() {
        DataCopyExtParams parameter={1,d_*2,0,0,0};DataCopyPadExtParams<half> pad={};pad.isPad=false;
        DataCopyPad(gh_,ggm_,parameter,pad);DataCopyPad(bh_,bgm_,parameter,pad);
        Prefetch(begin_,0);if(begin_+batch_<end_)Prefetch(begin_+batch_,1);
        bool pending=false;uint32_t slot=0;
        for(uint64_t row=begin_;row<end_;row+=batch_,slot^=1) {
            const uint32_t count=Min(batch_,static_cast<uint32_t>(end_-row)),active=count*stride_;
            WaitFlag<HardEvent::MTE2_V>(slot);
            Add(x_[slot],x_[slot],r_[slot],active);PipeBarrier<PIPE_V>();
            if(d_!=stride_) {
                const uint32_t tail=d_%128;
                uint64_t mask[2]={tail<64?~static_cast<uint64_t>(0)<<tail:0,
                    tail<64?~static_cast<uint64_t>(0):~static_cast<uint64_t>(0)<<(tail-64)};
                Duplicate(x_[slot][d_/128*128],static_cast<half>(0.0f),mask,count,1,stride_/16);PipeBarrier<PIPE_V>();
            }
            TryHalfNorm(x_[slot],count,active);
            // Detect half-square/reduction overflow from the actual partial sums.
            // Unlike a separate Abs pass, this reuses values already computed.
            WholeReduceMax(work_[1536],sums_,count,1,1,1,8);
            SetFlag<HardEvent::V_S>(3);WaitFlag<HardEvent::V_S>(3);
            const float largest=work_.GetValue(1536);
            if(!(largest<=3.402823466e38f)) {
                Cast(y_,x_[slot],RoundMode::CAST_NONE,active);PipeBarrier<PIPE_V>();
                Mul(tmp_,y_,y_,active);PipeBarrier<PIPE_V>();
                BlockReduceSum(work_,tmp_,active/64,64,1,1,8);PipeBarrier<PIPE_V>();
                const uint32_t parts=stride_/64,partialRow=stride_/8;
                if(partialRow>64) {
                    const uint8_t step=static_cast<uint8_t>(parts);
                    Add(work_,work_,work_[64],partialRow-64,count,{1,1,1,step,step,step});PipeBarrier<PIPE_V>();
                }
                WholeReduceSum(sums_,work_,Min(64,partialRow),count,1,1,parts);PipeBarrier<PIPE_V>();
            }
            Muls(sums_,sums_,invD_,count);PipeBarrier<PIPE_V>();
            Adds(sums_,sums_,eps_,count);PipeBarrier<PIPE_V>();
            Sqrt(sums_,sums_,count);Duplicate(work_,1.0f,count);PipeBarrier<PIPE_V>();
            Div(sums_,work_,sums_,count);PipeBarrier<PIPE_V>();
            auto scales=work_[1536].ReinterpretCast<half>();auto broadcast=work_.ReinterpretCast<half>();
            Cast(scales,sums_,RoundMode::CAST_RINT,count);PipeBarrier<PIPE_V>();
            Brcb(broadcast,scales,(count+7)/8,{1,8});PipeBarrier<PIPE_V>();
            if(pending)WaitFlag<HardEvent::MTE3_V>(3);
            const uint8_t step=static_cast<uint8_t>(stride_/16);
            for(uint32_t col=0;col<d_;col+=128)
                Mul(out_[col],x_[slot][col],broadcast,Min(128,d_-col),count,{1,1,0,step,step,1});
            PipeBarrier<PIPE_V>();
            // This is the last read of the retained half residual.
            if(row+2*batch_<end_) {
                SetFlag<HardEvent::V_MTE2>(slot);WaitFlag<HardEvent::V_MTE2>(slot);Prefetch(row+2*batch_,slot);
            }
            for(uint32_t col=0;col<d_;col+=128)
                FusedMulAdd(out_[col],gh_[col],bh_[col],Min(128,d_-col),count,{1,1,1,step,0,0});
            PipeBarrier<PIPE_V>();
            SetFlag<HardEvent::V_MTE3>(2);WaitFlag<HardEvent::V_MTE3>(2);
            DataCopyExtParams output={static_cast<uint16_t>(count),d_*2,Gap(),0,0};DataCopyPad(outgm_[row*d_],out_,output);
            SetFlag<HardEvent::MTE3_V>(3);pending=true;
        }
        if(pending)WaitFlag<HardEvent::MTE3_V>(3);
    }
'''
s=s[:p]+process+s[e:]
a=s.index('        Abs(squared,input,active);');z=s.index('        Mul(squared,input,input,active);',a)
s=s[:a]+s[z:]
s=s.replace('''        // Each 128-element sum is at most 32768 when |residual| <=16.
        // Wider or nonfinite input uses the original full FP32 square/reduction.
''','''        // Native half partials are merged in FP32. Overflow is detected by
        // the caller after this merge and uses an FP32 recomputation.
''')
wrapper='''__global__ __vector__ void fast_half_variance_custom(GM_ADDR x,GM_ADDR r,GM_ADDR g,GM_ADDR b,GM_ADDR out,
    uint64_t rows,uint32_t d,float invD,float eps) {
    InitSocState();FastHalfVarianceKernel op;op.Init(x,r,g,b,out,rows,d,invD,eps);op.Process();
}
'''
anchor='template <typename T, bool BlockReduction>\nclass PipelineBatch9Kernel {'
assert base.count(anchor)==1;code=base.replace(anchor,s+wrapper+'\n'+anchor)
anchor='    if(input.dtype==1 && d>1024 && d<=4096'
guard='''    if(input.dtype==1 && d>=321 && d<=1024 && rows>=static_cast<uint64_t>(blockNum)*4) {
        fast_half_variance_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert code.count(anchor)==1;code=code.replace(anchor,guard+anchor)
dest=H/'HFAST128/code';shutil.copytree(H/'FRESLONG/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'HFAST128/manifest.json').write_text(json.dumps(dict(variant='HFAST128',parent='FRESLONG',source_sha256=hashlib.sha256(code.encode()).hexdigest(),numerical_change=True,change='Retain native FP16 residual and use half square/128 partial sums with FP32 merge, native half scale/affine and no full FP32 residual/output conversion; detect variance overflow from merged partials and recompute in FP32; explicit 128-lane padding before norm'),indent=2)+'\n')
driver=H/'run_round.py';text=driver.read_text(encoding='utf-8')
if "if mode=='hfast':" not in text:
 text+='''
if mode=='hfast':
 items=[small[i] for i in [5,6,7,9]]+[(f'e027_hv_{r}_{d}',r,d,'float16') for r,d in [(161,321),(161,383),(161,397),(161,512),(161,577),(161,1023),(159,577)]]
 check('hfast_check',items,['BASE','HFAST128'])
 edges=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_hv_edge_'+pattern;case(cid,161,577,'float16',pattern);edges.append((cid,161,577,'float16'))
 check('hfast_edge_check',edges,['BASE','HFAST128'])
 pairs('hfast_pairs',[small[i] for i in [5,6,7,9]],'BASE','HFAST128',blocks=1)
'''
 driver.write_text(text,encoding='utf-8',newline='\n')
print(hashlib.sha256(code.encode()).hexdigest())
