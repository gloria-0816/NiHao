from pathlib import Path
import hashlib,json,shutil
H=Path(__file__).resolve().parent
base=(H/'BASE/code/kernel.asc').read_text(encoding='utf-8')
assert hashlib.sha256(base.encode()).hexdigest()=='bc62917a0b4e5a6155b188e5f829f32590832ba1e06345deb50564beacef356b'
code=base
sections=[('single_row_64_custom(', 'single_row_custom('),('class SingleRowStaticKernel {','class SmallRowsStaticKernel {'),('class SmallRowsStaticKernel {','class WholeRowsStaticDoubleBufferKernel {'),('class ShortFloatPartitionKernel {','class TinyBatchFloatKernel {')]
for start, end in sections:
    a=code.index(start);z=code.index(end,a+len(start))
    s=code[a:z]
    s=s.replace('Sqrt(sum, sum, 1);','Rsqrt(sum, sum, 1);').replace('Sqrt(sum_, sum_, 1);','Rsqrt(sum_, sum_, 1);')
    s=s.replace('Div(y, y, work,','Mul(y, y, work,').replace('Div(y_, y_, work_,','Mul(y_, y_, work_,')
    if start=='class ShortFloatPartitionKernel {':
        old='''        Sqrt(sums_, sums_, count_);
        Duplicate(work_, 1.0f, count_);
        PipeBarrier<PIPE_V>();
        Div(sums_, work_, sums_, count_);'''
        assert old in s
        s=s.replace(old,'        Rsqrt(sums_, sums_, count_);')
    assert s!=code[a:z]
    code=code[:a]+s+code[z:]
dest=H/'RSMALL/code'
shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'RSMALL/manifest.json').write_text(json.dumps(dict(variant='RSMALL',parent='FACC',source_sha256=hashlib.sha256(code.encode()).hexdigest(),numerical_change=True,change='Reciprocal-square-root plus multiplication only for existing small-row and short-FP32 partitions; keep wide and BF16 streaming routes unchanged'),indent=2)+'\n')
driver=H/'run_round.py'
text=driver.read_text(encoding='utf-8')
if "if mode=='rsmall':" not in text:
    text+='''
if mode=='rsmall':
 items=[small[0],small[1],small[2]]+[(f'e027_rs_{r}_{d}_{dt}',r,d,dt) for r,d,dt in [(1,64,'float32'),(1,64,'bfloat16'),(1,197,'float32'),(7,255,'float32'),(128,512,'float32'),(8,4096,'float16')]]
 check('rsmall_check',items,['BASE','RSMALL'])
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_rs_edge_'+pattern;case(cid,7,197,'float32',pattern)
  check('rsmall_edge_check',[(cid,7,197,'float32')],['BASE','RSMALL'])
 pairs('rsmall_pairs',small[:3],'BASE','RSMALL',blocks=2)
'''
    driver.write_text(text,encoding='utf-8',newline='\n')
print(hashlib.sha256(code.encode()).hexdigest())
