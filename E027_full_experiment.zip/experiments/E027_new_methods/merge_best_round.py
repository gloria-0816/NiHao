from pathlib import Path
import hashlib,json,shutil,zipfile
H=Path(__file__).resolve().parent
best=(H/'FRESLONG/code/kernel.asc').read_text(encoding='utf-8')
assert hashlib.sha256(best.encode()).hexdigest()=='d676dd20267c736d2c35d245c043be933a13f84ba0e0fc67d887e30611e66bce'
aff=(H/'AFFEARLY/code/kernel.asc').read_text(encoding='utf-8')
a=aff.index('class FloatBroadTripleKernel {');z=aff.index('template <typename T,bool BlockReduction>',a)
ba=best.index('class FloatBroadTripleKernel {');bz=best.index('template <typename T,bool BlockReduction>',ba)
afflong=best[:ba]+aff[a:z]+best[bz:]
w=best.replace('class FloatBroadTripleKernel {',(H/'float_resident.inc').read_text(encoding='utf-8')+'\nclass FloatBroadTripleKernel {')
guard='''    if(input.dtype==0 && d>1024 && d<=8192 && rows>=static_cast<uint64_t>(blockNum)*4) {
        float_resident8_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
anchor='    if(input.dtype==1 && d>1024 && d<=4096'
assert w.count(anchor)==1;w=w.replace(anchor,guard+anchor)
for name,code,change in [('AFFLONG',afflong,'Preserve official 65.34 FRESLONG and add early gamma scaling to its FP32 wide triple-buffer path'),('FRESWL',w,'Preserve official 65.34 FRESLONG and replace FP32 D1025..8192 multi-row routes with resident parameter and input/output ping-pong pipeline')]:
 dest=H/name/'code';shutil.copytree(H/'FRESLONG/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='FRESLONG',parent_official_score=65.34,source_sha256=hashlib.sha256(code.encode()).hexdigest(),numerical_change=True,change=change),indent=2)+'\n')
 print(name,hashlib.sha256(code.encode()).hexdigest())
with zipfile.ZipFile(H/'BEST_6534_project.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in (H/'FRESLONG/code').rglob('*'):
  if p.is_file():z.write(p,p.relative_to(H/'FRESLONG/code'))
with zipfile.ZipFile(H/'BEST_6534_project.zip') as z:
 assert z.testzip() is None
 assert len(z.namelist())==8
 assert hashlib.sha256(z.read('kernel.asc')).hexdigest()=='d676dd20267c736d2c35d245c043be933a13f84ba0e0fc67d887e30611e66bce'
driver=H/'run_round.py';text=driver.read_text(encoding='utf-8')
if "if mode=='merged':" not in text:
 text+='''
if mode=='merged':
 v=sys.argv[2]
 if v=='AFFLONG':
  items=[small[10],small[12],('e027_flong_81_16384',81,16384,'float32')]
  check('afflong_check',items,['BASE',v])
  pairs('afflong_pairs',[small[10],small[12]],'BASE',v,blocks=1)
 else:
  assert v=='FRESWL'
  items=[small[8],small[10],small[12],('e027_flong_81_16384',81,16384,'float32')]+[(f'e027_fwide_{r}_{d}',r,d,'float32') for r,d in [(161,1025),(161,1537),(161,2048),(161,4096),(159,3079)]]
  check('freswl_check',items,['BASE',v])
  pairs('freswl_pairs',[small[8],small[10],small[12]],'BASE',v,blocks=2)
'''
 driver.write_text(text,encoding='utf-8',newline='\n')
report=H/'README.md';s=report.read_text(encoding='utf-8')
s=s.replace('当前正式评测为 0/10，没有新的比赛分数。','2026-10-13 当前已完成 4/10 次正式评测，最高为 FRESLONG 65.34 分、15/15 Pass。')
s=s.replace('尚未得到官方分数，因此仍保留 FACC 为最佳比赛方案。','DBLOCK 已得到 63.95 分、15/15 Pass。当前最高比赛方案改为 FRESLONG 65.34 分，完整工程为 BEST_6534_project.zip。')
old='当前缺少可操作比赛网页的连接，已请求恢复原浏览器控制或连接 TinyFish。该连接恢复后，优先提交 DBLOCK，记录完整 15 点、源码身份、提交号和实际分数，然后按比赛结果选择下一步。不会用云机提速替代 70 分的达成证据。'
s=s.replace(old,'''## 正式比赛更新，2026-10-13

|次数|候选|提交号|分数|通过|
|---|---|---|---|---|
|1|DBLOCK|768104|63.95|15/15|
|2|CONST|768306|63.52|15/15|
|3|FRES8|768574|64.11|15/15|
|4|FRESLONG|768708|65.34|15/15|

FRES8 的 FP32 D4097..8192 参数常驻、双 X/输出槽和共享 residual/square 静态流水在 1024×4097/8192 云机输入上降低耗时 65.64%/63.01%，12 个尺寸及数值模式全部 strict 通过，但正式评测未显示对应量级的改善。

FRESLONG 将 FP32 D8193..32768 整行残差保留在 UB，X 直接搬入最终 Y，两个 residual/square 槽复用于 gamma/bias，使用静态同步和 FP32 affine FMA。云机 1024×16384/32768 降低 21.50%/12.65%，12 个尺寸及数值模式全部 strict 通过。正式分数 65.34，观察排名 78；TBest 与前一日发生变化，不能把 0.36 分的全部增幅归因于该算法。

RSMALL 仅改变小行归一化为原生 Rsqrt+Mul，s1/s2/s3 云机降低 4.12%/7.60%/1.24%；9 个常规输入中新增 8 个 strict 失败，没有当作正确的最佳方案。仍继续其他方法，未因这一数值问题停止调优。

当前继续在最高完整 FRESLONG 上测试 AFFLONG（提前 gamma 缩放，后续 FMA 融合归一化和 bias）及 FRESWL（将参数常驻双缓冲覆盖 FP32 中宽行）。正式记录和截图在各候选的 official/ 目录。最终停止条件仍为第 10 次结束后最高未超过 70 则停止，否则继续。''')
report.write_text(s,encoding='utf-8',newline='\n')
