"""Archive the ten completed official evaluations without launching more tests."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

H = Path(__file__).resolve().parent
ROOT = H.parents[1]
REPO = Path('F:/算法设计/CANN_HuaiWei')

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save(p, obj):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

state = json.loads((H/'stage_state.json').read_text(encoding='utf-8'))
results = sorted(state['official_results'], key=lambda r: r['trial'])
assert len(results) == 10 and [r['trial'] for r in results] == list(range(1, 11))
assert all(r['status'] == 'Pass' and r['passed'] == 15 for r in results)
best = max(results, key=lambda r: r['score'])
assert best['score'] <= 70, 'Stop condition has not been satisfied'
assert best['variant'] == 'FRESLONG' and best['score'] == 65.34
assert sha(H/best['variant']/'code/kernel.asc') == best['source_sha256']
state.update(status='stopped_after_10_best_not_over_70', official_completed=10,
             official_pending=[], best_variant=best['variant'], best_score=best['score'],
             best_official_score=best['score'], goal_achieved=False, npu_jobs_running=False)
state['cloud_completed'] = ['TREE','BTREE','DBLOCK','CONST','LIBRARY','FRES8','FRESLONG',
                           'FRESWL','FRES15','AFFEARLY','AFFLONG','RSMALL','RSMALLF',
                           'RFMAW','HVAR128','HFAST128','HWAVE2','HWAVE4']
state['cloud_candidate_methods_completed'] = len(state['cloud_completed'])
state['cloud_completed_note'] = 'Includes measured invalid HVAR128 prototype; official runs and compiled-only candidates are tracked separately.'
save(H/'stage_state.json', state)

methods = [
 ('TREE','二叉树归约','s11 -2.42%；s13 +0.09%','云机筛选后淘汰'),
 ('BTREE','块归约后树形归约','s11 +7.74%；s13 -0.07%','未提交；保留对照'),
 ('DBLOCK','两级块归约','s11 +8.92%；s13 -0.02%','正式63.95'),
 ('CONST','FP16 编译期行宽特化','s8 +1.69%；s10 +0.55%','正式63.52'),
 ('LIBRARY','高阶 RmsNorm 接口','s3 -3.72%','云机筛选后淘汰'),
 ('FRES8','FP32 参数常驻、双输入/输出槽、静态同步','1024×4097/8192：+65.64%/+63.01%','正式64.11'),
 ('FRESLONG','FP32 整行残差驻留、直接搬入最终 Y、槽位复用','1024×16384/32768：+21.50%/+12.65%','正式65.34；选用完整版本'),
 ('FRESWL','参数常驻扩展至中宽行，保留长行路径','s9 +16.84%；s11 -10.66%；s13 -1.18%','正式64.04'),
 ('FRES15','只选择有收益的行宽区间','s9 +16.82%','正式64.18'),
 ('AFFEARLY','提前 gamma 缩放，与归约重叠；最终 FMA','s11 +1.32%；s13 -0.11%','用于合成 AFFLONG'),
 ('AFFLONG','提前 affine 与最佳长行驻留组合','s11 +0.59%；s13 +0.01%','正式64.42'),
 ('RSMALL','原生 Rsqrt 替换 Sqrt/Div','s1/s2/s3：+4.12%/+7.60%/+1.24%','9个常规输入新增8个 strict 失败；未作为最佳'),
 ('RSMALLF','Rsqrt 加一次 FMA Newton 修正','s1/s2/s3：-7.47%/-11.16%/-4.17%','性能下降；部分 strict 失败；淘汰'),
 ('RFMAW','批量路径 Rsqrt 修正','s4/s6/s11：-1.55%/-5.59%/-6.54%','性能下降；淘汰'),
 ('HVAR128','FP16 方差归约及输入幅值回退','实现存在未清零 padding 的问题','无效原型；不得作为有效方法收益'),
 ('HFAST128','清零 padding 后 FP16 方差、溢出回退 FP32','s6 +0.87%；s7 -0.95%；s8 +5.84%；s10 -2.16%','正式63.63；15/15'),
 ('HWAVE2','FP16 逻辑核波次改为物理 AIV 的两倍','s6 -29.83%；s7 -27.74%','淘汰；未提交'),
 ('HWAVE4','FP16 逻辑核波次改为物理 AIV 的四倍','s6 -67.66%；s7 -66.16%','淘汰；未提交'),
 ('RMSCF','缓存常量、融合 sum/D+epsilon','云机已编译；SSH 断开后未测 NPU','正式64.03；15/15'),
 ('HFRMSCF','融合均方计算与 FP16 方差候选组合','云机已编译；未测 NPU','未提交'),
 ('AXSMALL','小输入连续地址 DMA 合并、独立 fallback、Axpy 均方融合','未做云机测试；比赛端编译成功','正式64.02；15/15'),
]
cloud_index = []
for variant, method, timing, decision in methods:
    manifest = json.loads((H/variant/'manifest.json').read_text(encoding='utf-8'))
    actual_sha = sha(H/variant/'code/kernel.asc')
    assert actual_sha == manifest['source_sha256'], variant
    cloud_index.append(dict(variant=variant, method=method, observed_cloud_summary=timing,
                            decision=decision, source_sha256=actual_sha,
                            official_result=next((r for r in results if r['variant']==variant), None),
                            late_cloud_raw_records_fully_downloaded=False))
save(H/'evidence_index.json', dict(methods=cloud_index,
    cloud_archive_boundary='Full early metadata snapshots retained; later cloud outcomes were observed in tool output, but their full raw reports remain remote after SSH failure.',
    official_evidence='All ten source identities, result snapshots, ranking snapshots and screenshots are local.'))

official_rows = '\n'.join(f"|{r['trial']}|{r['variant']}|[{r['id']}]({r['url']})|{r['score']:.2f}|15/15|{r['rank_observed']}|" for r in results)
method_rows = '\n'.join(f'|{v}|{m}|{t}|{d}|' for v,m,t,d in methods)
point_rows = '\n'.join(f"|{i}|{t:.2f}|{b:.2f}|Pass|" for i,(t,b) in enumerate(zip(best['times_us'],best['tbest_us']),1))
report = f'''# E027：更换优化方法的十次正式评测交接（2026-10-13）

本轮 **10/10 次正式评测已经结束，全部 15/15 Pass；最高完整成绩为 FRESLONG 65.34 分**，提交 [{best['id']}]({best['url']})。最后一版 AXSMALL 为 64.02 分。最高未超过 70 分，因此按用户设定停止新增实验。没有继续提交第 11 次，也没有把“恢复最好版本”算作额外测试。网站目前显示最新提交 AXSMALL 的 64.02 分；仓库根目录与最佳工程包选择历史最高完整源码 FRESLONG。

## 正式比赛结果

|次数|完整候选|提交|总分|通过|评测时观察排名|
|---|---|---|---:|---|---:|
{official_rows}

排名会变化，记录值是当时观察结果。各候选的 official/ 保存原始页面文本、结果 JSON、结果和排名截图。小数耗时来自网页显示值，毫秒换算为微秒；没有拼接不同提交的最快点。TBest 在本轮和前一日之间发生变化，不能将相对历史 FACC 64.98 的 0.36 分全部归因于算法改进，也不能据一次 65.34 分声称稳定突破 65 分。

## 实际实施的方法与取舍

正百分比表示云机候选比对照快，负百分比表示更慢。以下是自建形状的设备计时，不代表官方隐藏用例。

|候选|方法|云机观察|处理|
|---|---|---|---|
{method_rows}

额外保留 FRESW（已编译但未单独测量）、AXPROTO（与 AXSMALL 源码相同的准备版本，未云机编译）和 HVAR128_failed_scope（第一次编译失败的原始版本）。它们不是额外正式比赛次数。HVAR128 随后修复了编译作用域，但 padding 错误仍使该实现无效；修复 padding 后独立生成的是 HFAST128，不混用两者记录。

本轮没有仅围绕原方案调整常数，已尝试归约拓扑、静态片上驻留与槽位复用、计算重排、低精度方差、近似倒平方根及修正、逻辑核波次和搬运融合。多个自建输入出现明显设备收益，正式成绩却没有对应幅度的改善。这说明这些形状的云机收益不足以预测隐藏测试的总分；本轮无法证明新方法能超过 70 分。

## 最佳完整源码身份及路径

采用 `{best['variant']}/code` 的完整八文件工程。kernel.asc SHA256：`{best['source_sha256']}`。云机 runner SHA256：`9052108564f96a75d24abece7fc780f52c0ffbf2464545cfe233f35dc78d42a4`。

FRESLONG 继承 FACC 的少行/短行、FP16 非对齐短行、中行、长行、FP32 中宽行与 BF16 路径；新增 FP32 D8193..32768 的静态整行残差驻留路径。该路径使用约 168992 字节 UB，X 直接进入最终 Y，两个 residual/square 槽随后复用于 gamma/bias，归约完成后流式输出 affine FMA。分派只使用实际 dtype、维度、行数和设备核数；准确守卫和顺序见完整源码 run_kernel。云机的七个边界形状和五类模式共十二组检查均 strict 通过，正式评测全部 15 点通过。

|测试点|本方案 μs|当次 TBest μs|结果|
|---|---:|---:|---|
{point_rows}

## 计时与数值验证边界

云机为 Ascend 910B3、CANN 9.0.0、40 AIV。对照是原 FACC，通常执行 ABBA/BAAB，warmup10、batch20；每次 msprof 收集 31 个任务，取最后 20 个设备任务的中位数。输入由 seed42 及实际 shape/dtype/pattern 生成。后期部分筛选只运行一个 ABBA 块，读原始 driver 模式和记录确认次数，不把所有数据称为两块。

代表输入 s1=1×64 FP16，s2=7×197 FP32，s3=128×256 FP32，s4=767×193 FP16，s5=8×32768 FP16，s6=1513×577 FP16，s7=3113×397 FP16，s8=10240×512 FP16，s9=4096×1536 FP32，s10=8192×1024 FP16，s11=3749×3083 FP32，s12=3408×4096 BF16，s13=10300×3079 FP32；s14/s15 使用较小 BF16 形状。行数以合法 batch/seq 组合表达；这些名称不证明与官方 1..15 点一一对应。

部分 FP16/BF16 自建输入在 FACC 基线就未通过更严格的本地 strict 阈值；保留基线与候选结果，没有把“官方 Pass”改写成“本地 strict 全通过”。原生 Rsqrt 和 Newton 修正候选的数值与性能结果单独记录。未因为单个精度候选失败而中止其他方法。

## 归档及复现

E027_full_experiment.zip 包含所有候选八文件源码、生成脚本、驱动、清单、十次网页证据和已下载云机 metadata 快照。ROOT/cloud_bench 与 experiments/E006A_probe 的必要依赖一起保留。将 experiments/E027_new_methods/BASE/code/kernel.asc 用 cloud_bench/build.sh 构建到 experiments/E026_target70/build_FACC，再运行 run_round.py 对应模式；Windows 本机仅做归档、源码和压缩包一致性验证，不声称本机运行过 NPU。

云机当前结果位于 /home/developer/addrms_experiments/E027。工作盘满后的迁移及失败尝试记录在早期 metadata 中。已保存 results_complete.tar.gz 和 metadata_20261013_0958.tar.gz，完整元数据不含原始输入 tensor 和二进制 runner。后期 SSH 返回连接关闭/拒绝登录，因而后期云机完整原始日志尚留在云机；本报告后期云机数字来自已读取的执行输出，归档包未假称包含全部后期云机原始日志。RMSCF/HFRMSCF 云机只编译未测量，AXSMALL 未云机编译/测量而由比赛端成功编译并通过。

## 参考资料

归约方案依据 [Huawei AddRmsNormBias 原始归约实现](https://dev.modelhub.org.cn/EngineX/xc-llm-ascend/src/commit/fbae41697e83574f073cd1eb663b66caad19d91a/csrc/add_rms_norm_bias/op_kernel/reduce_common.h)。高阶接口候选依据 [RmsNorm API](https://asc.gitcode.com/api/SIMD-API/adv_api/normalization/RmsNorm.html) 并读取已安装 CANN9 头文件。静态流水参考 [Ascend C 手动同步接口](https://www.hiascend.com/doc_center/source/zh/canncommercial/80RC3/apiref/ascendcopapi/atlasascendc_api_07_0256.html)。

倒平方根方案查阅了 [Rsqrt 官方精度说明](https://www.hiascend.com/document/detail/zh/CANNCommunityEdition/900beta2/API/ascendcopapi/atlasascendc_api_07_0036.html)，A2 原生精度需实测而不能假设满足本题阈值。最后两版融合均方使用支持实际平台的 [Axpy 基础接口](https://www.hiascend.com/document/detail/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0063.html)，没有将仅适用于其他型号的寄存器接口当作 A2 能力。

## 停止状态

最高 65.34 ≤ 70，停止条件已触发。本轮新增研究和比赛评测停止，未达到 70 分；当前仅整理并发布实验交接。所有已启动云机任务均已返回，本地记录 npu_jobs_running=false。后续如继续，需重新确认可用云机并首先校准能预测比赛收益的工作负载；这些建议尚未执行。
'''
(H/'README.md').write_text(report, encoding='utf-8')
(H/'交接报告_E027_2026-10-13.md').write_text(report, encoding='utf-8')

# Preserve the previous top-level handoff before selecting the new complete project.
hist = REPO/'history/2026-10-12_E026'
hist.mkdir(parents=True, exist_ok=True)
for name in ['README.md','HANDOFF.md','selection.json','MANIFEST.json','official_results.json']:
    p = REPO/name
    if p.exists() and not (hist/name).exists():
        shutil.copyfile(p, hist/name)
with zipfile.ZipFile(REPO/'E026_previous_handoff.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in hist.iterdir():
        if p.is_file(): z.write(p,p.name)
for p in (H/best['variant']/'code').rglob('*'):
    if p.is_file():
        dest = REPO/p.relative_to(H/best['variant']/'code')
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, dest)
selection = dict(best, submission_id=best['id'], goal_score=70, goal_achieved=False,
                 selection_rule='Highest total score of one complete official submission; no per-point mixing',
                 latest_submission=results[-1], stop_reason=state['status'])
save(REPO/'selection.json', selection)
previous = json.loads((hist/'official_results.json').read_text(encoding='utf-8'))
known = {r.get('id',r.get('submission_id')) for r in previous}
save(REPO/'official_results.json', previous + [r for r in results if r['id'] not in known])
save(REPO/'official_results_E027.json', results)
(REPO/'HANDOFF.md').write_text(report, encoding='utf-8')
(REPO/'实验报告_E027.md').write_text(report, encoding='utf-8')
shutil.copyfile(H/best['variant']/'official/ranking.png', REPO/f"official_rank_{best['id']}.png")
shutil.copyfile(H/results[-1]['variant']/'official/ranking.png', REPO/f"official_rank_{results[-1]['id']}.png")

project_zip = REPO/f"best_submission_{best['id']}.zip"
with zipfile.ZipFile(project_zip,'w',zipfile.ZIP_DEFLATED) as z:
    for p in (H/best['variant']/'code').rglob('*'):
        if p.is_file(): z.write(p,p.relative_to(H/best['variant']/'code').as_posix())
with zipfile.ZipFile(project_zip) as z:
    assert z.testzip() is None and len(z.namelist())==8
    assert hashlib.sha256(z.read('kernel.asc')).hexdigest() == best['source_sha256']

pack = REPO/'E027_full_experiment.zip'
files = []
for p in H.rglob('*'):
    rel = p.relative_to(H)
    if not p.is_file() or rel.parts[0]=='cloud_results' or '__pycache__' in rel.parts or p.name=='archive_file_identity.json':
        continue
    if p.suffix in ('.asc','.h','.py','.sh','.json','.md','.inc','.txt','.png') or p.name in ('results_complete.tar.gz','metadata_20261013_0958.tar.gz'):
        files.append((p, 'experiments/E027_new_methods/'+rel.as_posix()))
for p in (ROOT/'cloud_bench').rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.py','.sh','.txt','.asc','.md','.json'):
        files.append((p,p.relative_to(ROOT).as_posix()))
for name in ('cloud_driver.py','protocol.json','source_manifest.json'):
    p=ROOT/'experiments/E006A_probe'/name
    files.append((p,p.relative_to(ROOT).as_posix()))
save(H/'archive_file_identity.json', {name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p,name in files})
files.append((H/'archive_file_identity.json','experiments/E027_new_methods/archive_file_identity.json'))
with zipfile.ZipFile(pack,'w',zipfile.ZIP_DEFLATED) as z:
    for p,name in files: z.write(p,name)
with zipfile.ZipFile(pack) as z:
    assert z.testzip() is None
    assert hashlib.sha256(z.read('experiments/E027_new_methods/FRESLONG/code/kernel.asc')).hexdigest()==best['source_sha256']
    packed=json.loads(z.read('experiments/E027_new_methods/stage_state.json'))
    assert packed['official_completed']==10 and packed['status']==state['status']
    for p,name in files:
        assert hashlib.sha256(z.read(name)).hexdigest()==sha(p), name
readme = f'''# CANN_HuaiWei

AddRmsNormBias 优化研究归档，更新于 2026-10-13。

**最高完整官方成绩：FRESLONG 65.34 分，15/15 Pass。** [提交 {best['id']}]({best['url']})，当时观察排名78。根目录与 scripts/ 为这一次完整提交的八文件工程，未拼接各次最快测试点。

本轮更换方法并完成10次正式测试，全部15/15；最后 AXSMALL 64.02分。最高未超过70分，已按用户限定停止新增测试。网站排名当前显示最后提交的64.02分，65.34是历史最高观察成绩。TBest与计时会变化，不将0.36分的增幅全部归因于算法。

- [交接与方法取舍](HANDOFF.md)、[E027实验报告](实验报告_E027.md)。
- [最佳完整比赛工程](best_submission_{best['id']}.zip)、[kernel.asc](kernel.asc)、[选择依据](selection.json)。
- [本轮10次官方结果](official_results_E027.json)、[历史正式结果](official_results.json)。
- [E027完整源码、驱动与网页证据包](E027_full_experiment.zip)、[文件身份清单](MANIFEST.json)。
- 先前 E026、E024 归档保留；[上一阶段顶层交接](E026_previous_handoff.zip)也保留，另可查看 Git 历史。

本轮已经尝试树形/块归约、静态片上驻留、计算重排、FP16方差、Rsqrt修正、核波次和DMA/Axpy融合。FRESLONG 在自建FP32长行上降低设备耗时，但正式成绩没有同等幅度提升。云机结果与官方隐藏输入区分记录；后期SSH断开，后期云机完整原始日志尚未全部下载，详细边界见交接文档。

![历史最高65.34分官方记录](official_rank_{best['id']}.png)

![最后一次64.02分官方记录](official_rank_{results[-1]['id']}.png)
'''
(REPO/'README.md').write_text(readme, encoding='utf-8')
manifest = dict(best=selection,official_experiments=10,status=state['status'],files={})
for p in REPO.rglob('*'):
    rel=p.relative_to(REPO)
    if p.is_file() and '.git' not in rel.parts and p.name!='MANIFEST.json' and rel.parts[0]!='history':
        manifest['files'][rel.as_posix()]=dict(bytes=p.stat().st_size,sha256=sha(p))
save(REPO/'MANIFEST.json',manifest)
assert sha(REPO/'kernel.asc')==best['source_sha256']
print(json.dumps(dict(best_score=best['score'],best_id=best['id'],latest_score=results[-1]['score'],
    source_sha256=sha(REPO/'kernel.asc'),archive_bytes=pack.stat().st_size,archive_sha256=sha(pack),
    archive_files=len(files),repo=str(REPO)),ensure_ascii=False))
