from pathlib import Path
import hashlib,json,shutil
H=Path(__file__).resolve().parent
code=(H/'FRES8/code/kernel.asc').read_text(encoding='utf-8')
assert hashlib.sha256(code.encode()).hexdigest()=='f3b7ccfe0b6a012659baf5b06ff5e38643d8a1bf8b25f160ad9187af8cb913a1'
old='''    if(input.dtype==0 && d>4096 && d<=8192) {
        float_resident8_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert code.count(old)==1;code=code.replace(old,'')
guard='''    if(input.dtype==0 && d>1024 && d<=8192 && rows>=static_cast<uint64_t>(blockNum)*4) {
        float_resident8_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
anchor='    if(input.dtype==1 && d>1024 && d<=4096'
assert code.count(anchor)==1;code=code.replace(anchor,guard+anchor)
dest=H/'FRESW/code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'FRESW/manifest.json').write_text(json.dumps(dict(variant='FRESW',parent='FACC',source_sha256=hashlib.sha256(code.encode()).hexdigest(),numerical_change=True,change='Expand the new static resident FP32 pipeline to D1025..8192 and at least four rows per core; replace the former multi-row routes with cached parameters and input/output ping-pong',ub_end_bytes=169248),indent=2)+'\n')
driver=H/'run_round.py';text=driver.read_text(encoding='utf-8')
if "if mode=='fresw':" not in text:
 text+='''
if mode=='fresw':
 items=[small[8],small[10],small[12]]+[(f'e027_fwide_{r}_{d}',r,d,'float32') for r,d in [(161,1025),(161,1537),(161,2048),(161,4096),(159,3079)]]
 check('fresw_check',items,['BASE','FRESW'])
 pairs('fresw_pairs',[small[8],small[10],small[12]],'BASE','FRESW',blocks=2)
'''
 driver.write_text(text,encoding='utf-8',newline='\n')
print(hashlib.sha256(code.encode()).hexdigest())
