from pathlib import Path
import hashlib,json,shutil
H=Path(__file__).resolve().parent
code=(H/'FRESLONG/code/kernel.asc').read_text(encoding='utf-8')
assert hashlib.sha256(code.encode()).hexdigest()=='d676dd20267c736d2c35d245c043be933a13f84ba0e0fc67d887e30611e66bce'
helper='''// One FMA-based Newton correction of the hardware inverse-square-root estimate.
// The original estimate is retained for Inf/NaN variance, so special-value
// behavior follows the original 1/sqrt operation rather than Inf*0 correction.
__aicore__ inline void RefinedSmallRsqrt(LocalTensor<float> dst,uint32_t n) {
    LocalTensor<float> scratch(TPosition::VECCALC,163840,1024);
    const uint32_t stride=(n+7)/8*8;
    auto a=scratch;auto correction=scratch[stride];
    auto estimate=scratch[2*stride];auto constant=scratch[3*stride];
    auto finite=scratch[4*stride].ReinterpretCast<uint8_t>();
    Adds(a,dst,0.0f,n);Duplicate(constant,1.5f,n);PipeBarrier<PIPE_V>();
    CompareScalar(finite,a,3.402823466e38f,CMPMODE::LE,n);
    Rsqrt(dst,dst,n);PipeBarrier<PIPE_V>();
    Muls(a,a,-0.5f,n);Adds(estimate,dst,0.0f,n);PipeBarrier<PIPE_V>();
    Mul(correction,a,dst,n);PipeBarrier<PIPE_V>();
    FusedMulAdd(correction,dst,constant,n);PipeBarrier<PIPE_V>();
    Mul(dst,estimate,correction,n);PipeBarrier<PIPE_V>();
    Select(dst,finite,dst,estimate,SELMODE::VSEL_TENSOR_TENSOR_MODE,n);
}

'''
code=code.replace('using namespace AscendC;\n','using namespace AscendC;\n\n'+helper,1)
sections=[('single_row_64_custom(', 'single_row_custom('),('class SingleRowStaticKernel {','class SmallRowsStaticKernel {'),('class SmallRowsStaticKernel {','class WholeRowsStaticDoubleBufferKernel {'),('class ShortFloatPartitionKernel {','class TinyBatchFloatKernel {')]
for start,end in sections:
 a=code.index(start);z=code.index(end,a+len(start));s=code[a:z]
 s=s.replace('Sqrt(sum, sum, 1);','RefinedSmallRsqrt(sum,1);').replace('Sqrt(sum_, sum_, 1);','RefinedSmallRsqrt(sum_,1);')
 s=s.replace('Div(y, y, work,','Mul(y, y, work,').replace('Div(y_, y_, work_,','Mul(y_, y_, work_,')
 if start=='class ShortFloatPartitionKernel {':
  old='''        Sqrt(sums_, sums_, count_);
        Duplicate(work_, 1.0f, count_);
        PipeBarrier<PIPE_V>();
        Div(sums_, work_, sums_, count_);'''
  assert old in s;s=s.replace(old,'        RefinedSmallRsqrt(sums_,count_);')
 assert s!=code[a:z];code=code[:a]+s+code[z:]
dest=H/'RSMALLF/code';shutil.copytree(H/'FRESLONG/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'RSMALLF/manifest.json').write_text(json.dumps(dict(variant='RSMALLF',parent='FRESLONG',source_sha256=hashlib.sha256(code.encode()).hexdigest(),numerical_change=True,change='Small-row Rsqrt with a fused Newton correction and preserved Inf/NaN estimates, then broadcast multiply; preserve official 65.34 long-row implementation'),indent=2)+'\n')
driver=H/'run_round.py';text=driver.read_text(encoding='utf-8')
if "if mode=='rsmallf':" not in text:
 text+='''
if mode=='rsmallf':
 items=[small[0],small[1],small[2]]+[(f'e027_rs_{r}_{d}_{dt}',r,d,dt) for r,d,dt in [(1,64,'float32'),(1,64,'bfloat16'),(1,197,'float32'),(7,255,'float32'),(128,512,'float32'),(8,4096,'float16')]]
 check('rsmallf_check',items,['BASE','RSMALLF'])
 edges=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_rs_edge_'+pattern;case(cid,7,197,'float32',pattern);edges.append((cid,7,197,'float32'))
 check('rsmallf_edge_check',edges,['BASE','RSMALLF'])
 pairs('rsmallf_pairs',small[:3],'BASE','RSMALLF',blocks=2)
'''
 driver.write_text(text,encoding='utf-8',newline='\n')
print(hashlib.sha256(code.encode()).hexdigest())
