from pathlib import Path
import hashlib,json,shutil
H=Path(__file__).resolve().parent
base=(H/'FRESLONG/code/kernel.asc').read_text(encoding='utf-8')
assert hashlib.sha256(base.encode()).hexdigest()=='d676dd20267c736d2c35d245c043be933a13f84ba0e0fc67d887e30611e66bce'
for factor,name in [(2,'HWAVE2'),(4,'HWAVE4')]:
 code=base
 anchor='    if(input.dtype==1 && d>1024 && d<=4096'
 prefix=f'    const uint32_t halfLogicalCores = blockNum <= 65535/{factor} ? blockNum*{factor} : blockNum;\n'
 assert code.count(anchor)==1;code=code.replace(anchor,prefix+anchor)
 for function in ['half_wide_pipeline_custom<half,false>','pipeline_batch9_custom<half,true>']:
  old=function+'<<<blockNum,nullptr,stream>>>'
  new=function+'<<<halfLogicalCores,nullptr,stream>>>'
  assert code.count(old)==1;code=code.replace(old,new)
 dest=H/name/'code';shutil.copytree(H/'FRESLONG/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='FRESLONG',source_sha256=hashlib.sha256(code.encode()).hexdigest(),numerical_change=False,change=f'For existing FP16 D321..4096 many-row pipeline routes only, launch {factor} waves of logical AIV blocks; preserve physical-core routing criteria and per-row arithmetic'),indent=2)+'\n')
 print(name,hashlib.sha256(code.encode()).hexdigest())
driver=H/'run_round.py';text=driver.read_text(encoding='utf-8')
if "if mode=='hwaves':" not in text:
 text+='''
if mode=='hwaves':
 items=[small[i] for i in [5,6,7,9]]+[(f'e027_wave_{r}_{d}',r,d,'float16') for r,d in [(160,321),(161,577),(319,1024),(321,1536),(161,4095),(159,577)]]
 check('hwave_check',items,['BASE','HWAVE2','HWAVE4'])
 for v in ['HWAVE2','HWAVE4']:
  pairs(v.lower()+'_pairs',[small[5],small[6]],'BASE',v,blocks=1)
'''
 driver.write_text(text,encoding='utf-8',newline='\n')
