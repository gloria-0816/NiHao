from pathlib import Path
import hashlib,json,shutil
H=Path(__file__).resolve().parent
code=(H/'FRESWL/code/kernel.asc').read_text(encoding='utf-8')
assert hashlib.sha256(code.encode()).hexdigest()=='f6a9507deb9ee6063bc7d810537ecb498cb42f010ef81a18e488d850dc24fdf2'
old='    if(input.dtype==0 && d>1024 && d<=8192 && rows>=static_cast<uint64_t>(blockNum)*4) {'
new='    if(input.dtype==0 && d<=8192 && ((d>1024 && d<=1536 && rows>=static_cast<uint64_t>(blockNum)*4) || d>4096)) {'
assert code.count(old)==1;code=code.replace(old,new)
dest=H/'FRES15/code';shutil.copytree(H/'FRESWL/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'FRES15/manifest.json').write_text(json.dumps(dict(variant='FRES15',parent='FRESLONG',source_sha256=hashlib.sha256(code.encode()).hexdigest(),numerical_change=True,change='Use cached FP32 resident rows in measured positive D1025..1536 and D4097..8192 intervals; keep original triple-buffer route at D1537..4096; retain official 65.34 long rows'),indent=2)+'\n')
driver=H/'run_round.py';text=driver.read_text(encoding='utf-8')
if "if mode=='fres15':" not in text:
 text+='''
if mode=='fres15':
 items=[small[8],small[10],small[12],('e027_fres_perf_1024_8192',1024,8192,'float32')]+[(f'e027_f15_{r}_{d}',r,d,'float32') for r,d in [(161,1025),(161,1535),(161,1536),(161,1537),(159,1536)]]
 check('fres15_check',items,['BASE','FRES15'])
 pairs('fres15_pairs',[small[8]],'BASE','FRES15',blocks=1)
'''
 driver.write_text(text,encoding='utf-8',newline='\n')
print(hashlib.sha256(code.encode()).hexdigest())
