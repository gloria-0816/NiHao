from pathlib import Path
import hashlib,json,shutil
H=Path(__file__).resolve().parent
base=(H/'BASE/code/kernel.asc').read_text(encoding='utf-8')
assert hashlib.sha256(base.encode()).hexdigest()=='bc62917a0b4e5a6155b188e5f829f32590832ba1e06345deb50564beacef356b'
a=base.index('class FloatBroadTripleKernel {');z=base.index('template <typename T,bool BlockReduction>',a)
s=base[a:z]
anchor='            WholeReduceSum(sums_,work_,64,count,1,1,8);PipeBarrier<PIPE_V>();'
replacement='''            WholeReduceSum(sums_,work_,64,count,1,1,8);
            // Gamma scaling is independent of the pending RMS reduction.
            // Norm partials were formed from the unscaled residual above.
            for(uint32_t i=0;i<count;++i)Mul(y[i*stride_],y[i*stride_],gf_,d_);
            PipeBarrier<PIPE_V>();'''
assert s.count(anchor)==1;s=s.replace(anchor,replacement)
old='''            for(uint32_t i=0;i<count;++i)
                Mul(y[i*stride_],y[i*stride_],work_[i*8],64,parts,{1,1,0,8,8,0});
            PipeBarrier<PIPE_V>();
            for(uint32_t i=0;i<count;++i)FusedMulAdd(y[i*stride_],gf_,bf_,d_);'''
new='''            for(uint32_t i=0;i<count;++i)
                FusedMulAdd(y[i*stride_],work_[i*8],bf_,64,parts,{1,0,1,8,0,8});'''
assert s.count(old)==1;s=s.replace(old,new)
code=base[:a]+s+base[z:]
dest=H/'AFFEARLY/code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'AFFEARLY/manifest.json').write_text(json.dumps(dict(variant='AFFEARLY',parent='FACC',source_sha256=hashlib.sha256(code.encode()).hexdigest(),numerical_change=True,change='FP32 wide rows compute residual*gamma while RMS reduction is pending, then FMA with broadcast inverse RMS and bias; same norm, tile, core count and DMA'),indent=2)+'\n')
driver=H/'run_round.py';text=driver.read_text(encoding='utf-8')
if "if mode=='affearly':" not in text:
 text+='''
if mode=='affearly':
 items=[small[10],small[12]]+[(f'e027_f{d}',161,d,'float32') for d in [1537,2048,3073,3136,4095,4096]]
 check('affearly_check',items,['BASE','AFFEARLY'])
 edges=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_aff_edge_'+pattern;case(cid,161,3079,'float32',pattern);edges.append((cid,161,3079,'float32'))
 check('affearly_edge_check',edges,['BASE','AFFEARLY'])
 pairs('affearly_pairs',[small[10],small[12]],'BASE','AFFEARLY',blocks=2)
'''
 driver.write_text(text,encoding='utf-8',newline='\n')
print(hashlib.sha256(code.encode()).hexdigest())
