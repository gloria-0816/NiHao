from pathlib import Path
import hashlib,json,shutil,re
H=Path(__file__).resolve().parent
code=(H/'FRESLONG/code/kernel.asc').read_text(encoding='utf-8')
small=(H/'RSMALLF/code/kernel.asc').read_text(encoding='utf-8')
a=small.index('__aicore__ inline void RefinedSmallRsqrt(');z=small.index('\ntemplate <typename T>',a)
helper=small[a:z]
helper=helper.replace('RefinedSmallRsqrt(LocalTensor<float> dst,uint32_t n)','RefinedBatchRsqrt(LocalTensor<float> dst,LocalTensor<float> scratch,uint32_t n)')
helper=helper.replace('    LocalTensor<float> scratch(TPosition::VECCALC,163840,1024);\n','')
code=code.replace('using namespace AscendC;\n','using namespace AscendC;\n\n'+helper+'\n',1)
sections=[('class PipelineBatch9Kernel {','class BFloatTripleInplaceKernel {'),('class BFloatTripleInplaceKernel {','class FloatResidentLongKernel {'),('class FloatBroadTripleKernel {','class HalfWidePipelineKernel {'),('class HalfWidePipelineKernel {','class BFloatStatic8Kernel {'),('class BFloatShortInplaceKernel {','class StaticHalfRowsKernel {'),('class StaticHalfRowsKernel {','class ShortFloatPartitionKernel {')]
pat=re.compile(r'Sqrt\(sums_,\s*sums_,\s*(count|rms)\);\s*Duplicate\(work_,\s*1\.0f,\s*\1\);\s*PipeBarrier<PIPE_V>\(\);\s*Div\(sums_,\s*work_,\s*sums_,\s*\1\);')
changed=0
for start,end in sections:
 a=code.index(start);z=code.index(end,a+len(start));s=code[a:z]
 s,n=pat.subn(lambda m:'RefinedBatchRsqrt(sums_,work_,'+m.group(1)+');',s)
 assert n==1,(start,n);changed+=n;code=code[:a]+s+code[z:]
dest=H/'RFMAW/code';shutil.copytree(H/'FRESLONG/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'RFMAW/manifest.json').write_text(json.dumps(dict(variant='RFMAW',parent='FRESLONG',source_sha256=hashlib.sha256(code.encode()).hexdigest(),numerical_change=True,change='RMS batch paths use inverse sqrt plus FMA Newton correction in existing reduction workspace; preserve finite/Inf/NaN behavior and 65.34 long-row implementation',modified_sections=changed),indent=2)+'\n')
driver=H/'run_round.py';text=driver.read_text(encoding='utf-8')
if "if mode=='rfmaw':" not in text:
 text+='''
if mode=='rfmaw':
 check('rfmaw_check',small,['BASE','RFMAW'])
 edges=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  for r,d,dt in [(161,193,'float16'),(161,3079,'float32'),(161,128,'bfloat16')]:
   cid=f'e027_rf_{d}_{pattern}';case(cid,r,d,dt,pattern);edges.append((cid,r,d,dt))
 check('rfmaw_edge_check',edges,['BASE','RFMAW'])
 pairs('rfmaw_pairs',[small[3],small[5],small[10],small[13]],'BASE','RFMAW',blocks=1)
'''
 driver.write_text(text,encoding='utf-8',newline='\n')
print(hashlib.sha256(code.encode()).hexdigest())
