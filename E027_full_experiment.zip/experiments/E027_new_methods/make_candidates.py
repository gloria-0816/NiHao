from pathlib import Path
import hashlib, json, shutil, tarfile

H = Path(__file__).resolve().parent
ROOT = H.parents[1]
OLD = ROOT / 'experiments/E026_target70'
base_dir = OLD / 'FACC/code'
base = (base_dir / 'kernel.asc').read_text(encoding='utf-8')
assert hashlib.sha256(base.encode()).hexdigest() == 'bc62917a0b4e5a6155b188e5f829f32590832ba1e06345deb50564beacef356b'
shutil.copytree(base_dir, H / 'BASE/code', dirs_exist_ok=True)

a = base.index('class FloatBroadTripleKernel {')
z = base.index('template <typename T,bool BlockReduction>', a)
section = base[a:z]
start = section.index('            const uint32_t parts=stride_/64;')
end = section.index('            if(row+batch_<end_) {', start)

tree = '''            const uint32_t parts=stride_/64;
            // Fold the non-power-of-two tail, then halve the reduction
            // domain. The final add writes the 64 lanes used by WholeReduceSum.
            uint32_t body=64;
            while(body*2<=stride_) body*=2;
            for(uint32_t i=0;i<count;++i) {
                auto square=tmp[i*stride_];
                if(stride_>body) {
                    Add(square,square,square[body],stride_-body);
                    PipeBarrier<PIPE_V>();
                }
                for(uint32_t span=body/2;span>64;span/=2) {
                    Add(square,square,square[span],span);
                    PipeBarrier<PIPE_V>();
                }
                Add(work_[i*64],square,square[64],64);
            }
            PipeBarrier<PIPE_V>();
            WholeReduceSum(sums_,work_,64,count,1,1,8);
            PipeBarrier<PIPE_V>();
'''
block_tree = '''            const uint32_t parts=stride_/64;
            // First reduce all independent 32-byte blocks together.
            // This makes each later tree operate on eight times fewer values.
            BlockReduceSum(work_,tmp,active/64,64,1,1,8);
            PipeBarrier<PIPE_V>();
            const uint32_t reducedStride=stride_/8;
            uint32_t body=64;
            while(body*2<=reducedStride) body*=2;
            for(uint32_t i=0;i<count;++i) {
                auto partial=work_[i*reducedStride];
                if(reducedStride>body) {
                    Add(partial,partial,partial[body],reducedStride-body);
                    PipeBarrier<PIPE_V>();
                }
                for(uint32_t span=body/2;span>64;span/=2) {
                    Add(partial,partial,partial[span],span);
                    PipeBarrier<PIPE_V>();
                }
                Add(tmp[i*64],partial,partial[64],64);
            }
            PipeBarrier<PIPE_V>();
            WholeReduceSum(sums_,tmp,64,count,1,1,8);
            PipeBarrier<PIPE_V>();
'''
double_block = '''            const uint32_t parts=stride_/64;
            BlockReduceSum(work_,tmp,active/64,64,1,1,8);
            PipeBarrier<PIPE_V>();
            const uint32_t partialStride=stride_/8;
            const uint32_t whole=partialStride/64,tail=partialStride%64;
            for(uint32_t i=0;i<count;++i) {
                BlockReduceSum(tmp[i*64],work_[i*partialStride],whole,64,1,1,8);
                if(tail)
                    BlockReduceSum(tmp[i*64+whole*8],work_[i*partialStride+whole*64],1,tail,1,1,8);
            }
            PipeBarrier<PIPE_V>();
            WholeReduceSum(sums_,tmp,parts,count,1,1,8);
            PipeBarrier<PIPE_V>();
'''
for name, replacement in [('TREE', tree), ('BTREE', block_tree), ('DBLOCK', double_block)]:
    changed = section[:start] + replacement + section[end:]
    code = base[:a] + changed + base[z:]
    dest = H / name / 'code'
    shutil.copytree(base_dir, dest, dirs_exist_ok=True)
    (dest / 'kernel.asc').write_text(code, encoding='utf-8', newline='\n')
    manifest = dict(variant=name, parent='FACC',
                    source_sha256=hashlib.sha256(code.encode()).hexdigest(),
                    change={'TREE':'FP32 wide-row binary reduction','BTREE':'FP32 wide-row block reduction followed by binary reduction','DBLOCK':'FP32 wide-row two hardware block-reduction levels followed by one whole reduction'}[name],
                    numerical_change=True, status='prepared_not_measured',
                    reference='https://dev.modelhub.org.cn/EngineX/xc-llm-ascend/src/commit/fbae41697e83574f073cd1eb663b66caad19d91a/csrc/add_rms_norm_bias/op_kernel/reduce_common.h')
    (H/name/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(name,manifest['source_sha256'])

pstart=base.index('template <typename T, bool BlockReduction>\nclass PipelineBatch9Kernel {')
pend=base.index('class BFloatTripleInplaceKernel {',pstart)
constant=base[pstart:pend]
constant=constant.replace('template <typename T, bool BlockReduction>\nclass PipelineBatch9Kernel {',
    'template <uint32_t FixedD>\nclass ConstDenseHalfKernel {\n    using T=half;\n    static constexpr bool BlockReduction=true;')
constant=constant.replace('d_=d; stride_=(d+63)/64*64; batch_=9408/stride_;', '(void)d; batch_=9408/FixedD;')
constant=constant.replace('uint64_t begin_,end_; uint32_t d_,stride_,batch_; float invD_,eps_;',
    'static constexpr uint32_t d_=FixedD,stride_=FixedD;\n    uint64_t begin_,end_; uint32_t batch_; float invD_,eps_;')
wrapper=constant.index('template <typename T,bool BlockReduction>\n__global__')
constant=constant[:wrapper]+'''template <uint32_t FixedD>
__global__ __vector__ void const_dense_half_custom(GM_ADDR x,GM_ADDR r,GM_ADDR g,
    GM_ADDR b,GM_ADDR out,uint64_t rows,float invD,float eps) {
    InitSocState(); ConstDenseHalfKernel<FixedD> op;
    op.Init(x,r,g,b,out,rows,FixedD,invD,eps);op.Process();
}

'''
code=base[:pstart]+constant+base[pstart:]
anchor='    if(input.dtype==1 && d>1024 && d<=4096'
guard='''    if(input.dtype==1 && (d==512 || d==1024) && rows>=static_cast<uint64_t>(blockNum)*4) {
        if(d==512) const_dense_half_custom<512><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,inverseD,epsilon);
        else const_dense_half_custom<1024><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,inverseD,epsilon);
        return;
    }
'''
assert code.count(anchor)==1
code=code.replace(anchor,guard+anchor)
dest=H/'CONST/code';shutil.copytree(base_dir,dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'CONST/manifest.json').write_text(json.dumps(dict(variant='CONST',parent='FACC',
    source_sha256=hashlib.sha256(code.encode()).hexdigest(),numerical_change=False,
    change='Compile-time dimensions for the existing FP16 dense D512 and D1024 pipeline; identical arithmetic and buffer capacities',status='prepared_not_measured'),indent=2)+'\n')
print('CONST',hashlib.sha256(code.encode()).hexdigest())

prefix = (OLD/'run_round.py').read_text(encoding='utf-8').split('mode=sys.argv[1]')[0]
prefix = prefix.replace("OUT=Path('/mnt/workspace/addrms_results/E026')", "OUT=Path('/home/developer/addrms_experiments/E027')")
prefix = prefix.replace("if v=='BASE':return ROOT/'experiments/E025_pipeline/build_DB9/cloud_addrmsnormbias'", "if v=='BASE':return ROOT/'experiments/E026_target70/build_FACC/cloud_addrmsnormbias'")
prefix = prefix.replace("Path('/mnt/workspace/addrms_results/E023/inputs')", "Path('/mnt/workspace/addrms_results/E023/inputs'),Path('/mnt/workspace/addrms_results/E026/inputs')")
driver = prefix + '''
def copied_case_readonly(case_id,destination):
 src=core.origin(case_id)
 destination.mkdir(mode=0o700)
 for name in core.FILES:
  (destination/name).symlink_to((src/name).resolve())
 meta=json.loads((destination/'meta.json').read_text())
 old=src/'output.bin'
 return meta,core.sha(old) if old.is_file() else None
core.copied_case=copied_case_readonly
mode=sys.argv[1]
if mode=='build':build(sys.argv[2:])
if mode=='check':
 items=[small[10],small[12]]+[(f'e027_f{d}',161,d,'float32') for d in [1537,2048,3073,3136,4095,4096]]
 check('initial_check',items,['BASE','TREE','BTREE'])
if mode=='measure':
 for v in ['TREE','BTREE']:
  pairs(v.lower()+'_pairs',[small[10],small[12]],'BASE',v,blocks=2)
if mode=='dblock':
 items=[small[10],small[12]]+[(f'e027_f{d}',161,d,'float32') for d in [1537,2048,3073,3136,4095,4096]]
 check('dblock_check',items,['BASE','DBLOCK'])
 pairs('dblock_pairs',[small[10],small[12]],'BASE','DBLOCK',blocks=2)
if mode=='constant':
 items=[small[7],small[9]]+[(f'e027_dense_{r}_{d}',r,d,'float16') for r,d in [(160,512),(161,512),(161,1024),(321,1024),(17,512)]]
 check('constant_check',items,['BASE','CONST'])
 pairs('constant_pairs',[small[7],small[9]],'BASE','CONST',blocks=2)
if mode=='dblock_edges':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_dblock_edge_'+pattern;case(cid,161,3079,'float32',pattern)
  items.append((cid,161,3079,'float32'))
 check('dblock_edge_check',items,['BASE','DBLOCK'])
if mode=='edges':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_edge_'+pattern;case(cid,161,3079,'float32',pattern)
  items.append((cid,161,3079,'float32'))
 check('edge_check',items,['BASE','TREE','BTREE'])
'''
(H/'run_round.py').write_text(driver,encoding='utf-8',newline='\n')
state=H/'stage_state.json'
if not state.exists():
    state.write_text(json.dumps(dict(best_score=64.98,target_score=70.0,
        max_official_experiments_before_decision=10,official_completed=0,
        cloud_candidate_methods_completed=0,official_results=[],
        stop_condition='After 10 official experiments stop if best score <=70; continue if best score >70',
        status='active'),indent=2)+'\n')
with tarfile.open(H/'upload_initial.tar.gz','w:gz') as tar:
    for path in [H/'BASE',H/'TREE',H/'BTREE',H/'DBLOCK',H/'CONST',H/'run_round.py',state]:
        tar.add(path,arcname=path.relative_to(ROOT))
