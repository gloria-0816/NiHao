from pathlib import Path
import hashlib,json,shutil,sys,re
H=Path(__file__).resolve().parent
parent=sys.argv[1] if len(sys.argv)>1 else 'FRESLONG'
name=sys.argv[2] if len(sys.argv)>2 else 'AXPROTO'
code=(H/parent/'code/kernel.asc').read_text(encoding='utf-8')
a=code.index('single_row_64_custom(');z=code.index('single_row_custom(',a+1);s=code[a:z]
s=s.replace('    LocalTensor<T> xt(TPosition::VECIN, 0, 64);','    constexpr uint32_t rawSlot=64*sizeof(T)+64;\n    LocalTensor<T> xt(TPosition::VECIN, 0, 64);')
for symbol,offset in [('rt','rawSlot'),('gt','2*rawSlot'),('bt','3*rawSlot')]:
 s,k=re.subn(r'(LocalTensor<T> '+symbol+r'\(TPosition::VECIN, )\d+(, 64\);)',lambda m:m.group(1)+offset+m.group(2),s);assert k==1
for symbol,offset in [('y',1536),('tmp',1856),('gf',2208),('bf',2528),('sum',2816),('work',2880)]:
 s,k=re.subn(r'(LocalTensor<float> '+symbol+r'\(TPosition::VECCALC, )\d+(, \d+\);)',lambda m:m.group(1)+str(offset)+m.group(2),s);assert k==1
s=s.replace('LocalTensor<T> result(TPosition::VECOUT, 2336, 64);','LocalTensor<T> result(TPosition::VECOUT, 3136, 64);\n    LocalTensor<float> variance(TPosition::VECCALC,3424,8);\n    Duplicate(variance,epsilon,1);')
start=s.index('    DataCopy(xt, xgm, copy);');end=s.index('    WaitFlag<HardEvent::MTE2_V>(0);',start)
old=s[start:end]
packed='''    const uint64_t xp=reinterpret_cast<uint64_t>(x),rp=reinterpret_cast<uint64_t>(residual),
        gp=reinterpret_cast<uint64_t>(gamma),bp=reinterpret_cast<uint64_t>(bias);
    // A single packet is valid only when the four complete inputs form one
    // contiguous GM span. The fallback reads each tensor independently.
    if(rp==xp+64*sizeof(T) && gp==rp+64*sizeof(T) && bp==gp+64*sizeof(T)) {
        GlobalTensor<T> all;all.SetGlobalBuffer((__gm__ T*)x,256);
        LocalTensor<T> packed(TPosition::VECIN,0,4*rawSlot/sizeof(T));
        DataCopyParams group={4,static_cast<uint16_t>(64*sizeof(T)/32),0,2};
        DataCopy(packed,all,group);
        SetFlag<HardEvent::MTE2_V>(0);SetFlag<HardEvent::MTE2_V>(1);
    } else {
'''+old+'''    }
'''
s=s[:start]+packed+s[end:]
s,k=re.subn(r'Muls\(sum, sum, 0\.015625f, 1\);\s*PipeBarrier<PIPE_V>\(\);\s*Adds\(sum, sum, epsilon, 1\);','Axpy(variance,sum,0.015625f,1);',s);assert k==1
s=s.replace('Sqrt(sum, sum, 1);','Sqrt(variance, variance, 1);').replace('Brcb(work, sum, 1, {1, 8});','Brcb(work, variance, 1, {1, 8});')
code=code[:a]+s+code[z:]
for start,end in [('class SingleRowStaticKernel {','class SmallRowsStaticKernel {'),('class SmallRowsStaticKernel {','class WholeRowsStaticDoubleBufferKernel {')]:
 a=code.index(start);z=code.index(end,a+len(start));s=code[a:z]
 if start=='class SingleRowStaticKernel {':
  anchor='        SetFlag<HardEvent::MTE2_V>(0);'
  assert s.count(anchor)==1
  s=s.replace(anchor,'        LocalTensor<float> variance(TPosition::VECCALC,163840,8);\n        Duplicate(variance,epsilon_,1);\n'+anchor)
 else:
  p=s.index('    __aicore__ inline void ProcessRow(')
  old=s[:p];body=s[p:]
  anchor='        SetFlag<HardEvent::MTE2_V>(0);'
  assert body.count(anchor)==1
  body=body.replace(anchor,'        LocalTensor<float> variance(TPosition::VECCALC,163840,8);\n        Duplicate(variance,epsilon_,1);\n'+anchor)
  s=old+body
 s,k=re.subn(r'Muls\(sum_, sum_, invD_, 1\);\s*PipeBarrier<PIPE_V>\(\);\s*Adds\(sum_, sum_, epsilon_, 1\);','Axpy(variance,sum_,invD_,1);',s);assert k==1
 s=s.replace('Sqrt(sum_, sum_, 1);','Sqrt(variance, variance, 1);').replace('Brcb(work_, sum_, 1, {1, 8});','Brcb(work_, variance, 1, {1, 8});')
 code=code[:a]+s+code[z:]
a=code.index('class ShortFloatPartitionKernel {');z=code.index('class TinyBatchFloatKernel {',a);s=code[a:z]
anchor='        SetFlag<HardEvent::MTE2_V>(0);'
assert s.count(anchor)==1
s=s.replace(anchor,'        LocalTensor<float> variance(TPosition::VECCALC,163840,128);\n        Duplicate(variance,eps_,count_);\n'+anchor)
s,k=re.subn(r'Muls\(sums_, sums_, invD_, count_\);\s*PipeBarrier<PIPE_V>\(\);\s*Adds\(sums_, sums_, eps_, count_\);','Axpy(variance,sums_,invD_,count_);',s);assert k==1
s=s.replace('Sqrt(sums_, sums_, count_);','Sqrt(variance, variance, count_);').replace('Div(sums_, work_, sums_, count_);','Div(variance, work_, variance, count_);').replace('Brcb(work_, sums_, (count_+7)/8, {1, 8});','Brcb(work_, variance, (count_+7)/8, {1, 8});')
code=code[:a]+s+code[z:]
dest=H/name/'code';shutil.copytree(H/parent/'code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent=parent,source_sha256=hashlib.sha256(code.encode()).hexdigest(),numerical_change=True,change='Small rows prefill epsilon during DMA then Axpy the squared norm; single D64 uses phased compact operands and coalesces four inputs only when their actual GM spans are adjacent',references=['https://www.hiascend.com/document/detail/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0063.html']),indent=2)+'\n')
driver=H/'run_round.py';text=driver.read_text(encoding='utf-8')
if "if mode=='small_axpy':" not in text:
 text+='''
if mode=='small_axpy':
 v=sys.argv[2];assert v in ['AXPROTO','AXSMALL']
 items=small[:3]+[(f'e027_ax_{r}_{d}_{dt}',r,d,dt) for r,d,dt in [(1,64,'float32'),(1,64,'bfloat16'),(1,197,'float32'),(7,255,'float32'),(128,512,'float32'),(8,4096,'float16')]]
 check(v.lower()+'_check',items,['BASE',v])
 edges=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_rs_edge_'+pattern;case(cid,7,197,'float32',pattern);edges.append((cid,7,197,'float32'))
 check(v.lower()+'_edge_check',edges,['BASE',v])
 pairs(v.lower()+'_pairs',small[:3],'BASE',v,blocks=1)
'''
 driver.write_text(text,encoding='utf-8',newline='\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
