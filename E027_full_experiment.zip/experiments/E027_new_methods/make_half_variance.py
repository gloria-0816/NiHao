from pathlib import Path
import hashlib,json,shutil
H=Path(__file__).resolve().parent
base=(H/'FRESLONG/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class PipelineBatch9Kernel {');z=base.index('class BFloatTripleInplaceKernel {',a)
s=base[a:z]
s=s.replace('            const uint32_t parts=stride_/64;\n','')
s=s.replace('stride_=(d+63)/64*64;','stride_=(d+127)/128*128;')
anchor='            const uint32_t active=count*stride_;\n'
assert s.count(anchor)==1;s=s.replace(anchor,anchor+'            const uint32_t parts=stride_/64;\n            bool halfReduced=false;\n')
anchor='                Add(x_[slot],x_[slot],r_[slot],active);PipeBarrier<PIPE_V>();\n'
assert s.count(anchor)==1
s=s.replace(anchor,anchor+'                halfReduced=TryHalfNorm(x_[slot].template ReinterpretCast<half>(),count,active);\n')
anchor='            Mul(tmp_,y_,y_,active); PipeBarrier<PIPE_V>();'
assert s.count(anchor)==1;s=s.replace(anchor,'            if(!halfReduced) {\n'+anchor)
anchor='            Muls(sums_,sums_,invD_,count); PipeBarrier<PIPE_V>();'
assert s.count(anchor)==1;s=s.replace(anchor,'            }\n'+anchor)
helper='''    __aicore__ inline bool TryHalfNorm(LocalTensor<half> input,uint32_t count,uint32_t active) {
        // Each 128-element sum is at most 32768 when |residual| <=16.
        // Wider or nonfinite input uses the original full FP32 square/reduction.
        auto squared=tmp_.template ReinterpretCast<half>();
        auto partial=work_.template ReinterpretCast<half>();
        const uint32_t chunks=active/128,parts=stride_/128;
        Abs(squared,input,active);PipeBarrier<PIPE_V>();
        WholeReduceMax(partial,squared,128,chunks,1,1,8);PipeBarrier<PIPE_V>();
        WholeReduceMax(partial[128],partial,chunks,1,1,1,8);
        SetFlag<HardEvent::V_S>(3);WaitFlag<HardEvent::V_S>(3);
        const float bound=static_cast<float>(partial.GetValue(128));
        if(!(bound<=16.0f))return false;
        Mul(squared,input,input,active);PipeBarrier<PIPE_V>();
        // One partial per 32-byte block keeps all row starts aligned.
        WholeReduceSum(partial,squared,128,chunks,16,1,8);PipeBarrier<PIPE_V>();
        // Half source and float destination overlap here, so use an independent
        // section of tmp_ for the cast before reducing into the existing sums_.
        auto fp=tmp_;
        Cast(fp,partial,RoundMode::CAST_NONE,chunks*16);PipeBarrier<PIPE_V>();
        uint64_t mask[2]={0,0};
        for(uint32_t p=0;p<Min(parts,4);++p)mask[0]|=static_cast<uint64_t>(1)<<(p*16);
        if(parts>4) {
            uint64_t extra[2]={0,0};
            for(uint32_t p=0;p<parts-4;++p)extra[0]|=static_cast<uint64_t>(1)<<(p*16);
            const uint8_t step=static_cast<uint8_t>(parts*2);
            Add(fp,fp,fp[64],extra,count,{1,1,1,step,step,step});PipeBarrier<PIPE_V>();
        }
        WholeReduceSum(sums_,fp,mask,count,1,1,static_cast<uint8_t>(parts*2));PipeBarrier<PIPE_V>();
        return true;
    }
'''
anchor='private:\n    __aicore__ inline uint32_t Min'
assert s.count(anchor)==1;s=s.replace(anchor,'private:\n'+helper+'    __aicore__ inline uint32_t Min')
code=base[:a]+s+base[z:]
dest=H/'HVAR128/code'
if dest.exists() and not (H/'HVAR128_failed_scope').exists():
 shutil.copytree(H/'HVAR128',H/'HVAR128_failed_scope')
shutil.copytree(H/'FRESLONG/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'HVAR128/manifest.json').write_text(json.dumps(dict(variant='HVAR128',parent='FRESLONG',source_sha256=hashlib.sha256(code.encode()).hexdigest(),numerical_change=True,change='FP16 D321..1024 uses bounded native half square and 128-element partial reductions, FP32 partial merge and original FP32 normalization; runtime |residual|<=16 guard with FP32 fallback; rows pad to128'),indent=2)+'\n')
driver=H/'run_round.py';text=driver.read_text(encoding='utf-8')
if "if mode=='hvar':" not in text:
 text+='''
if mode=='hvar':
 items=[small[i] for i in [5,6,7,9]]+[(f'e027_hv_{r}_{d}',r,d,'float16') for r,d in [(161,321),(161,383),(161,397),(161,512),(161,577),(161,1023),(159,577)]]
 check('hvar_check',items,['BASE','HVAR128'])
 edges=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_hv_edge_'+pattern;case(cid,161,577,'float16',pattern);edges.append((cid,161,577,'float16'))
 check('hvar_edge_check',edges,['BASE','HVAR128'])
 pairs('hvar_pairs',[small[i] for i in [5,6,7,9]],'BASE','HVAR128',blocks=1)
'''
 driver.write_text(text,encoding='utf-8',newline='\n')
print(hashlib.sha256(code.encode()).hexdigest())
