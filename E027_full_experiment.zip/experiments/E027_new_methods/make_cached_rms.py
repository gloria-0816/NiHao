from pathlib import Path
import hashlib,json,shutil,re
H=Path(__file__).resolve().parent
def change_section(code,start,end,offset,n):
 a=code.index(start);z=code.index(end,a+len(start));s=code[a:z]
 init=f'''
        // These constant vectors survive all reduction and broadcast writes.
        auto cachedInv=work_[{offset}];auto cachedEps=work_[{offset+n}];auto cachedOne=work_[{offset+2*n}];
        Duplicate(cachedInv,invD_,{n});Duplicate(cachedEps,eps_,{n});Duplicate(cachedOne,1.0f,{n});
        PipeBarrier<PIPE_V>();
'''
 s,k=re.subn(r'(    __aicore__ inline void Process\(\)\s*\{)',lambda m:m.group(1)+init,s,count=1);assert k==1
 s,k=re.subn(r'Muls\(sums_,sums_,invD_,count\);\s*PipeBarrier<PIPE_V>\(\);\s*Adds\(sums_,sums_,eps_,count\);','FusedMulAdd(sums_,cachedInv,cachedEps,count);',s);assert k==1
 s,k=re.subn(r'Sqrt\(sums_,sums_,count\);\s*Duplicate\(work_,1\.0f,count\);\s*PipeBarrier<PIPE_V>\(\);\s*Div\(sums_,work_,sums_,count\);','Sqrt(sums_,sums_,count);PipeBarrier<PIPE_V>();\n            Div(sums_,cachedOne,sums_,count);',s);assert k==1
 return code[:a]+s+code[z:]
for parent,name in [('FRESLONG','RMSCF'),('HFAST128','HFRMSCF')]:
 code=(H/parent/'code/kernel.asc').read_text(encoding='utf-8')
 code=change_section(code,'class PipelineBatch9Kernel {','class BFloatTripleInplaceKernel {',1856,32)
 code=change_section(code,'class FloatBroadTripleKernel {','class HalfWidePipelineKernel {',1280,8)
 if parent=='HFAST128':code=change_section(code,'class FastHalfVarianceKernel {','class PipelineBatch9Kernel {',1856,32)
 a=code.index('class StaticHalfRowsKernel {');z=code.index('class ShortFloatPartitionKernel {',a);s=code[a:z]
 anchor='        SetFlag<HardEvent::MTE2_V>(0); WaitFlag<HardEvent::MTE2_V>(0);'
 assert s.count(anchor)==1;s=s.replace(anchor,'        Duplicate(gamma_,eps_,(count_+7)/8*8);\n'+anchor)
 s,k=re.subn(r'Muls\(sums_,sums_,invD_,rms\);\s*PipeBarrier<PIPE_V>\(\);\s*Adds\(sums_,sums_,eps_,rms\);','Axpy(gamma_,sums_,invD_,rms);',s);assert k==1
 s=s.replace('Sqrt(sums_,sums_,rms);','Sqrt(gamma_,gamma_,rms);').replace('Div(sums_,work_,sums_,rms);','Div(gamma_,work_,gamma_,rms);').replace('Cast(scales,sums_,RoundMode::CAST_RINT,count_);','Cast(scales,gamma_,RoundMode::CAST_RINT,count_);')
 code=code[:a]+s+code[z:]
 dest=H/name/'code';shutil.copytree(H/parent/'code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent=parent,source_sha256=hashlib.sha256(code.encode()).hexdigest(),numerical_change=True,change='Cache inverseD/epsilon/one vectors outside batch reductions, fuse mean+epsilon with FP32 FMA, and prefill epsilon for Axpy in native short-half partition',reference='https://www.hiascend.com/document/detail/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0063.html'),indent=2)+'\n')
 print(name,hashlib.sha256(code.encode()).hexdigest())
driver=H/'run_round.py';text=driver.read_text(encoding='utf-8')
if "if mode=='cached_rms':" not in text:
 text+='''
if mode=='cached_rms':
 v=sys.argv[2];assert v in ['RMSCF','HFRMSCF']
 check(v.lower()+'_check',small,['BASE',v])
 pairs(v.lower()+'_pairs',[small[i] for i in [3,5,7,10]],'BASE',v,blocks=1)
'''
 driver.write_text(text,encoding='utf-8',newline='\n')
