from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'BASE/code/kernel.asc').read_text(encoding='utf-8')
implementation='''
__global__ __vector__ void library_short_float_custom(
    GM_ADDR x,GM_ADDR r,GM_ADDR g,GM_ADDR b,GM_ADDR o,
    uint64_t rows,uint32_t d,float eps) {
    InitSocState();
    const uint32_t count=static_cast<uint32_t>(rows/GetBlockNum());
    const uint32_t n=count*d;
    const uint64_t offset=static_cast<uint64_t>(GetBlockIdx())*n;
    GlobalTensor<float> xgm,rgm,ggm,bgm,ogm;
    xgm.SetGlobalBuffer((__gm__ float*)x);
    rgm.SetGlobalBuffer((__gm__ float*)r);
    ggm.SetGlobalBuffer((__gm__ float*)g);
    bgm.SetGlobalBuffer((__gm__ float*)b);
    ogm.SetGlobalBuffer((__gm__ float*)o);
    LocalTensor<float> input(TPosition::VECIN,0,8192);
    LocalTensor<float> output(TPosition::VECOUT,32768,8192);
    LocalTensor<float> gamma(TPosition::VECIN,65536,512);
    LocalTensor<float> bias(TPosition::VECIN,67584,512);
    LocalTensor<uint8_t> scratch(TPosition::VECCALC,69632,126976);
    DataCopy(input,xgm[offset],n);
    DataCopy(output,rgm[offset],n);
    DataCopy(gamma,ggm,d);DataCopy(bias,bgm,d);
    SetFlag<HardEvent::MTE2_V>(0);WaitFlag<HardEvent::MTE2_V>(0);
    Add(input,input,output,n);PipeBarrier<PIPE_V>();
    RmsNormTiling tiling={};
    tiling.bLength=1;tiling.sLength=count;tiling.hLength=d;
    tiling.originalHLength=d;tiling.reciprocalOfHLength=1.0f/d;
    tiling.mainBshLength=n;tiling.mainBsLength=count;
    tiling.mainBsLengthAlign=count;tiling.loopRound=1;
    tiling.inputTailPos=n;tiling.tailBshLength=0;tiling.tailBsLength=0;
    RmsNorm<float,true>(output,input,gamma,scratch,eps,tiling);
    PipeBarrier<PIPE_V>();
    for(uint32_t col=0;col<d;col+=64)
        Add(output[col],output[col],bias[col],64,count,
            {1,1,1,static_cast<uint8_t>(d/8),static_cast<uint8_t>(d/8),0});
    PipeBarrier<PIPE_V>();
    SetFlag<HardEvent::V_MTE3>(0);WaitFlag<HardEvent::V_MTE3>(0);
    DataCopy(ogm[offset],output,n);
    PipeBarrier<PIPE_ALL>();
}

'''
code=base.replace('#include "kernel_operator.h"','#include "kernel_operator.h"\n#include "lib/rmsnorm/rmsnorm.h"',1)
anchor='} // namespace addrmsnormbias_solution'
assert code.count(anchor)==1;code=code.replace(anchor,implementation+anchor)
anchor='    const uint32_t shortFloatCores=blockNum<8?blockNum:8;'
guard='''
    if(input.dtype==0 && d>=64 && d<=512 && d%64==0 &&
       rows%shortFloatCores==0 && (rows/shortFloatCores)%8==0 &&
       rows/shortFloatCores*d<=8192 && rows>=static_cast<uint64_t>(blockNum)*2) {
        library_short_float_custom<<<shortFloatCores,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,epsilon);
        return;
    }
'''
assert code.count(anchor)==1;code=code.replace(anchor,anchor+guard)
dest=H/'LIBRARY/code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
manifest=dict(variant='LIBRARY',parent='FACC',source_sha256=hashlib.sha256(code.encode()).hexdigest(),
    numerical_change=True,change='CANN9 RmsNorm<float,true> replaces manual RMS pipeline for aligned FP32 short partitions; beta added on NPU',
    guards='D64..512 multiple64; per-core rows multiple8; partition <=8192 floats',
    reference='https://asc.gitcode.com/api/SIMD-API/adv_api/normalization/RmsNorm.html')
(H/'LIBRARY/manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='library'" not in s:
    s+='''
if mode=='library':
 items=[small[2]]+[(f'e027_lib_{r}_{d}',r,d,'float32') for r,d in [(128,64),(128,128),(256,256),(128,512),(161,256),(128,255)]]
 check('library_check',items,['BASE','LIBRARY'])
 pairs('library_pairs',[small[2]],'BASE','LIBRARY',blocks=2)
'''
    p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_library.tar.gz','w:gz') as t:
    for q in [H/'LIBRARY',p]:t.add(q,arcname=q.relative_to(H.parents[1]))
print(manifest['source_sha256'])
