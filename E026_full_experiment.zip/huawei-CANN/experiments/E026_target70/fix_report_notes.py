from pathlib import Path
H=Path(__file__).resolve().parent
p=H/'update_report.py';s=p.read_text(encoding='utf-8')
old='- CACHEIN/CACHEALL：大张量流式输入/输出配置 L2 bypass；参数继续缓存。新建超出缓存容量的 BF16 输入检查，避免只根据小输入外推。'
new='- CACHEIN/CACHEALL：编译通过，FP32 大场景输出检查通过。随后大 BF16 测试因 [1,524288,128] 的序列维度越界退出，未产生缓存性能结论。检查已安装 CANN 的 L2CacheAlter 实现及编译标志后，发现 Kernel 直调工程没有 L2_CACHE_HINT，SetL2CacheHint 在当前工程不改变访问；因此终止这个候选方向，不声称实现了 L2 bypass。'
assert old in s;s=s.replace(old,new)
old='(H/\'报告.md\').write_text(\'\\n\'.join(lines),encoding=\'utf-8\')'
new="notes=H/'phase_notes.md'\nif notes.exists():lines += ['', notes.read_text(encoding='utf-8')]\n"+old
assert old in s;s=s.replace(old,new)
p.write_text(s,encoding='utf-8',newline='\n')
print('updated report explanation')
