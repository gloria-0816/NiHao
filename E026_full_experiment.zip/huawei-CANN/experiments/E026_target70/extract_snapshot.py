from pathlib import Path
import tarfile,hashlib,json,sys
H=Path(__file__).resolve().parent;dest=H/'cloud_results';dest.mkdir(exist_ok=True)
archive=Path(sys.argv[1]) if len(sys.argv)>1 else H/'E026_snapshot_20261012_0308.tar.gz'
with tarfile.open(archive,'r:gz') as tar:
    manifest=json.load(tar.extractfile('_snapshot_manifest.json'))
    records={x['path']:x for x in manifest['files']}
    changed=unchanged=0
    for member in tar:
        if member.name=='_snapshot_manifest.json':continue
        info=records[member.name];data=tar.extractfile(member).read()
        assert len(data)==info['bytes'] and hashlib.sha256(data).hexdigest()==info['sha256'],member.name
        target=(dest/member.name).resolve();assert target.is_relative_to(dest.resolve())
        if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest()==info['sha256']:
            unchanged+=1;continue
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);changed+=1
    (H/(archive.stem.removesuffix('.tar')+'_manifest.json')).write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(files=len(records),written=changed,unchanged=unchanged,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest())))
