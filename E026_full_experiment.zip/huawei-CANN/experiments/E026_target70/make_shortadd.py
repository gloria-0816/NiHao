from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent;base=(H/'COMBO2/code/kernel.asc').read_text()
a=base.index('class StaticHalfRowsKernel {');z=base.index('__global__ __vector__ void static_half_rows_custom',a);s=base[a:z]
old='''        ToFloat<half>(y_,x_,active); ToFloat<half>(tmp_,r_,active);'''
new='''        Add(x_,x_,r_,active);PipeBarrier<PIPE_V>();
        ToFloat<half>(y_,x_,active);'''
assert old in s;s=s.replace(old,new,1)
s=s.replace('        Add(y_,y_,tmp_,active); PipeBarrier<PIPE_V>();','',1)
code=base[:a]+s+base[z:]
name='SHORTADD';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'COMBO2','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'native FP16 residual addition for short rows; FP32 norm and affine unchanged','numerical_change':True},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='shortaddquick'" not in s:
 s+='''
if mode=='shortaddquick':
 check('shortadd_check',[small[3],('flath_65',767,65,'float16'),('flath_255',767,255,'float16')],['COMBO2','SHORTADD'])
 pairs('shortadd_pairs',[small[3]],'COMBO2','SHORTADD',blocks=2)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
