from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'BFPN4/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class PipelineBatch9Kernel {');z=base.index('template <typename T,bool BlockReduction>',a)
s=base[a:z]
anchor='            if(BlockReduction) {'
new='''            if(!CompactParameterType<T>::value && d_==128) {
                // Fold adjacent 32-byte blocks, retaining every second block.
                Add(tmp_,tmp_,tmp_[8],64,count,{2,2,2,16,16,16});PipeBarrier<PIPE_V>();
                WholeReduceSum(sums_,tmp_,64,count,1,2,16);
            } else if(BlockReduction) {'''
assert s.count(anchor)==1;s=s.replace(anchor,new)
code=base[:a]+s+base[z:]
name='TREE128';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFPN4',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='BF16 D128 FP32 square reduction folds adjacent 32-byte blocks then WholeReduceSum with source block stride two; no partial-result scratch stage',numerical_change=True),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='tree128quick'" not in s:
 s+='''
if mode=='tree128quick':
 items=[small[13],('tree128_321',321,128,'bfloat16'),('tree128_4097',4097,128,'bfloat16')]
 check('tree128_check',items,['BFPN4','TREE128'])
 pairs('tree128_pairs',[small[13]],'BFPN4','TREE128',blocks=1)
if mode=='tree128large':
 items=[('bf128s_large',524288,128,'bfloat16')]
 check('tree128_large_check',items,['BFPN4','TREE128'])
 pairs('tree128_large_pairs',items,'BFPN4','TREE128',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_tree128.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
