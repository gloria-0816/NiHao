from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent;base=(H/'COMBO2/code/kernel.asc').read_text()
a=base.index('class PipelineBatch9Kernel {');z=base.index('template <typename T,bool BlockReduction>',a)
s=base[a:z].replace('PipelineBatch9Kernel','HalfRecastBatchKernel').replace('batch_=9408/stride_;','batch_=12288/stride_;')
ia=s.index('        x_[0]=LocalTensor');iz=s.index('    }\n    __aicore__ inline void Process()',ia)
s=s[:ia]+'''        x_[0]=LocalTensor<T>(TPosition::VECIN,0,12288);
        x_[1]=LocalTensor<T>(TPosition::VECIN,24704,12288);
        r_[0]=LocalTensor<T>(TPosition::VECIN,49408,12288);
        r_[1]=LocalTensor<T>(TPosition::VECIN,74112,12288);
        y_=LocalTensor<float>(TPosition::VECCALC,98816,12288);
        tmp_=y_; // Square in place; retain the FP16 sum until the second Cast.
        out_=LocalTensor<T>(TPosition::VECOUT,148096,12288);
        gamma_=LocalTensor<float>(TPosition::VECCALC,172800,1024);
        bias_=LocalTensor<float>(TPosition::VECCALC,177024,1024);
        gh_=LocalTensor<T>(TPosition::VECIN,181248,1024);
        bh_=LocalTensor<T>(TPosition::VECIN,183424,1024);
        work_=LocalTensor<float>(TPosition::VECCALC,185600,1536);
        sums_=LocalTensor<float>(TPosition::VECCALC,191872,128);
'''+s[iz:]
ia=s.index('            // This slot is only overwritten after both Cast source reads end.')
iz=s.index('            if(!CompactParameterType<T>::value)',ia)
prefetch=s[ia:iz]
s=s[:ia]+s[iz:]
anchor='            if(count<=parts) {'
extra='''            ToFloat<T>(y_,x_[slot],active);PipeBarrier<PIPE_V>();
'''+prefetch.replace('            // This slot is only overwritten after both Cast source reads end.','            // Refill only after the retained half sum has been converted again.')
assert anchor in s;s=s.replace(anchor,extra+anchor,1)
s='template <typename T,bool BlockReduction>\n'+s
s+='''template <typename T,bool BlockReduction>
__global__ __vector__ void half_recast_batch_custom(GM_ADDR x,GM_ADDR r,GM_ADDR g,GM_ADDR b,GM_ADDR out,
    uint64_t rows,uint32_t d,float invD,float eps)
{
    InitSocState();HalfRecastBatchKernel<T,BlockReduction> op;op.Init(x,r,g,b,out,rows,d,invD,eps);op.Process();
}
'''
(H/'half_recast.inc').write_text(s,encoding='utf-8',newline='\n')
code=base.replace('class StaticHalfRowsKernel {',s+'\nclass StaticHalfRowsKernel {',1)
anchor='    if (rows >= static_cast<uint64_t>(blockNum)*4 && ((input.dtype==1'
launch='''    if(input.dtype==1 && d>=321 && d<=1024 && rows>=static_cast<uint64_t>(blockNum)*4) {
        half_recast_batch_custom<half,true><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert anchor in code;code=code.replace(anchor,launch+anchor,1)
name='RECAST';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'COMBO2','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'retain FP16 sum; reuse one FP32 buffer for squared sum and normalization; batch capacity 12288','ub_end_bytes':192384},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='recastquick'" not in s:
 s+='''
if mode=='recastquick':
 check('recast_check',[small[i] for i in [5,6,7,9]],['COMBO2','RECAST'])
 pairs('recast_pairs',[small[i] for i in [5,6,7,9]],'COMBO2','RECAST',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
