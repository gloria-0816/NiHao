from pathlib import Path
import json,re,hashlib
H=Path(__file__).resolve().parent
variants=[]
for p in sorted(H.glob('*/manifest.json')):
 x=json.loads(p.read_text());source=p.parent/'code/kernel.asc'
 if source.exists():
  assert hashlib.sha256(source.read_bytes()).hexdigest()==x['source_sha256'],p
  variants.append(x)
official=[]
for p in sorted(H.glob('*/official_dom.txt')):
 text=p.read_text(encoding='utf-8');sid=re.search(r'提交 ID：(\d+)',text);rows=re.findall(r'row "(\d+) (Pass|Failed|Wrong Answer) ([\d.]+%) ([\d.]+)(μs|ms) ([\d.]+)(μs|ms)"',text)
 record={'variant':p.parent.name,'submission_id':int(sid.group(1)) if sid else None,'points':[dict(case=int(n),status=s,error=err,time_us=float(t)*(1000 if unit=='ms' else 1),tbest_us=float(b)*(1000 if bu=='ms' else 1)) for n,s,err,t,unit,b,bu in rows]}
 rank=p.parent/'ranking_dom.txt'
 if rank.exists():
  line=rank.read_text(encoding='utf-8');m=re.search(r'row "(\d+) 我 ttal6688 的队伍 gem_1210 Pass ([\d.]+) ',line)
  if m:record.update(score=float(m.group(2)),observed_rank=int(m.group(1)))
 official.append(record)
(H/'official_results.json').write_text(json.dumps(official,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(H/'source_inventory.json').write_text(json.dumps(variants,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
best=max((x for x in official if 'score' in x and len(x['points'])==15 and all(p['status']=='Pass' for p in x['points'])),key=lambda x:x['score'],default=None)
state=json.loads((H/'stop_state.json').read_text(encoding='utf-8')) if (H/'stop_state.json').exists() else {}
status='用户要求本轮评分后停止，现已停止实验；70 分目标未达成。' if state.get('stopped') else '当前目标仍在执行，未宣告达成。'
lines=['# E026：70 分目标优化记录','','目标：比赛完整提交 ≥70 分。'+status]
if best:lines+=['',f"当前历史最好完整提交：{best['variant']}，{best['score']} 分，提交 {best['submission_id']}，观察排名 {best['observed_rank']}。"]
lines+=['','比赛结果：','', '|版本|提交 ID|分数|观察排名|通过点数|','|---|---:|---:|---:|---:|']
for x in official:lines.append(f"|{x['variant']}|{x['submission_id']}|{x.get('score','待刷新排行榜')}|{x.get('observed_rank','')}|{sum(p['status']=='Pass' for p in x['points'])}/15|")
lines+=['','云机使用 Ascend 910B3、CANN 9.0.0，40 个向量核。输入为可复现的代表性场景；官方隐藏输入形状未直接披露，不把代理场景视为隐藏数据。每个性能比较使用 BASE/CAND/CAND/BASE 交错顺序，普通 msprof 任务用时中位数。','','云机 strict 检查要求所有元素通过，和比赛工程脚本的 mismatch fraction ≤0.001 不同。HALFAFF2 有少量 strict 超差，但比赛完整 15/15 Pass；不能把 strict 未通过自动写成官方失败，也不能把官方错误占比四舍五入为 0.00% 当作逐位相同。BF16 代理输入有基线继承的严格误差失败，所有原始记录保留。','', '|对照组|场景|基线 μs|候选 μs|变化（正为提速）|','|---|---|---|---|---:|']
cloud=H/'cloud_results'
for p in sorted(cloud.glob('*/summary.json')):
 obj=json.loads(p.read_text())
 for cid,r in obj.items():
  if 'gain_pct' in r:lines.append(f"|{p.parent.name}|{cid}|{r['base_us']}|{r['candidate_us']}|{r['gain_pct']:+.2f}%|")
lines+=['','修改与取舍：','', '- COMBO1：短 FP16 使用 BlockReduceSum；宽行按批内行数与列块数选择归一化循环方向。15 个云机代表输入与 DB9 输出逐位一致，官方 15/15 Pass。','- SHORT8B/16B/32B：少量 FP32 短行减少启动核数，每核整体批处理。原 SHORT8/16/32 有静态 UB 地址生成错误，修正版本另存，原日志不覆盖。','- FPSTATIC2/3：FP32 宽行静态缓冲与直接输出；3 版共用残差缓冲提高批次容量。原 FPSTATIC 非对齐尾部 repeat stride 超过 8 位，修正版逐行清零。','- FLATDMA：对齐行批次连续搬运，测量变化接近噪声。','- RES1：共用残差缓冲区扩大批量，半精度主要场景回退，不采用。','- LONGACC：并行静态长行平方和跨块累加有明显数据错误；LONGACC2 串行版正确但慢约 48%，不采用。','- RETACC/RETACC2：从已验证队列内核尝试跨块累加与参数提前预取；RETACC 缺失模板声明编译失败，修正版及结果单独保留。','- COMBO2/HALFADD：FP16 原生残差加法后再转 FP32。官方 15/15 Pass、60.17 分。','- HALFAFF/HALFAFF2：FP32 RMS 后转 FP16，原生 FMA 融合缩放与偏置。HALFAFF 的 BF16 模板编译检查失败；2 版修复并官方 15/15 Pass、60.97 分。','- COMBOA：合并长行跨核、单行重叠、短行加法、FP32 静态批次及 D512 recast。官方 15/15 Pass、60.64 分；未取代 HALFAFF2 最佳版。云机局部收益没有完全转化成官方收益。','- AUTOV：减少显式 PIPE_V 屏障，保留跨流水事件和终结屏障，15 代理场景与 HALFAFF2 逐位相同；性能实验仍需实测筛选。','- FPBROAD/HALFWIDE：扩大已验证算法的实际形状覆盖范围，新增边界验证。','- CACHEIN/CACHEALL：编译通过，FP32 大场景输出检查通过。随后大 BF16 测试因 [1,524288,128] 的序列维度越界退出，未产生缓存性能结论。检查已安装 CANN 的 L2CacheAlter 实现及编译标志后，发现 Kernel 直调工程没有 L2_CACHE_HINT，SetL2CacheHint 在当前工程不改变访问；因此终止这个候选方向，不声称实现了 L2 bypass。','','资料依据：','', '- [低延迟归约指令](https://asc.gitcode.com/guide/operator_practice/simd_operator_optimization/vector_compute/low_latency_instruction.html)：结合数据大小比较分块归约、整块归约与二分加法。','- [A2/2201 UB bank 冲突](https://asc.gitcode.com/guide/operator_practice/simd_operator_optimization/memory_access/avoid_ub_bank_conflict/avoid_bank_conflict_npu_arch_2201.html)：按实际 A2 内存结构处理，未套用 950 内存布局。','- [全局掩码复用](https://asc.gitcode.com/guide/operator_practice/simd_operator_optimization/vector_compute/vector_counter_mode.html)：独立实验 MASK64B/MASKBATCH 没有整体明显收益。','- [非对齐场景](https://asc.gitcode.com/guide/operator_practice/simd_operator_impl/vector_programming/unaligned_scenario.html)：GatherMask 打包与平坦输入实验都保留实际回退结果。','- [PipeBarrier 与自动同步](https://www.hiascend.com/doc_center/source/zh/canncommercial/850/API/ascendcopapi/atlasascendc_api_07_0271.html)：实际输出校验支持自动向量依赖实验；不删除搬运事件。','- [A2 L2 CacheMode](https://www.hiascend.com/doc_center/source/en/CANNCommunityEdition/900/programug/Ascendcopdevg/atlas_ascendc_best_practices_10_00014.html)：只访问一次的大数据可绕过 L2，实际收益由同一输入配对测量确定。','','完整源码和 SHA-256 在 source_inventory.json；网站结果 DOM、截图在各候选目录；云机原始 JSON/CSV/日志存放于 cloud_results，并有独立压缩包清单。当前 E026 记录保存在本机，尚未声称已上传 GitHub。','']
notes=H/'phase_notes.md'
if notes.exists():lines += ['', notes.read_text(encoding='utf-8')]
round_notes=H/'handoff_round_notes.md'
if round_notes.exists():lines += ['',round_notes.read_text(encoding='utf-8')]
lines=[line.replace('当前 E026 记录保存在本机，尚未声称已上传 GitHub。','上传交接包时包含本报告，发布确认见 GitHub 提交和本机截图。') for line in lines]
(H/'报告.md').write_text('\n'.join(lines),encoding='utf-8')
print(json.dumps({'variants':len(variants),'official_submissions':len(official),'best':dict(variant=best['variant'],score=best['score'],submission_id=best['submission_id']) if best else None},ensure_ascii=False))
