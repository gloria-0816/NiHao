from pathlib import Path
import json, hashlib, shutil, tarfile
H = Path(__file__).resolve().parent
parent = (H/'PAIRACC/code/kernel.asc').read_text(encoding='utf-8')
old_guard = 'rows<=static_cast<uint64_t>(availableCoreNum)/2'
assert parent.count(old_guard)==1
for name, code, change in [
    ('PAIRSINGLE', parent.replace(old_guard, 'rows==1'),
     'Enable verified PAIRACC only for a single aligned FP16 long row; retain FACC fallback for all multiple-row inputs'),
    ('PAIRASY', parent.replace('CrossCoreSetFlag<1,PIPE_MTE2>(9);CrossCoreWaitFlag(9);',
                             'CrossCoreSetFlag<1,PIPE_MTE2>(9);')
                      .replace('DataCopy(ogm_[off],x_,n_);PipeBarrier<PIPE_ALL>();',
                               'CrossCoreWaitFlag(9);DataCopy(ogm_[off],x_,n_);PipeBarrier<PIPE_ALL>();'),
     'Overlap second paired read-completion synchronization with local RMS and affine computation; preserve wait before final output overwrite')
]:
    dest=H/name/'code'; shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
    if name=='PAIRASY':
        assert code!=parent and code.count('CrossCoreWaitFlag(9);')==1
    (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
    sha=hashlib.sha256(code.encode()).hexdigest()
    (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='PAIRACC',source_sha256=sha,change=change,static_ub_end=164352,numerical_change=False),indent=2)+'\n')
    print(name,sha)
p=H/'run_round.py'; s=p.read_text(encoding='utf-8')
if "mode=='pairasyncquick'" not in s:
    s+='''
if mode=='pairasyncquick':
 items=[('split_one',1,32768,'float16'),('pairsingle_1_16384',1,16384,'float16'),('pairsingle_1_24576',1,24576,'float16'),small[4],('split_two',2,16384,'float16'),('sync2_8448',3,8448,'float16'),('sync2_24576',20,24576,'float16'),('sync2_fallback',21,32768,'float16')]
 check('pairasync_check',items,['FACC','PAIRSINGLE','PAIRASY'])
 pairs('pairasync_pairs',[items[0],items[1],items[2],small[4]],'PAIRACC','PAIRASY',blocks=1)
if mode=='pairasyncedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  for r in [1,8]:
   cid='pairasync_edge_'+str(r)+'_'+pattern;case(cid,r,32768,'float16',pattern);items.append((cid,r,32768,'float16'))
 check('pairasync_edge_check',items,['FACC','PAIRSINGLE','PAIRASY'])
if mode=='pairsingleboundary':
 items=[('pairbound_'+str(d),1,d,'float16') for d in [8192,8193,8320,8448,12288,16256,16512,24575,24576,32640,32768]]
 check('pairsingle_boundary_check',items,['FACC','PAIRSINGLE','PAIRASY'])
 pairs('pairsingle_confirm_pairs', [('pairsingle_1_16384',1,16384,'float16'),('pairsingle_1_24576',1,24576,'float16'),('pairsingle_1_32768',1,32768,'float16')],'FACC','PAIRSINGLE',blocks=2)
'''
    p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_pairasync.tar.gz','w:gz') as t:
    for q in [H/'PAIRSINGLE',H/'PAIRASY',p]:t.add(q,arcname=q.relative_to(H.parents[1]))
