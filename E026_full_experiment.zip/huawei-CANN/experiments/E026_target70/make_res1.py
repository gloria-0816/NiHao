from pathlib import Path
import json,hashlib,shutil,re
H=Path(__file__).resolve().parent;base=(H/'COMBO1/code/kernel.asc').read_text()
a=base.index('class PipelineBatch9Kernel {');z=base.index('template <typename T,bool BlockReduction>',a);s=base[a:z]
s=s.replace('batch_=9408/stride_;','batch_=11008/stride_;')
ia=s.index('        x_[0]=LocalTensor');iz=s.index('    }\n    __aicore__ inline void Process()',ia)
s=s[:ia]+'''        x_[0]=LocalTensor<T>(TPosition::VECIN,0,11008);
        x_[1]=LocalTensor<T>(TPosition::VECIN,22144,11008);
        r_=LocalTensor<T>(TPosition::VECIN,44288,11008);
        y_=LocalTensor<float>(TPosition::VECCALC,66432,11008);
        tmp_=LocalTensor<float>(TPosition::VECCALC,110592,11008);
        out_=LocalTensor<T>(TPosition::VECOUT,154752,11008);
        gamma_=LocalTensor<float>(TPosition::VECCALC,176896,1024);
        bias_=LocalTensor<float>(TPosition::VECCALC,181120,1024);
        gh_=LocalTensor<T>(TPosition::VECIN,185344,1024);
        bh_=LocalTensor<T>(TPosition::VECIN,187520,1024);
        work_=LocalTensor<float>(TPosition::VECCALC,189696,1376);
        sums_=LocalTensor<float>(TPosition::VECCALC,195328,128);
'''+s[iz:]
s=s.replace('        Prefetch(begin_,0);','        Prefetch(begin_,0);PrefetchR(begin_);',1)
s=s.replace('            WaitFlag<HardEvent::MTE2_V>(slot);','            WaitFlag<HardEvent::MTE2_V>(slot);WaitFlag<HardEvent::MTE2_V>(2);',1)
s=s.replace('ToFloat<T>(tmp_,r_[slot],active);','ToFloat<T>(tmp_,r_,active);',1)
anchor='            // This slot is only overwritten after both Cast source reads end.'
extra='''            // The one residual tile is released after its Cast reads finish.
            if(row+batch_<end_) {
                SetFlag<HardEvent::V_MTE2>(2);WaitFlag<HardEvent::V_MTE2>(2);
                PrefetchR(row+batch_);
            }
'''
assert anchor in s;s=s.replace(anchor,extra+anchor,1)
s=s.replace('        DataCopyPad(r_[slot],rgm_[row*d_],copy,pad);\n','',1)
anchor='    GlobalTensor<T> xgm_,rgm_,ggm_,bgm_,outgm_;'
extra='''    __aicore__ inline void PrefetchR(uint64_t row)
    {
        const uint32_t count=Min(batch_,static_cast<uint32_t>(end_-row));
        DataCopyExtParams copy={static_cast<uint16_t>(count),static_cast<uint32_t>(d_*sizeof(T)),0,Gap(),0};
        DataCopyPadExtParams<T> pad={};pad.isPad=false;
        DataCopyPad(r_,rgm_[row*d_],copy,pad);SetFlag<HardEvent::MTE2_V>(2);
    }
'''
assert anchor in s;s=s.replace(anchor,extra+anchor,1)
s=s.replace('LocalTensor<T> x_[2],r_[2],out_,gh_,bh_;','LocalTensor<T> x_[2],r_,out_,gh_,bh_;',1)
assert 'r_[slot]' not in s and 'r_[1]' not in s
code=base[:a]+s+base[z:];name='RES1';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'COMBO1','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'capacity_elements':11008,'ub_end_bytes':195840},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='res1quick'" not in s:
 s+='''
if mode=='res1quick':
 check('res1_check',[small[i] for i in [5,6,7,9,13]],['COMBO1','RES1'])
 pairs('res1_pairs',[small[i] for i in [5,6,7,9,13]],'COMBO1','RES1',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
