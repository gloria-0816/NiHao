from pathlib import Path
import json,statistics,math
H=Path(__file__).resolve().parent
official=json.loads((H/'official_results.json').read_text(encoding='utf-8'))
for r in official:
 if r['variant'] in ['FACC','FWACC','FDACC','LSQM']:
  ratios=[p['tbest_us']/p['time_us'] for p in r['points']]
  scores=[100/(1+math.log(1/x,1.5)) for x in ratios]
  print(r['variant'],r.get('score'),dict(formula=statistics.mean(scores),linear=100*statistics.mean(ratios),squared=100*statistics.mean(x*x for x in ratios),geometric=100*math.exp(statistics.mean(math.log(x) for x in ratios))))
  if r['variant']=='FACC':
   priority=[]
   for point,score in zip(r['points'],scores):
    reduced=max(point['time_us']*.9,point['tbest_us'])
    next_score=100/(1+math.log(reduced/point['tbest_us'],1.5))
    priority.append(dict(case=point['case'],time_us=point['time_us'],tbest_us=point['tbest_us'],point_score=score,total_gain_if_10pct_faster=(next_score-score)/15))
   priority.sort(key=lambda p:p['total_gain_if_10pct_faster'],reverse=True)
   (H/'score_priorities.json').write_text(json.dumps(dict(formula='mean(100/(1+log_1.5(t/TBest)))',observed_score=r.get('score'),calculated_score=statistics.mean(scores),points=priority),indent=2)+'\n',encoding='utf-8')
   print(json.dumps(priority,indent=2))
