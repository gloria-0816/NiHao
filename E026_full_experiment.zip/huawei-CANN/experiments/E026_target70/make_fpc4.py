from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'BROAD3/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class FloatBroadTripleKernel {');z=base.index('template <typename T,bool BlockReduction>',a)
s=base[a:z].replace('batch_=12288/stride_','batch_=12800/stride_')
replacements={'VECIN,0,12288':'VECIN,0,12800','49280,12288':'51328,12800','98560,12288':'102656,12800','147840,4096':'153984,4096','164352,4096':'170496,4096','180864,1536':'187008,1600','187136,32':'193536,32'}
for old,new in replacements.items():
 assert s.count(old)==1,(old,s.count(old));s=s.replace(old,new)
code=base[:a]+s+base[z:]
name='FPC4';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BROAD3',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='Increase FP32 static triple-buffer capacity from 12288 to 12800 elements; four instead of three padded 3136-element rows; preserve math and events',numerical_change=False,ub_end_bytes=193664),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='fpc4quick'" not in s:
 s+='''
if mode=='fpc4quick':
 items=[small[10],small[12]]+[('fpc4_'+str(d),321,d,'float32') for d in [1537,2048,3136,3200,4095,4096]]
 check('fpc4_check',items,['BROAD3','FPC4'])
 pairs('fpc4_pairs',[small[10],small[12]],'BROAD3','FPC4',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_fpc4.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
