from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'BFSIP/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('__global__ __vector__ void single_row_64_custom');z=base.index('template <typename T>\n__global__ __vector__ void single_row_custom',a)
s=base[a:z]
old='''    WaitFlag<HardEvent::MTE2_V>(1);
    if(sizeof(T)!=sizeof(float)) {
        ToFloat<T>(gf,gt,64);ToFloat<T>(bf,bt,64);PipeBarrier<PIPE_V>();
    }
'''
assert s.count(old)==1
s=s.replace(old,'    if(sizeof(T)==sizeof(float)) WaitFlag<HardEvent::MTE2_V>(1);\n')
anchor='    WholeReduceSum(sum, tmp, 64, 1, 1, 1, 8);\n'
assert s.count(anchor)==1
s=s.replace(anchor,anchor+'''    // Independent parameter casts fill the first reduction's latency.
    if(sizeof(T)!=sizeof(float)) {
        WaitFlag<HardEvent::MTE2_V>(1);
        ToFloat<T>(gf,gt,64);ToFloat<T>(bf,bt,64);
    }
''')
code=base[:a]+s+base[z:]
dest=H/'PAR64/code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
sha=hashlib.sha256(code.encode()).hexdigest()
(H/'PAR64/manifest.json').write_text(json.dumps(dict(variant='PAR64',parent='BFSIP',source_sha256=sha,
 change='D64 single-row half/BF16 gamma/bias conversion issued between first WholeReduceSum and its barrier; independent vector work overlaps reduction latency',numerical_change=False),indent=2)+'\n')
p=H/'run_round.py';q=p.read_text(encoding='utf-8')
if "mode=='par64quick'" not in q:
 q+='''
if mode=='par64quick':
 items=[small[0],('m64_float',1,64,'float32'),('m64_bf16',1,64,'bfloat16')]
 check('par64_check',items,['BFSIP','PAR64'])
 pairs('par64_pairs',items,'BFSIP','PAR64',blocks=1)
'''
 p.write_text(q,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_par64.tar.gz','w:gz') as tar:
 for target in [H/'PAR64',p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(sha)
