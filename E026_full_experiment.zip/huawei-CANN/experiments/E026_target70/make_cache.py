from pathlib import Path
import re,json,hashlib,shutil
H=Path(__file__).resolve().parent
base=(H/'HALFAFF2/code/kernel.asc').read_text()
rx=re.compile(r'(\b(\w+)\.SetGlobalBuffer\(\(__gm__ (T|half|float)\*\)(x|residual|r|output|out|o)\);)')
for name,only in [('CACHEIN',{'x','residual','r'}),('CACHEALL',{'x','residual','r','output','out','o'})]:
 changes=[];code=base
 # Work backwards through class definitions; only their Init methods with a
 # rows argument qualify. Single-row code remains unchanged.
 classes=list(re.finditer(r'class (\w+) \{',base))
 for m in reversed(classes):
  a=m.start();z=base.index('\n};',a)+3;s=base[a:z]
  if 'uint64_t rows' not in s:continue
  def repl(p):
   text,var,dt,arg=p.groups()
   if arg not in only:return text
   changes.append({'class':m.group(1),'tensor':var,'argument':arg})
   return text+f'\n        if(rows*static_cast<uint64_t>(d)*sizeof({dt})>=67108864ULL) {var}.SetL2CacheHint(CacheMode::CACHE_MODE_DISABLE);'
  s=rx.sub(repl,s);code=code[:a]+s+code[z:]
 assert changes,name
 dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
 (H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'HALFAFF2','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'disable L2 allocation for large streaming tensors, one tensor >=64 MiB; parameters stay cached','disabled':sorted(only),'sites':changes,'numerical_change':False},indent=2)+'\n')
 print(name,hashlib.sha256(code.encode()).hexdigest(),len(changes))
p=H/'run_round.py';s=p.read_text()
if "mode=='cachequick'" not in s:
 s+='''
if mode=='cachequick':
 items=[small[12],('s14_large',524288,128,'bfloat16'),('s15_large',8192,8192,'bfloat16')]
 check('cache_check',items,['HALFAFF2','CACHEIN','CACHEALL'])
 for cand in ['CACHEIN','CACHEALL']:
  pairs('cache_'+cand.lower()+'_pairs',items,'HALFAFF2',cand,blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
