from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'LSQM/code/kernel.asc').read_text(encoding='utf-8')
native=(H/'HNQM/code/kernel.asc').read_text(encoding='utf-8')
old='if(input.dtype==1) half_native_mixed_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'
new='if(input.dtype==1 && d%64==0) half_native_mixed_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);\n        else if(input.dtype==1) pipeline_batch9_custom<half,true><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'
assert native.count(old)==1
aligned=native.replace(old,new)
start=base.index('class FloatBroadTripleKernel {');end=base.index('template <typename T,bool BlockReduction>',start)
section=base[start:end]
assert section.count('stride_=(d+63)/64*64;')==1
section=section.replace('stride_=(d+63)/64*64;','stride_=(d+511)/512*512;')
oldpad='for(uint32_t i=0;i<count;++i)Duplicate(y[i*stride_+d_/64*64],0.0f,tail,1,1,8);'
newpad='''for(uint32_t i=0;i<count;++i) {
                    Duplicate(y[i*stride_+d_/64*64],0.0f,tail,1,1,8);
                    const uint32_t padded=(d_+63)/64*64;
                    if(stride_>padded)Duplicate(y[i*stride_+padded],0.0f,stride_-padded);
                }'''
assert section.count(oldpad)==1;section=section.replace(oldpad,newpad)
oldwr='''for(uint32_t i=0;i<count;++i)
                WholeReduceSum(work_[i*partialStride],tmp[i*stride_],64,parts,1,1,8);'''
newwr='''// Every row contributes an aligned multiple of eight partials.
            WholeReduceSum(work_,tmp,64,count*parts,1,1,8);'''
assert section.count(oldwr)==1;section=section.replace(oldwr,newwr)
fpr=base[:start]+section+base[end:]
variants={'HNQMA':(aligned,'HNQM','Use native-half mixed squares and deferred output drains only for aligned FP16 D321..1024; nonaligned path remains LSQM',195840,True),
          'FPR56':(fpr,'LSQM','FP32 wide rows pad to 512 elements and reduce all chunks in one contiguous WholeReduceSum invocation per batch',187264,False)}
for name,(code,parent,change,ub,numerical) in variants.items():
 dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
 sha=hashlib.sha256(code.encode()).hexdigest()
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent=parent,source_sha256=sha,change=change,static_ub_end=ub,numerical_change=numerical),indent=2)+'\n')
 print(name,sha)
p=H/'run_round.py';q=p.read_text(encoding='utf-8')
if "mode=='hnqmaquick'" not in q:
 q+='''
if mode=='hnqmaquick':
 items=[small[i] for i in [5,6,7,9]]+[('hnqma_'+str(d),257,d,'float16') for d in [384,448,640,768,960]]
 check('hnqma_check',items,['LSQM','HNQMA'])
if mode=='hnqmaedge':
 items=[]
 for d in [512,1024]:
  for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
   cid='hnqma_edge_'+str(d)+'_'+pattern;case(cid,257,d,'float16',pattern)
   items.append((cid,257,d,'float16'))
 check('hnqma_edge_check',items,['LSQM','HNQMA'])
if mode=='fpr56quick':
 items=[small[i] for i in [10,12]]+[('fpr56_'+str(d),641,d,'float32') for d in [1537,2048,2561,3136,3584,4095,4096]]
 check('fpr56_check',items,['LSQM','FPR56'])
 pairs('fpr56_pairs',[small[i] for i in [10,12]],'LSQM','FPR56',blocks=1)
'''
 p.write_text(q,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_hnqma_fpr56.tar.gz','w:gz') as tar:
 for target in [H/'HNQMA',H/'FPR56',p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
