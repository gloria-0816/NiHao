from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'BFP3/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class FloatBroadTripleKernel {');z=base.index('__global__ __vector__ void float_broad_triple_custom',a)
s=base[a:z].replace('FloatBroadTripleKernel','BFloatTripleInplaceKernel').replace('batch_=12288/stride_','batch_=13312/stride_')
s=s.replace('(__gm__ float*)','(__gm__ bfloat16_t*)')
start=s.index('        x_[0]=LocalTensor');end=s.index('    }\n    __aicore__ inline void Process()',start)
s=s[:start]+'''        x_[0]=LocalTensor<bfloat16_t>(TPosition::VECIN,0,13312);
        x_[1]=LocalTensor<bfloat16_t>(TPosition::VECIN,26752,13312);
        tmp_=LocalTensor<float>(TPosition::VECCALC,53504,13312);
        r_=tmp_.ReinterpretCast<bfloat16_t>();
        y_=LocalTensor<float>(TPosition::VECCALC,106880,13312);
        gf_=LocalTensor<float>(TPosition::VECCALC,160256,4096);
        bf_=LocalTensor<float>(TPosition::VECCALC,176768,4096);
        work_=LocalTensor<float>(TPosition::VECCALC,193280,320);
        sums_=LocalTensor<float>(TPosition::VECCALC,194688,32);
'''+s[end:]
start=s.index('        DataCopyExtParams cp=');end=s.index('        Copy(x_[0],xgm_,begin_)',start)
s=s[:start]+'''        DataCopyExtParams cp={1,d_*2,0,0,0};DataCopyPadExtParams<bfloat16_t> pad={};pad.isPad=false;
        DataCopyPad(x_[0],ggm_,cp,pad);DataCopyPad(r_,bgm_,cp,pad);
        SetFlag<HardEvent::MTE2_V>(3);WaitFlag<HardEvent::MTE2_V>(3);
        Cast(gf_,x_[0],RoundMode::CAST_NONE,d_);Cast(bf_,r_,RoundMode::CAST_NONE,d_);PipeBarrier<PIPE_V>();
        SetFlag<HardEvent::V_MTE2>(3);WaitFlag<HardEvent::V_MTE2>(3);
'''+s[end:]
s=s.replace('            auto y=x_[slot];auto tmp=r_;','            auto y=y_;auto tmp=tmp_;')
old='            Add(y,y,tmp,active);PipeBarrier<PIPE_V>();'
new='''            // TMP aliases the raw residual, so read residual before overwriting TMP.
            Cast(y,r_,RoundMode::CAST_NONE,active);PipeBarrier<PIPE_V>();
            Cast(tmp,x_[slot],RoundMode::CAST_NONE,active);PipeBarrier<PIPE_V>();
            Add(y,y,tmp,active);PipeBarrier<PIPE_V>();'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('            SetFlag<HardEvent::V_MTE3>(slot);WaitFlag<HardEvent::V_MTE3>(slot);\n            Cast(x_[slot],y,RoundMode::CAST_RINT,active);','            Cast(x_[slot],y,RoundMode::CAST_RINT,active);')
old='''            DataCopyExtParams out={static_cast<uint16_t>(count),d_*4,Gap(),0,0};DataCopyPad(outgm_[row*d_],y,out);'''
new='''            Cast(x_[slot],y,RoundMode::CAST_RINT,active);PipeBarrier<PIPE_V>();
            SetFlag<HardEvent::V_MTE3>(slot);WaitFlag<HardEvent::V_MTE3>(slot);
            DataCopyExtParams out={static_cast<uint16_t>(count),d_*2,Gap(),0,0};DataCopyPad(outgm_[row*d_],x_[slot],out);'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('(stride_*4-(d_*4+31)/32*32)/32','(stride_*2-(d_*2+31)/32*32)/32')
s=s.replace('Copy(LocalTensor<float> dst,GlobalTensor<float> src','Copy(LocalTensor<bfloat16_t> dst,GlobalTensor<bfloat16_t> src')
s=s.replace('static_cast<uint16_t>(count),d_*4,0,Gap(),0','static_cast<uint16_t>(count),d_*2,0,Gap(),0')
s=s.replace('DataCopyPadExtParams<float> pad={};','DataCopyPadExtParams<bfloat16_t> pad={};')
s=s.replace('GlobalTensor<float> xgm_,rgm_,ggm_,bgm_,outgm_;','GlobalTensor<bfloat16_t> xgm_,rgm_,ggm_,bgm_,outgm_;')
s=s.replace('LocalTensor<float> x_[2],r_,gf_,bf_,work_,sums_;','LocalTensor<bfloat16_t> x_[2],r_;\n    LocalTensor<float> y_,tmp_,gf_,bf_,work_,sums_;')
entry='''__global__ __vector__ void bfloat_triple_inplace_custom(GM_ADDR x,GM_ADDR r,GM_ADDR g,GM_ADDR b,GM_ADDR out,
    uint64_t rows,uint32_t d,float invD,float eps) {
    InitSocState();BFloatTripleInplaceKernel op;op.Init(x,r,g,b,out,rows,d,invD,eps);op.Process();
}
'''
code=base[:a]+s+entry+'\n'+base[a:]
old='bfloat_batch_pipeline_custom<<<blockNum,nullptr,stream>>>'
assert code.count(old)==1;code=code.replace(old,'bfloat_triple_inplace_custom<<<blockNum,nullptr,stream>>>')
name='BFPN4';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFP3',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='BF16 triple pipeline with output reusing input X slot; raw residual aliases FP32 square scratch after residual cast; 13312 element capacity yields three D4096 rows; 320-float partial scratch covers all padded row widths',numerical_change=True,ub_end_bytes=194816),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='bfpn4quick'" not in s:
 s+='''
if mode=='bfpn4quick':
 items=[small[11]]+[('bfp3_'+str(d),321,d,'bfloat16') for d in [1025,2048,3079,4095]]+[('bfpn3_1536',321,1536,'bfloat16'),('bfpn3_4096',321,4096,'bfloat16')]
 check('bfpn4_check',items,['BFP3','BFPN4'])
 pairs('bfpn4_pairs',[small[11],items[2]],'BFP3','BFPN4',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_bfpn4.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
