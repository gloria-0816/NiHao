from pathlib import Path
import shutil,json,hashlib
H=Path(__file__).resolve().parent
base=(H/'HALFBR/code/kernel.asc').read_text()
helpers='''
template <typename T>
__aicore__ inline void ToFloatMasked(LocalTensor<float> dst,LocalTensor<T> src)
{
    Cast<float,T,false>(dst,src,RoundMode::CAST_NONE,static_cast<uint64_t>(0),1,{1,1,8,4});
}
template <typename T>
__aicore__ inline void FromFloatMasked(LocalTensor<T> dst,LocalTensor<float> src)
{
    Cast<T,float,false>(dst,src,RoundMode::CAST_RINT,static_cast<uint64_t>(0),1,{1,1,4,8});
}
__aicore__ inline void Counter(uint32_t n)
{
    SetMaskCount();SetVectorMask<float,MaskMode::COUNTER>(0,n);
}
__aicore__ inline void EndCounter(){ResetMask();SetMaskNorm();}
__aicore__ inline void InvRmsMasked(LocalTensor<float> sums,LocalTensor<float> work,
    uint32_t n,float invD,float eps)
{
    Counter(n);
    Muls<float,false>(sums,sums,invD,static_cast<uint64_t>(0),1,{1,1,8,8});PipeBarrier<PIPE_V>();
    Adds<float,false>(sums,sums,eps,static_cast<uint64_t>(0),1,{1,1,8,8});PipeBarrier<PIPE_V>();
    Sqrt<float,false>(sums,sums,static_cast<uint64_t>(0),1,{1,1,8,8});
    Duplicate<float,false>(work,1.0f,static_cast<uint64_t>(0),1,1,8);PipeBarrier<PIPE_V>();
    Div<float,false>(sums,work,sums,static_cast<uint64_t>(0),1,{1,1,1,8,8,8});PipeBarrier<PIPE_V>();
    EndCounter();
}
'''
code=base.replace('using namespace AscendC;','using namespace AscendC;\n'+helpers,1)
a=code.index('class PipelineBatch9Kernel {');b=code.index('class StaticHalfRowsKernel {',a)
s=code[a:b]
old='        ToFloat<T>(gamma_,gh_,d_); ToFloat<T>(bias_,bh_,d_);'
assert old in s
s=s.replace(old,'        Counter(d_);ToFloatMasked<T>(gamma_,gh_);ToFloatMasked<T>(bias_,bh_);EndCounter();',1)
s=s.replace('            ToFloat<T>(y_,x_[slot],active); ToFloat<T>(tmp_,r_[slot],active);','            Counter(active);ToFloatMasked<T>(y_,x_[slot]);ToFloatMasked<T>(tmp_,r_[slot]);',1)
s=s.replace('            Add(y_,y_,tmp_,active); PipeBarrier<PIPE_V>();','            Add<float,false>(y_,y_,tmp_,static_cast<uint64_t>(0),1,{1,1,1,8,8,8});PipeBarrier<PIPE_V>();',1)
s=s.replace('            if(d_!=stride_) {\n                uint64_t tail','            if(d_!=stride_) {\n                EndCounter();\n                uint64_t tail',1)
old='''                PipeBarrier<PIPE_V>();
            }
            Mul(tmp_,y_,y_,active); PipeBarrier<PIPE_V>();'''
new='''                PipeBarrier<PIPE_V>();Counter(active);
            }
            Mul<float,false>(tmp_,y_,y_,static_cast<uint64_t>(0),1,{1,1,1,8,8,8});PipeBarrier<PIPE_V>();EndCounter();'''
assert old in s
s=s.replace(old,new,1)
old='''            Muls(sums_,sums_,invD_,count); PipeBarrier<PIPE_V>();
            Adds(sums_,sums_,eps_,count); PipeBarrier<PIPE_V>();
            Sqrt(sums_,sums_,count); Duplicate(work_,1.0f,count); PipeBarrier<PIPE_V>();
            Div(sums_,work_,sums_,count); PipeBarrier<PIPE_V>();'''
assert old in s
s=s.replace(old,'            InvRmsMasked(sums_,work_,count,invD_,eps_);',1)
old='            FromFloat<T>(out_,y_,active); PipeBarrier<PIPE_V>();'
assert old in s
s=s.replace(old,'            Counter(active);FromFloatMasked<T>(out_,y_);PipeBarrier<PIPE_V>();EndCounter();',1)
code=code[:a]+s+code[b:]

a=code.index('class StaticHalfRowsKernel {');b=code.index('__global__ __vector__ void static_half_rows_custom',a)
s=code[a:b]
old='''        Muls(sums_,sums_,invD_,rms); PipeBarrier<PIPE_V>();
        Adds(sums_,sums_,eps_,rms); PipeBarrier<PIPE_V>();
        Sqrt(sums_,sums_,rms);
        Duplicate(work_,1.0f,rms); PipeBarrier<PIPE_V>();
        Div(sums_,work_,sums_,rms); PipeBarrier<PIPE_V>();'''
assert old in s
s=s.replace(old,'        InvRmsMasked(sums_,work_,count_,invD_,eps_);',1)
code=code[:a]+s+code[b:]

mask64=(H/'MASK64/code/kernel.asc').read_text()
a=mask64.index('__global__ __vector__ void single_row_64_custom')
b=mask64.index('template <typename T>\n__global__ __vector__ void single_row_custom',a)
part=mask64[a:b].replace(',0,1,{',',static_cast<uint64_t>(0),1,{')
start=code.index('__global__ __vector__ void single_row_64_custom')
end=code.index('template <typename T>\n__global__ __vector__ void single_row_custom',start)
code=code[:start]+part+code[end:]

for v,source in [('MASKBATCH',code),('MASK64B',mask64[:a]+part+mask64[b:])]:
 d=H/v/'code';shutil.copytree(H/'BASE/code',d,dirs_exist_ok=True)
 (d/'kernel.asc').write_text(source,encoding='utf-8',newline='\n')
 (H/v/'manifest.json').write_text(json.dumps({'variant':v,'source_sha256':hashlib.sha256(source.encode()).hexdigest()},indent=2)+'\n')
 print(v,hashlib.sha256(source.encode()).hexdigest())
f=H/'run_round.py';s=f.read_text()
if "mode=='maskbatchquick'" not in s:
 s+='''
if mode=='mask64bquick':
 check('mask64b_check',[small[0],('m64_float',1,64,'float32'),('m64_bf16',1,64,'bfloat16')],['BASE','MASK64B'])
 pairs('mask64b_pairs',[small[0]],'BASE','MASK64B',blocks=2)
if mode=='maskbatchquick':
 check('maskbatch_check',[small[i] for i in [0,3,5,6,7,9,13]],['BASE','MASKBATCH'])
 pairs('maskbatch_pairs',[small[i] for i in [3,5,6,7,9]],'BASE','MASKBATCH',blocks=1)
'''
 f.write_text(s,encoding='utf-8',newline='\n')
