from pathlib import Path
import tarfile,json,hashlib,io
root=Path('/mnt/workspace/addrms_results/E026')
target=Path('/home/developer/addrms_archived/E026_incremental_20261012_0745.tar.gz')
assert not target.exists()
prefixes=('flong','hslane','pload','rmn','sfdir','sfacc','cpart','hostp','coal64','sftiny','build_HSLANE','build_PLOAD','build_RMN','build_SFDIR','build_SFACC','build_CPART','build_HOSTP','build_COAL64','build_SFTINY')
files=[]
for group in root.iterdir():
 if group.is_dir() and group.name.startswith(prefixes):
  files.extend(p for p in group.rglob('*') if p.is_file() and p.suffix in {'.json','.csv','.log','.txt'})
files.extend(p for p in root.glob('*.json'))
for p in Path('/mnt/workspace').glob('*.log'):
 if p.name.startswith(('hslane','pload','rmn','sfdir','cpart','hostp','coal64','sftiny')):files.append(p)
manifest=[];skipped=[]
with tarfile.open(target,'w:gz') as archive:
 for path in sorted(set(files)):
  data=path.read_bytes()
  relative=path.relative_to(root).as_posix() if path.is_relative_to(root) else '_queue_logs/'+path.name
  if path.suffix=='.json':
   try:json.loads(data)
   except (ValueError,UnicodeError):skipped.append(relative);continue
  entry=tarfile.TarInfo(relative);entry.size=len(data);entry.mode=0o600
  archive.addfile(entry,io.BytesIO(data))
  manifest.append(dict(path=relative,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 data=(json.dumps(dict(description='Completed records snapshot; symlinked groups traversed explicitly; tensor files retained on cloud',files=manifest,skipped_invalid_json=skipped),indent=2)+'\n').encode()
 entry=tarfile.TarInfo('_snapshot_manifest.json');entry.size=len(data);archive.addfile(entry,io.BytesIO(data))
print(json.dumps(dict(files=len(manifest),bytes=target.stat().st_size,archive=str(target),sha256=hashlib.sha256(target.read_bytes()).hexdigest())))
