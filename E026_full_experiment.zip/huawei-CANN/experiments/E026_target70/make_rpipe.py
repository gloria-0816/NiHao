from pathlib import Path
import json, hashlib, shutil, tarfile
H=Path(__file__).resolve().parent
base=(H/'HALFAFF2/code/kernel.asc').read_text(encoding='utf-8')
old=(H.parents[0]/'E023_performance_rewrite/REFINED_SAFE2/code/kernel.asc').read_text(encoding='utf-8')
a=old.index('__aicore__ inline void RefineInvRms(')
z=old.index('template <typename T>',a)
helper=old[a:z]
a=base.index('class PipelineBatch9Kernel {')
z=base.index('class StaticHalfRowsKernel {',a)
target='''            Sqrt(sums_,sums_,count); Duplicate(work_,1.0f,count); PipeBarrier<PIPE_V>();
            Div(sums_,work_,sums_,count); PipeBarrier<PIPE_V>();'''
assert base[a:z].count(target)==1
for name, replacement in [('RPIPE0','Rsqrt(sums_,sums_,count); PipeBarrier<PIPE_V>();'),('RPIPE1','RefineInvRms(sums_,work_,count); PipeBarrier<PIPE_V>();')]:
    sub=base[a:z].replace(target,'            '+replacement)
    code=base[:a]+sub+base[z:]
    if name=='RPIPE1': code=code.replace('template <typename T>',helper+'\ntemplate <typename T>',1)
    dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
    (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
    (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='HALFAFF2',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='Pipeline RMS uses '+('native reciprocal sqrt' if name=='RPIPE0' else 'reciprocal sqrt with one Newton refinement and Inf/NaN estimate selection'),numerical_change=True),indent=2)+'\n',encoding='utf-8')
    print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='rpipequick'" not in s:
    s+='''
if mode=='rpipequick':
 items=[small[i] for i in [5,6,7,9,13]]
 check('rpipe_check',items,['HALFAFF2','RPIPE0','RPIPE1'])
 for v in ['RPIPE0','RPIPE1']:
  pairs(v.lower()+'_pairs',[small[5],small[7],small[9]],'HALFAFF2',v,blocks=1)
'''
    p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_rpipe.tar.gz','w:gz') as tar:
    for target in [H/'RPIPE0',H/'RPIPE1',p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
