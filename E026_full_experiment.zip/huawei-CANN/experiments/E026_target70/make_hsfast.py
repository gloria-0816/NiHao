from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'BFP3/code/kernel.asc').read_text(encoding='utf-8')
code=base.replace('class FloatBroadTripleKernel {',(H/'half_single_fast.inc').read_text(encoding='utf-8')+'\nclass FloatBroadTripleKernel {',1)
anchor='    if (rows == 1 && d == 64) {'
assert code.count(anchor)==1
code=code.replace(anchor,'''    if(input.dtype==1 && rows==1 && d==64) {
        half_single_fast_custom<<<1,nullptr,stream>>>(x,residual,gamma,bias,output,epsilon);
        return;
    }
'''+anchor)
name='HSFAST';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFP3',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='Single-row FP16 D64 native residual sum, FP32 RMS, native half scaling and FMA with shared vector masks',numerical_change=True,ub_end_bytes=1664),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='hsfastquick'" not in s:
 s+='''
if mode=='hsfastquick':
 items=[small[0]]
 for seed in [1,2,3,7,11,19,23,31,53,101,202,303,404,505,606,707,808,909,1001,1021]:
  cid='hsfast_seed_'+str(seed);dest=OUT/'inputs'/cid
  if not dest.exists():core.case_data.generate(dest,[1,1,64],'float16',seed=seed,pattern='uniform',case_id=cid,max_tensor_mib=2048)
  items.append((cid,1,64,'float16'))
 check('hsfast_check',items,['BFP3','HSFAST'])
 pairs('hsfast_pairs',[small[0]],'BFP3','HSFAST',blocks=2)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_hsfast.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
