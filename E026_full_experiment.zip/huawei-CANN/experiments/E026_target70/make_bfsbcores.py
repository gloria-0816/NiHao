from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'BFSB2/code/kernel.asc').read_text(encoding='utf-8')
old='        else bfloat_short_inplace_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,epsilon);'
assert base.count(old)==1
names=[]
for cores in [16,24,32]:
 name='BSBC'+str(cores);names.append(name)
 new=f'''        else {{
            const uint32_t cores=blockNum>{cores}?{cores}:blockNum;
            bfloat_short_inplace_custom<<<cores,nullptr,stream>>>(x,residual,gamma,bias,output,rows,epsilon);
        }}'''
 code=base.replace(old,new)
 dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n');sha=hashlib.sha256(code.encode()).hexdigest()
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFSB2',source_sha256=sha,change=f'BF16 D128 119-row cyclic batches launch at most {cores} vector cores; same arithmetic and safe empty-core return',numerical_change=False),indent=2)+'\n')
 print(name,sha)
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='bsbcquick'" not in s:
 s+='''
if mode=='bsbcquick':
 items=[small[13]]+[('bfsb_'+str(r),r,128,'bfloat16') for r in [160,4761]]
 check('bsbc_check',items,['FACC','BFSB2','BSBC16','BSBC24','BSBC32'])
 for v in ['BSBC16','BSBC24','BSBC32']:
  pairs(v.lower()+'_pairs',[('b128large',524288,128,'bfloat16')],'BFSB2',v,blocks=1)
if mode=='bfsb2confirm':
 pairs('bfsb2_confirm_pairs',[('b128large',524288,128,'bfloat16')],'FACC','BFSB2',blocks=2)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_bsbc.tar.gz','w:gz') as t:
 for q in [H/n for n in names]+[p]:t.add(q,arcname=q.relative_to(H.parents[1]))
