from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'BFSIP/code/kernel.asc').read_text(encoding='utf-8')
code=base.replace('class BFloatStatic8Kernel {',(H/'bfloat_db8.inc').read_text(encoding='utf-8')+'\nclass BFloatStatic8Kernel {',1)
anchor='    if (rows >= static_cast<uint64_t>(blockNum)*4 && ((input.dtype==1 && d>=321 && d<=1024) || (input.dtype==2 && d==128))) {'
branch='''    if(input.dtype==2 && d==8192 && rows>=static_cast<uint64_t>(blockNum)*4) {
        bfloat_double8_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,epsilon);
        return;
    }
'''
assert code.count(anchor)==1;code=code.replace(anchor,branch+anchor)
name='BFDB8';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFSIP',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='BF16 D8192 static dual X/R input prefetch two rows ahead, early residual refill, consumed X slot borrowed for reduction scratch and output; retains full-vector FP32 Div and separate affine Mul/Add',static_ub_end=196608,numerical_change=True),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='bfdb8quick'" not in s:
 s+='''
if mode=='bfdb8quick':
 items=[small[14]]+[('bfdb8_'+str(rows),rows,8192,'bfloat16') for rows in [160,161,321,159]]
 check('bfdb8_check',items,['BFSIP','BFDB8'])
 pairs('bfdb8_pairs',[small[14]],'BFSIP','BFDB8',blocks=1)
if mode=='bfdb8edge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='bfinv_'+pattern;case(cid,161,8192,'bfloat16',pattern);items.append((cid,161,8192,'bfloat16'))
 check('bfdb8_edge',items,['BFSIP','BFDB8'])
if mode=='bfdb8large':
 items=[('bf8_large',8192,8192,'bfloat16')]
 check('bfdb8_large_check',items,['BFSIP','BFDB8'])
 pairs('bfdb8_large_pairs',items,'BFSIP','BFDB8',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_bfdb8.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
