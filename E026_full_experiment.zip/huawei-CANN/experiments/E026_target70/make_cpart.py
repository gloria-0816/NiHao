from pathlib import Path
import json,hashlib,shutil,tarfile,re
H=Path(__file__).resolve().parent
base=(H/'FACC/code/kernel.asc').read_text(encoding='utf-8')
helper='''
// Metadata-only partition. Preserve floor(rows * index / blockNum) exactly.
__aicore__ inline uint64_t ConstantCorePartition(uint64_t rows,uint32_t index) {
    const uint32_t n=GetBlockNum();
    if(rows==static_cast<uint64_t>(n))return index;
    if(n==40)return rows*index/40;
    if(n==8)return (rows*index)>>3;
    if(n==32)return (rows*index)>>5;
    if(n==1)return rows*index;
    return rows*index/n;
}
'''
pat=r'\b(rows_?)\s*\*\s*(GetBlockIdx\(\)|\(GetBlockIdx\(\)\s*\+\s*1\))\s*/\s*GetBlockNum\(\)'
def replace(m):
 idx='GetBlockIdx()' if '+' not in m[2] else 'GetBlockIdx()+1'
 return 'ConstantCorePartition('+m[1]+','+idx+')'
code,count=re.subn(pat,replace,base)
assert count>=20,count
code=code.replace('using namespace AscendC;','using namespace AscendC;\n'+helper,1)
name='CPART';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
sha=hashlib.sha256(code.encode()).hexdigest()
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='FACC',source_sha256=sha,
 change='Metadata-only constant core partition for 40/8/32/1 and one row per core; preserve exact floor boundaries and all tensor arithmetic',numerical_change=False,partition_sites=count),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='cpartquick'" not in s:
 s+='''
if mode=='cpartquick':
 check('cpart_check',small,['FACC','CPART'])
 pairs('cpart_pairs',[small[i] for i in [1,2,3,5,6,10]],'FACC','CPART',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_cpart.tar.gz','w:gz') as t:
 for q in [H/name,p]:t.add(q,arcname=q.relative_to(H.parents[1]))
print(name,sha,count)
