from pathlib import Path
import hashlib,json,re,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'SHAREDA/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class HalfSharedResidualKernel {');z=base.index('class StaticHalfRowsKernel {',a)
s=base[a:z]
s=s[:s.index('__global__ __vector__ void half_shared_residual_custom')]
s=s.replace('HalfSharedResidualKernel','BFloatSharedResidualKernel')
s=s.replace('ReinterpretCast<half>','ReinterpretCast<KEEP_HALF>')
s=re.sub(r'\bhalf\b','bfloat16_t',s).replace('ReinterpretCast<KEEP_HALF>','ReinterpretCast<half>')
old='''        gh_=LocalTensor<bfloat16_t>(TPosition::VECIN,179840,1024);
        bh_=LocalTensor<bfloat16_t>(TPosition::VECIN,182016,1024);'''
new='''        gamma_=LocalTensor<float>(TPosition::VECCALC,179840,512);
        bias_=LocalTensor<float>(TPosition::VECCALC,182016,512);
        gh_=x_[0];bh_=r_[0];'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('sums_=LocalTensor<float>(TPosition::VECCALC,190720,128);','sums_=LocalTensor<float>(TPosition::VECCALC,190720,256);')
old='''        PipeBarrier<PIPE_V>();
        Prefetch(begin_,0);'''
new='''        PipeBarrier<PIPE_V>();
        SetFlag<HardEvent::V_MTE2>(3);WaitFlag<HardEvent::V_MTE2>(3);
        Prefetch(begin_,0);'''
assert s.count(old)==1;s=s.replace(old,new)
old='''                ToFloat<bfloat16_t>(y_,x_[slot],active);ToFloat<bfloat16_t>(tmp_,r_[slot],active);PipeBarrier<PIPE_V>();'''
new='''                // Convert R before the aliased square buffer overwrites it.
                ToFloat<bfloat16_t>(y_,r_[slot],active);PipeBarrier<PIPE_V>();
                ToFloat<bfloat16_t>(tmp_,x_[slot],active);PipeBarrier<PIPE_V>();'''
assert s.count(old)==1;s=s.replace(old,new)
entry='''__global__ __vector__ void bfloat_shared_residual_custom(GM_ADDR x,GM_ADDR r,GM_ADDR g,
    GM_ADDR b,GM_ADDR out,uint64_t rows,uint32_t d,float invD,float eps) {
    InitSocState();BFloatSharedResidualKernel op;op.Init(x,r,g,b,out,rows,d,invD,eps);op.Process();
}
'''
code=base.replace('class StaticHalfRowsKernel {',s+entry+'\nclass StaticHalfRowsKernel {',1)
anchor='    if(input.dtype==1 && d>=321 && d<=1024 && d%64==0'
launch='''    if(input.dtype==2 && d<=512 && d%64==0 && rows>=static_cast<uint64_t>(blockNum)*4) {
        bfloat_shared_residual_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert code.count(anchor)==1;code=code.replace(anchor,launch+anchor)
name='BF128S';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='SHAREDA',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='Aligned BF16 short rows with shared residual/square buffer and capacity 12800; convert residual before input X into float alias; cached FP32 parameters',numerical_change=True,ub_end_bytes=191744),indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
old="dest.parent.mkdir(exist_ok=True);core.case_data.generate(dest,[1,r,d],dt,seed=42,pattern=pattern,case_id=cid,max_tensor_mib=2048)"
new="""dest.parent.mkdir(exist_ok=True)
  if r<=32768: shape=[1,r,d]
  else:
   factors=[b for b in range(1,8193) if r%b==0 and r//b<=32768]
   if not factors: raise ValueError('Cannot represent rows as a legal batch/sequence product')
   b=factors[0];shape=[b,r//b,d]
  core.case_data.generate(dest,shape,dt,seed=42,pattern=pattern,case_id=cid,max_tensor_mib=2048)"""
assert s.count(old)==1;s=s.replace(old,new)
if "mode=='bf128squick'" not in s:
 s+='''
if mode=='bf128squick':
 items=[small[13]]+[('bf128s_'+str(d),767,d,'bfloat16') for d in [64,128,192,256,384,512]]
 check('bf128s_check',items,['SHAREDA','BF128S'])
 pairs('bf128s_pairs',[small[13]],'SHAREDA','BF128S',blocks=2)
if mode=='bf128slarge':
 items=[('bf128s_large',524288,128,'bfloat16')]
 check('bf128s_large_check',items,['SHAREDA','BF128S'])
 pairs('bf128s_large_pairs',items,'SHAREDA','BF128S',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_bf128s.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
