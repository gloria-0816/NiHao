from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent
code=(H/'RETACC/code/kernel.asc').read_text()
assert code.count('class RetainedAccKernel {')==1
code=code.replace('class RetainedAccKernel {','template <typename T>\nclass RetainedAccKernel {',1)
name='RETACC2';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'RETACC','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'fix':'template declaration for standalone injected retained class'},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='retacc2quick'" not in s:
 s+='''
if mode=='retacc2quick':
 check('retacc2_check',[small[4],('longacc_16',41,16384,'float16'),('longacc_24',3,24576,'float16')],['COMBO1','RETACC2'])
 pairs('retacc2_pairs',[small[4]],'COMBO1','RETACC2',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
