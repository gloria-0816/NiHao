from pathlib import Path
import subprocess, json, time
H=Path(__file__).resolve().parent
O=Path('/mnt/workspace/addrms_results/E026')
for name,phase in [('PACK','packquick'),('HALFBR','halfbrquick'),('H20','h20quick')]:
    record=O/f'build_{name}'/'record.json'
    while not record.exists():time.sleep(5)
    assert json.loads(record.read_text())['returncode']==0
    subprocess.run(['python3',str(H/'run_round.py'),phase],check=True)
