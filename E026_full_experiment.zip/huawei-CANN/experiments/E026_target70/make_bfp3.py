from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
code=(H/'BFP2/code/kernel.asc').read_text(encoding='utf-8')
shared='''    if(input.dtype==1 && d>=321 && d<=1024 && d%64==0 && rows>=static_cast<uint64_t>(blockNum)*4) {
        half_shared_residual_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert code.count(shared)==1
code=code.replace(shared,'')
old='if(input.dtype==2 && d>1024 && d<=4096 && rows>=static_cast<uint64_t>(blockNum)*4)'
assert code.count(old)==1
code=code.replace(old,old.replace('*4','*8'))
name='BFP3';dest=H/name/'code'
shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BROAD3',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='BF16 wide batch pipeline from BFP2; at least eight rows per launched core amortize startup; FP16 dispatch restored to official best BROAD3',numerical_change=True,ub_end_bytes=186112),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='bfp3quick'" not in s:
 s+='''
if mode=='bfp3quick':
 items=[small[11],('bfp3_1025',321,1025,'bfloat16'),('bfp3_2048',321,2048,'bfloat16'),('bfp3_3079',321,3079,'bfloat16'),('bfp3_4095',321,4095,'bfloat16'),('bfp3_small',257,4096,'bfloat16'),small[7]]
 check('bfp3_check',items,['BROAD3','BFP3'])
 pairs('bfp3_pairs',[small[11]],'BROAD3','BFP3',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_bfp3.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
