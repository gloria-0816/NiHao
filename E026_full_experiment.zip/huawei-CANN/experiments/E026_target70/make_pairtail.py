from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
code=(H/'PAIRASY/code/kernel.asc').read_text(encoding='utf-8')
a=code.index('class LongHalfPair2Kernel {');z=code.index('class LongHalfRetainedKernel {',a)
p=code[a:z]
p=p.replace('d_=d;n_=d/2;row_=GetBlockIdx()/2;part_=GetBlockIdx()%2;col_=part_*n_;',
'''d_=d;n_=(d+127)/128*64;row_=GetBlockIdx()/2;part_=GetBlockIdx()%2;col_=part_*n_;
        valid_=part_?d_-n_:n_;''')
p=p.replace('DataCopy(x_,xgm_[off],n_);DataCopy(r_,rgm_[off],n_);SetFlag<HardEvent::MTE2_V>(0);',
'''DataCopyExtParams cp={1,valid_*2,0,0,0};DataCopyPadExtParams<half> pad={};pad.isPad=false;
        DataCopyPad(x_,xgm_[off],cp,pad);DataCopyPad(r_,rgm_[off],cp,pad);SetFlag<HardEvent::MTE2_V>(0);''')
p=p.replace('DataCopy(g_,ggm_[col_],n_);DataCopy(b_,bgm_[col_],n_);SetFlag<HardEvent::MTE2_V>(1);',
'DataCopyPad(g_,ggm_[col_],cp,pad);DataCopyPad(b_,bgm_[col_],cp,pad);SetFlag<HardEvent::MTE2_V>(1);')
p=p.replace('Add(x_,x_,r_,n_);','Add(x_,x_,r_,valid_);')
old='''        for(uint32_t col=0;col<n_;col+=8192) {
            const uint32_t size=n_-col<8192?n_-col:8192;
            MulAddDst(square_,x_[col],x_[col],64,size/64,{1,1,1,8,4,4});
        }'''
assert p.count(old)==1
p=p.replace(old,'''        for(uint32_t col=0;col<valid_;col+=8192) {
            const uint32_t size=valid_-col<8192?valid_-col:8192;
            if(size/64)MulAddDst(square_,x_[col],x_[col],64,size/64,{1,1,1,8,4,4});
            if(size%64)MulAddDst(square_[size/64*64],x_[col+size/64*64],x_[col+size/64*64],size%64,1,{1,1,1,8,4,4});
        }''')
p=p.replace('const uint64_t scratchRow=row_*(d_/2);',
'''// Both slots lie fully inside this row, including odd-width rows.
        const uint64_t scratchRow=(row_*static_cast<uint64_t>(d_)*2+31)/32*8;''')
p=p.replace('128,n_/128,','128,valid_/128,')
p=p.replace('if(n_%128)Mul(x_[n_/128*128],x_[n_/128*128],broadcast_,n_%128,1,',
            'if(valid_%128)Mul(x_[valid_/128*128],x_[valid_/128*128],broadcast_,valid_%128,1,')
p=p.replace('FusedMulAdd(x_,g_,b_,n_);','FusedMulAdd(x_,g_,b_,valid_);')
p=p.replace('DataCopy(ogm_[off],x_,n_);','DataCopyPad(ogm_[off],x_,cp);')
p=p.replace('uint32_t part_,d_,n_,col_;','uint32_t part_,d_,n_,col_,valid_;')
code=code[:a]+p+code[z:]
code=code.replace('d<=32768 && d%128==0 &&','d<=32768 &&')
name='PAIRTAIL';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n');sha=hashlib.sha256(code.encode()).hexdigest()
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='PAIRASY',source_sha256=sha,change='Two AIV per FP16 long row including nonaligned widths: 64-element aligned partition, masked mixed square tails, DataCopyPad for valid slices, scratch slots rounded inside each output row, read completion wait before overwrite',static_ub_end=164352,numerical_change=True),indent=2)+'\n')
q=H/'run_round.py';s=q.read_text(encoding='utf-8')
if "mode=='pairtailquick'" not in s:
 s+='''
if mode=='pairtailquick':
 items=[('pairtail_'+str(r)+'_'+str(d),r,d,'float16') for r,d in [(1,8193),(2,8449),(3,16383),(2,16513),(1,24575),(4,24577),(1,32767),(2,32767),(4,32767),(8,32767),(20,32767),(21,32767)]]
 check('pairtail_check',items,['FACC','PAIRTAIL'])
 pairs('pairtail_pairs',[items[i] for i in [0,2,4,6,7,8,9]],'FACC','PAIRTAIL',blocks=1)
if mode=='pairtailedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  for r,d in [(1,16383),(3,32767)]:
   cid='pairtail_edge_'+str(r)+'_'+str(d)+'_'+pattern;case(cid,r,d,'float16',pattern);items.append((cid,r,d,'float16'))
 check('pairtail_edge_check',items,['FACC','PAIRTAIL'])
if mode=='pairasymultiquick':
 items=[('pairasy_multi_'+str(r)+'_'+str(d),r,d,'float16') for r,d in [(2,16384),(2,24576),(2,32768),(4,32768),(8,32768),(16,32768),(20,32768)]]
 check('pairasy_multi_check',items,['FACC','PAIRASY'])
 pairs('pairasy_multi_pairs',items,'FACC','PAIRASY',blocks=1)
'''
 q.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_pairtail.tar.gz','w:gz') as t:
 for q in [H/name,q]:t.add(q,arcname=q.relative_to(H.parents[1]))
print(name,sha)
