from pathlib import Path
import tarfile
H=Path(__file__).resolve().parent
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='faccvalidate'" not in s:
 s+='''
if mode=='faccvalidate':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='facc_edge_'+pattern;case(cid,641,3083,'float32',pattern)
  items.append((cid,641,3083,'float32'))
 check('facc_edge_check',items,['LSQM','FACC'])
 subprocess.run(['python3',str(HERE/'run_cold.py'),'facc'],check=True)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_facc_validation.tar.gz','w:gz') as t:
 for q in [p,H/'run_cold.py']:t.add(q,arcname=q.relative_to(H.parents[1]))
