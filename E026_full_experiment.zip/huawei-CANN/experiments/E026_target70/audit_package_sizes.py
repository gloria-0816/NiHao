from pathlib import Path
import os,json
H=Path(__file__).resolve().parent
base=Path('\\\\?\\'+str((H/'cloud_results').resolve()))
files=[]
for root,ds,fs in os.walk(base):
    for n in fs:
        p=Path(root)/n
        if p.suffix in {'.json','.csv','.txt','.log'}:files.append((p.relative_to(base).as_posix(),p.stat().st_size))
print(json.dumps(dict(files=len(files),bytes=sum(s for p,s in files),largest=sorted(files,key=lambda x:x[1],reverse=True)[:15])))
