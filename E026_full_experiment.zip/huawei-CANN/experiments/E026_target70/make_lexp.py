from pathlib import Path
import hashlib,json,shutil,tarfile,re
H=Path(__file__).resolve().parent;base=(H/'BFP3/code/kernel.asc').read_text(encoding='utf-8')
pattern=r'Sqrt\((\w+),\s*\1,\s*(\w+)\);\s*Duplicate\((\w+),1\.0f,\w+\);\s*PipeBarrier<PIPE_V>\(\);\s*Div\(\1,\s*\3,\s*\1,\s*\2\);\s*PipeBarrier<PIPE_V>\(\);'
def replacement(m):
 v,n,_=m.groups()
 return f'Ln({v},{v},{n});PipeBarrier<PIPE_V>();\n            Muls({v},{v},-0.5f,{n});PipeBarrier<PIPE_V>();\n            Exp({v},{v},{n});PipeBarrier<PIPE_V>();'
code,num=re.subn(pattern,replacement,base)
assert num>=8,num
name='LEXP';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFP3',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='Inverse RMS uses exp(-0.5*log(meanSquare+epsilon)), as CANN RmsNorm high-precision implementation, replacing square-root, duplicate and divide in batch paths',numerical_change=True,replaced_sequences=num),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='lexpquick'" not in s:
 s+='''
if mode=='lexpquick':
 check('lexp_check',small,['BFP3','LEXP'])
 pairs('lexp_pairs',[small[i] for i in [3,4,5,6,7,9,11,13,14]],'BFP3','LEXP',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_lexp.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,num,hashlib.sha256(code.encode()).hexdigest())
