from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'FACC/code/kernel.asc').read_text(encoding='utf-8')
raw=(H/'long_pair2.inc').read_text(encoding='utf-8')
for name,mode,qualifier,guard,launch in [('PAIR2',1,'__schedmode__(1) __global__ __mix__(1,2)','if (g_coreType == AscendC::AIV)','rows'),('SYNC2',0,'__schedmode__(1) __global__ __mix__(0,1)','if (true)','rows*2')]:
 inc=raw.replace('PAIR_SYNC_MODE',str(mode)).replace('PAIR_KERNEL_QUALIFIER',qualifier).replace('PAIR_AIV_GUARD',guard)
 code=base.replace('class LongHalfRetainedKernel {',inc+'\nclass LongHalfRetainedKernel {',1)
 anchor='    if(input.dtype==1 && d>8192 && d<=32768) {'
 branch=f'''    if(input.dtype==1 && d>8192 && d<=32768 && d%128==0 &&
        rows<=static_cast<uint64_t>(availableCoreNum)/2) {{
        long_half_pair2_custom<<<static_cast<uint32_t>({launch}),nullptr,stream>>>(x,residual,gamma,bias,output,d,inverseD,epsilon);
        return;
    }}
'''
 assert code.count(anchor)==1;code=code.replace(anchor,branch+anchor)
 dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n');sha=hashlib.sha256(code.encode()).hexdigest()
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='FACC',source_sha256=sha,change=f'FP16 aligned long rows split over two vector cores; mixed square and retained half slices; CrossCore mode {mode}; 64 bytes of temporary partials inside each output row, all reads synchronized before output overwrite',static_ub_end=196608,numerical_change=True,references=['https://www.hiascend.com/doc_center/source/zh/canncommercial/900/API/ascendcopapi/atlasascendc_api_07_0273.html','https://asc.gitcode.com/guide/programming_guide/language_extension/simd_builtin_keywords.html']),indent=2)+'\n')
 print(name,sha)
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='pair2quick'" not in s:
 s+='''
if mode=='pair2quick':
 items=[('split_one',1,32768,'float16'),('split_two',2,16384,'float16'),small[4],('sync2_8448',3,8448,'float16'),('sync2_24576',20,24576,'float16'),('sync2_fallback',21,32768,'float16')]
 check('pair2_check',items,['FACC','PAIR2','SYNC2'])
 for v in ['PAIR2','SYNC2']:
  pairs(v.lower()+'_pairs',[small[4],items[0],items[1]],'FACC',v,blocks=1)
if mode=='pair2edge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='pair2_edge_'+pattern;case(cid,8,32768,'float16',pattern);items.append((cid,8,32768,'float16'))
 check('pair2_edge_check',items,['FACC','PAIR2','SYNC2'])
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_pair2.tar.gz','w:gz') as t:
 for q in [H/'PAIR2',H/'SYNC2',p]:t.add(q,arcname=q.relative_to(H.parents[1]))
