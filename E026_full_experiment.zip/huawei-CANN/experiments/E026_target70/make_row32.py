from pathlib import Path
import re,shutil,json,hashlib
H=Path(__file__).resolve().parent
base=(H/'BASE/code/kernel.asc').read_text()
helper='''
__aicore__ inline uint64_t RowBoundary(uint64_t rows,uint32_t id,uint32_t blocks)
{
    // Preserve the original floor partition exactly, including large shapes.
    // Use the cheaper 32-bit division when its numerator cannot overflow.
    if(rows<=static_cast<uint64_t>(0xffffffffu/blocks))
        return (static_cast<uint32_t>(rows)*id)/blocks;
    return rows*id/blocks;
}
'''
code=base.replace('using namespace AscendC;','using namespace AscendC;\n'+helper,1)
code,n1=re.subn(r'(rows_?)\s*\*\s*GetBlockIdx\(\)\s*/\s*GetBlockNum\(\)',r'RowBoundary(\1,GetBlockIdx(),GetBlockNum())',code)
code,n2=re.subn(r'(rows_?)\s*\*\s*\(GetBlockIdx\(\)\s*\+\s*1\)\s*/\s*GetBlockNum\(\)',r'RowBoundary(\1,GetBlockIdx()+1,GetBlockNum())',code)
d=H/'ROW32/code';shutil.copytree(H/'BASE/code',d,dirs_exist_ok=True)
(d/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'ROW32/manifest.json').write_text(json.dumps({'variant':'ROW32','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'replaced_boundaries':n1+n2},indent=2)+'\n')
f=H/'run_round.py';s=f.read_text()
if "mode=='row32quick'" not in s:
 s+='''
if mode=='row32quick':
 check('row32_check',[small[i] for i in [1,2,3,5,6,7,10]],['BASE','ROW32'])
 pairs('row32_pairs',[small[i] for i in [2,3,5,6,10]],'BASE','ROW32',blocks=1)
'''
 f.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'sha256':hashlib.sha256(code.encode()).hexdigest(),'boundaries':n1+n2}))
