from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
code=(H/'LONGH/code/kernel.asc').read_text(encoding='utf-8')
old='''                    Prefetch(row,col+16384,slot,false);
                }
                Cast(tmp_,y_[col],RoundMode::CAST_NONE,n);'''
new='''                    Prefetch(row,col+16384,slot,false);
                } else {
                    // Final readers of each raw input slot must finish before
                    // the parameter phase reuses it for gamma/bias DMA.
                    SetFlag<HardEvent::V_MTE2>(slot);
                }
                Cast(tmp_,y_[col],RoundMode::CAST_NONE,n);'''
assert code.count(old)==1;code=code.replace(old,new)
old='            Prefetch(row,0,0,true);if(chunks>1)Prefetch(row,8192,1,true);'
new='''            WaitFlag<HardEvent::V_MTE2>(0);WaitFlag<HardEvent::V_MTE2>(1);
            Prefetch(row,0,0,true);if(chunks>1)Prefetch(row,8192,1,true);'''
assert code.count(old)==1;code=code.replace(old,new)
name='LONGH2';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BROAD2',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='LONGH static 8K input tiles with explicit last raw-input V_MTE2 lifetime fence before gamma/bias refill',numerical_change=True,fix_of='LONGH'),indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='longh2quick'" not in s:
 s+='''
if mode=='longh2quick':
 items=[small[4],('longh_8193',3,8193,'float16'),('longh_16384',41,16384,'float16'),('longh_24576',3,24576,'float16')]
 check('longh2_check',items,['BROAD2','LONGH2'])
 pairs('longh2_pairs',[small[4],items[2]],'BROAD2','LONGH2',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_longh2.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
