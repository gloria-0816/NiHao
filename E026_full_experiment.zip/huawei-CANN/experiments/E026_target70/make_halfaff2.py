from pathlib import Path
import hashlib,json,shutil
H=Path(__file__).resolve().parent
code=(H/'HALFAFF/code/kernel.asc').read_text()
# FP16 FMA is supported on A2. The nonexecuted BF16 template branch still
# instantiates calls, so explicitly bind this guarded operation to half.
code=code.replace('FusedMulAdd(out_[i*stride_],gh_,bh_,d_)',
 'FusedMulAdd(out_[i*stride_].template ReinterpretCast<half>(),gh_.template ReinterpretCast<half>(),bh_.template ReinterpretCast<half>(),d_)')
code=code.replace('FusedMulAdd(out_[col],gh_[col],bh_[col],Min(128,d_-col),count,',
 'FusedMulAdd(out_[col].template ReinterpretCast<half>(),gh_[col].template ReinterpretCast<half>(),bh_[col].template ReinterpretCast<half>(),Min(128,d_-col),count,')
assert code!=(H/'HALFAFF/code/kernel.asc').read_text()
name='HALFAFF2';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'COMBO2','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'FP16 native fused affine after FP32 normalization; compile guard for BF16 route','numerical_change':True},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='halfaff2quick'" not in s:
 s+='''
if mode=='halfaff2quick':
 check('halfaff2_check',[small[i] for i in [5,6,7,9,13]],['COMBO2','HALFAFF2'])
 pairs('halfaff2_pairs',[small[i] for i in [5,6,7,9]],'COMBO2','HALFAFF2',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
