from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'BFSIP/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class LongHalfRetainedKernel {');z=base.index('class HalfSharedResidualKernel {',a)
s=base[a:z]
s=s.replace('            Duplicate(partial_,0.0f,64);PipeBarrier<PIPE_V>();','            Duplicate(tmp_,0.0f,8192);PipeBarrier<PIPE_V>();')
start=s.index('                Cast(tmp_,y_[col]');end=s.index('\n            }\n            WholeReduceSum(sum_',start)
s=s[:start]+'''                // Mixed vmla squares half inputs directly into an FP32
                // accumulator, combining every retained 8192-element chunk.
                MulAddDst<float,half>(tmp_,y_[col],y_[col],n);PipeBarrier<PIPE_V>();'''+s[end:]
old='            WholeReduceSum(sum_,partial_,64,1,1,1,8);PipeBarrier<PIPE_V>();'
new='''            WholeReduceSum(work_,tmp_,64,128,1,1,8);PipeBarrier<PIPE_V>();
            Add(work_,work_,work_[64],64);PipeBarrier<PIPE_V>();
            WholeReduceSum(sum_,work_,64,1,1,1,8);PipeBarrier<PIPE_V>();'''
assert s.count(old)==1;s=s.replace(old,new)
code=base[:a]+s+base[z:]
dest=H/'LSQM/code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
sha=hashlib.sha256(code.encode()).hexdigest()
(H/'LSQM/manifest.json').write_text(json.dumps(dict(variant='LSQM',parent='BFSIP',source_sha256=sha,
 change='FP16 retained long rows: mixed MulAddDst<float,half> accumulates squared 8192-element chunks into one FP32 buffer, followed by one final FP32 reduction; full elementwise cast and per-chunk reductions removed',
 numerical_change=True,reference='https://www.hiascend.com/document/detail/en/canncommercial/850/API/ascendcopapi/atlasascendc_api_07_0048.html'),indent=2)+'\n')
p=H/'run_round.py';q=p.read_text(encoding='utf-8')
if "mode=='lsqmquick'" not in q:
 q+='''
if mode=='lsqmquick':
 items=[small[4]]+[('lh16g_'+str(d),3,d,'float16') for d in [8193,8448,16384,24576,32767]]+[('lconst_32k_many',41,32768,'float16')]
 check('lsqm_check',items,['BFSIP','LSQM'])
 pairs('lsqm_pairs',[small[4],items[3]],'BFSIP','LSQM',blocks=1)
if mode=='lsqmedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='lh16g_edge_'+pattern;case(cid,3,32768,'float16',pattern)
  items.append((cid,3,32768,'float16'))
 check('lsqm_edge_check',items,['BFSIP','LSQM'])
'''
 p.write_text(q,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_lsqm.tar.gz','w:gz') as tar:
 for target in [H/'LSQM',p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(sha)
