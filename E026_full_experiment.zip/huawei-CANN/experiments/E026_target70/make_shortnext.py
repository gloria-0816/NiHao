from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'BFPN4/code/kernel.asc').read_text(encoding='utf-8')
def save(name,code,change):
 dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFPN4',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change=change,numerical_change=True),indent=2)+'\n')
 print(name,hashlib.sha256(code.encode()).hexdigest())

a=base.index('class StaticHalfRowsKernel {');z=base.index('class TinyBatchFloatKernel {',a)
s=base[a:z]
old1='''        BlockReduceSum(work_,tmp_,active/64,64,1,1,8);
        PipeBarrier<PIPE_V>();
        WholeReduceSum(sums_,work_,static_cast<int32_t>(stride_/8),count_,1,1,parts);'''
old2='''        BlockReduceSum(work_, tmp_, static_cast<int32_t>(active / 64), 64, 1, 1, 8);
        PipeBarrier<PIPE_V>();
        WholeReduceSum(sums_, work_, static_cast<int32_t>(stride_ / 8),
                       static_cast<int32_t>(count_), 1, 1,
                       static_cast<uint8_t>(stride_ / 64));'''
tree='''        if(stride_==64) {
            WholeReduceSum(sums_,tmp_,64,count_,1,1,8);
        } else if(stride_==128) {
            Add(tmp_,tmp_,tmp_[8],64,count_,{2,2,2,16,16,16});PipeBarrier<PIPE_V>();
            WholeReduceSum(sums_,tmp_,64,count_,1,2,16);
        } else if(stride_==256) {
            Add(tmp_,tmp_,tmp_[8],64,count_*2,{2,2,2,16,16,16});PipeBarrier<PIPE_V>();
            Add(tmp_,tmp_,tmp_[16],64,count_,{4,4,4,32,32,32});PipeBarrier<PIPE_V>();
            WholeReduceSum(sums_,tmp_,64,count_,1,4,32);
        } else {
            BlockReduceSum(work_,tmp_,active/64,64,1,1,8);PipeBarrier<PIPE_V>();
            WholeReduceSum(sums_,work_,stride_/8,count_,1,1,stride_/64);
        }'''
assert s.count(old1)==1 and s.count(old2)==1
s=s.replace(old1,tree).replace(old2,tree)
save('SHORTTREE',base[:a]+s+base[z:],'FP16 and FP32 short rows use 32-byte interleaved block folds for power-of-two padded widths, followed by one WholeReduceSum')

a=base.index('class StaticHalfRowsKernel {');z=base.index('// At most four FP32',a);s=base[a:z]
old='''        Sqrt(sums_,sums_,rms);
        Duplicate(work_,1.0f,rms); PipeBarrier<PIPE_V>();
        Div(sums_,work_,sums_,rms); PipeBarrier<PIPE_V>();
        auto scales=work_[768].ReinterpretCast<half>();
        auto broadcast=work_.ReinterpretCast<half>();
        Cast(scales,sums_,RoundMode::CAST_RINT,count_);PipeBarrier<PIPE_V>();'''
new='''        auto scales=work_[768].ReinterpretCast<half>();
        auto ones=work_[800].ReinterpretCast<half>();
        auto broadcast=work_.ReinterpretCast<half>();
        Cast(scales,sums_,RoundMode::CAST_RINT,count_);PipeBarrier<PIPE_V>();
        Sqrt(scales,scales,count_);
        Duplicate(ones,static_cast<half>(1.0f),count_);PipeBarrier<PIPE_V>();
        Div(scales,ones,scales,count_);PipeBarrier<PIPE_V>();'''
assert s.count(old)==1;s=s.replace(old,new)
save('HINV',base[:a]+s+base[z:],'FP16 short rows retain FP32 square reduction, then round variance to half and use native half Sqrt/Div for inverse RMS')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='shorttreequick'" not in s:
 s+='''
if mode=='shorttreequick':
 items=[small[2],small[3]]+[('st_f'+str(d),129,d,'float32') for d in [64,65,127,128,193,255]]+[('st_h'+str(d),767,d,'float16') for d in [64,65,127,128,129,192,255,256]]
 check('shorttree_check',items,['BFPN4','SHORTTREE'])
 pairs('shorttree_pairs',[small[2],small[3]],'BFPN4','SHORTTREE',blocks=1)
if mode=='hinvquick':
 items=[small[3]]+[('hi_'+str(d),767,d,'float16') for d in [64,65,127,128,129,192,255,256]]
 for pattern in ['zeros','cancel','wide_range','specials']:
  cid='hi_'+pattern;case(cid,767,193,'float16',pattern=pattern);items.append((cid,767,193,'float16'))
 check('hinv_check',items,['BFPN4','HINV'])
 pairs('hinv_pairs',[small[3]],'BFPN4','HINV',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_shortnext.tar.gz','w:gz') as tar:
 for target in [H/'SHORTTREE',H/'HINV',p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
