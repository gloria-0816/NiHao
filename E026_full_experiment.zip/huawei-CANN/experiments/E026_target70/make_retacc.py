from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent;base=(H/'COMBO1/code/kernel.asc').read_text()
a=base.index('class RetainedLongRowKernel {');z=base.index('template <typename T>\n__global__ __vector__ void retained_long_row_custom',a)
s=base[a:z].replace('RetainedLongRowKernel','RetainedAccKernel')
s=s.replace('const uint8_t inputBuffers = sizeof(T) == sizeof(float) ? 1 : 2;','const uint8_t inputBuffers = 1;')
s=s.replace('        pipe_.InitBuffer(partials_, 1024);','        pipe_.InitBuffer(partials_, 1024);\n        pipe_.InitBuffer(accum_,tile*sizeof(float));')
s=s.replace('            Duplicate(partials, 0.0f, groups * 64);\n            PipeBarrier<PIPE_V>();','')
old='''                qfirst_.FreeTensor(g);
                qsecond_.FreeTensor(b);
                const uint32_t next = col + tile_;
                if (next < d_) {
                    PrefetchPair(g_, b_, next, Min(tile_, d_ - next));
                }
'''
assert old in s;s=s.replace(old,'',1)
s=s.replace('!RetainedEarlyInputPrefetchType<T>::value','false').replace('RetainedEarlyInputPrefetchType<T>::value','true')
old='''        ReduceSum(partials[chunk * 8], tmp, work, padded);
        PipeBarrier<PIPE_V>();'''
new='''        auto accum=accum_.template Get<float>();
        if(col==0)Adds(accum,tmp,0.0f,padded);
        else Add(accum,accum,tmp,padded);
        PipeBarrier<PIPE_V>();'''
assert old in s;s=s.replace(old,new,1)
ia=s.index('        // Each group comprises eight float partials')
iz=s.index('        Muls(partials, partials, invD_, 1);',ia)
s=s[:ia]+'''        auto accum=accum_.template Get<float>();
        WholeReduceSum(work,accum,64,tile_/64,1,1,8);PipeBarrier<PIPE_V>();
        WholeReduceSum(partials,work,static_cast<int32_t>(tile_/64),1,1,1,8);PipeBarrier<PIPE_V>();
'''+s[iz:]
ia=s.index('        Muls(y, y, invRms, n);',s.index('inline void NormalizeRetained'))
iz=s.index('\n    }',ia)
s=s[:ia]+'''        auto bias=accum_.template Get<float>();
        ToFloat<T>(tmp,g,n);ToFloat<T>(bias,b,n);PipeBarrier<PIPE_V>();
        qfirst_.FreeTensor(g);qsecond_.FreeTensor(b);
        const uint32_t next=col+tile_;
        if(next<d_)PrefetchPair(g_,b_,next,Min(tile_,d_-next));
        Muls(y,y,invRms,n);PipeBarrier<PIPE_V>();
        Mul(y,y,tmp,n);PipeBarrier<PIPE_V>();
        Add(y,y,bias,n);PipeBarrier<PIPE_V>();'''+s[iz:]
s=s.replace('TBuf<QuePosition::VECCALC> tmpbuf_, workbuf_, partials_;','TBuf<QuePosition::VECCALC> tmpbuf_, workbuf_, partials_, accum_;')
s+='''template <typename T>
__global__ __vector__ void retained_acc_custom(GM_ADDR x,GM_ADDR r,GM_ADDR g,GM_ADDR b,GM_ADDR out,
    uint64_t rows,uint32_t d,float invD,float eps)
{
    RetainedAccKernel<T> op;op.Init(x,r,g,b,out,rows,d,4096,invD,eps);op.Process();
}
'''
(H/'retained_acc.inc').write_text(s,encoding='utf-8',newline='\n')
code=base.replace('class StaticHalfRowsKernel {',s+'\nclass StaticHalfRowsKernel {',1)
anchor='    if (input.dtype == 1 && d <= 256'
launch='''    if((input.dtype==1 || input.dtype==2) && d>8192 && d<=32768 && d%4096==0) {
        if(input.dtype==1)retained_acc_custom<half><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        else retained_acc_custom<bfloat16_t><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert anchor in code;code=code.replace(anchor,launch+anchor,1)
name='RETACC';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'COMBO1','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'queue-safe vertical accumulation, one final reduction, early parameter prefetch','ub_peak_bytes':191488},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='retaccquick'" not in s:
 s+='''
if mode=='retaccquick':
 check('retacc_check',[small[4],('longacc_16',41,16384,'float16'),('longacc_24',3,24576,'float16')],['COMBO1','RETACC'])
 pairs('retacc_pairs',[small[4]],'COMBO1','RETACC',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
