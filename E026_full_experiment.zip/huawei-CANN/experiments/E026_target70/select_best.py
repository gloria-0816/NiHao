from pathlib import Path
import json,shutil,hashlib,zipfile
H=Path(__file__).resolve().parent
official=json.loads((H/'official_results.json').read_text(encoding='utf-8'))
best=max((r for r in official if 'score' in r and len(r['points'])==15 and all(p['status']=='Pass' for p in r['points'])),key=lambda r:r['score'])
source=H/best['variant']/'code';dst=H/'selected/code'
shutil.copytree(source,dst,dirs_exist_ok=True)
sha=hashlib.sha256((dst/'kernel.asc').read_bytes()).hexdigest()
original=json.loads((H/best['variant']/'manifest.json').read_text())
assert sha==original['source_sha256']
with zipfile.ZipFile(H/'selected/project.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for p in sorted(dst.rglob('*')):
  if p.is_file():archive.write(p,p.relative_to(dst).as_posix())
with zipfile.ZipFile(H/'selected/project.zip') as archive:
 assert archive.testzip() is None
 for entry in archive.infolist():assert archive.read(entry)==(dst/entry.filename).read_bytes()
best.update(source_sha256=sha,goal_score=70,goal_achieved=best['score']>=70)
(H/'selected/selection.json').write_text(json.dumps(best,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'variant':best['variant'],'score':best['score'],'source_sha256':sha,'archive_files':len(list(dst.rglob('*')))},ensure_ascii=False))
