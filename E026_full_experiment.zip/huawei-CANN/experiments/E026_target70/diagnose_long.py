import numpy as np,json
from pathlib import Path
p=Path('/mnt/workspace/addrms_results/E026/longacc_check/s5_LONGACC/case')
def read(n):return np.fromfile(p/n,np.float16).astype(np.float32)
x=read('x.bin').reshape(8,32768);r=read('residual.bin').reshape(8,32768)
g=read('gamma.bin');b=read('bias.bin');out=read('output.bin').reshape(x.shape)
y=x+r;inv=1/np.sqrt(np.mean(y*y,axis=1)+1e-5)
for i in range(8):
 q=(out[i]-b)/g; good=np.abs(g)>.1
 print(i,'expected_inverse',float(inv[i]),'chunk_relative_l2',[float(np.linalg.norm(q[k:k+4096]-y[i,k:k+4096]*inv[i])/np.linalg.norm(y[i,k:k+4096]*inv[i])) for k in range(0,32768,4096)],'estimated_inv',[float(np.sum((q[k:k+4096]*y[i,k:k+4096])[good[k:k+4096]])/np.sum((y[i,k:k+4096]**2)[good[k:k+4096]])) for k in range(0,32768,4096)])
