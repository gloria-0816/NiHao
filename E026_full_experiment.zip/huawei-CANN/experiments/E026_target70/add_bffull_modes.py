from pathlib import Path
import tarfile
H=Path(__file__).resolve().parent;p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='bffullquick'" not in s:
 s+='''
if mode=='bffullquick':
 pairs('bffull14_pairs',[('bffull14',3317760,128,'bfloat16')],'FACC','BFSB2',blocks=1)
 for group,cand in [('bffull15_db_pairs','BFDB8'),('bffull15_inv_pairs','BFINV'),('bffull15_rr_pairs','BFRR')]:
  pairs(group,[('bffull15',117760,8192,'bfloat16')],'FACC',cand,blocks=1)
if mode=='bffulldiag':
 for cid in ['bffull14','bffull15']:
  core.run_case(OUT/'bffull_op'/cid,cid,'FACC',dict(warmup=11,repeats=1,batch=5,timing='host'),'op')
 core.save(OUT/'bffull_op'/'complete.json',dict(cases=2))
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_bffull.tar.gz','w:gz') as t:
 for q in [H/'prepare_bffull.py',p]:t.add(q,arcname=q.relative_to(H.parents[1]))
