from pathlib import Path
import json, hashlib, shutil

H=Path(__file__).resolve().parent
ROOT=H.parents[1]
parent=ROOT/'experiments/E025_pipeline/DB9/code'
base=(parent/'kernel.asc').read_text(encoding='utf-8')
variants={'BASE':base}

def replace_section(code, name, next_name, transform):
    start=code.index('class '+name+' {')
    end=code.index(next_name,start)
    return code[:start]+transform(code[start:end])+code[end:]

def halfpack(s):
    old='''        SetFlag<HardEvent::V_MTE3>(1); WaitFlag<HardEvent::V_MTE3>(1);
        DataCopyExtParams out = {static_cast<uint16_t>(count_),d_*2,gap,0,0};
        DataCopyPad(outgm_[begin_*d_],r_,out);'''
    new='''        // A2 GatherMask counter mode packs d_ valid values per row.
        // Input-x is dead after the FP32 casts, so it becomes packed output.
        uint64_t kept=0;
        GatherMask(x_,r_,static_cast<uint8_t>(7),true,d_,
            {1,static_cast<uint16_t>(count_),static_cast<uint16_t>(stride_/16),0},kept);
        PipeBarrier<PIPE_V>();
        SetFlag<HardEvent::V_MTE3>(1); WaitFlag<HardEvent::V_MTE3>(1);
        DataCopyExtParams out = {1,count_*d_*2,0,0,0};
        DataCopyPad(outgm_[begin_*d_],x_,out);'''
    assert old in s
    return s.replace(old,new,1)

def fpack(s):
    old='''            DataCopyExtParams params={static_cast<uint16_t>(count),static_cast<uint32_t>(d_*sizeof(T)),
                static_cast<uint32_t>((stride_*sizeof(T)-(d_*sizeof(T)+31)/32*32)/32),0,0};
            DataCopyPad(out_[row*d_],x,params);'''
    new='''            // Residual storage is dead here. Compact valid FP32 rows in it
            // and send one contiguous output burst, with no padded row gaps.
            uint64_t kept=0;
            GatherMask(tmp,y,static_cast<uint8_t>(7),true,d_,
                {1,static_cast<uint16_t>(count),static_cast<uint16_t>(stride_/8),0},kept);
            PipeBarrier<PIPE_V>();
            SetFlag<HardEvent::V_MTE3>(ready);WaitFlag<HardEvent::V_MTE3>(ready);
            DataCopyExtParams params={1,static_cast<uint32_t>(count*d_*sizeof(T)),0,0,0};
            DataCopyPad(out_[row*d_],r,params);'''
    assert old in s
    return s.replace(old,new,1)

packed=replace_section(base,'StaticHalfRowsKernel','__global__ __vector__ void static_half_rows_custom',halfpack)
packed=replace_section(packed,'MultiRowDirectKernel','__global__ __vector__ void multi_row_direct_custom',fpack)
variants['PACK']=packed

def block(s):
    a=s.index('        Duplicate(sums_,0.0f,rms);')
    b=s.index('        PipeBarrier<PIPE_V>();\n        Muls(sums_',a)
    return s[:a]+'''        BlockReduceSum(work_,tmp_,active/64,64,1,1,8);
        PipeBarrier<PIPE_V>();
        WholeReduceSum(sums_,work_,static_cast<int32_t>(stride_/8),count_,1,1,parts);
'''+s[b:]

variants['HALFBR']=replace_section(base,'StaticHalfRowsKernel','__global__ __vector__ void static_half_rows_custom',block)

def bigger(s):
    s=s.replace('8192','12288')
    offsets={'16512':24704,'33024':49408,'65920':98688,'98816':147968,
             '100096':149248,'101248':150400,'101888':151040,
             '102528':151680,'106752':160000}
    for key,value in offsets.items():s=s.replace(', '+key+',',', '+str(value)+',')
    s=s.replace('151680, 1024','151680, 2048').replace('160000, 32','160000, 64')
    return s

h20=replace_section(base,'StaticHalfRowsKernel','__global__ __vector__ void static_half_rows_custom',bigger)
anchor='    if (input.dtype == 1 && d <= 256'
launch='''    // Short-row kernels can suffer shared-parameter traffic across all AIVs.
    // Use half the available vector cores when one enlarged UB tile fits.
    const uint32_t shortCores=(blockNum+1)/2;
    if(input.dtype==1 && d<=256 && rows>=static_cast<uint64_t>(blockNum)*4 &&
        rows<=static_cast<uint64_t>(shortCores)*(12288/((d+63)/64*64))) {
        static_half_rows_custom<<<shortCores,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert anchor in h20
variants['H20']=h20.replace(anchor,launch+anchor,1)

for name,code in variants.items():
    dest=H/name/'code';shutil.copytree(parent,dest,dirs_exist_ok=True)
    (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
    (H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'E025/DB9','source_sha256':hashlib.sha256(code.encode()).hexdigest()},indent=2)+'\n')

driver=(ROOT/'experiments/E025_pipeline/run_round.py').read_text()
driver=driver[:driver.index("mode=sys.argv[1]")]
driver=driver.replace("OUT=Path('/mnt/workspace/addrms_results/E025')","OUT=Path('/mnt/workspace/addrms_results/E026')")
driver=driver.replace("if v=='BASE':return HERE/'build_BASE/cloud_addrmsnormbias'","if v=='BASE':return ROOT/'experiments/E025_pipeline/build_DB9/cloud_addrmsnormbias'")
driver+='''
mode=sys.argv[1]
if mode=='build':build(sys.argv[2:])
if mode=='packquick':
 check('pack_check',[small[i] for i in [3,10,12]],['BASE','PACK'])
 pairs('pack_pairs',[small[i] for i in [3,10,12]],'BASE','PACK',blocks=1)
if mode=='halfbrquick':
 check('halfbr_check',[small[3]],['BASE','HALFBR'])
 pairs('halfbr_pairs',[small[3]],'BASE','HALFBR',blocks=1)
if mode=='h20quick':
 check('h20_check',[small[3]],['BASE','H20'])
 pairs('h20_pairs',[small[3]],'BASE','H20',blocks=1)
'''
(H/'run_round.py').write_text(driver,encoding='utf-8',newline='\n')
print(json.dumps({v:hashlib.sha256(s.encode()).hexdigest() for v,s in variants.items()},indent=2))
