from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent
code=(H/'COMBO1/code/kernel.asc').read_text()
a=code.index('class PipelineBatch9Kernel {');z=code.index('template <typename T,bool BlockReduction>',a);s=code[a:z]
old='            DataCopyExtParams copy={static_cast<uint16_t>(count),static_cast<uint32_t>(d_*sizeof(T)),Gap(),0,0};'
new='''            DataCopyExtParams copy={static_cast<uint16_t>(count),static_cast<uint32_t>(d_*sizeof(T)),Gap(),0,0};
            if(d_==stride_)copy={1,static_cast<uint32_t>(count*d_*sizeof(T)),0,0,0};'''
assert old in s;s=s.replace(old,new,1)
old='        DataCopyExtParams copy={static_cast<uint16_t>(count),static_cast<uint32_t>(d_*sizeof(T)),0,Gap(),0};'
new='''        DataCopyExtParams copy={static_cast<uint16_t>(count),static_cast<uint32_t>(d_*sizeof(T)),0,Gap(),0};
        if(d_==stride_)copy={1,static_cast<uint32_t>(count*d_*sizeof(T)),0,0,0};'''
assert old in s;s=s.replace(old,new,1)
code=code[:a]+s+code[z:];name='FLATDMA';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'source_sha256':hashlib.sha256(code.encode()).hexdigest(),'parent':'COMBO1','change':'single contiguous DMA for aligned batches'},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='flatdmaquick'" not in s:
 s+='''
if mode=='flatdmaquick':
 check('flatdma_check',[small[i] for i in [5,6,7,9,13]],['COMBO1','FLATDMA'])
 pairs('flatdma_pairs',[small[i] for i in [7,9,13]],'COMBO1','FLATDMA',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
