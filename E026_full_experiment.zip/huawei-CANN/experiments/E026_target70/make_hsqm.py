from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'BFSIP/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class StaticHalfRowsKernel {');z=base.index('class ShortFloatPartitionKernel {',a)
s=base[a:z]
anchor='        DataCopyPad(x_,xgm_[begin_*d_],batch,pad);'
assert s.count(anchor)==1
s=s.replace(anchor,'        Duplicate(tmp_,0.0f,active);\n'+anchor)
start=s.index('        ToFloat<half>(y_,x_,active)');end=s.index('        const uint32_t parts = stride_/64;',start)
s=s[:start]+'''        if(d_!=stride_) {
            const uint32_t lane=d_%128,endLane=stride_-d_/128*128;
            uint64_t tail[2]={lane<64?(~static_cast<uint64_t>(0)<<lane):0,
                endLane==128?(lane<64?~static_cast<uint64_t>(0):(~static_cast<uint64_t>(0)<<(lane-64))):0};
            Duplicate(x_[d_/128*128],static_cast<half>(0),tail,count_,1,stride_/16);PipeBarrier<PIPE_V>();
        }
        // Initialization overlaps input DMA; mixed vmla produces FP32 squares
        // directly from the retained half residual without a full Cast tile.
        MulAddDst<float,half>(tmp_,x_,x_,active);PipeBarrier<PIPE_V>();
'''+s[end:]
s=s.replace('        y_ = LocalTensor<float>(TPosition::VECCALC, 33024, 8192);\n','')
s=s.replace('LocalTensor<float> y_,tmp_,gamma_,bias_,work_,sums_;','LocalTensor<float> tmp_,gamma_,bias_,work_,sums_;')
code=base[:a]+s+base[z:]
dest=H/'HSQM/code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
sha=hashlib.sha256(code.encode()).hexdigest()
(H/'HSQM/manifest.json').write_text(json.dumps(dict(variant='HSQM',parent='BFSIP',source_sha256=sha,
 change='FP16 static short-row path overlaps zeroing FP32 square buffer with input DMA and squares retained half residual with mixed MulAddDst; native half tail clearing stays within each row',numerical_change=False),indent=2)+'\n')
p=H/'run_round.py';q=p.read_text(encoding='utf-8')
if "mode=='hsqmquick'" not in q:
 q+='''
if mode=='hsqmquick':
 items=[small[3]]+[('hshortn_'+str(d),767,d,'float16') for d in [64,65,127,128,129,192,255,256]]
 check('hsqm_check',items,['BFSIP','HSQM'])
 pairs('hsqm_pairs',[small[3]],'BFSIP','HSQM',blocks=1)
'''
 p.write_text(q,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_hsqm.tar.gz','w:gz') as tar:
 for target in [H/'HSQM',p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(sha)
