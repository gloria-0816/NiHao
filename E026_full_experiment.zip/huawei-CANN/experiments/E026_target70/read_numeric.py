from pathlib import Path
import json,sys
O=Path('/mnt/workspace/addrms_results/E026')
for group in sys.argv[1:]:
    print(group)
    p=O/group/'records.json'
    if not p.exists():continue
    for x in json.loads(p.read_text()):
        s=x.get('strict',{});n=s.get('elements',0);failed=s.get('failed_elements',0)
        print(dict(case=x['case_id'],variant=x['variant'],elements=n,failed=failed,failed_pct=100*failed/n if n else None,classification=s.get('classification_failures'),max_abs_error=s.get('max_abs_error'),bitwise_equal_parent=x.get('bitwise_equal_parent')))
