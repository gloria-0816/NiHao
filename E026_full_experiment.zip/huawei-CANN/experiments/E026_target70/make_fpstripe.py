from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'BFP3/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class FloatBroadTripleKernel {');z=base.index('__global__ __vector__ void float_broad_triple_custom',a)
s=base[a:z].replace('FloatBroadTripleKernel','FloatStripedKernel')
old='begin_=rows*GetBlockIdx()/GetBlockNum();end_=rows*(GetBlockIdx()+1)/GetBlockNum();invD_=invD;eps_=eps;'
new='begin_=static_cast<uint64_t>(GetBlockIdx())*batch_;end_=rows;step_=static_cast<uint64_t>(batch_)*GetBlockNum();invD_=invD;eps_=eps;'
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('+2*batch_','+2*step_').replace('+batch_','+step_').replace('row+=batch_','row+=step_')
s=s.replace('uint64_t begin_,end_;','uint64_t begin_,end_,step_;')
entry='''__global__ __vector__ void float_striped_custom(GM_ADDR x,GM_ADDR r,GM_ADDR g,GM_ADDR b,GM_ADDR out,
    uint64_t rows,uint32_t d,float invD,float eps) {
    InitSocState();FloatStripedKernel op;op.Init(x,r,g,b,out,rows,d,invD,eps);op.Process();
}
'''
code=base[:a]+s+entry+'\n'+base[a:]
anchor='    if(input.dtype==0 && d>1536 && d<=4096'
assert code.count(anchor)==1
code=code.replace(anchor,'''    if(input.dtype==0 && d>1536 && d<=4096 && rows>=static_cast<uint64_t>(blockNum)*16) {
        float_striped_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''+anchor)
name='FPSTRIPE';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFP3',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='Wide FP32 row batches interleaved across cores, so neighboring cores read neighboring GM ranges; math and buffer capacity preserved',numerical_change=False,ub_end_bytes=187264),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='fpstripequick'" not in s:
 s+='''
if mode=='fpstripequick':
 items=[small[10],small[12]]+[('fpstripe_'+str(d),641,d,'float32') for d in [1537,2048,3136,3200,4095,4096]]
 check('fpstripe_check',items,['BFP3','FPSTRIPE'])
 pairs('fpstripe_pairs',[small[10],small[12]],'BFP3','FPSTRIPE',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_fpstripe.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
