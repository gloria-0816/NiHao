from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'FACC/code/kernel.asc').read_text(encoding='utf-8')
ref=(H/'HSQM/code/kernel.asc').read_text(encoding='utf-8')
a=ref.index('class StaticHalfRowsKernel {');z=ref.index('class ShortFloatPartitionKernel {',a)
p=ref[a:z].replace('StaticHalfRowsKernel','LargeShortHalfRowsKernel').replace('static_half_rows_custom','large_short_half_rows_custom')
p=p.replace('TPosition::VECIN, 0, 8192','TPosition::VECIN, 0, 16384')
p=p.replace('TPosition::VECIN, 16512, 8192','TPosition::VECIN, 32896, 16384')
p=p.replace('TPosition::VECCALC, 65920, 8192','TPosition::VECCALC, 65792, 16384')
p=p.replace('        gamma_ = LocalTensor<float>(TPosition::VECCALC, 98816, 256);\n','')
p=p.replace('        bias_ = LocalTensor<float>(TPosition::VECCALC, 100096, 256);\n','')
p=p.replace('TPosition::VECIN, 101248, 256','TPosition::VECIN, 131584, 256')
p=p.replace('TPosition::VECIN, 101888, 256','TPosition::VECIN, 132224, 256')
p=p.replace('TPosition::VECCALC, 102528, 1024','TPosition::VECCALC, 132864, 2048')
p=p.replace('TPosition::VECCALC, 106752, 32','TPosition::VECCALC, 141184, 64')
p=p.replace('LocalTensor<float> tmp_,gamma_,bias_,work_,sums_;','LocalTensor<float> tmp_,work_,sums_;')
code=base.replace('class StaticHalfRowsKernel {',p+'\nclass StaticHalfRowsKernel {',1)
anchor='    if (input.dtype == 1 && d <= 256 && rows >= static_cast<uint64_t>(blockNum)*4 &&'
assert code.count(anchor)==1
branch='''    if (input.dtype==1 && d<=256 && rows>static_cast<uint64_t>(blockNum)*32 &&
        rows<=static_cast<uint64_t>(blockNum)*63) {
        large_short_half_rows_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
code=code.replace(anchor,branch+anchor)
name='HSM63';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n');sha=hashlib.sha256(code.encode()).hexdigest()
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='FACC',source_sha256=sha,change='FP16 short rows: retain half residual and mixed FP32 square without full float residual tile; fit up to 63 rows per core and preserve existing path up to 32 rows; max BlockReduce repeats 252',static_ub_end=141440,numerical_change=True),indent=2)+'\n')
q=H/'run_round.py';s=q.read_text(encoding='utf-8')
if "mode=='hsm63quick'" not in s:
 s+='''
if mode=='hsm63quick':
 items=[('hsm63_'+str(r)+'_'+str(d),r,d,'float16') for r,d in [(1280,193),(1281,193),(1313,193),(2047,193),(2519,193),(2520,256),(2521,256),(2047,65),(2047,192),(2047,255)]]
 check('hsm63_check',items,['FACC','HSM63'])
 pairs('hsm63_pairs',[items[i] for i in [2,3,5,8]],'FACC','HSM63',blocks=1)
if mode=='hsm63edge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='hsm63_edge_'+pattern;case(cid,2047,193,'float16',pattern);items.append((cid,2047,193,'float16'))
 check('hsm63_edge_check',items,['FACC','HSM63'])
'''
 q.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_hsm63.tar.gz','w:gz') as t:
 for q in [H/name,q]:t.add(q,arcname=q.relative_to(H.parents[1]))
print(name,sha)
