from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'LSQM/code/kernel.asc').read_text(encoding='utf-8')
inc=(H/'half_native_mixed.inc').read_text(encoding='utf-8')
anchor='class BFloatShortInplaceKernel {'
assert base.count(anchor)==1
code=base.replace(anchor,inc+'\n'+anchor)
old='if(input.dtype==1) pipeline_batch9_custom<half,true><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'
new='if(input.dtype==1) half_native_mixed_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'
assert code.count(old)==1;code=code.replace(old,new)
dest=H/'HNQM/code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
sha=hashlib.sha256(code.encode()).hexdigest()
(H/'HNQM/manifest.json').write_text(json.dumps(dict(variant='HNQM',parent='LSQM',source_sha256=sha,
 change='FP16 D321..1024 many-row path: retain native half residual, mixed FP32 square accumulation, compact in-place BlockReduce partials, half normalization/FMA and double input/output slots; capacity 23040; deferred output drains overlap next reduction',
 numerical_change=True,static_ub_end=195840),indent=2)+'\n')
p=H/'run_round.py';q=p.read_text(encoding='utf-8')
if "mode=='hnqmquick'" not in q:
 q+='''
if mode=='hnqmquick':
 items=[small[i] for i in [5,6,7,9]]+[('hip_'+str(d),257,d,'float16') for d in [321,383,384,447,511,512,513,767,1023,1024]]
 check('hnqm_check',items,['LSQM','HNQM'])
 pairs('hnqm_pairs',[small[i] for i in [5,6,7,9]],'LSQM','HNQM',blocks=1)
if mode=='hnqmedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='hnqm_edge_'+pattern;case(cid,257,577,'float16',pattern)
  items.append((cid,257,577,'float16'))
 check('hnqm_edge_check',items,['LSQM','HNQM'])
'''
 p.write_text(q,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_hnqm.tar.gz','w:gz') as tar:
 for target in [H/'HNQM',p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(sha)
