from pathlib import Path
import json,hashlib,shutil,tarfile,re
H=Path(__file__).resolve().parent;base=(H/'BFSIP/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class BFloatShortInplaceKernel {');z=base.index('class StaticHalfRowsKernel {',a)
names=[]
for rows in [125,127]:
 name='BFS'+str(rows);names.append(name);s=base[a:z]
 start=s.index('        x_[0]=LocalTensor');end=s.index('\n    }',start)
 cap=rows*128
 if rows==125:layout=[0,32128,64256,128384,192512,193152]
 else:layout=[0,32640,65280,130432,195488,196032]
 s=s[:start]+f'''        x_[0]=LocalTensor<bfloat16_t>(TPosition::VECIN,{layout[0]},{cap});
        x_[1]=LocalTensor<bfloat16_t>(TPosition::VECIN,{layout[1]},{cap});
        tmp_=LocalTensor<float>(TPosition::VECCALC,{layout[2]},{cap});r_=tmp_.ReinterpretCast<bfloat16_t>();
        y_=LocalTensor<float>(TPosition::VECCALC,{layout[3]},{cap});
        gf_=LocalTensor<float>(TPosition::VECCALC,{layout[4]},128);
        bf_=LocalTensor<float>(TPosition::VECCALC,{layout[5]},128);'''+s[end:]
 s=s.replace('119',str(rows)).replace('238',str(rows*2))
 anchor='            BlockReduceSum(work_,tmp_,active/64,64,1,1,8);'
 new='''            // X has been cast and is dead until output conversion.
            // Reuse it for at most 2032 reduction partials, then RMS broadcast.
            work_=x_[slot].ReinterpretCast<float>();sums_=work_[2048];
'''+anchor
 assert s.count(anchor)==1;s=s.replace(anchor,new)
 code=base[:a]+s+base[z:]
 dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFSIP',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change=f'BF16 D128 {rows}-row batches borrow consumed X slot for BlockReduce partials, sums and broadcast, then BF16 output; arithmetic and prefetch order retained',static_ub_end=layout[5]+512,numerical_change=False),indent=2)+'\n')
 print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='bfsmaxquick'" not in s:
 s+='''
if mode=='bfsmaxquick':
 items=[small[13]]+[('bfsmax_'+str(r),r,128,'bfloat16') for r in [5000,5080,5081,9501]]
 for v in ['BFS125','BFS127']:
  check(v.lower()+'_check',items,['BFSIP',v])
  pairs(v.lower()+'_pairs',[small[13]],'BFSIP',v,blocks=1)
if mode=='bfsmaxlarge':
 items=[('bf128s_large',524288,128,'bfloat16')]
 check('bfsmax_large_check',items,['BFSIP','BFS125','BFS127'])
 for v in ['BFS125','BFS127']:
  pairs(v.lower()+'_large_pairs',items,'BFSIP',v,blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_bfsmax.tar.gz','w:gz') as tar:
 for target in [*[H/n for n in names],p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
