from pathlib import Path
import shutil,json,hashlib
H=Path(__file__).resolve().parent
base=(H/'BASE/code/kernel.asc').read_text()
inc=(H/'split_long.inc').read_text()
code=base.replace('class StaticHalfRowsKernel {',inc+'\nclass StaticHalfRowsKernel {',1)
anchor='    if (input.dtype == 1 && d <= 256'
launch='''    if(input.dtype==1 && d>8192 && d<=32768 && rows<=static_cast<uint64_t>(availableCoreNum)/2) {
        uint32_t splits=2;
        while(splits<8 && rows*(splits*2)<=static_cast<uint64_t>(availableCoreNum))splits*=2;
        if(d%(splits*64)==0 && d/splits<=8192) {
            split_long_custom<half><<<static_cast<uint32_t>(rows*splits),nullptr,stream>>>(x,residual,gamma,bias,output,d,splits,inverseD,epsilon);
            return;
        }
    }
'''
assert anchor in code
code=code.replace(anchor,launch+anchor,1)
d=H/'SPLIT/code';shutil.copytree(H/'BASE/code',d,dirs_exist_ok=True)
(d/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'SPLIT/manifest.json').write_text(json.dumps({'variant':'SPLIT','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'ub_end_bytes':165408},indent=2)+'\n')
f=H/'run_round.py';s=f.read_text()
if "mode=='splitquick'" not in s:
 s+='''
if mode=='splitquick':
 check('split_check',[small[4],('split_one',1,32768,'float16'),('split_two',2,16384,'float16')],['BASE','SPLIT'])
 pairs('split_pairs',[small[4]],'BASE','SPLIT',blocks=1)
'''
 f.write_text(s,encoding='utf-8',newline='\n')
print(hashlib.sha256(code.encode()).hexdigest())
