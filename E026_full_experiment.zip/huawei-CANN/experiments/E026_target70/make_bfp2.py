from pathlib import Path
import hashlib,json,re,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'SHAREDA/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class PipelineBatch9Kernel {');z=base.index('template <typename T,bool BlockReduction>',a)
s=base[a:z].replace('PipelineBatch9Kernel','BFloatBatchPipelineKernel')
s=re.sub(r'\bT\b','bfloat16_t',s);s=s.replace('BlockReduction','false')
s=s.replace('batch_=9408/stride_;','batch_=8192/stride_;')
start=s.index('        x_[0]=LocalTensor');end=s.index('    }\n    __aicore__ inline void Process()',start)
s=s[:start]+'''        x_[0]=LocalTensor<bfloat16_t>(TPosition::VECIN,0,8192);
        x_[1]=LocalTensor<bfloat16_t>(TPosition::VECIN,16512,8192);
        r_[0]=LocalTensor<bfloat16_t>(TPosition::VECIN,33024,8192);
        r_[1]=LocalTensor<bfloat16_t>(TPosition::VECIN,49536,8192);
        y_=LocalTensor<float>(TPosition::VECCALC,66048,8192);
        tmp_=LocalTensor<float>(TPosition::VECCALC,98944,8192);
        out_=LocalTensor<bfloat16_t>(TPosition::VECOUT,131840,8192);
        gamma_=LocalTensor<float>(TPosition::VECCALC,148352,4096);
        bias_=LocalTensor<float>(TPosition::VECCALC,164864,4096);
        gh_=x_[0];bh_=r_[0];
        work_=LocalTensor<float>(TPosition::VECCALC,181376,1024);
        sums_=LocalTensor<float>(TPosition::VECCALC,185600,128);
'''+s[end:]
old='''        PipeBarrier<PIPE_V>();
        Prefetch(begin_,0);'''
new='''        PipeBarrier<PIPE_V>();
        // Parameter Cast still reads the first raw input slots.
        SetFlag<HardEvent::V_MTE2>(3);WaitFlag<HardEvent::V_MTE2>(3);
        Prefetch(begin_,0);'''
assert s.count(old)==1;s=s.replace(old,new)
old='''                Duplicate(y_[d_/64*64],0.0f,tail,count,1,stride_/8);'''
new='''                for(uint32_t i=0;i<count;++i)
                    Duplicate(y_[i*stride_+d_/64*64],0.0f,tail,1,1,8);'''
assert s.count(old)==1;s=s.replace(old,new)
entry='''__global__ __vector__ void bfloat_batch_pipeline_custom(GM_ADDR x,GM_ADDR r,GM_ADDR g,
    GM_ADDR b,GM_ADDR out,uint64_t rows,uint32_t d,float invD,float eps) {
    InitSocState();BFloatBatchPipelineKernel op;op.Init(x,r,g,b,out,rows,d,invD,eps);op.Process();
}
'''
code=base.replace('class StaticHalfRowsKernel {',s+entry+'\nclass StaticHalfRowsKernel {',1)
anchor='    if(input.dtype==1 && d>=321 && d<=1024 && d%64==0'
launch='''    if(input.dtype==2 && d>1024 && d<=4096 && rows>=static_cast<uint64_t>(blockNum)*4) {
        bfloat_batch_pipeline_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert code.count(anchor)==1;code=code.replace(anchor,launch+anchor)
name='BFP2';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='SHAREDA',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='BF16 1025..4096 uses multi-row batch pipeline with two input slots, cached FP32 affine operands and direct Cast output; reduction remains FP32',numerical_change=True,ub_end_bytes=186112),indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='bfp2quick'" not in s:
 s+='''
if mode=='bfp2quick':
 items=[small[11]]+[('bfp2_'+str(d),257,d,'bfloat16') for d in [1025,1536,2048,2049,3079,4095,4096]]
 check('bfp2_check',items,['SHAREDA','BFP2'])
 pairs('bfp2_pairs',[small[11],items[3],items[-1]],'SHAREDA','BFP2',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_bfp2.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
