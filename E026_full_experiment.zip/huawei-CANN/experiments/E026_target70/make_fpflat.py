from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'BFSIP/code/kernel.asc').read_text(encoding='utf-8')
code=base.replace('class FloatBroadTripleKernel {',(H/'float_flat_pipeline.inc').read_text(encoding='utf-8')+'\nclass FloatBroadTripleKernel {',1)
anchor='    if(input.dtype==0 && d>1536 && d<=4096 && rows>=static_cast<uint64_t>(blockNum)*4) {'
branch='''    if(input.dtype==0 && d>1536 && d<=4096 && d%64!=0 && rows>=static_cast<uint64_t>(blockNum)*4) {
        float_flat_pipeline_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert code.count(anchor)==1;code=code.replace(anchor,branch+anchor)
name='FPFLAT';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFSIP',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='Nonaligned FP32 wide rows use packed X/residual DMA, alternating X/residual roles of two input/square slots, one Gather into reusable output tile, original FP32 reduction and affine',static_ub_end=192512,numerical_change=False),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='fpflatquick'" not in s:
 s+='''
if mode=='fpflatquick':
 items=[small[i] for i in [10,12]]+[('fpflat_'+str(d),641,d,'float32') for d in [1537,2048,3073,3136,3200,4095,4096]]
 check('fpflat_check',items,['BFSIP','FPFLAT'])
 pairs('fpflat_pairs',[small[i] for i in [10,12]],'BFSIP','FPFLAT',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
c=H/'run_cold.py';s=c.read_text(encoding='utf-8')
if "mode=='fpflat'" not in s:
 s=s.replace("records=[]","if mode=='fpflat':items=[(r.small[10],['BFSIP','FPFLAT','FPFLAT','BFSIP']),(r.small[12],['FPFLAT','BFSIP','BFSIP','FPFLAT'])]\nrecords=[]",1)
 c.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_fpflat.tar.gz','w:gz') as tar:
 for target in [H/name,p,c]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
