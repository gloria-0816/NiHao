from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'BFSIP/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('    __aicore__ inline void ComputeWholeRow(');z=base.index('    __aicore__ inline float ComputeInvRms(',a);s=base[a:z]
old='''        Mul(y, y, g, d_);
        PipeBarrier<PIPE_V>();
        Add(y, y, b, d_);
        PipeBarrier<PIPE_V>();'''
new='''        if(SingleSlotWholePrefetchType<T>::value) {
            FusedMulAdd(y,g,b,d_);
        } else {
            Mul(y,y,g,d_);PipeBarrier<PIPE_V>();
            Add(y,y,b,d_);
        }
        PipeBarrier<PIPE_V>();'''
assert s.count(old)==1;s=s.replace(old,new);code=base[:a]+s+base[z:]
name='BFA8';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFSIP',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='Only BF16 generic whole-row affine changes Mul plus Add to FP32 FusedMulAdd; queue, reduction, normalization and prefetch retained',numerical_change=True),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='bfa8quick'" not in s:
 s+='''
if mode=='bfa8quick':
 items=[small[14]]+[('bfa8_'+str(d),161,d,'bfloat16') for d in [4097,6144,8191]]
 check('bfa8_check',items,['BFSIP','BFA8'])
 pairs('bfa8_pairs',[small[14]],'BFSIP','BFA8',blocks=1)
if mode=='bfa8large':
 items=[('bf8_large',8192,8192,'bfloat16')]
 check('bfa8_large_check',items,['BFSIP','BFA8'])
 pairs('bfa8_large_pairs',items,'BFSIP','BFA8',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_bfa8.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
