from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
code=(H/'SHAREDH/code/kernel.asc').read_text(encoding='utf-8')
old='if(input.dtype==1 && d>=321 && d<=1024 && rows>=static_cast<uint64_t>(blockNum)*4) {'
new='if(input.dtype==1 && d>=321 && d<=1024 && d%64==0 && rows>=static_cast<uint64_t>(blockNum)*4) {'
assert code.count(old)==1;code=code.replace(old,new)
name='SHAREDA';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BROAD3',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='SHAREDH residual/square shared-buffer route restricted to widths divisible by 64; retain parent route for non-aligned widths',numerical_change=False),indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='sharedaquick'" not in s:
 s+='''
if mode=='sharedaquick':
 items=[small[i] for i in [5,6,7,9]]+[('shareda_'+str(d),257,d,'float16') for d in [384,448,576,640,768,960]]
 check('shareda_check',items,['BROAD3','SHAREDA'])
 pairs('shareda_pairs',[small[7],small[9]],'BROAD3','SHAREDA',blocks=2)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_shareda.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
