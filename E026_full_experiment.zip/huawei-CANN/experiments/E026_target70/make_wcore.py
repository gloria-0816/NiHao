from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'BFSIP/code/kernel.asc').read_text(encoding='utf-8')
names=[]
for cores in [24,32]:
 name='WCORE'+str(cores);names.append(name)
 code=base
 anchor='    const uint32_t limit = input.dtype == 0 ? 4096 : 8192;'
 select=f'''    const uint32_t wideCores=blockNum<{cores}?blockNum:{cores};
    const uint32_t bfloatWholeCores=(input.dtype==2 && d==8192 && rows>=static_cast<uint64_t>(blockNum)*4)?wideCores:blockNum;
'''
 assert code.count(anchor)==1;code=code.replace(anchor,select+anchor)
 code=code.replace('float_broad_triple_custom<<<blockNum,nullptr,stream>>>','float_broad_triple_custom<<<wideCores,nullptr,stream>>>')
 code=code.replace('pipeline_batch9_custom<half,true><<<blockNum,nullptr,stream>>>','pipeline_batch9_custom<half,true><<<(d%64!=0?wideCores:blockNum),nullptr,stream>>>')
 code=code.replace('add_rms_norm_bias_custom<bfloat16_t><<<blockNum, nullptr, stream>>>','add_rms_norm_bias_custom<bfloat16_t><<<bfloatWholeCores, nullptr, stream>>>')
 dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFSIP',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change=f'Prefer {cores} cores on FP32 broad rows, nonaligned FP16 D321..1024 batches and BF16 D8192 many-row generic whole path; preserve original route guards and arithmetic',numerical_change=False),indent=2)+'\n')
 print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='wcorequick'" not in s:
 s+='''
if mode=='wcorequick':
 items=[small[i] for i in [5,6,10,12,14]]
 for v in ['WCORE24','WCORE32']:
  check(v.lower()+'_check',items,['BFSIP',v])
  pairs(v.lower()+'_pairs',items,'BFSIP',v,blocks=1)
if mode=='wcorelarge':
 items=[('bf8_large',8192,8192,'bfloat16')]
 check('wcore_large_check',items,['BFSIP','WCORE24','WCORE32'])
 for v in ['WCORE24','WCORE32']:
  pairs(v.lower()+'_large_pairs',items,'BFSIP',v,blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_wcore.tar.gz','w:gz') as tar:
 for target in [*[H/n for n in names],p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
