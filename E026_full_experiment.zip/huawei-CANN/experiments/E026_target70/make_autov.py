from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent
base=(H/'HALFAFF2/code/kernel.asc').read_text()
code=base.replace('PipeBarrier<PIPE_V>();','')
name='AUTOV';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'HALFAFF2','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'experimental compiler-managed vector dependencies; retain all cross-pipeline flags and final barriers','removed_explicit_vector_barriers':base.count('PipeBarrier<PIPE_V>();'),'validation_requirement':'bitwise comparison on full representative suite; static alias risks require actual tests'},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='autovquick'" not in s:
 s+='''
if mode=='autovquick':
 check('autov_check',small,['HALFAFF2','AUTOV'])
 pairs('autov_pairs',[small[i] for i in [0,3,4,5,6,7,10,11,12,13,14]],'HALFAFF2','AUTOV',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
