from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent
base=(H/'COMBO2/code/kernel.asc').read_text()
a=base.index('__global__ __vector__ void single_row_64_custom');z=base.index('template <typename T>\n__global__ __vector__ void single_row_custom',a)
s=base[a:z]
old='''    DataCopy(rt, rgm, copy);
    DataCopy(gt, ggm, copy);
    DataCopy(bt, bgm, copy);
    SetFlag<HardEvent::MTE2_V>(0);
    WaitFlag<HardEvent::MTE2_V>(0);'''
new='''    DataCopy(rt, rgm, copy);
    SetFlag<HardEvent::MTE2_V>(0);
    DataCopy(gt, ggm, copy);
    DataCopy(bt, bgm, copy);
    SetFlag<HardEvent::MTE2_V>(1);
    WaitFlag<HardEvent::MTE2_V>(0);'''
assert old in s;s=s.replace(old,new,1)
s=s.replace('''        ToFloat<T>(gf, gt, 64);
        ToFloat<T>(bf, bt, 64);
''','',1)
old='''        ToFloat<T>(y, xt, 64);
        ToFloat<T>(tmp, rt, 64);
        PipeBarrier<PIPE_V>();'''
new='''        if(CompactParameterType<T>::value) {
            Add(xt,xt,rt,64);PipeBarrier<PIPE_V>();
            ToFloat<T>(y,xt,64);
        } else {
            ToFloat<T>(y,xt,64);ToFloat<T>(tmp,rt,64);
        }
        PipeBarrier<PIPE_V>();'''
assert old in s;s=s.replace(old,new,1)
s=s.replace('    Add(y, y, tmp, 64);','    if(!CompactParameterType<T>::value) Add(y,y,tmp,64);',1)
old='''    Mul(y, y, gf, 64);
    PipeBarrier<PIPE_V>();
    Add(y, y, bf, 64);
    PipeBarrier<PIPE_V>();'''
new='''    WaitFlag<HardEvent::MTE2_V>(1);
    if(sizeof(T)!=sizeof(float)) {
        ToFloat<T>(gf,gt,64);ToFloat<T>(bf,bt,64);PipeBarrier<PIPE_V>();
    }
    FusedMulAdd(y,gf,bf,64);
    PipeBarrier<PIPE_V>();'''
assert old in s;s=s.replace(old,new,1)
code=base[:a]+s+base[z:]
name='SINGLEOV';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'COMBO2','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'D64 overlap parameter DMA with norm; native FP16 add and FP32 affine FMA','numerical_change':True},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='singleovquick'" not in s:
 s+='''
if mode=='singleovquick':
 check('singleov_check',[small[0],('singleov_fp32',1,64,'float32'),('singleov_bf16',1,64,'bfloat16')],['COMBO2','SINGLEOV'])
 pairs('singleov_pairs',[small[0]],'COMBO2','SINGLEOV',blocks=2)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
