from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'LSQM/code/kernel.asc').read_text(encoding='utf-8')
code=base
for cls,step in [('FloatBroadTripleKernel','batch_'),('BFloatTripleInplaceKernel','batch_'),('BFloatShortInplaceKernel','119')]:
 a=code.index('class '+cls+' {');z=code.index('__global__ __vector__ void ',a)
 s=code[a:z]
 assert s.count('uint32_t slot=0;')==1
 s=s.replace('uint32_t slot=0;','bool pending[2]={false,false};uint32_t slot=0;')
 anchor='Copy(r_,rgm_,row+'+step+');SetFlag<HardEvent::MTE2_V>(2);'
 extra='''
                // Drain the previous output only when its input slot is needed.
                // This overlaps its DMA with this batch's residual and reduction.
                if(row!=begin_) {
                    const uint32_t refill=slot^1;
                    WaitFlag<HardEvent::MTE3_MTE2>(refill);pending[refill]=false;
                    Copy(x_[refill],xgm_,row+STEP);SetFlag<HardEvent::MTE2_V>(refill);
                }'''.replace('STEP',step)
 assert s.count(anchor)==1;s=s.replace(anchor,anchor+extra)
 old='SetFlag<HardEvent::MTE3_MTE2>(slot);WaitFlag<HardEvent::MTE3_MTE2>(slot);'
 assert s.count(old)==1;s=s.replace(old,'SetFlag<HardEvent::MTE3_MTE2>(slot);pending[slot]=true;')
 if step=='batch_':
  old='''            if(row+2*batch_<end_) {
                Copy(x_[slot],xgm_,row+2*batch_);SetFlag<HardEvent::MTE2_V>(slot);
            }'''
 else:old='            if(row+238<end_) {Copy(x_[slot],xgm_,row+238);SetFlag<HardEvent::MTE2_V>(slot);}'
 assert s.count(old)==1;s=s.replace(old,'')
 if '        PipeBarrier<PIPE_ALL>();' in s:
  s=s.replace('        PipeBarrier<PIPE_ALL>();','        if(pending[0])WaitFlag<HardEvent::MTE3_MTE2>(0);\n        if(pending[1])WaitFlag<HardEvent::MTE3_MTE2>(1);')
 else:
  anchor='''        }
    }
private:'''
  assert s.count(anchor)==1
  s=s.replace(anchor,'''        }
        if(pending[0])WaitFlag<HardEvent::MTE3_MTE2>(0);
        if(pending[1])WaitFlag<HardEvent::MTE3_MTE2>(1);
    }
private:''')
 code=code[:a]+s+code[z:]
name='OVL3';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
sha=hashlib.sha256(code.encode()).hexdigest()
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='LSQM',source_sha256=sha,change='FP32 broad, BF16 medium and D128: defer output drain until input slot refill during next batch reduction; same arithmetic and buffer layout',numerical_change=False),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='ovl3quick'" not in s:
 s+='''
if mode=='ovl3quick':
 items=[small[i] for i in [10,11,12,13]]+[('ovl3_f_'+str(d),641,d,'float32') for d in [1537,2048,3136,4096]]+[('ovl3_b_'+str(d),641,d,'bfloat16') for d in [1025,2048,3079,4095]]
 check('ovl3_check',items,['LSQM','OVL3'])
 pairs('ovl3_pairs',[small[i] for i in [10,11,12,13]],'LSQM','OVL3',blocks=1)
if mode=='ovl3large':
 check('ovl3_large_check',[('b128large',524288,128,'bfloat16')],['LSQM','OVL3'])
 pairs('ovl3_large_pairs',[('b128large',524288,128,'bfloat16')],'LSQM','OVL3',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_ovl3.tar.gz','w:gz') as t:
 for q in [H/name,p]:t.add(q,arcname=q.relative_to(H.parents[1]))
print(name,sha)
