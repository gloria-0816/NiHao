from pathlib import Path
import csv,json,statistics,sys
root=Path('/mnt/workspace/addrms_results/E026')/(sys.argv[1] if len(sys.argv)>1 else 'cold_first')
results={}
for p in sorted(root.glob('*_*/profile/*/OpBasicInfo.csv')):
 def rows(filename):
  with (p.parent/filename).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
 basic=rows('OpBasicInfo.csv')[0];pipe=rows('PipeUtilization.csv');cache=rows('L2Cache.csv')
 out={k:basic[k] for k in ['Task Duration(us)','Block Dim','Current Freq']}
 for k in ['aiv_mte2_ratio','aiv_vec_ratio','aiv_mte3_ratio','aiv_scalar_ratio','aiv_scalar_vector_stall_time(us)']:
  out[k]=statistics.mean(float(x[k]) for x in pipe)
 out['read_hit_rate_pct']=statistics.mean(float(x['aiv_read_hit_rate(%)']) for x in cache)
 results[p.parents[2].name]=out
(root/'metrics_summary.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
