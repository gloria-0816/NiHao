from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'FACC/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class StaticHalfRowsKernel {');z=base.index('// At most four FP32 short rows',a)
inc=base[a:z].replace('StaticHalfRowsKernel','HalfShortLaneKernel').replace('static_half_rows_custom','half_short_lane_custom')
st=inc.index('        ToFloat<half>(y_,x_,active);');en=inc.index('        Muls(sums_,sums_,invD_',st)
inc=inc[:st]+'''        if(d_!=stride_) {
            const uint32_t lane=d_%128,endLane=stride_-d_/128*128;
            uint64_t tail[2]={lane<64?(~static_cast<uint64_t>(0)<<lane):0,
                endLane==128?(lane<64?~static_cast<uint64_t>(0):(~static_cast<uint64_t>(0)<<(lane-64))):0};
            Duplicate(x_[d_/128*128],static_cast<half>(0),tail,count_,1,stride_/16);
            PipeBarrier<PIPE_V>();
        }
        Duplicate(tmp_,0.0f,count_*64);PipeBarrier<PIPE_V>();
        for(uint32_t col=0;col<stride_;col+=64) {
            MulAddDst<float,half>(tmp_,x_[col],x_[col],64,count_,{1,1,1,8,static_cast<uint8_t>(stride_/16),static_cast<uint8_t>(stride_/16)});
            PipeBarrier<PIPE_V>();
        }
        WholeReduceSum(sums_,tmp_,64,count_,1,1,8);PipeBarrier<PIPE_V>();
        const uint32_t rms=(count_+7)/8*8;
'''+inc[en:]
code=base.replace('class StaticHalfRowsKernel {',inc+'\nclass StaticHalfRowsKernel {',1)
old='static_half_rows_custom<<<blockNum,nullptr,stream>>>'
assert code.count(old)==1
code=code.replace(old,'half_short_lane_custom<<<blockNum,nullptr,stream>>>')
name='HSLANE';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
sha=hashlib.sha256(code.encode()).hexdigest()
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='FACC',source_sha256=sha,change='FP16 D64..256, 4..32 rows per core: direct mixed VMLA 64-lane FP32 sum, native half normalization; remove full FP32 residual and square tiles',numerical_change=True),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='hslanequick'" not in s:
 s+='''
if mode=='hslanequick':
 items=[small[3]]+[('hslane_'+str(d),767,d,'float16') for d in [64,65,127,128,192,255,256]]
 check('hslane_check',items,['FACC','HSLANE'])
 pairs('hslane_pairs',[small[3]],'FACC','HSLANE',blocks=2)
if mode=='hslaneedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='hslane_edge_'+pattern;case(cid,767,193,'float16',pattern)
  items.append((cid,767,193,'float16'))
 check('hslane_edge_check',items,['FACC','HSLANE'])
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_hslane.tar.gz','w:gz') as t:
 for q in [H/name,p]:t.add(q,arcname=q.relative_to(H.parents[1]))
print(name,sha)
