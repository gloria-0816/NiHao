from pathlib import Path
import shutil,hashlib,json
H=Path(__file__).resolve().parent
code=(H/'FPSTATIC/code/kernel.asc').read_text()
old='                Duplicate(y[d_/64*64],0.0f,tail,count,1,stride_/8);PipeBarrier<PIPE_V>();'
new='''                // A2 high-dimensional repeat strides are only 8 bits.
                // A 3136-float row needs 392 blocks, so clear rows individually.
                for(uint32_t i=0;i<count;++i)Duplicate(y[i*stride_+d_/64*64],0.0f,tail,1,1,8);
                PipeBarrier<PIPE_V>();'''
assert old in code;code=code.replace(old,new,1)
name='FPSTATIC2';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'source_sha256':hashlib.sha256(code.encode()).hexdigest(),'fix':'nonaligned tail clearing avoids 8-bit repeat-stride overflow','ub_end_bytes':190848},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='fpstatic2quick'" not in s:
 s+='''
if mode=='fpstatic2quick':
 check('fpstatic2_check',[small[10],small[12],('fps_2048',161,2048,'float32'),('fps_3136',257,3136,'float32')],['BASE','FPSTATIC2'])
 pairs('fpstatic2_pairs',[small[10],small[12]],'BASE','FPSTATIC2',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
