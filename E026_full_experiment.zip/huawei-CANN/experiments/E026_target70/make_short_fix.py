from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent
for cores in (8,16,32):
 old=f'SHORT{cores}';name=old+'B';code=(H/old/'code/kernel.asc').read_text()
 bad='tmp_ = LocalTensor<float>(TPosition::VECIN, 8320, 8192);'
 assert code.count(bad)==1
 code=code.replace(bad,'tmp_ = LocalTensor<float>(TPosition::VECIN, 32896, 8192);',1)
 dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
 (H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':old,'source_sha256':hashlib.sha256(code.encode()).hexdigest(),'fix':'disjoint 32 KiB input-x and residual slots','ub_end_bytes':74624},indent=2)+'\n')
 print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='shortbquick'" not in s:
 s+='''
if mode=='shortbquick':
 check('shortb_check',[small[2],('shortf_512',257,512,'float32'),('shortf_193',161,193,'float32'),('shortf_64',257,64,'float32')],['COMBO1','SHORT8B','SHORT16B','SHORT32B'])
 for v in ['SHORT8B','SHORT16B','SHORT32B']:
  pairs(v.lower()+'_pairs',[small[2]],'COMBO1',v,blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
