from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
code=(H/'FACC/code/kernel.asc').read_text(encoding='utf-8')
targets=[('PipelineBatch9Kernel','pipeline_batch9_custom','blockNum'),('StaticHalfRowsKernel','static_half_rows_custom','blockNum'),('ShortFloatPartitionKernel','short_float_partition_custom','shortFloatCores')]
for cls,entry,cores in targets:
 a=code.index('class '+cls+' {')
 z=code.index('\n};',a)+4
 part=code[a:z]
 sig=part.index('    __aicore__ inline void Init(')
 end=part.index(')',sig)
 part=part[:end]+', uint64_t coreRows, uint32_t extraRows'+part[end:]
 if cls=='PipelineBatch9Kernel':
  old='''        begin_=rows*GetBlockIdx()/GetBlockNum();
        end_=rows*(GetBlockIdx()+1)/GetBlockNum(); invD_=invD; eps_=eps;'''
  new='''        const uint32_t index=GetBlockIdx();
        begin_=coreRows*index+(index<extraRows?index:extraRows);
        end_=begin_+coreRows+(index<extraRows?1:0);invD_=invD;eps_=eps;'''
 elif cls=='StaticHalfRowsKernel':
  old='''        begin_ = rows * GetBlockIdx() / GetBlockNum();
        count_ = static_cast<uint32_t>(rows * (GetBlockIdx()+1) / GetBlockNum() - begin_);'''
  new='''        const uint32_t index=GetBlockIdx();
        begin_=coreRows*index+(index<extraRows?index:extraRows);
        count_=static_cast<uint32_t>(coreRows)+(index<extraRows?1:0);'''
 else:
  old='''        begin_ = rows * GetBlockIdx() / GetBlockNum();
        const uint64_t end = rows * (GetBlockIdx() + 1) / GetBlockNum();
        count_ = static_cast<uint32_t>(end - begin_);'''
  new='''        const uint32_t index=GetBlockIdx();
        begin_=coreRows*index+(index<extraRows?index:extraRows);
        count_=static_cast<uint32_t>(coreRows)+(index<extraRows?1:0);'''
 assert part.count(old)==1,cls
 part=part.replace(old,new)
 code=code[:a]+part+code[z:]
 # Alter only the actual device entry and its Init call.
 a=code.index('__global__ __vector__ void '+entry)
 z=code.index('\n}',a)+2
 part=code[a:z]
 end=part.index(')',part.index('('))
 part=part[:end]+',uint64_t coreRows,uint32_t extraRows'+part[end:]
 init=part.index('op.Init(');end=part.index(')',init)
 part=part[:end]+',coreRows,extraRows'+part[end:]
 code=code[:a]+part+code[z:]
 # The host controls only launch metadata, with all tensor math on the NPU.
 a=code.index('extern "C" void run_kernel(')
 pre=code[:a];host=code[a:]
 if entry=='pipeline_batch9_custom':
  old='pipeline_batch9_custom<half,true><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'
 elif entry=='static_half_rows_custom':
  old='''static_half_rows_custom<<<blockNum,nullptr,stream>>>(
            x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'''
 else:
  old='short_float_partition_custom<<<shortFloatCores,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'
 assert host.count(old)==1,entry
 host=host.replace(old,old[:-2]+',rows/'+cores+',static_cast<uint32_t>(rows%'+cores+'));')
 code=pre+host
name='HOSTP';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
sha=hashlib.sha256(code.encode()).hexdigest()
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='FACC',source_sha256=sha,change='Host computes quotient and remainder for FP16 short/medium and FP32 short batch partitions; no division in device partition setup; same maximum rows per core and complete balanced coverage',numerical_change=False,partition_order_changed=True),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='hostpquick'" not in s:
 s+='''
if mode=='hostpquick':
 items=[small[i] for i in [2,3,5,6,7,9]]+[('hostp_h_'+str(d),161,d,'float16') for d in [65,193,321,577,1024]]+[('hostp_f_256',161,256,'float32')]
 check('hostp_check',items,['FACC','HOSTP'])
 pairs('hostp_pairs',[small[i] for i in [2,3,5,6,7,9]],'FACC','HOSTP',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_hostpart.tar.gz','w:gz') as t:
 for q in [H/name,p]:t.add(q,arcname=q.relative_to(H.parents[1]))
print(name,sha)
