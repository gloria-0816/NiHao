from pathlib import Path
import hashlib,json,sys,tarfile
O=Path('/mnt/workspace/addrms_results/E026').resolve()
A=O.parent/'E026_incremental_20261012_0600.tar.gz'
with tarfile.open(A,'r:gz') as tar:
 manifest=json.load(tar.extractfile('_snapshot_manifest.json'))
 archived={x['path']:x for x in manifest['files']}
groups=['bfinv_large_check','bfinv_large_pairs','bfdb8_large_check','bfdb8_large_pairs',
 'wcore_large_check','wcore24_large_pairs','wcore32_large_pairs',
 'bfsmax_large_check','bfs125_large_pairs','bfs127_large_pairs']
items=[]
for group in groups:
 p=(O/group).resolve();assert p.is_relative_to(O)
 assert (p/'complete.json').exists() or (p/'summary.json').exists(),group
 for out in p.rglob('output.bin'):
  assert not out.is_symlink() and out.resolve().is_relative_to(p)
  record=out.parent.parent/'record.json'
  key=record.relative_to(O).as_posix()
  raw=record.read_bytes()
  assert key in archived and hashlib.sha256(raw).hexdigest()==archived[key]['sha256'],key
  r=json.loads(raw)
  assert hashlib.sha256(out.read_bytes()).hexdigest()==r['output_sha256'],str(out)
  items.append(dict(path=out.relative_to(O).as_posix(),bytes=out.stat().st_size,
    sha256=r['output_sha256'],record=key))
report=dict(archive_sha256=hashlib.sha256(A.read_bytes()).hexdigest(),files=items,
 count=len(items),bytes=sum(x['bytes'] for x in items),apply='--apply' in sys.argv)
print(json.dumps(dict(count=report['count'],bytes=report['bytes'],apply=report['apply'])))
if report['apply']:
 (O/'cleanup_completed_large_outputs_0600.json').write_text(json.dumps(report,indent=2)+'\n')
 for item in items:(O/item['path']).unlink()
