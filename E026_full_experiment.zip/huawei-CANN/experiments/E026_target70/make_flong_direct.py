from pathlib import Path
import hashlib, json, shutil, tarfile

H = Path(__file__).resolve().parent
base = (H/'FACC/code/kernel.asc').read_text(encoding='utf-8')
a = base.index('template <typename T>\nclass RetainedLongRowKernel {')
z = base.index('// Multi-row RMSNorm:', a)
inc = base[a:z].replace('RetainedLongRowKernel', 'FloatDirectLongKernel').replace('retained_long_row_custom', 'float_direct_long_custom')
old = '''        ToFloat<T>(y, x, n);
        ToFloat<T>(tmp, r, n);
        PipeBarrier<PIPE_V>();'''
assert inc.count(old) == 1
inc = inc.replace(old, '''        Add(y, x, r, n);
        PipeBarrier<PIPE_V>();''')
assert inc.count('        Add(y, y, tmp, n);\n        PipeBarrier<PIPE_V>();') == 2
inc = inc.replace('        Add(y, y, tmp, n);\n        PipeBarrier<PIPE_V>();', '', 1)
start = inc.index('        Muls(y, y, invRms, n);', inc.index('inline void NormalizeRetained'))
end = inc.index('\n    }', start)
inc = inc[:start] + '''        Muls(y, y, invRms, n);
        PipeBarrier<PIPE_V>();
        FusedMulAdd(y, g, b, n);
        PipeBarrier<PIPE_V>();''' + inc[end:]
inc = inc.replace('''            // Match the baseline FP32 final conversion (Adds with zero).
            Adds(y, y, 0.0f, n);
            PipeBarrier<PIPE_V>();
''', '')
launch = 'retained_long_row_custom<float><<<blockNum, nullptr, stream>>>'
assert base.count(launch) == 1

for name, accumulating in [('FDIR', False), ('FDACC', True)]:
    part = inc
    if accumulating:
        part = part.replace('FloatDirectLongKernel', 'FloatDirectAccLongKernel').replace('float_direct_long_custom', 'float_direct_acc_long_custom')
        part = part.replace('''            Duplicate(partials, 0.0f, groups * 64);
            PipeBarrier<PIPE_V>();''', '''            auto accum = workbuf_.template Get<float>();
            Duplicate(accum, 0.0f, 64);
            PipeBarrier<PIPE_V>();''')
        old = '''        ReduceSum(partials[chunk * 8], tmp, work, padded);
        PipeBarrier<PIPE_V>();'''
        assert part.count(old) == 1
        part = part.replace(old, '''        Add(work, tmp, work, 64, padded / 64, {1,1,1,0,8,0});
        PipeBarrier<PIPE_V>();''')
        st = part.index('        // Each group comprises eight float partials')
        en = part.index('        Muls(partials, partials, invD_, 1);', st)
        part = part[:st] + '''        WholeReduceSum(partials, work, 64, 1, 1, 1, 8);
        PipeBarrier<PIPE_V>();
''' + part[en:]
    entry = 'float_direct_acc_long_custom' if accumulating else 'float_direct_long_custom'
    code = base[:a] + part + '\n' + base[a:]
    code = code.replace(launch, entry+'<float><<<blockNum, nullptr, stream>>>')
    dest = H/name/'code'
    shutil.copytree(H/'BASE/code', dest, dirs_exist_ok=True)
    (dest/'kernel.asc').write_text(code, encoding='utf-8', newline='\n')
    sha = hashlib.sha256(code.encode()).hexdigest()
    (H/name/'manifest.json').write_text(json.dumps(dict(variant=name, parent='FACC', source_sha256=sha,
        change='FP32 D4097..32768: direct residual Add and direct affine FMA without copy/conversion instructions'+('; cross-chunk lane accumulation with one final reduction' if accumulating else ''),
        numerical_change=True), indent=2)+'\n', encoding='utf-8')
    print(name, sha)

p = H/'run_round.py'
s = p.read_text(encoding='utf-8')
if "mode=='flongquick'" not in s:
    s += '''
if mode=='flongquick':
 items=[('flong_'+str(d),161,d,'float32') for d in [4097,8192,16384,32768]]+[('flong_'+str(d),7,d,'float32') for d in [8191,16383,32767]]
 check('flong_check',items,['FACC','FDIR','FDACC'])
 for v in ['FDIR','FDACC']:
  pairs(v.lower()+'_pairs',[items[i] for i in [1,2,3]],'FACC',v,blocks=1)
if mode=='flongedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='flong_edge_'+pattern;case(cid,7,32767,'float32',pattern)
  items.append((cid,7,32767,'float32'))
 check('flong_edge_check',items,['FACC','FDIR','FDACC'])
'''
    p.write_text(s, encoding='utf-8', newline='\n')
with tarfile.open(H/'upload_flong_direct.tar.gz', 'w:gz') as t:
    for q in [H/'FDIR', H/'FDACC', p]:
        t.add(q, arcname=q.relative_to(H.parents[1]))
