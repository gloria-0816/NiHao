from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent;code=(H/'HIP15/code/kernel.asc').read_text(encoding='utf-8')
a=code.index('class HalfInplaceRowsKernel {');z=code.index('class StaticHalfRowsKernel {',a);s=code[a:z]
s=s.replace('stride_=(d+63)/64*64','stride_=(d+15)/16*16')
s=s.replace('183168,2048','183168,2304').replace('191488,128','192512,128')
s=s.replace('active=count*stride_,parts=stride_/64','active=count*stride_,parts=(stride_+63)/64')
old='''                uint64_t tail[2]={~static_cast<uint64_t>(0)<<(d_%64),0};
                Duplicate(square_[d_/64*64],0.0f,tail,count,1,stride_/8);PipeBarrier<PIPE_V>();'''
new='''                const uint64_t paddedMask=stride_%64 ? ((static_cast<uint64_t>(1)<<(stride_%64))-1) : ~static_cast<uint64_t>(0);
                uint64_t tail[2]={(~static_cast<uint64_t>(0)<<(d_%64))&paddedMask,0};
                Duplicate(square_[d_/64*64],0.0f,tail,count,1,stride_/8);PipeBarrier<PIPE_V>();'''
assert s.count(old)==1;s=s.replace(old,new)
old='''            BlockReduceSum(work_,square_,active/64,64,1,1,8);PipeBarrier<PIPE_V>();
            if(parts>8) {
                Add(work_,work_,work_[64],parts*8-64,count,{1,1,1,static_cast<uint8_t>(parts),static_cast<uint8_t>(parts),static_cast<uint8_t>(parts)});
                PipeBarrier<PIPE_V>();
            }
            WholeReduceSum(sums_,work_,Min(64,parts*8),count,1,1,parts);PipeBarrier<PIPE_V>();'''
new='''            // Each column reduction writes a disjoint 8-result slice per row.
            for(uint32_t col=0;col<stride_;col+=64)
                BlockReduceSum(work_[col/8],square_[col],count,Min(64,stride_-col),parts,1,stride_/8);
            PipeBarrier<PIPE_V>();
            const uint32_t blocks=stride_/8;
            if(blocks>64) {
                Add(work_,work_,work_[64],blocks-64,count,{1,1,1,static_cast<uint8_t>(parts),static_cast<uint8_t>(parts),static_cast<uint8_t>(parts)});
                PipeBarrier<PIPE_V>();
            }
            WholeReduceSum(sums_,work_,Min(64,blocks),count,1,1,parts);PipeBarrier<PIPE_V>();'''
assert s.count(old)==1;s=s.replace(old,new)
code=code[:a]+s+code[z:];name='HIP16S';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='HIP15',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='FP16 native row batches pad to 16 elements, with column-wise BlockReduceSum and bounded tail mask; enlarged partial workspace 2304 floats',static_ub_end=193024,numerical_change=True),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='hip16squick'" not in s:
 s+='''
if mode=='hip16squick':
 items=[small[i] for i in [5,6]]+[('hip_'+str(d),257,d,'float16') for d in [321,383,384,447,511,512,513,767,1023,1024]]
 check('hip16s_check',items,['BFPN4','HIP16S'])
 pairs('hip16s_pairs',[small[i] for i in [5,6]],'BFPN4','HIP16S',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_hip16s.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
