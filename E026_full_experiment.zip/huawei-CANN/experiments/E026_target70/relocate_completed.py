from pathlib import Path
import shutil,json,time
root=Path('/mnt/workspace/addrms_results/E026').resolve()
target=Path('/home/developer/addrms_archived/E026')
target.mkdir(parents=True,exist_ok=True)
groups=['fpstatic_check','autov_pairs','comboa_pairs','combo3_pairs','fpbroad_pairs','fpstatic_pairs','pack_pairs','bf128s_large_check','cold_bfstripe','cold_fpd4','cold_fpc4']
events=[]
for name in groups:
 src=root/name;dst=target/name
 assert src.parent.resolve()==root
 assert dst.parent.resolve()==target.resolve()
 if src.is_symlink():
  assert src.resolve()==dst.resolve();continue
 assert (src/'complete.json').exists() or (src/'summary.json').exists(),name
 assert not dst.exists(),dst
 # shutil.move preserves the complete dataset, including tensor outputs.
 size=sum(p.stat().st_size for p in src.rglob('*') if p.is_file() and not p.is_symlink())
 shutil.move(str(src),str(dst))
 src.symlink_to(dst,target_is_directory=True)
 assert src.resolve()==dst.resolve()
 events.append(dict(group=name,original=str(src),new=str(dst),bytes=size))
 print(json.dumps(events[-1]),flush=True)
(root/'relocate_completed_0645.json').write_text(json.dumps(dict(description='Reversible relocation; all files preserved; original paths restored with symlinks',events=events),indent=2)+'\n')
print(json.dumps(dict(free_bytes=shutil.disk_usage(root).free)),flush=True)
