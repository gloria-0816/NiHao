from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'BFPN4/code/kernel.asc').read_text(encoding='utf-8')
code=base.replace('class StaticHalfRowsKernel {',(H/'bfloat_short_inplace.inc').read_text(encoding='utf-8')+'\nclass StaticHalfRowsKernel {',1)
old='        else pipeline_batch9_custom<bfloat16_t,true><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'
new='        else bfloat_short_inplace_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,epsilon);'
assert code.count(old)==1;code=code.replace(old,new)
name='BFSIP';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFPN4',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='BF16 D128 119-row batches use input/output ping-pong, residual/square alias, column-wise FP32 affine and aligned bulk DMA',static_ub_end=193024,numerical_change=False),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='bfsipquick'" not in s:
 s+='''
if mode=='bfsipquick':
 items=[small[13]]+[('bfsip_'+str(r),r,128,'bfloat16') for r in [160,321,4097,9501]]
 check('bfsip_check',items,['BFPN4','BFSIP'])
 pairs('bfsip_pairs',[small[13]],'BFPN4','BFSIP',blocks=1)
if mode=='bfsiplarge':
 items=[('bf128s_large',524288,128,'bfloat16')]
 check('bfsip_large_check',items,['BFPN4','BFSIP'])
 pairs('bfsip_large_pairs',items,'BFPN4','BFSIP',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_bfsip.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
