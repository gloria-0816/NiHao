from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'FACC/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('            } else if (prefetch_) {');z=base.index('            } else {',a)
part=base[a:z].replace('} else if (prefetch_) {','} else if (SingleSlotWholePrefetchType<T>::value && d_==8192 && rows_>=static_cast<uint64_t>(GetBlockNum())*4) {',1)
part=part.replace('rows_ * GetBlockIdx() / GetBlockNum()','GetBlockIdx()').replace('rows_ * (GetBlockIdx() + 1) / GetBlockNum()','rows_').replace('++row','row+=GetBlockNum()').replace('const uint64_t next = row + 1;','const uint64_t next = row + GetBlockNum();')
rr=base[:a]+part+base[a:]
sb=(H/'BFSB/code/kernel.asc').read_text(encoding='utf-8')
a=sb.index('class BFloatShortInplaceKernel {');z=sb.index('class StaticHalfRowsKernel {',a)
part=sb[a:z];old='''    __aicore__ inline void Process() {
        DataCopyParams parameter={1,8,0,0};'''
new='''    __aicore__ inline void Process() {
        if(begin_>=end_)return;
        DataCopyParams parameter={1,8,0,0};'''
assert part.count(old)==1;part=part.replace(old,new)
sb=sb[:a]+part+sb[z:]
for name,code,change in [('BFRR',rr,'BF16 D8192 row round-robin with original next-row prefetch preserved'),('BFSB2',sb,'BF16 D128 cyclic 119-row batches with early return for empty cores, before any input copy or event; fixes BFSB tail-core error')]:
 dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n');sha=hashlib.sha256(code.encode()).hexdigest()
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='FACC',source_sha256=sha,change=change,numerical_change=False),indent=2)+'\n')
 print(name,sha)
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='bfrrquick'" not in s:
 s+='''
if mode=='bfrrquick':
 items=[small[14]]+[('bfstripe_'+str(r),r,8192,'bfloat16') for r in [160,321,511,1281]]
 check('bfrr_check',items,['FACC','BFRR'])
 pairs('bfrr_pairs',[('bf8large',8192,8192,'bfloat16')],'FACC','BFRR',blocks=1)
if mode=='bfsb2quick':
 items=[small[13]]+[('bfsb_'+str(r),r,128,'bfloat16') for r in [160,161,4759,4760,4761,9521]]
 check('bfsb2_check',items,['FACC','BFSB2'])
 pairs('bfsb2_pairs',[('b128large',524288,128,'bfloat16')],'FACC','BFSB2',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_bfstripe2.tar.gz','w:gz') as t:
 for q in [H/'BFRR',H/'BFSB2',p]:t.add(q,arcname=q.relative_to(H.parents[1]))
