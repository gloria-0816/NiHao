from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent;base=(H/'BASE/code/kernel.asc').read_text();inc=(H/'fp_static.inc').read_text()
code=base.replace('class StaticHalfRowsKernel {',inc+'\nclass StaticHalfRowsKernel {',1)
anchor='    if (input.dtype == 1 && d <= 256'
launch='''    if(input.dtype==0 && d>=2048 && d<=3136 && rows>=static_cast<uint64_t>(blockNum)*4) {
        float_static_batch_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
code=code.replace(anchor,launch+anchor,1);name='FPSTATIC';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'source_sha256':hashlib.sha256(code.encode()).hexdigest(),'ub_end_bytes':190848},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='fpstaticquick'" not in s:
 s+='''
if mode=='fpstaticquick':
 check('fpstatic_check',[small[10],small[12],('fps_2048',161,2048,'float32'),('fps_3136',257,3136,'float32')],['BASE','FPSTATIC'])
 pairs('fpstatic_pairs',[small[10],small[12]],'BASE','FPSTATIC',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
