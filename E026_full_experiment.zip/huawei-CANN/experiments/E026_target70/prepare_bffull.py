from pathlib import Path
import sys,json,importlib.util,shutil
R=Path('/mnt/workspace/addrms_cloudbench/huawei-CANN')
S=R/'cloud_bench/scripts/case_data.py'
spec=importlib.util.spec_from_file_location('case_data',S);cd=importlib.util.module_from_spec(spec);spec.loader.exec_module(cd)
base=Path('/home/developer/addrms_full_inputs');base.mkdir(exist_ok=True)
out=Path('/mnt/workspace/addrms_results/E026')
assert shutil.disk_usage(base).free>60*1024**3
for cid,shape in [('bffull14',[128,25920,128]),('bffull15',[16,7360,8192])]:
 target=base/cid
 if (target/'meta.json').exists():
  meta=json.loads((target/'meta.json').read_text());assert meta['shape']==shape and meta['dtype']=='bfloat16'
 else:
  assert not target.exists(),target
  meta=cd.generate(target,shape,'bfloat16',seed=42,case_id=cid,max_tensor_mib=2048)
 link=out/'inputs'/cid
 if link.exists():assert link.is_symlink() and link.resolve()==target.resolve()
 else:link.symlink_to(target,target_is_directory=True)
 print(json.dumps(dict(case=cid,shape=shape,bytes=meta['expected_bytes'],directory=str(target))),flush=True)
for name in ['bffull14_pairs','bffull15_db_pairs','bffull15_inv_pairs','bffull15_rr_pairs','bffull_op']:
 target=Path('/home/developer/addrms_archived/E026')/name
 target.mkdir(exist_ok=True)
 link=out/name
 if link.exists():assert link.is_symlink() and link.resolve()==target.resolve()
 else:link.symlink_to(target,target_is_directory=True)
signal=out/'prepare_bffull_complete.json'
assert not signal.exists()
signal.write_text(json.dumps(dict(cases=['bffull14','bffull15'],description='Documented representative full workload sizes; not claimed to be undisclosed official inputs; all files and perf groups on /home retain same-filesystem hardlinks'),indent=2)+'\n')
