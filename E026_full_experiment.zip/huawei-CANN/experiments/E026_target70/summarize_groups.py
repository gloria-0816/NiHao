from pathlib import Path
import json, statistics, sys

O=Path('/mnt/workspace/addrms_results/E026')
for group in sys.argv[1:]:
 p=O/group
 if (p/'summary.json').exists():
  print(group,json.dumps(json.loads((p/'summary.json').read_text())))
 elif (p/'records.json').exists():
  r=json.loads((p/'records.json').read_text())
  if not r:
   print(group,'no records');continue
  if 'median_us' in r[0]:
   results={}
   for cid in dict.fromkeys(x['case_id'] for x in r):
    c=[x for x in r if x['case_id']==cid]
    v=list(dict.fromkeys(x['variant'] for x in c))
    times={k:[x['median_us'] for x in c if x['variant']==k] for k in v}
    results[cid]=dict(times=times)
    if len(v)==2:
     b,cand=[statistics.median(times[k]) for k in v]
     results[cid]['candidate_gain_pct']=100*(b-cand)/b
   print(group,'partial',json.dumps(results))
  else:
   print(group,'checks',len(r),'complete',(p/'complete.json').exists(),
     'bitwise',all(x.get('bitwise_equal_parent',True) for x in r))
 else:print(group,'pending')
