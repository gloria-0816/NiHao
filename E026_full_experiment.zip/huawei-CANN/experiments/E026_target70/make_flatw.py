from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'BFSIP/code/kernel.asc').read_text(encoding='utf-8')
code=base.replace('class LongHalfRetainedKernel {',(H/'half_flat_wide.inc').read_text(encoding='utf-8')+'\nclass LongHalfRetainedKernel {',1)
anchor='    if (rows >= static_cast<uint64_t>(blockNum)*4 && ((input.dtype==1 && d>=321 && d<=1024) || (input.dtype==2 && d==128))) {'
new='''    if(input.dtype==1 && d>=321 && d<=1024 && d%64!=0 && rows>=static_cast<uint64_t>(blockNum)*4) {
        half_flat_wide_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert code.count(anchor)==1;code=code.replace(anchor,new+anchor)
name='FLATW';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFSIP',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='Nonaligned FP16 D321..1024 packed input DMA, native-half residual Add, one Gather into padded rows, FP32 RMS and native-half normalize/FMA; shared residual/square and two prefetched X slots',static_ub_end=185856,numerical_change=True),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='flatwquick'" not in s:
 s+='''
if mode=='flatwquick':
 items=[small[i] for i in [5,6]]+[('hip_'+str(d),257,d,'float16') for d in [321,383,384,447,511,512,513,767,1023,1024]]
 check('flatw_check',items,['BFSIP','FLATW'])
 pairs('flatw_pairs',[small[i] for i in [5,6]],'BFSIP','FLATW',blocks=1)
if mode=='flatwedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='flatw_'+pattern;case(cid,1513,577,'float16',pattern);items.append((cid,1513,577,'float16'))
 check('flatw_edge',items,['BFSIP','FLATW'])
'''
 p.write_text(s,encoding='utf-8',newline='\n')
c=H/'run_cold.py';s=c.read_text(encoding='utf-8')
if "mode=='flatw'" not in s:
 s=s.replace("records=[]","if mode=='flatw':items=[(r.small[5],['BFSIP','FLATW','FLATW','BFSIP']),(r.small[6],['FLATW','BFSIP','BFSIP','FLATW'])]\nrecords=[]",1)
 c.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_flatw.tar.gz','w:gz') as tar:
 for target in [H/name,p,c]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
