from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'BROAD2/code/kernel.asc').read_text(encoding='utf-8')
anchor='    const uint32_t shortFloatCores=blockNum<8?blockNum:8;'
assert base.count(anchor)==1
for name,cores in [('SMALL1',1),('SMALL2',2),('SMALL4',4)]:
    launch=f'''    if(input.dtype==0 && rows>1 && rows<=16 && d<=512 && rows*((d+63)/64*64)<=8192) {{
        const uint32_t smallCores=blockNum<{cores}?blockNum:{cores};
        short_float_partition_custom<<<smallCores,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }}
'''
    code=base.replace(anchor,launch+anchor,1)
    dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
    (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
    (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BROAD2',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change=f'FP32 <=16 short rows and <=8192 padded elements use entire-core batch with up to {cores} vector cores'),indent=2)+'\n')
    print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='smallcorequick'" not in s:
    s+='''
if mode=='smallcorequick':
 items=[small[1],('smallcore_2',2,65,'float32'),('smallcore_16',16,512,'float32'),('smallcore_9',9,193,'float32')]
 check('smallcore_check',items,['BROAD2','SMALL1','SMALL2','SMALL4'])
 for v in ['SMALL1','SMALL2','SMALL4']:
  pairs(v.lower()+'_pairs',[small[1]],'BROAD2',v,blocks=2)
'''
    p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_smallcore.tar.gz','w:gz') as tar:
    for target in [H/'SMALL1',H/'SMALL2',H/'SMALL4',p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
