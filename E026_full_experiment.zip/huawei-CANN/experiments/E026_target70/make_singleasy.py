from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
code=(H/'PAIRASY/code/kernel.asc').read_text(encoding='utf-8')
old='rows<=static_cast<uint64_t>(availableCoreNum)/2'
assert code.count(old)==1
code=code.replace(old,'rows==1')
name='SINGLEASY';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
sha=hashlib.sha256(code.encode()).hexdigest()
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='PAIRASY',source_sha256=sha,change='Single aligned FP16 long row only: paired two AIV mixed square accumulator and deferred second synchronization; all multi-row and other-type paths retain FACC',static_ub_end=164352,numerical_change=False),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='singleasyquick'" not in s:
 s+='''
if mode=='singleasyquick':
 items=[('pairsingle_1_16384',1,16384,'float16'),('pairsingle_1_24576',1,24576,'float16'),('pairsingle_1_32768',1,32768,'float16')]+[small[i] for i in [0,3,4,10,13,14]]
 check('singleasy_check',items,['FACC','SINGLEASY'])
 pairs('singleasy_pairs',items[:3],'FACC','SINGLEASY',blocks=2)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_singleasy.tar.gz','w:gz') as t:
 for q in [H/name,p]:t.add(q,arcname=q.relative_to(H.parents[1]))
print(name,sha)
