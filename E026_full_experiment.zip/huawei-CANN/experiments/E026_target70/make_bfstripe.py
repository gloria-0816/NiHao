from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'FACC/code/kernel.asc').read_text(encoding='utf-8')
for name,grain in [('BFS1',1),('BFS32',32),('BFS128',128),('BFSB',None)]:
 code=base
 if grain is not None:
  anchor='''            } else if (prefetch_) {'''
  assert code.count(anchor)==1
  branch=f'''            }} else if (SingleSlotWholePrefetchType<T>::value && d_==8192 &&
                rows_>=static_cast<uint64_t>(GetBlockNum())*4) {{
                const uint64_t step=static_cast<uint64_t>(GetBlockNum())*{grain};
                for(uint64_t start=static_cast<uint64_t>(GetBlockIdx())*{grain};start<rows_;start+=step) {{
                    const uint64_t stop=start+{grain}<rows_?start+{grain}:rows_;
                    PrefetchY(start*d_,d_);
                    for(uint64_t row=start;row<stop;++row) {{
                        ConsumeY(d_);
                        if(row+1<stop)PrefetchY((row+1)*d_,d_);
                        ComputeWholeRow(row*d_,gf,bf);
                    }}
                }}
'''+anchor
  code=code.replace(anchor,branch)
 else:
  a=code.index('class BFloatShortInplaceKernel {');z=code.index('class StaticHalfRowsKernel {',a)
  part=code[a:z]
  old='begin_=rows*GetBlockIdx()/GetBlockNum();end_=rows*(GetBlockIdx()+1)/GetBlockNum();eps_=eps;'
  new='begin_=static_cast<uint64_t>(GetBlockIdx())*119;end_=rows;step_=static_cast<uint64_t>(GetBlockNum())*119;eps_=eps;'
  assert part.count(old)==1;part=part.replace(old,new)
  part=part.replace('begin_+119','begin_+step_').replace('row+238','row+2*step_').replace('row+119','row+step_').replace('row+=119','row+=step_')
  part=part.replace('uint64_t begin_,end_;','uint64_t begin_,end_,step_;')
  code=code[:a]+part+code[z:]
 dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
 sha=hashlib.sha256(code.encode()).hexdigest()
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='FACC',source_sha256=sha,change=f'BF16 block-cyclic row assignment; D8192 grain={grain}' if grain else 'BF16 D128 interleaved 119-row batches across cores; unchanged arithmetic, UB and DMA lengths',numerical_change=False),indent=2)+'\n')
 print(name,sha)
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='bfstripequick'" not in s:
 s+='''
if mode=='bfstripequick':
 items=[small[14]]+[('bfstripe_'+str(r),r,8192,'bfloat16') for r in [160,321,511,1281]]
 check('bfstripe_check',items,['FACC','BFS1','BFS32','BFS128'])
 for v in ['BFS1','BFS32','BFS128']:
  pairs(v.lower()+'_pairs',[('bf8large',8192,8192,'bfloat16')],'FACC',v,blocks=1)
if mode=='bfsbquick':
 items=[small[13]]+[('bfsb_'+str(r),r,128,'bfloat16') for r in [160,161,4759,4760,4761,9521]]
 check('bfsb_check',items,['FACC','BFSB'])
 pairs('bfsb_pairs',[('b128large',524288,128,'bfloat16')],'FACC','BFSB',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_bfstripe.tar.gz','w:gz') as t:
 for q in [H/n for n in ['BFS1','BFS32','BFS128','BFSB']]+[p]:t.add(q,arcname=q.relative_to(H.parents[1]))
