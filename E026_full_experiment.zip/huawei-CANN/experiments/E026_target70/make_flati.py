from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'FACC/code/kernel.asc').read_text(encoding='utf-8')
inc=(H/'flat_native_half.inc').read_text(encoding='utf-8')
a=inc.index('        uint32_t shift=0;');z=inc.index('        WaitFlag<HardEvent::MTE2_V>(0);',a)
inc=inc[:a]+'''        // Shape-derived byte offsets: build one column sequence and one
        // row sequence, then combine them with a row broadcast. This avoids
        // transforming every index through four full-buffer instructions.
        for(uint32_t i=0;i<8;++i) {
            indices_.SetValue(i,static_cast<int32_t>(i*2));
            rowindex_.SetValue(i,static_cast<int32_t>(i*d_*2));
        }
        SetFlag<HardEvent::S_V>(0);WaitFlag<HardEvent::S_V>(0);
        for(uint32_t span=8;span<stride_;span*=2) {
            const uint32_t n=Min(span,stride_-span);
            Adds(indices_[span],indices_,static_cast<int32_t>(span*2),n);PipeBarrier<PIPE_V>();
        }
        for(uint32_t span=8;span<count_;span*=2) {
            const uint32_t n=Min(span,count_-span);
            Adds(rowindex_[span],rowindex_,static_cast<int32_t>(span*d_*2),n);PipeBarrier<PIPE_V>();
        }
        auto rows=rowindex_[64];
        Brcb(rows,rowindex_,(count_+7)/8,{1,8});PipeBarrier<PIPE_V>();
        for(uint32_t col=0;col<stride_;col+=64)
            Add(indices_[col],indices_[col],rows,64,count_,{1,1,0,static_cast<uint8_t>(stride_/8),0,1});
        PipeBarrier<PIPE_V>();
'''+inc[z:]
inc=inc.replace('FlatNativeHalfKernel','FlatIndexHalfKernel').replace('flat_native_half_custom','flat_index_half_custom')
code=base.replace('class StaticHalfRowsKernel {',inc+'\nclass StaticHalfRowsKernel {',1)
old='''        static_half_rows_custom<<<blockNum,nullptr,stream>>>(
            x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'''
new='''        if(d%64!=0) flat_index_half_custom<<<blockNum,nullptr,stream>>>(
            x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        else static_half_rows_custom<<<blockNum,nullptr,stream>>>(
            x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'''
assert code.count(old)==1;code=code.replace(old,new)
name='FLATI';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
sha=hashlib.sha256(code.encode()).hexdigest()
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='FACC',source_sha256=sha,change='Short FP16 packed input: one Gather with row/column byte indices assembled using Brcb and high-dimensional Add; avoid four full-index transformations; support padded strides 64/128/192/256',numerical_change=False,static_ub_end=153856),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='flatiquick'" not in s:
 s+='''
if mode=='flatiquick':
 items=[small[3]]+[('flati_'+str(d),767,d,'float16') for d in [65,97,127,129,153,191,197,241,255]]+[('flati_rows'+str(r),r,193,'float16') for r in [160,161,1280]]
 check('flati_check',items,['FACC','FLATI'])
 pairs('flati_pairs',[small[3]],'FACC','FLATI',blocks=2)
if mode=='flatiedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='flati_edge_'+pattern;case(cid,767,193,'float16',pattern);items.append((cid,767,193,'float16'))
 check('flati_edge_check',items,['FACC','FLATI'])
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_flati.tar.gz','w:gz') as t:
 for q in [H/name,p]:t.add(q,arcname=q.relative_to(H.parents[1]))
print(name,sha)
