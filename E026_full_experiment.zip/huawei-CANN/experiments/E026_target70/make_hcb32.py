from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'BFSIP/code/kernel.asc').read_text(encoding='utf-8')
other=(H/'HCORE32/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class StaticHalfRowsKernel {');z=base.index('// At most four FP32',a)
c=other.index('class StaticHalfRowsKernel {');e=other.index('// At most four FP32',c)
code=base[:a]+other[c:e]+base[z:]
old='''        static_half_rows_custom<<<blockNum,nullptr,stream>>>(
            x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'''
new='''        const uint32_t preferred=blockNum<32?blockNum:32;
        const uint32_t shortCores=rows<=static_cast<uint64_t>(preferred)*63?preferred:blockNum;
        static_half_rows_custom<<<shortCores,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'''
assert code.count(old)==1;code=code.replace(old,new)
name='HCB32';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFSIP',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='Merge numerically identical HCORE32 short FP16 in-place square tile and 32-core preference into best official BFSIP',static_ub_end=141312,numerical_change=False),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='hcb32quick'" not in s:
 s+='''
if mode=='hcb32quick':
 items=[small[3],('hc_65',257,65,'float16'),('hc_1008',1008,255,'float16'),('hc_1009',1009,255,'float16'),('hc_1280',1280,256,'float16'),small[13]]
 check('hcb32_check',items,['BFSIP','HCB32'])
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_hcb32.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
