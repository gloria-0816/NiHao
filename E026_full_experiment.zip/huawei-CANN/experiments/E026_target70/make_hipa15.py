from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent;code=(H/'HIP15/code/kernel.asc').read_text(encoding='utf-8')
old='        if(input.dtype==1) half_inplace_rows_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'
new='''        if(input.dtype==1 && d%64==0) half_inplace_rows_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        else if(input.dtype==1) pipeline_batch9_custom<half,true><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'''
assert code.count(old)==1;code=code.replace(old,new)
name='HIPA15';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFPN4',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='Adopt HIP15 in-place FP16 batches only at D divisible by 64; non-aligned FP16 retains BFPN4 route',static_ub_end=192000,numerical_change=True),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='hipa15quick'" not in s:
 s+='''
if mode=='hipa15quick':
 check('hipa15_check',[small[i] for i in [5,6,7,9]],['BFPN4','HIP15','HIPA15'])
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_hipa15.tar.gz','w:gz') as tar:
 for target in [H/name,p,H/'run_cold.py',H/'run_after_cold.py']:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
