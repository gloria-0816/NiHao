from pathlib import Path
import shutil,json,hashlib
H=Path(__file__).resolve().parent
base=(H/'BASE/code/kernel.asc').read_text()
inc=(H/'long_acc.inc').read_text()
code=base.replace('class StaticHalfRowsKernel {',inc+'\nclass StaticHalfRowsKernel {',1)
anchor='    if (input.dtype == 1 && d <= 256'
launch='''    if((input.dtype==1 || input.dtype==2) && d>8192 && d<=32768 && d%4096==0) {
        if(input.dtype==1)long_acc_custom<half><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        else long_acc_custom<bfloat16_t><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert anchor in code
code=code.replace(anchor,launch+anchor,1)
d=H/'LONGACC/code';shutil.copytree(H/'BASE/code',d,dirs_exist_ok=True)
(d/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'LONGACC/manifest.json').write_text(json.dumps({'variant':'LONGACC','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'ub_end_bytes':196608},indent=2)+'\n')
f=H/'run_round.py';s=f.read_text()
if "mode=='longaccquick'" not in s:
 s+='''
if mode=='longaccquick':
 check('longacc_check',[small[4],('longacc_16',41,16384,'float16'),('longacc_24',3,24576,'float16')],['BASE','LONGACC'])
 pairs('longacc_pairs',[small[4]],'BASE','LONGACC',blocks=1)
'''
 f.write_text(s,encoding='utf-8',newline='\n')
print(hashlib.sha256(code.encode()).hexdigest())
