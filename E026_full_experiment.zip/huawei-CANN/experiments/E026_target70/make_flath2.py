from pathlib import Path
import shutil,json,hashlib
H=Path(__file__).resolve().parent
code=(H/'FLATH/code/kernel.asc').read_text()
old='        CreateVecIndex(indices_,static_cast<int32_t>(0),active);PipeBarrier<PIPE_V>();'
new='''        // CANN 9.0 A2 CreateVecIndex internally dereferences GetTPipePtr.
        // Static tensors have no TPipe. Seed eight scalar entries with an
        // explicit S->V event, then expand them by powers of two.
        for(uint32_t i=0;i<8;++i)indices_.SetValue(i,static_cast<int32_t>(i));
        SetFlag<HardEvent::S_V>(0);WaitFlag<HardEvent::S_V>(0);
        for(uint32_t span=8;span<active;span*=2) {
            const uint32_t count=active-span<span?active-span:span;
            Adds(indices_[span],indices_,static_cast<int32_t>(span),count);
            PipeBarrier<PIPE_V>();
        }'''
assert old in code
code=code.replace(old,new,1)
d=H/'FLATH2/code';shutil.copytree(H/'BASE/code',d,dirs_exist_ok=True)
(d/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'FLATH2/manifest.json').write_text(json.dumps({'variant':'FLATH2','source_sha256':hashlib.sha256(code.encode()).hexdigest()},indent=2)+'\n')
f=H/'run_round.py';s=f.read_text()
if "mode=='flath2quick'" not in s:
 s+='''
if mode=='flath2quick':
 check('flath2_check',[small[3],('flath_65',767,65,'float16'),('flath_255',767,255,'float16')],['BASE','FLATH2'])
 pairs('flath2_pairs',[small[3]],'BASE','FLATH2',blocks=1)
'''
 f.write_text(s,encoding='utf-8',newline='\n')
print(hashlib.sha256(code.encode()).hexdigest())
