from pathlib import Path
import shutil,hashlib,json
H=Path(__file__).resolve().parent
code=(H/'AFFROW/code/kernel.asc').read_text()
short=(H/'HALFBR/code/kernel.asc').read_text()
start=code.index('class StaticHalfRowsKernel {');end=code.index('__global__ __vector__ void static_half_rows_custom',start)
sa=short.index('class StaticHalfRowsKernel {');sz=short.index('__global__ __vector__ void static_half_rows_custom',sa)
code=code[:start]+short[sa:sz]+code[end:]
name='COMBO1';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'source_sha256':hashlib.sha256(code.encode()).hexdigest(),'parent':'DB9','changes':['HALFBR short FP16 reduction','AFFROW row/column adaptive normalization']},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='combo1quick'" not in s:
 s+='''
if mode=='combo1quick':
 check('combo1_check',small,['BASE','COMBO1'])
 pairs('combo1_pairs',[small[3],small[9]],'BASE','COMBO1',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
