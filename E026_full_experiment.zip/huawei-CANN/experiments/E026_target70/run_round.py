import sys,json,hashlib,subprocess,statistics,csv,time,os,importlib.util
from pathlib import Path
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[1]
spec=importlib.util.spec_from_file_location('core',ROOT/'experiments/E006A_probe/cloud_driver.py');core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
core.PROTOCOL=dict(timeout_ms=30000,process_timeout_s=240)
OUT=Path('/mnt/workspace/addrms_results/E026');OUT.mkdir(exist_ok=True)
def source(v):
 if v=='BASE':return HERE/'BASE/code/kernel.asc'
 return ROOT/'experiments/E014_crossrow_cast/source/C/kernel.asc' if v=='C' else HERE/v/'code/kernel.asc'
def runner(v):
 if v=='BASE':return ROOT/'experiments/E025_pipeline/build_DB9/cloud_addrmsnormbias'
 return ROOT/'experiments/E014_crossrow_cast/build_C/cloud_addrmsnormbias' if v=='C' else HERE/f'build_{v}/cloud_addrmsnormbias'
core.version=lambda v:(runner(v),core.sha(source(v)))
core.origin=lambda cid: next((q/cid for q in [Path('/mnt/workspace/addrms_results/E021/inputs'),Path('/mnt/workspace/addrms_results/E023/inputs')] if (q/cid/'meta.json').exists()),OUT/'inputs'/cid)
orig=core.run_logged
def logged(cmd,*a,**k):
 if '--case-dir' in cmd:cmd.extend(['--max-device-bytes','8589934592'])
 return orig(cmd,*a,**k)
core.run_logged=logged

def build(names):
 for v in names:
  folder=OUT/f'build_{v}';folder.mkdir(exist_ok=True)
  cmd=['env','ASCEND_HOME_PATH=/home/developer/Ascend/cann-9.0.0','KERNEL_SOURCE='+str(source(v)),'BUILD_DIR='+str(runner(v).parent),'bash',str(ROOT/'cloud_bench/build.sh')]
  r=orig(cmd,folder/'stdout.log',folder/'stderr.log',600);r.update(source_sha256=core.sha(source(v)))
  if r['returncode']==0:r['runner_sha256']=core.sha(runner(v))
  core.save(folder/'record.json',r);print(v,r,flush=True)
  assert r['returncode']==0

def case(cid,r,d,dt,pattern='uniform'):
 dest=core.origin(cid)
 if not dest.exists():
  dest.parent.mkdir(exist_ok=True)
  if r<=32768: shape=[1,r,d]
  else:
   factors=[b for b in range(1,8193) if r%b==0 and r//b<=32768]
   if not factors: raise ValueError('Cannot represent rows as a legal batch/sequence product')
   b=factors[0];shape=[b,r//b,d]
  core.case_data.generate(dest,shape,dt,seed=42,pattern=pattern,case_id=cid,max_tensor_mib=2048)
 return cid

def run(cid,v,folder,profile=False):
 rec=core.run_case(folder,cid,v,dict(warmup=10 if profile else 0,repeats=1,batch=20 if profile else 1,timing='host'),'ordinary' if profile else None)
 assert rec['status'] in ('measured_strict_pass','measured_strict_fail_retained'),rec
 # Retain all numerical outcomes, including the approximate Rsqrt probe.
 if profile:
  rows=[]
  for f in (folder/'profile').rglob('op_summary*.csv'):
   with f.open(encoding='utf-8-sig') as h:rows+=list(csv.DictReader(h))
  rows.sort(key=lambda x:float(x['Task Start Time(us)']));assert len(rows)==31,len(rows)
  rec['task_times_us']=[float(x['Task Duration(us)']) for x in rows[-20:]];rec['median_us']=statistics.median(rec['task_times_us'])
  core.save(folder/'record.json',rec)
 return rec

def check(group,items,variants):
 dest=OUT/group;dest.mkdir(exist_ok=True);records=[]
 for cid,r,d,dt in items:
  case(cid,r,d,dt);pair=[]
  for v in variants:
   f=dest/f'{cid}_{v}'
   rec=json.loads((f/'record.json').read_text()) if (f/'record.json').exists() else run(cid,v,f)
   pair.append(rec);records.append(rec)
  
  for x in pair:x['bitwise_equal_parent']=x['output_sha256']==pair[0]['output_sha256']
  core.save(dest/'records.json',records)
 core.save(dest/'complete.json',dict(cases=len(items),runs=len(records),bitwise_equal=all(x.get('bitwise_equal_parent',True) for x in records),strict_fail=sum(not x['strict']['pass'] for x in records)))

def pairs(group,items,base,cand,blocks=2):
 dest=OUT/group;dest.mkdir(exist_ok=True);records=[]
 for block in range(blocks):
  for cid,r,d,dt in items:
   case(cid,r,d,dt)
   for pos,v in enumerate([base,cand,cand,base] if block%2==0 else [cand,base,base,cand]):
    f=dest/f'b{block}_{cid}_{pos}_{v}'
    rec=json.loads((f/'record.json').read_text()) if (f/'record.json').exists() else run(cid,v,f,True)
    records.append(rec);core.save(dest/'records.json',records)
 summary={}
 for cid,*_ in items:
  b=[x['median_us'] for x in records if x['case_id']==cid and x['variant']==base];c=[x['median_us'] for x in records if x['case_id']==cid and x['variant']==cand]
  summary[cid]=dict(base=base,candidate=cand,base_us=b,candidate_us=c,gain_pct=100*(statistics.median(b)-statistics.median(c))/statistics.median(b))
 core.save(dest/'summary.json',summary);print(json.dumps(summary),flush=True)

small=[('s1',1,64,'float16'),('s2',7,197,'float32'),('s3',128,256,'float32'),('s4',767,193,'float16'),('s5',8,32768,'float16'),('s6',1513,577,'float16'),('s7',3113,397,'float16'),('s8',10240,512,'float16'),('s9',4096,1536,'float32'),('s10',8192,1024,'float16'),('s11',3749,3083,'float32'),('s12',3408,4096,'bfloat16'),('s13',10300,3079,'float32'),('s14_reduced',3841,128,'bfloat16'),('s15_reduced',161,8192,'bfloat16')]



mode=sys.argv[1]
if mode=='build':build(sys.argv[2:])
if mode=='packquick':
 check('pack_check',[small[i] for i in [3,10,12]],['BASE','PACK'])
 pairs('pack_pairs',[small[i] for i in [3,10,12]],'BASE','PACK',blocks=1)
if mode=='halfbrquick':
 check('halfbr_check',[small[3]],['BASE','HALFBR'])
 pairs('halfbr_pairs',[small[3]],'BASE','HALFBR',blocks=1)
if mode=='h20quick':
 check('h20_check',[small[3]],['BASE','H20'])
 pairs('h20_pairs',[small[3]],'BASE','H20',blocks=1)

if mode=='splitquick':
 check('split_check',[small[4],('split_one',1,32768,'float16'),('split_two',2,16384,'float16')],['BASE','SPLIT'])
 pairs('split_pairs',[small[4]],'BASE','SPLIT',blocks=1)

if mode=='flathquick':
 check('flath_check',[small[3],('flath_65',767,65,'float16'),('flath_255',767,255,'float16')],['BASE','FLATH'])
 pairs('flath_pairs',[small[3]],'BASE','FLATH',blocks=1)

if mode=='row32quick':
 check('row32_check',[small[i] for i in [1,2,3,5,6,7,10]],['BASE','ROW32'])
 pairs('row32_pairs',[small[i] for i in [2,3,5,6,10]],'BASE','ROW32',blocks=1)

if mode=='dupquick':
 check('dup_check',[small[4],('split_one',1,32768,'float16'),('split_two',2,16384,'float16')],['BASE','DUP'])
 pairs('dup_pairs',[small[4]],'BASE','DUP',blocks=1)

if mode=='flath2quick':
 check('flath2_check',[small[3],('flath_65',767,65,'float16'),('flath_255',767,255,'float16')],['BASE','FLATH2'])
 pairs('flath2_pairs',[small[3]],'BASE','FLATH2',blocks=1)

if mode=='mask64quick':
 check('mask64_check',[small[0],('m64_float',1,64,'float32'),('m64_bf16',1,64,'bfloat16')],['BASE','MASK64'])
 pairs('mask64_pairs',[small[0]],'BASE','MASK64',blocks=2)

if mode=='mask64bquick':
 check('mask64b_check',[small[0],('m64_float',1,64,'float32'),('m64_bf16',1,64,'bfloat16')],['BASE','MASK64B'])
 pairs('mask64b_pairs',[small[0]],'BASE','MASK64B',blocks=2)
if mode=='maskbatchquick':
 check('maskbatch_check',[small[i] for i in [0,3,5,6,7,9,13]],['BASE','MASKBATCH'])
 pairs('maskbatch_pairs',[small[i] for i in [3,5,6,7,9]],'BASE','MASKBATCH',blocks=1)

if mode=='longaccquick':
 check('longacc_check',[small[4],('longacc_16',41,16384,'float16'),('longacc_24',3,24576,'float16')],['BASE','LONGACC'])
 pairs('longacc_pairs',[small[4]],'BASE','LONGACC',blocks=1)

if mode=='affrowquick':
 check('affrow_check',[small[i] for i in [5,6,7,9]],['BASE','AFFROW'])
 pairs('affrow_pairs',[small[9]],'BASE','AFFROW',blocks=1)
if mode=='longacc2quick':
 check('longacc2_check',[small[4],('longacc_16',41,16384,'float16'),('longacc_24',3,24576,'float16')],['BASE','LONGACC2'])
 pairs('longacc2_pairs',[small[4]],'BASE','LONGACC2',blocks=1)

if mode=='fpstaticquick':
 check('fpstatic_check',[small[10],small[12],('fps_2048',161,2048,'float32'),('fps_3136',257,3136,'float32')],['BASE','FPSTATIC'])
 pairs('fpstatic_pairs',[small[10],small[12]],'BASE','FPSTATIC',blocks=1)

if mode=='combo1quick':
 check('combo1_check',small,['BASE','COMBO1'])
 pairs('combo1_pairs',[small[3],small[9]],'BASE','COMBO1',blocks=1)

if mode=='fpstatic2quick':
 check('fpstatic2_check',[small[10],small[12],('fps_2048',161,2048,'float32'),('fps_3136',257,3136,'float32')],['BASE','FPSTATIC2'])
 pairs('fpstatic2_pairs',[small[10],small[12]],'BASE','FPSTATIC2',blocks=1)

if mode=='flatdmaquick':
 check('flatdma_check',[small[i] for i in [5,6,7,9,13]],['COMBO1','FLATDMA'])
 pairs('flatdma_pairs',[small[i] for i in [7,9,13]],'COMBO1','FLATDMA',blocks=1)

if mode=='shortquick':
 check('short_check',[small[2],('shortf_512',257,512,'float32'),('shortf_193',161,193,'float32')],['COMBO1','SHORT8','SHORT16','SHORT32'])
 for v in ['SHORT8','SHORT16','SHORT32']:
  pairs(v.lower()+'_pairs',[small[2]],'COMBO1',v,blocks=1)

if mode=='shortbquick':
 check('shortb_check',[small[2],('shortf_512',257,512,'float32'),('shortf_193',161,193,'float32'),('shortf_64',257,64,'float32')],['COMBO1','SHORT8B','SHORT16B','SHORT32B'])
 for v in ['SHORT8B','SHORT16B','SHORT32B']:
  pairs(v.lower()+'_pairs',[small[2]],'COMBO1',v,blocks=1)

if mode=='res1quick':
 check('res1_check',[small[i] for i in [5,6,7,9,13]],['COMBO1','RES1'])
 pairs('res1_pairs',[small[i] for i in [5,6,7,9,13]],'COMBO1','RES1',blocks=1)

if mode=='retaccquick':
 check('retacc_check',[small[4],('longacc_16',41,16384,'float16'),('longacc_24',3,24576,'float16')],['COMBO1','RETACC'])
 pairs('retacc_pairs',[small[4]],'COMBO1','RETACC',blocks=1)

if mode=='halfaddquick':
 check('halfadd_check',[small[i] for i in [5,6,7,9,13]],['COMBO1','HALFADD'])
 pairs('halfadd_pairs',[small[i] for i in [5,6,7,9]],'COMBO1','HALFADD',blocks=1)

if mode=='retacc2quick':
 check('retacc2_check',[small[4],('longacc_16',41,16384,'float16'),('longacc_24',3,24576,'float16')],['COMBO1','RETACC2'])
 pairs('retacc2_pairs',[small[4]],'COMBO1','RETACC2',blocks=1)

if mode=='combo2quick':
 check('combo2_check',small,['SHORT8B','COMBO2'])
 pairs('combo2_pairs',[small[5],small[6],small[7],small[9]],'SHORT8B','COMBO2',blocks=1)

if mode=='recastquick':
 check('recast_check',[small[i] for i in [5,6,7,9]],['COMBO2','RECAST'])
 pairs('recast_pairs',[small[i] for i in [5,6,7,9]],'COMBO2','RECAST',blocks=1)

if mode=='halfaffquick':
 check('halfaff_check',[small[i] for i in [5,6,7,9,13]],['COMBO2','HALFAFF'])
 pairs('halfaff_pairs',[small[i] for i in [5,6,7,9]],'COMBO2','HALFAFF',blocks=1)

if mode=='smallaffquick':
 check('smallaff_check',[small[0],small[3],('m64_float',1,64,'float32'),('m64_bf16',1,64,'bfloat16'),('flath_65',767,65,'float16'),('flath_255',767,255,'float16')],['COMBO2','SMALLAFF'])
 pairs('smallaff_pairs',[small[0],small[3]],'COMBO2','SMALLAFF',blocks=1)

if mode=='halfaff2quick':
 check('halfaff2_check',[small[i] for i in [5,6,7,9,13]],['COMBO2','HALFAFF2'])
 pairs('halfaff2_pairs',[small[i] for i in [5,6,7,9]],'COMBO2','HALFAFF2',blocks=1)

if mode=='combo3quick':
 check('combo3_check',small+[('combo3_longbf',3,16384,'bfloat16')],['COMBO2','COMBO3'])
 pairs('combo3_pairs',[small[i] for i in [4,7,10,12]],'COMBO2','COMBO3',blocks=1)

if mode=='singleovquick':
 check('singleov_check',[small[0],('singleov_fp32',1,64,'float32'),('singleov_bf16',1,64,'bfloat16')],['COMBO2','SINGLEOV'])
 pairs('singleov_pairs',[small[0]],'COMBO2','SINGLEOV',blocks=2)

if mode=='shortaddquick':
 check('shortadd_check',[small[3],('flath_65',767,65,'float16'),('flath_255',767,255,'float16')],['COMBO2','SHORTADD'])
 pairs('shortadd_pairs',[small[3]],'COMBO2','SHORTADD',blocks=2)

if mode=='splitaffquick':
 check('splitaff_check',[small[4],('split_one',1,32768,'float16'),('split_two',2,16384,'float16')],['COMBO2','SPLITAFF'])
 pairs('splitaff_pairs',[small[4]],'COMBO2','SPLITAFF',blocks=2)

if mode=='comboaquick':
 check('comboa_check',small,['HALFAFF2','COMBOA'])
 pairs('comboa_pairs',[small[i] for i in [0,3,4,7,10,12]],'HALFAFF2','COMBOA',blocks=1)

if mode=='fpstatic3quick':
 check('fpstatic3_check',[small[10],small[12],('fps_2048',161,2048,'float32'),('fps_3136',257,3136,'float32')],['COMBOA','FPSTATIC3'])
 pairs('fpstatic3_pairs',[small[10],small[12]],'COMBOA','FPSTATIC3',blocks=1)

if mode=='autovquick':
 check('autov_check',small,['HALFAFF2','AUTOV'])
 pairs('autov_pairs',[small[i] for i in [0,3,4,5,6,7,10,11,12,13,14]],'HALFAFF2','AUTOV',blocks=1)

if mode=='fpbroadquick':
 items=[small[10],small[12]]+[('fpbroad_'+str(d),257,d,'float32') for d in [1537,2048,3136,3200,4095,4096]]
 check('fpbroad_check',items,['HALFAFF2','FPBROAD'])
 pairs('fpbroad_pairs',[small[10],small[12],('fpbroad_4095',257,4095,'float32')],'HALFAFF2','FPBROAD',blocks=1)

if mode=='halfwidequick':
 items=[('halfwide_'+str(d),257,d,'float16') for d in [1025,1536,2048,2049,4095,4096]]
 check('halfwide_check',items,['HALFAFF2','HALFWIDE'])
 pairs('halfwide_pairs',[items[i] for i in [1,2,4,5]],'HALFAFF2','HALFWIDE',blocks=1)

if mode=='cachequick':
 items=[small[12],('s14_large',524288,128,'bfloat16'),('s15_large',8192,8192,'bfloat16')]
 check('cache_check',items,['HALFAFF2','CACHEIN','CACHEALL'])
 for cand in ['CACHEIN','CACHEALL']:
  pairs('cache_'+cand.lower()+'_pairs',items,'HALFAFF2',cand,blocks=1)

if mode=='bfs8quick':
 check('bfs8_check',[small[14],('bfs8_4097',161,4097,'bfloat16'),('bfs8_8191',161,8191,'bfloat16')],['HALFAFF2','BFS8'])
 pairs('bfs8_pairs',[small[14]],'HALFAFF2','BFS8',blocks=2)

if mode=='broad1quick':
 check('broad1_check',small+[('halfwide_1536',257,1536,'float16'),('halfwide_4095',257,4095,'float16'),('fpbroad_4095',257,4095,'float32')],['HALFAFF2','BROAD1'])
 pairs('broad1_pairs',[small[10],small[14]],'HALFAFF2','BROAD1',blocks=1)

if mode=='bankhquick':
 check('bankh_check',[small[i] for i in [5,6,7,9,13]],['HALFAFF2','BANKH'])
 pairs('bankh_pairs',[small[i] for i in [5,6,7,9]],'HALFAFF2','BANKH',blocks=2)

if mode=='broad2quick':
 check('broad2_check',small+[('halfwide_1536',257,1536,'float16'),('halfwide_4095',257,4095,'float16'),('fpbroad_4095',257,4095,'float32')],['HALFAFF2','BROAD2'])
 pairs('broad2_pairs',[small[10],small[12]],'HALFAFF2','BROAD2',blocks=1)

if mode=='rpipequick':
 items=[small[i] for i in [5,6,7,9,13]]
 check('rpipe_check',items,['HALFAFF2','RPIPE0','RPIPE1'])
 for v in ['RPIPE0','RPIPE1']:
  pairs(v.lower()+'_pairs',[small[5],small[7],small[9]],'HALFAFF2',v,blocks=1)

if mode=='smallcorequick':
 items=[small[1],('smallcore_2',2,65,'float32'),('smallcore_16',16,512,'float32'),('smallcore_9',9,193,'float32')]
 check('smallcore_check',items,['BROAD2','SMALL1','SMALL2','SMALL4'])
 for v in ['SMALL1','SMALL2','SMALL4']:
  pairs(v.lower()+'_pairs',[small[1]],'BROAD2',v,blocks=2)

if mode=='halfnormquick':
 items=[small[i] for i in [5,6,7,9,13]]+[('hn_321',257,321,'float16'),('hn_1023',257,1023,'float16')]
 check('halfnorm_check',items,['BROAD2','HALFNORM'])
 pairs('halfnorm_pairs',[small[i] for i in [5,6,7,9]],'BROAD2','HALFNORM',blocks=1)

if mode=='halfnorm2quick':
 items=[small[i] for i in [5,6,7,9,13]]+[('hn_321',257,321,'float16'),('hn_1023',257,1023,'float16')]
 check('halfnorm2_check',items,['BROAD2','HALFNORM2'])
 pairs('halfnorm2_pairs',[small[i] for i in [5,6,7,9]],'BROAD2','HALFNORM2',blocks=1)

if mode=='hshortnquick':
 items=[small[3]]+[('hshortn_'+str(d),767,d,'float16') for d in [64,65,127,128,129,192,255,256]]
 check('hshortn_check',items,['BROAD2','HSHORTN'])
 pairs('hshortn_pairs',[small[3]],'BROAD2','HSHORTN',blocks=2)

if mode=='longhquick':
 items=[small[4],('longh_8193',3,8193,'float16'),('longh_16384',41,16384,'float16'),('longh_24576',3,24576,'float16')]
 check('longh_check',items,['BROAD2','LONGH'])
 pairs('longh_pairs',[small[4],items[2]],'BROAD2','LONGH',blocks=1)

if mode=='longh2quick':
 items=[small[4],('longh_8193',3,8193,'float16'),('longh_16384',41,16384,'float16'),('longh_24576',3,24576,'float16')]
 check('longh2_check',items,['BROAD2','LONGH2'])
 pairs('longh2_pairs',[small[4],items[2]],'BROAD2','LONGH2',blocks=1)

if mode=='broad3quick':
 check('broad3_check',small+[('longh_8193',3,8193,'float16')],['BROAD2','BROAD3'])
 pairs('broad3_pairs',[small[3],small[4]],'BROAD2','BROAD3',blocks=1)

if mode=='sharedhquick':
 items=[small[i] for i in [5,6,7,9]]+[('sharedh_321',257,321,'float16'),('sharedh_1023',257,1023,'float16')]
 check('sharedh_check',items,['BROAD3','SHAREDH'])
 pairs('sharedh_pairs',[small[i] for i in [5,6,7,9]],'BROAD3','SHAREDH',blocks=1)

if mode=='sharedaquick':
 items=[small[i] for i in [5,6,7,9]]+[('shareda_'+str(d),257,d,'float16') for d in [384,448,576,640,768,960]]
 check('shareda_check',items,['BROAD3','SHAREDA'])
 pairs('shareda_pairs',[small[7],small[9]],'BROAD3','SHAREDA',blocks=2)

if mode=='bfp2quick':
 items=[small[11]]+[('bfp2_'+str(d),257,d,'bfloat16') for d in [1025,1536,2048,2049,3079,4095,4096]]
 check('bfp2_check',items,['SHAREDA','BFP2'])
 pairs('bfp2_pairs',[small[11],items[3],items[-1]],'SHAREDA','BFP2',blocks=1)

if mode=='bf128squick':
 items=[small[13]]+[('bf128s_'+str(d),767,d,'bfloat16') for d in [64,128,192,256,384,512]]
 check('bf128s_check',items,['SHAREDA','BF128S'])
 pairs('bf128s_pairs',[small[13]],'SHAREDA','BF128S',blocks=2)
if mode=='bf128slarge':
 items=[('bf128s_large',524288,128,'bfloat16')]
 check('bf128s_large_check',items,['SHAREDA','BF128S'])
 pairs('bf128s_large_pairs',items,'SHAREDA','BF128S',blocks=1)

if mode=='bfp3quick':
 items=[small[11],('bfp3_1025',321,1025,'bfloat16'),('bfp3_2048',321,2048,'bfloat16'),('bfp3_3079',321,3079,'bfloat16'),('bfp3_4095',321,4095,'bfloat16'),('bfp3_small',257,4096,'bfloat16'),small[7]]
 check('bfp3_check',items,['BROAD3','BFP3'])
 pairs('bfp3_pairs',[small[11]],'BROAD3','BFP3',blocks=1)

if mode=='fpc4quick':
 items=[small[10],small[12]]+[('fpc4_'+str(d),321,d,'float32') for d in [1537,2048,3136,3200,4095,4096]]
 check('fpc4_check',items,['BROAD3','FPC4'])
 pairs('fpc4_pairs',[small[10],small[12]],'BROAD3','FPC4',blocks=1)

if mode=='hsfastquick':
 items=[small[0]]
 for seed in [1,2,3,7,11,19,23,31,53,101,202,303,404,505,606,707,808,909,1001,1021]:
  cid='hsfast_seed_'+str(seed);dest=OUT/'inputs'/cid
  if not dest.exists():core.case_data.generate(dest,[1,1,64],'float16',seed=seed,pattern='uniform',case_id=cid,max_tensor_mib=2048)
  items.append((cid,1,64,'float16'))
 check('hsfast_check',items,['BFP3','HSFAST'])
 pairs('hsfast_pairs',[small[0]],'BFP3','HSFAST',blocks=2)

if mode=='hsfastedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='hsfast_'+pattern;case(cid,1,64,'float16',pattern);items.append((cid,1,64,'float16'))
 check('hsfast_edge',items,['BFP3','HSFAST'])

if mode=='fpd4quick':
 items=[small[10],small[12]]+[('fpd4_'+str(d),321,d,'float32') for d in [3073,3136,3137,3200]]
 check('fpd4_check',items,['BFP3','FPD4'])
 pairs('fpd4_pairs',[small[10],small[12]],'BFP3','FPD4',blocks=1)

if mode=='hsfast2quick':
 items=[small[0]]+[('hsfast_seed_'+str(seed),1,64,'float16') for seed in [1,2,3,7,11,19,23,31,53,101,202,303,404,505,606,707,808,909,1001,1021]]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='hsfast_'+pattern;case(cid,1,64,'float16',pattern);items.append((cid,1,64,'float16'))
 check('hsfast2_check',items,['BFP3','HSFAST2'])
 pairs('hsfast2_pairs',[small[0]],'BFP3','HSFAST2',blocks=1)

if mode=='bfpn3quick':
 items=[small[11]]+[('bfp3_'+str(d),321,d,'bfloat16') for d in [1025,2048,3079,4095]]+[('bfpn3_1536',321,1536,'bfloat16'),('bfpn3_4096',321,4096,'bfloat16')]
 check('bfpn3_check',items,['BFP3','BFPN3'])
 pairs('bfpn3_pairs',[small[11],items[2]],'BFP3','BFPN3',blocks=1)

if mode=='bfpn4quick':
 items=[small[11]]+[('bfp3_'+str(d),321,d,'bfloat16') for d in [1025,2048,3079,4095]]+[('bfpn3_1536',321,1536,'bfloat16'),('bfpn3_4096',321,4096,'bfloat16')]
 check('bfpn4_check',items,['BFP3','BFPN4'])
 pairs('bfpn4_pairs',[small[11],items[2]],'BFP3','BFPN4',blocks=1)

if mode=='fpstripequick':
 items=[small[10],small[12]]+[('fpstripe_'+str(d),641,d,'float32') for d in [1537,2048,3136,3200,4095,4096]]
 check('fpstripe_check',items,['BFP3','FPSTRIPE'])
 pairs('fpstripe_pairs',[small[10],small[12]],'BFP3','FPSTRIPE',blocks=1)

if mode=='lexpquick':
 check('lexp_check',small,['BFP3','LEXP'])
 pairs('lexp_pairs',[small[i] for i in [3,4,5,6,7,9,11,13,14]],'BFP3','LEXP',blocks=1)

if mode=='tree128quick':
 items=[small[13],('tree128_321',321,128,'bfloat16'),('tree128_4097',4097,128,'bfloat16')]
 check('tree128_check',items,['BFPN4','TREE128'])
 pairs('tree128_pairs',[small[13]],'BFPN4','TREE128',blocks=1)
if mode=='tree128large':
 items=[('bf128s_large',524288,128,'bfloat16')]
 check('tree128_large_check',items,['BFPN4','TREE128'])
 pairs('tree128_large_pairs',items,'BFPN4','TREE128',blocks=1)

if mode=='shorttreequick':
 items=[small[2],small[3]]+[('st_f'+str(d),129,d,'float32') for d in [64,65,127,128,193,255]]+[('st_h'+str(d),767,d,'float16') for d in [64,65,127,128,129,192,255,256]]
 check('shorttree_check',items,['BFPN4','SHORTTREE'])
 pairs('shorttree_pairs',[small[2],small[3]],'BFPN4','SHORTTREE',blocks=1)
if mode=='hinvquick':
 items=[small[3]]+[('hi_'+str(d),767,d,'float16') for d in [64,65,127,128,129,192,255,256]]
 for pattern in ['zeros','cancel','wide_range','specials']:
  cid='hi_'+pattern;case(cid,767,193,'float16',pattern=pattern);items.append((cid,767,193,'float16'))
 check('hinv_check',items,['BFPN4','HINV'])
 pairs('hinv_pairs',[small[3]],'BFPN4','HINV',blocks=1)

if mode=='hip15quick':
 items=[small[i] for i in [5,6,7,9]]+[('hip_'+str(d),257,d,'float16') for d in [321,383,384,447,511,512,513,767,1023,1024]]
 check('hip15_check',items,['BFPN4','HIP15'])
 pairs('hip15_pairs',[small[i] for i in [5,6,7,9]],'BFPN4','HIP15',blocks=1)

if mode=='hipa15quick':
 check('hipa15_check',[small[i] for i in [5,6,7,9]],['BFPN4','HIP15','HIPA15'])

if mode=='hip16squick':
 items=[small[i] for i in [5,6]]+[('hip_'+str(d),257,d,'float16') for d in [321,383,384,447,511,512,513,767,1023,1024]]
 check('hip16s_check',items,['BFPN4','HIP16S'])
 pairs('hip16s_pairs',[small[i] for i in [5,6]],'BFPN4','HIP16S',blocks=1)

if mode=='bfsipquick':
 items=[small[13]]+[('bfsip_'+str(r),r,128,'bfloat16') for r in [160,321,4097,9501]]
 check('bfsip_check',items,['BFPN4','BFSIP'])
 pairs('bfsip_pairs',[small[13]],'BFPN4','BFSIP',blocks=1)
if mode=='bfsiplarge':
 items=[('bf128s_large',524288,128,'bfloat16')]
 check('bfsip_large_check',items,['BFPN4','BFSIP'])
 pairs('bfsip_large_pairs',items,'BFPN4','BFSIP',blocks=1)

if mode=='flatnhquick':
 items=[small[3]]+[('flatnh_'+str(d),767,d,'float16') for d in [65,97,127,193,197,241,255]]
 check('flatnh_check',items,['BFPN4','FLATNH'])
 pairs('flatnh_pairs',[small[3]],'BFPN4','FLATNH',blocks=1)

if mode=='hcorequick':
 items=[small[3],('hc_65',257,65,'float16'),('hc_1008',1008,255,'float16'),('hc_1009',1009,255,'float16'),('hc_1280',1280,256,'float16')]
 for v in ['HCORE16','HCORE24','HCORE32','HCORE40']:
  check(v.lower()+'_check',items,['BFPN4',v])
  pairs(v.lower()+'_pairs',[small[3]],'BFPN4',v,blocks=1)

if mode=='bfa8quick':
 items=[small[14]]+[('bfa8_'+str(d),161,d,'bfloat16') for d in [4097,6144,8191]]
 check('bfa8_check',items,['BFSIP','BFA8'])
 pairs('bfa8_pairs',[small[14]],'BFSIP','BFA8',blocks=1)
if mode=='bfa8large':
 items=[('bf8_large',8192,8192,'bfloat16')]
 check('bfa8_large_check',items,['BFSIP','BFA8'])
 pairs('bfa8_large_pairs',items,'BFSIP','BFA8',blocks=1)

if mode=='hcb32quick':
 items=[small[3],('hc_65',257,65,'float16'),('hc_1008',1008,255,'float16'),('hc_1009',1009,255,'float16'),('hc_1280',1280,256,'float16'),small[13]]
 check('hcb32_check',items,['BFSIP','HCB32'])

if mode=='sync4quick':
 items=[('split_one',1,32768,'float16'),('split_two',2,16384,'float16'),small[4],('sync4_8448',3,8448,'float16'),('sync4_24576',10,24576,'float16'),('sync4_fallback',11,32768,'float16')]
 check('sync4_check',items,['BFSIP','SYNC4'])
 pairs('sync4_pairs',[small[4],items[0],items[1]],'BFSIP','SYNC4',blocks=1)
if mode=='sync4edge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='sync4_'+pattern;case(cid,8,32768,'float16',pattern);items.append((cid,8,32768,'float16'))
 check('sync4_edge',items,['BFSIP','SYNC4'])

if mode=='bfinvquick':
 items=[small[14]]+[('bfa8_'+str(d),161,d,'bfloat16') for d in [4097,6144,8191]]
 check('bfinv_check',items,['BFSIP','BFINV'])
 pairs('bfinv_pairs',[small[14]],'BFSIP','BFINV',blocks=1)
if mode=='bfinvedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='bfinv_'+pattern;case(cid,161,8192,'bfloat16',pattern);items.append((cid,161,8192,'bfloat16'))
 check('bfinv_edge',items,['BFSIP','BFINV'])
if mode=='bfinvlarge':
 items=[('bf8_large',8192,8192,'bfloat16')]
 check('bfinv_large_check',items,['BFSIP','BFINV'])
 pairs('bfinv_large_pairs',items,'BFSIP','BFINV',blocks=1)

if mode=='flatwquick':
 items=[small[i] for i in [5,6]]+[('hip_'+str(d),257,d,'float16') for d in [321,383,384,447,511,512,513,767,1023,1024]]
 check('flatw_check',items,['BFSIP','FLATW'])
 pairs('flatw_pairs',[small[i] for i in [5,6]],'BFSIP','FLATW',blocks=1)
if mode=='flatwedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='flatw_'+pattern;case(cid,1513,577,'float16',pattern);items.append((cid,1513,577,'float16'))
 check('flatw_edge',items,['BFSIP','FLATW'])

if mode=='fpflatquick':
 items=[small[i] for i in [10,12]]+[('fpflat_'+str(d),641,d,'float32') for d in [1537,2048,3073,3136,3200,4095,4096]]
 check('fpflat_check',items,['BFSIP','FPFLAT'])
 pairs('fpflat_pairs',[small[i] for i in [10,12]],'BFSIP','FPFLAT',blocks=1)

if mode=='bfdb8quick':
 items=[small[14]]+[('bfdb8_'+str(rows),rows,8192,'bfloat16') for rows in [160,161,321,159]]
 check('bfdb8_check',items,['BFSIP','BFDB8'])
 pairs('bfdb8_pairs',[small[14]],'BFSIP','BFDB8',blocks=1)
if mode=='bfdb8edge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='bfinv_'+pattern;case(cid,161,8192,'bfloat16',pattern);items.append((cid,161,8192,'bfloat16'))
 check('bfdb8_edge',items,['BFSIP','BFDB8'])
if mode=='bfdb8large':
 items=[('bf8_large',8192,8192,'bfloat16')]
 check('bfdb8_large_check',items,['BFSIP','BFDB8'])
 pairs('bfdb8_large_pairs',items,'BFSIP','BFDB8',blocks=1)

if mode=='wcorequick':
 items=[small[i] for i in [5,6,10,12,14]]
 for v in ['WCORE24','WCORE32']:
  check(v.lower()+'_check',items,['BFSIP',v])
  pairs(v.lower()+'_pairs',items,'BFSIP',v,blocks=1)
if mode=='wcorelarge':
 items=[('bf8_large',8192,8192,'bfloat16')]
 check('wcore_large_check',items,['BFSIP','WCORE24','WCORE32'])
 for v in ['WCORE24','WCORE32']:
  pairs(v.lower()+'_large_pairs',items,'BFSIP',v,blocks=1)

if mode=='bfsmaxquick':
 items=[small[13]]+[('bfsmax_'+str(r),r,128,'bfloat16') for r in [5000,5080,5081,9501]]
 for v in ['BFS125','BFS127']:
  check(v.lower()+'_check',items,['BFSIP',v])
  pairs(v.lower()+'_pairs',[small[13]],'BFSIP',v,blocks=1)
if mode=='bfsmaxlarge':
 items=[('bf128s_large',524288,128,'bfloat16')]
 check('bfsmax_large_check',items,['BFSIP','BFS125','BFS127'])
 for v in ['BFS125','BFS127']:
  pairs(v.lower()+'_large_pairs',items,'BFSIP',v,blocks=1)

if mode=='shape0quick':
 check('shape0_check',small,['BFSIP','SHAPE0'])
 pairs('shape0_pairs',[small[i] for i in [0,1,2,3,4,5,6,10,13,14]],'BFSIP','SHAPE0',blocks=1)

if mode=='lh16gquick':
 items=[small[4]]+[('lh16g_'+str(d),3,d,'float16') for d in [8193,8448,16384,24576,32767]]
 check('lh16g_check',items,['BFSIP','LH16G'])
 pairs('lh16g_pairs',[small[4],items[3]],'BFSIP','LH16G',blocks=1)
if mode=='lh16gedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='lh16g_edge_'+pattern;case(cid,3,32768,'float16',pattern)
  items.append((cid,3,32768,'float16'))
 check('lh16g_edge_check',items,['BFSIP','LH16G'])

if mode=='par64quick':
 items=[small[0],('m64_float',1,64,'float32'),('m64_bf16',1,64,'bfloat16')]
 check('par64_check',items,['BFSIP','PAR64'])
 pairs('par64_pairs',items,'BFSIP','PAR64',blocks=1)

if mode=='lconstquick':
 items=[small[4],('lconst_16k',3,16384,'float16'),('lconst_32k_many',41,32768,'float16'),('lconst_fallback',3,24576,'float16')]
 check('lconst_check',items,['BFSIP','LCONST'])
 pairs('lconst_pairs',items[:2],'BFSIP','LCONST',blocks=1)

if mode=='lconst2quick':
 items=[small[4],('lconst_16k',3,16384,'float16'),('lconst_32k_many',41,32768,'float16'),('lconst_fallback',3,24576,'float16')]
 check('lconst2_check',items,['BFSIP','LCONST2'])
 pairs('lconst2_pairs',items[:2],'BFSIP','LCONST2',blocks=1)

if mode=='lsqmquick':
 items=[small[4]]+[('lh16g_'+str(d),3,d,'float16') for d in [8193,8448,16384,24576,32767]]+[('lconst_32k_many',41,32768,'float16')]
 check('lsqm_check',items,['BFSIP','LSQM'])
 pairs('lsqm_pairs',[small[4],items[3]],'BFSIP','LSQM',blocks=1)
if mode=='lsqmedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='lh16g_edge_'+pattern;case(cid,3,32768,'float16',pattern)
  items.append((cid,3,32768,'float16'))
 check('lsqm_edge_check',items,['BFSIP','LSQM'])

if mode=='hsqmquick':
 items=[small[3]]+[('hshortn_'+str(d),767,d,'float16') for d in [64,65,127,128,129,192,255,256]]
 check('hsqm_check',items,['BFSIP','HSQM'])
 pairs('hsqm_pairs',[small[3]],'BFSIP','HSQM',blocks=1)

if mode=='hnqmquick':
 items=[small[i] for i in [5,6,7,9]]+[('hip_'+str(d),257,d,'float16') for d in [321,383,384,447,511,512,513,767,1023,1024]]
 check('hnqm_check',items,['LSQM','HNQM'])
 pairs('hnqm_pairs',[small[i] for i in [5,6,7,9]],'LSQM','HNQM',blocks=1)
if mode=='hnqmedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='hnqm_edge_'+pattern;case(cid,257,577,'float16',pattern)
  items.append((cid,257,577,'float16'))
 check('hnqm_edge_check',items,['LSQM','HNQM'])

if mode=='hnqmaquick':
 items=[small[i] for i in [5,6,7,9]]+[('hnqma_'+str(d),257,d,'float16') for d in [384,448,640,768,960]]
 check('hnqma_check',items,['LSQM','HNQMA'])
if mode=='hnqmaedge':
 items=[]
 for d in [512,1024]:
  for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
   cid='hnqma_edge_'+str(d)+'_'+pattern;case(cid,257,d,'float16',pattern)
   items.append((cid,257,d,'float16'))
 check('hnqma_edge_check',items,['LSQM','HNQMA'])
if mode=='fpr56quick':
 items=[small[i] for i in [10,12]]+[('fpr56_'+str(d),641,d,'float32') for d in [1537,2048,2561,3136,3584,4095,4096]]
 check('fpr56_check',items,['LSQM','FPR56'])
 pairs('fpr56_pairs',[small[i] for i in [10,12]],'LSQM','FPR56',blocks=1)

if mode=='ovl3quick':
 items=[small[i] for i in [10,11,12,13]]+[('ovl3_f_'+str(d),641,d,'float32') for d in [1537,2048,3136,4096]]+[('ovl3_b_'+str(d),641,d,'bfloat16') for d in [1025,2048,3079,4095]]
 check('ovl3_check',items,['LSQM','OVL3'])
 pairs('ovl3_pairs',[small[i] for i in [10,11,12,13]],'LSQM','OVL3',blocks=1)
if mode=='ovl3large':
 check('ovl3_large_check',[('b128large',524288,128,'bfloat16')],['LSQM','OVL3'])
 pairs('ovl3_large_pairs',[('b128large',524288,128,'bfloat16')],'LSQM','OVL3',blocks=1)

if mode=='faccquick':
 items=[small[i] for i in [10,12]]+[('facc_'+str(d),641,d,'float32') for d in [1537,2048,3073,3136,4095,4096]]
 check('facc_check',items,['LSQM','FACC'])
 pairs('facc_pairs',[small[i] for i in [10,12]],'LSQM','FACC',blocks=1)
if mode=='baccquick':
 items=[small[14]]+[('bacc_'+str(d),161,d,'bfloat16') for d in [4097,6144,8191]]
 check('bacc_check',items,['LSQM','BACC8'])
 pairs('bacc_pairs',[small[14]],'LSQM','BACC8',blocks=1)
if mode=='bacclarge':
 check('bacc_large_check',[('bf8large',8192,8192,'bfloat16')],['LSQM','BACC8'])
 pairs('bacc_large_pairs',[('bf8large',8192,8192,'bfloat16')],'LSQM','BACC8',blocks=1)

if mode=='hmaccquick':
 items=[small[i] for i in [5,6,7,9]]+[('hip_'+str(d),257,d,'float16') for d in [321,383,384,447,511,512,513,767,1023,1024]]
 check('hmacc_check',items,['LSQM','HMACC'])
 pairs('hmacc_pairs',[small[i] for i in [5,6,7,9]],'LSQM','HMACC',blocks=1)
if mode=='fmaccquick':
 items=[small[i] for i in [10,12]]+[('facc_'+str(d),641,d,'float32') for d in [1537,2048,3073,3136,4095,4096]]
 check('fmacc_check',items,['LSQM','FMACC'])
 pairs('fmacc_pairs',[small[i] for i in [10,12]],'LSQM','FMACC',blocks=1)

if mode=='faccvalidate':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='facc_edge_'+pattern;case(cid,641,3083,'float32',pattern)
  items.append((cid,641,3083,'float32'))
 check('facc_edge_check',items,['LSQM','FACC'])
 subprocess.run(['python3',str(HERE/'run_cold.py'),'facc'],check=True)

if mode=='hwaccquick':
 items=[('hwacc_'+str(d),3408,d,'float16') for d in [1536,2048,3072,4096]]+[('hwacc_'+str(d),257,d,'float16') for d in [1025,1537,3079,4095]]
 check('hwacc_check',items,['LSQM','HWACC'])
 pairs('hwacc_pairs',items[:4],'LSQM','HWACC',blocks=1)
if mode=='hwaccedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='hwacc_edge_'+pattern;case(cid,257,4096,'float16',pattern)
  items.append((cid,257,4096,'float16'))
 check('hwacc_edge_check',items,['LSQM','HWACC'])

if mode=='flongquick':
 items=[('flong_'+str(d),161,d,'float32') for d in [4097,8192,16384,32768]]+[('flong_'+str(d),7,d,'float32') for d in [8191,16383,32767]]
 check('flong_check',items,['FACC','FDIR','FDACC'])
 for v in ['FDIR','FDACC']:
  pairs(v.lower()+'_pairs',[items[i] for i in [1,2,3]],'FACC',v,blocks=1)
if mode=='flongedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='flong_edge_'+pattern;case(cid,7,32767,'float32',pattern)
  items.append((cid,7,32767,'float32'))
 check('flong_edge_check',items,['FACC','FDIR','FDACC'])

if mode=='fwaccquick':
 items=[('hwacc_1536',3408,1536,'float16'),('hwacc_4095',257,4095,'float16'),('facc_1537',641,1537,'float32'),small[4]]
 check('fwacc_check',items,['FACC','FWACC'])

if mode=='hslanequick':
 items=[small[3]]+[('hslane_'+str(d),767,d,'float16') for d in [64,65,127,128,192,255,256]]
 check('hslane_check',items,['FACC','HSLANE'])
 pairs('hslane_pairs',[small[3]],'FACC','HSLANE',blocks=2)
if mode=='hslaneedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='hslane_edge_'+pattern;case(cid,767,193,'float16',pattern)
  items.append((cid,767,193,'float16'))
 check('hslane_edge_check',items,['FACC','HSLANE'])

if mode=='ploadrmnquick':
 items=[small[i] for i in [3,5,6,7,9,10]]+[('hwacc_1536',3408,1536,'float16'),('facc_1537',641,1537,'float32')]
 check('ploadrmn_check',items,['FACC','PLOAD','RMN'])
 for v in ['PLOAD','RMN']:
  pairs(v.lower()+'_pairs',[small[i] for i in ([5,6,7,9,10] if v=='PLOAD' else [3,5,6,7,9])],'FACC',v,blocks=1)

if mode=='sfdirquick':
 items=[small[1]]+[('sfdir_'+str(d),7,d,'float32') for d in [64,65,128,255,512,1025,2048,4095,4096]]
 check('sfdir_check',items,['FACC','SFDIR','SFACC'])
 for v in ['SFDIR','SFACC']:
  pairs(v.lower()+'_pairs',[small[1]],'FACC',v,blocks=2)
if mode=='sfdir edge':
 pass
if mode=='sfdiredge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='sfdir_edge_'+pattern;case(cid,7,197,'float32',pattern)
  items.append((cid,7,197,'float32'))
 check('sfdir_edge_check',items,['FACC','SFDIR','SFACC'])

if mode=='cpartquick':
 check('cpart_check',small,['FACC','CPART'])
 pairs('cpart_pairs',[small[i] for i in [1,2,3,5,6,10]],'FACC','CPART',blocks=1)

if mode=='hostpquick':
 items=[small[i] for i in [2,3,5,6,7,9]]+[('hostp_h_'+str(d),161,d,'float16') for d in [65,193,321,577,1024]]+[('hostp_f_256',161,256,'float32')]
 check('hostp_check',items,['FACC','HOSTP'])
 pairs('hostp_pairs',[small[i] for i in [2,3,5,6,7,9]],'FACC','HOSTP',blocks=1)

if mode=='coal64quick':
 items=[small[0],('m64_float',1,64,'float32'),('m64_bf16',1,64,'bfloat16')]
 check('coal64_check',items,['FACC','COAL64'])
 pairs('coal64_pairs',items,'FACC','COAL64',blocks=2)

if mode=='sftinyquick':
 items=[small[i] for i in [0,1]]+[('m64_float',1,64,'float32'),('m64_bf16',1,64,'bfloat16'),('sftiny_h64',2,64,'float16'),('sftiny_h193',7,193,'float16'),('sfdir_4095',7,4095,'float32')]
 check('sftiny_check',items,['FACC','SFTINY'])
 pairs('sftiny_pairs',[small[i] for i in [0,1]],'FACC','SFTINY',blocks=2)

if mode=='bfstripequick':
 items=[small[14]]+[('bfstripe_'+str(r),r,8192,'bfloat16') for r in [160,321,511,1281]]
 check('bfstripe_check',items,['FACC','BFS1','BFS32','BFS128'])
 for v in ['BFS1','BFS32','BFS128']:
  pairs(v.lower()+'_pairs',[('bf8large',8192,8192,'bfloat16')],'FACC',v,blocks=1)
if mode=='bfsbquick':
 items=[small[13]]+[('bfsb_'+str(r),r,128,'bfloat16') for r in [160,161,4759,4760,4761,9521]]
 check('bfsb_check',items,['FACC','BFSB'])
 pairs('bfsb_pairs',[('b128large',524288,128,'bfloat16')],'FACC','BFSB',blocks=1)

if mode=='flatiquick':
 items=[small[3]]+[('flati_'+str(d),767,d,'float16') for d in [65,97,127,129,153,191,197,241,255]]+[('flati_rows'+str(r),r,193,'float16') for r in [160,161,1280]]
 check('flati_check',items,['FACC','FLATI'])
 pairs('flati_pairs',[small[3]],'FACC','FLATI',blocks=2)
if mode=='flatiedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='flati_edge_'+pattern;case(cid,767,193,'float16',pattern);items.append((cid,767,193,'float16'))
 check('flati_edge_check',items,['FACC','FLATI'])

if mode=='bfrrquick':
 items=[small[14]]+[('bfstripe_'+str(r),r,8192,'bfloat16') for r in [160,321,511,1281]]
 check('bfrr_check',items,['FACC','BFRR'])
 pairs('bfrr_pairs',[('bf8large',8192,8192,'bfloat16')],'FACC','BFRR',blocks=1)
if mode=='bfsb2quick':
 items=[small[13]]+[('bfsb_'+str(r),r,128,'bfloat16') for r in [160,161,4759,4760,4761,9521]]
 check('bfsb2_check',items,['FACC','BFSB2'])
 pairs('bfsb2_pairs',[('b128large',524288,128,'bfloat16')],'FACC','BFSB2',blocks=1)

if mode=='pair2quick':
 items=[('split_one',1,32768,'float16'),('split_two',2,16384,'float16'),small[4],('sync2_8448',3,8448,'float16'),('sync2_24576',20,24576,'float16'),('sync2_fallback',21,32768,'float16')]
 check('pair2_check',items,['FACC','PAIR2','SYNC2'])
 for v in ['PAIR2','SYNC2']:
  pairs(v.lower()+'_pairs',[small[4],items[0],items[1]],'FACC',v,blocks=1)
if mode=='pair2edge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='pair2_edge_'+pattern;case(cid,8,32768,'float16',pattern);items.append((cid,8,32768,'float16'))
 check('pair2_edge_check',items,['FACC','PAIR2','SYNC2'])

if mode=='bsbcquick':
 items=[small[13]]+[('bfsb_'+str(r),r,128,'bfloat16') for r in [160,4761]]
 check('bsbc_check',items,['FACC','BFSB2','BSBC16','BSBC24','BSBC32'])
 for v in ['BSBC16','BSBC24','BSBC32']:
  pairs(v.lower()+'_pairs',[('b128large',524288,128,'bfloat16')],'BFSB2',v,blocks=1)
if mode=='bfsb2confirm':
 pairs('bfsb2_confirm_pairs',[('b128large',524288,128,'bfloat16')],'FACC','BFSB2',blocks=2)

if mode=='pairaccquick':
 items=[('split_one',1,32768,'float16'),('split_two',2,16384,'float16'),small[4],('sync2_8448',3,8448,'float16'),('sync2_24576',20,24576,'float16'),('sync2_fallback',21,32768,'float16')]
 check('pairacc_check',items,['FACC','PAIRACC'])
 pairs('pairacc_pairs',[small[4],items[0],items[1]],'FACC','PAIRACC',blocks=1)
if mode=='pairaccedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='pair2_edge_'+pattern;case(cid,8,32768,'float16',pattern);items.append((cid,8,32768,'float16'))
 check('pairacc_edge_check',items,['FACC','PAIRACC'])
if mode=='pairsinglequick':
 items=[('pairsingle_'+str(r)+'_'+str(d),r,d,'float16') for r,d in [(1,16384),(1,24576),(1,32768),(2,24576),(2,32768),(4,32768)]]
 check('pairsingle_check',items,['FACC','PAIRACC'])
 pairs('pairsingle_pairs',items,'FACC','PAIRACC',blocks=1)

if mode=='pairasyncquick':
 items=[('split_one',1,32768,'float16'),('pairsingle_1_16384',1,16384,'float16'),('pairsingle_1_24576',1,24576,'float16'),small[4],('split_two',2,16384,'float16'),('sync2_8448',3,8448,'float16'),('sync2_24576',20,24576,'float16'),('sync2_fallback',21,32768,'float16')]
 check('pairasync_check',items,['FACC','PAIRSINGLE','PAIRASY'])
 pairs('pairasync_pairs',[items[0],items[1],items[2],small[4]],'PAIRACC','PAIRASY',blocks=1)
if mode=='pairasyncedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  for r in [1,8]:
   cid='pairasync_edge_'+str(r)+'_'+pattern;case(cid,r,32768,'float16',pattern);items.append((cid,r,32768,'float16'))
 check('pairasync_edge_check',items,['FACC','PAIRSINGLE','PAIRASY'])
if mode=='pairsingleboundary':
 items=[('pairbound_'+str(d),1,d,'float16') for d in [8192,8193,8320,8448,12288,16256,16512,24575,24576,32640,32768]]
 check('pairsingle_boundary_check',items,['FACC','PAIRSINGLE','PAIRASY'])
 pairs('pairsingle_confirm_pairs', [('pairsingle_1_16384',1,16384,'float16'),('pairsingle_1_24576',1,24576,'float16'),('pairsingle_1_32768',1,32768,'float16')],'FACC','PAIRSINGLE',blocks=2)

if mode=='singleasyquick':
 items=[('pairsingle_1_16384',1,16384,'float16'),('pairsingle_1_24576',1,24576,'float16'),('pairsingle_1_32768',1,32768,'float16')]+[small[i] for i in [0,3,4,10,13,14]]
 check('singleasy_check',items,['FACC','SINGLEASY'])
 pairs('singleasy_pairs',items[:3],'FACC','SINGLEASY',blocks=2)

if mode=='pairtailquick':
 items=[('pairtail_'+str(r)+'_'+str(d),r,d,'float16') for r,d in [(1,8193),(2,8449),(3,16383),(2,16513),(1,24575),(4,24577),(1,32767),(2,32767),(4,32767),(8,32767),(20,32767),(21,32767)]]
 check('pairtail_check',items,['FACC','PAIRTAIL'])
 pairs('pairtail_pairs',[items[i] for i in [0,2,4,6,7,8,9]],'FACC','PAIRTAIL',blocks=1)
if mode=='pairtailedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  for r,d in [(1,16383),(3,32767)]:
   cid='pairtail_edge_'+str(r)+'_'+str(d)+'_'+pattern;case(cid,r,d,'float16',pattern);items.append((cid,r,d,'float16'))
 check('pairtail_edge_check',items,['FACC','PAIRTAIL'])
if mode=='pairasymultiquick':
 items=[('pairasy_multi_'+str(r)+'_'+str(d),r,d,'float16') for r,d in [(2,16384),(2,24576),(2,32768),(4,32768),(8,32768),(16,32768),(20,32768)]]
 check('pairasy_multi_check',items,['FACC','PAIRASY'])
 pairs('pairasy_multi_pairs',items,'FACC','PAIRASY',blocks=1)

if mode=='hsm63quick':
 items=[('hsm63_'+str(r)+'_'+str(d),r,d,'float16') for r,d in [(1280,193),(1281,193),(1313,193),(2047,193),(2519,193),(2520,256),(2521,256),(2047,65),(2047,192),(2047,255)]]
 check('hsm63_check',items,['FACC','HSM63'])
 pairs('hsm63_pairs',[items[i] for i in [2,3,5,8]],'FACC','HSM63',blocks=1)
if mode=='hsm63edge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='hsm63_edge_'+pattern;case(cid,2047,193,'float16',pattern);items.append((cid,2047,193,'float16'))
 check('hsm63_edge_check',items,['FACC','HSM63'])

if mode=='bffullquick':
 pairs('bffull14_pairs',[('bffull14',3317760,128,'bfloat16')],'FACC','BFSB2',blocks=1)
 for group,cand in [('bffull15_db_pairs','BFDB8'),('bffull15_inv_pairs','BFINV'),('bffull15_rr_pairs','BFRR')]:
  pairs(group,[('bffull15',117760,8192,'bfloat16')],'FACC',cand,blocks=1)
if mode=='bffulldiag':
 for cid in ['bffull14','bffull15']:
  core.run_case(OUT/'bffull_op'/cid,cid,'FACC',dict(warmup=11,repeats=1,batch=5,timing='host'),'op')
 core.save(OUT/'bffull_op'/'complete.json',dict(cases=2))

if mode=='sched1quick':
 check('sched1_check',small,['FACC','SCHED1'])
 pairs('sched1_pairs',[small[i] for i in [0,1,3,4,10,13]],'FACC','SCHED1',blocks=1)
if mode=='bfvquick':
 items=[('bfv_'+str(r)+'_'+str(d),r,d,'bfloat16') for r,d in [(1279,128),(1280,128),(1281,128),(3841,128),(1280,8192),(1281,8192),(161,8192)]]
 check('bfv_check',items,['FACC','BFV80','BFV160'])
if mode=='bfvfull':
 for v in ['BFV80','BFV160']:
  for i,r,d in [(14,3317760,128),(15,117760,8192)]:
   group=v.lower()+'_full'+str(i)+'_pairs';target=Path('/home/developer/addrms_archived/E026')/group
   target.mkdir(exist_ok=True);link=OUT/group
   if link.exists():assert link.is_symlink() and link.resolve()==target.resolve()
   else:link.symlink_to(target,target_is_directory=True)
   pairs(group,[('bffull'+str(i),r,d,'bfloat16')],'FACC',v,blocks=1)
