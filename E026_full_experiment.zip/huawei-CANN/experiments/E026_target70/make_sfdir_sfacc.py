from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'FACC/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class SmallRowsStaticKernel {');z=base.index('// Many whole rows use manual ping/pong',a)
part=base[a:z]
old='''        SetFlag<HardEvent::MTE2_V>(0);
        WaitFlag<HardEvent::MTE2_V>(0);
        if (sizeof(T) == sizeof(float)) {
            gf_ = g_.template ReinterpretCast<float>();
            bf_ = b_.template ReinterpretCast<float>();
        } else {
            ToFloat<T>(gf_, g_, d_);
            ToFloat<T>(bf_, b_, d_);
        }
        PipeBarrier<PIPE_V>();'''
new='''        if (sizeof(T) == sizeof(float)) {
            // First row's input event covers the preceding parameter DMA.
            gf_ = g_.template ReinterpretCast<float>();
            bf_ = b_.template ReinterpretCast<float>();
        } else {
            SetFlag<HardEvent::MTE2_V>(0);WaitFlag<HardEvent::MTE2_V>(0);
            ToFloat<T>(gf_, g_, d_);ToFloat<T>(bf_, b_, d_);PipeBarrier<PIPE_V>();
        }'''
assert part.count(old)==1;part=part.replace(old,new)
st=part.index('        if (sizeof(T) == sizeof(float) && d_ == padded_) {')
en=part.index('        Mul(tmp_, y_, y_, padded_);',st)
part=part[:st]+'''        if(d_!=padded_) {
            Duplicate(y_[d_/64*64],0.0f,64);PipeBarrier<PIPE_V>();
        }
        if(sizeof(T)==sizeof(float)) {
            Add(y_,x_.template ReinterpretCast<float>(),r_.template ReinterpretCast<float>(),d_);
            PipeBarrier<PIPE_V>();
        } else {
            ToFloat<T>(y_,x_,d_);ToFloat<T>(tmp_,r_,d_);PipeBarrier<PIPE_V>();
            Add(y_,y_,tmp_,d_);PipeBarrier<PIPE_V>();
        }
'''+part[en:]
old='''            // VECIN (aligned) and VECOUT (unaligned) are both A2 DMA sources.
            // Retain the baseline's final FP32 Adds(+0) conversion.
            Adds(y_, y_, 0.0f, d_);
            PipeBarrier<PIPE_V>();
'''
assert part.count(old)==1;part=part.replace(old,'')
for name,reduce in [('SFDIR',False),('SFACC',True)]:
 inc=part
 if reduce:
  st=inc.index('        // A2 ReduceSum(count) is not supported')
  en=inc.index('        Muls(sum_, sum_, invD_',st)
  inc=inc[:st]+'''        if(sizeof(T)==sizeof(float)) {
            Duplicate(work_,0.0f,64);PipeBarrier<PIPE_V>();
            Add(work_,tmp_,work_,64,parts,{1,1,1,0,8,0});PipeBarrier<PIPE_V>();
            WholeReduceSum(sum_,work_,64,1,1,1,8);
        } else {
            WholeReduceSum(partials_,tmp_,64,parts,1,1,8);PipeBarrier<PIPE_V>();
            WholeReduceSum(sum_,partials_,parts,1,1,1,8);
        }
        PipeBarrier<PIPE_V>();
'''+inc[en:]
 code=base[:a]+inc+base[z:]
 dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
 sha=hashlib.sha256(code.encode()).hexdigest()
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='FACC',source_sha256=sha,
  change='Small static rows: first input event covers FP32 parameter DMA, direct float residual Add and direct output'+('; float lane accumulation replaces two-stage WR' if reduce else ''),numerical_change=reduce),indent=2)+'\n')
 print(name,sha)
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='sfdirquick'" not in s:
 s+='''
if mode=='sfdirquick':
 items=[small[1]]+[('sfdir_'+str(d),7,d,'float32') for d in [64,65,128,255,512,1025,2048,4095,4096]]
 check('sfdir_check',items,['FACC','SFDIR','SFACC'])
 for v in ['SFDIR','SFACC']:
  pairs(v.lower()+'_pairs',[small[1]],'FACC',v,blocks=2)
if mode=='sfdir edge':
 pass
if mode=='sfdiredge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='sfdir_edge_'+pattern;case(cid,7,197,'float32',pattern)
  items.append((cid,7,197,'float32'))
 check('sfdir_edge_check',items,['FACC','SFDIR','SFACC'])
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_sfdir.tar.gz','w:gz') as t:
 for q in [H/'SFDIR',H/'SFACC',p]:t.add(q,arcname=q.relative_to(H.parents[1]))
