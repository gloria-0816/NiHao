from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent;base=(H/'COMBO2/code/kernel.asc').read_text()
a=base.index('__global__ __vector__ void single_row_64_custom');z=base.index('template <typename T>\n__global__ __vector__ void add_rms_norm_bias_custom',a);s=base[a:z]
s=s.replace('''        ToFloat<T>(gf, gt, 64);
        ToFloat<T>(bf, bt, 64);''','''        if(!CompactParameterType<T>::value) {
            ToFloat<T>(gf,gt,64);ToFloat<T>(bf,bt,64);
        }''',1)
old='''    Mul(y, y, gf, 64);
    PipeBarrier<PIPE_V>();
    Add(y, y, bf, 64);
    PipeBarrier<PIPE_V>();'''
new='''    if(!CompactParameterType<T>::value) {
        Mul(y,y,gf,64);PipeBarrier<PIPE_V>();
        Add(y,y,bf,64);PipeBarrier<PIPE_V>();
    }'''
assert old in s;s=s.replace(old,new,1)
anchor='''        FromFloat<T>(result, y, 64);
        PipeBarrier<PIPE_V>();'''
assert anchor in s;s=s.replace(anchor,anchor+'''
        if(CompactParameterType<T>::value) {
            FusedMulAdd(result,gt,bt,64);PipeBarrier<PIPE_V>();
        }''',1)
code=base[:a]+s+base[z:]
a=code.index('class StaticHalfRowsKernel {');z=code.index('__global__ __vector__ void static_half_rows_custom',a);s=code[a:z]
old='''        ToFloat<half>(gamma_,gh_,d_); ToFloat<half>(bias_,bh_,d_);
'''
assert old in s;s=s.replace(old,'',1)
ia=s.index('        for(uint32_t col=0;col<d_;col+=64) {',s.index('const uint8_t rb'))
ia=s.index('        for(uint32_t col=0;col<d_;col+=64) {',ia+10)
iz=s.index('        FromFloat<half>(r_,y_,active);',ia)
s=s[:ia]+s[iz:]
anchor='        FromFloat<half>(r_,y_,active); PipeBarrier<PIPE_V>();'
assert anchor in s;s=s.replace(anchor,anchor+'''
        for(uint32_t col=0;col<d_;col+=128) {
            const uint64_t mask=d_-col<128?d_-col:128;
            FusedMulAdd(r_[col],gh_[col],bh_[col],mask,repeats,
                {1,1,1,static_cast<uint8_t>(stride_/16),0,0});
        }
        PipeBarrier<PIPE_V>();''',1)
code=code[:a]+s+code[z:]
name='SMALLAFF';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'COMBO2','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'FP16 output affine fusion for single D64 and static short rows; FP32 residual sum and norm retained','numerical_change':True},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='smallaffquick'" not in s:
 s+='''
if mode=='smallaffquick':
 check('smallaff_check',[small[0],small[3],('m64_float',1,64,'float32'),('m64_bf16',1,64,'bfloat16'),('flath_65',767,65,'float16'),('flath_255',767,255,'float16')],['COMBO2','SMALLAFF'])
 pairs('smallaff_pairs',[small[0],small[3]],'COMBO2','SMALLAFF',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
