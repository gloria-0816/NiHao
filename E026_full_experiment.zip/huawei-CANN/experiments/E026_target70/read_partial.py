from pathlib import Path
import json,sys,statistics
O=Path('/mnt/workspace/addrms_results/E026')
for group in sys.argv[1:]:
 p=O/group/'records.json'
 if not p.exists():print(group,'not started');continue
 rr=json.loads(p.read_text());out={}
 for r in rr:
  if 'median_us' in r:out.setdefault(r['case_id'],{}).setdefault(r['variant'],[]).append(r['median_us'])
 print(group,json.dumps(out))
