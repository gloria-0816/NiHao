from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent;base=(H/'COMBO1/code/kernel.asc').read_text()
a=base.index('class TinyBatchFloatKernel {');z=base.index('__global__ __vector__ void tiny_batch_float_custom',a)
inc=base[a:z].replace('TinyBatchFloatKernel','ShortFloatPartitionKernel')
inc=inc.replace('0, 2048','0, 8192').replace('8320, 2048','32896, 8192').replace('16640, 512','65792, 512').replace('19328, 512','67968, 512').replace('21504, 256','70144, 1024').replace('22528, 8','74368, 64')
inc=inc.replace('Duplicate(sums_, 1.0f, 8);','Duplicate(sums_, 1.0f, (count_+7)/8*8);')
inc=inc.replace('Muls(sums_, sums_, invD_, 8);','Muls(sums_, sums_, invD_, count_);').replace('Adds(sums_, sums_, eps_, 8);','Adds(sums_, sums_, eps_, count_);').replace('Sqrt(sums_, sums_, 8);','Sqrt(sums_, sums_, count_);').replace('Duplicate(work_, 1.0f, 8);','Duplicate(work_, 1.0f, count_);').replace('Div(sums_, work_, sums_, 8);','Div(sums_, work_, sums_, count_);').replace('Brcb(work_, sums_, 1, {1, 8});','Brcb(work_, sums_, (count_+7)/8, {1, 8});')
inc+='''__global__ __vector__ void short_float_partition_custom(GM_ADDR x,GM_ADDR r,GM_ADDR g,GM_ADDR b,GM_ADDR out,
    uint64_t rows,uint32_t d,float invD,float eps)
{
    InitSocState();ShortFloatPartitionKernel op;op.Init(x,r,g,b,out,rows,d,invD,eps);op.Process();
}
'''
(H/'short_float.inc').write_text(inc,encoding='utf-8',newline='\n')
for cores in (8,16,32):
 code=base.replace('class TinyBatchFloatKernel {',inc+'\nclass TinyBatchFloatKernel {',1)
 launch=f'''    const uint32_t shortFloatCores=blockNum<{cores}?blockNum:{cores};
    if(input.dtype==0 && d<=512 && rows>=static_cast<uint64_t>(blockNum)*2 &&
        rows<=static_cast<uint64_t>(shortFloatCores)*(8192/((d+63)/64*64))) {{
        short_float_partition_custom<<<shortFloatCores,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }}
'''
 anchor='    if (input.dtype == 0 && rows >= static_cast<uint64_t>(blockNum) * 2'
 assert anchor in code;code=code.replace(anchor,launch+anchor,1)
 name=f'SHORT{cores}';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
 (H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'COMBO1','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'short_cores':cores,'ub_end_bytes':74624},indent=2)+'\n')
 print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='shortquick'" not in s:
 s+='''
if mode=='shortquick':
 check('short_check',[small[2],('shortf_512',257,512,'float32'),('shortf_193',161,193,'float32')],['COMBO1','SHORT8','SHORT16','SHORT32'])
 for v in ['SHORT8','SHORT16','SHORT32']:
  pairs(v.lower()+'_pairs',[small[2]],'COMBO1',v,blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
