from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent;code=(H/'BROAD2/code/kernel.asc').read_text(encoding='utf-8')
code=code.replace('class StaticHalfRowsKernel {',(H/'long_half_retained.inc').read_text(encoding='utf-8')+'\nclass StaticHalfRowsKernel {',1)
anchor='    if (d > limit && d <= 32768) {'
assert code.count(anchor)==1
launch='''    if(input.dtype==1 && d>8192 && d<=32768) {
        long_half_retained_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
code=code.replace(anchor,launch+anchor,1)
name='LONGH';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BROAD2',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='Long FP16 rows retain native half residual; FP32 square/norm reduction, 8192-element double-buffer input and half normalization/FMA',numerical_change=True,ub_end_bytes=169632),indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='longhquick'" not in s:
 s+='''
if mode=='longhquick':
 items=[small[4],('longh_8193',3,8193,'float16'),('longh_16384',41,16384,'float16'),('longh_24576',3,24576,'float16')]
 check('longh_check',items,['BROAD2','LONGH'])
 pairs('longh_pairs',[small[4],items[2]],'BROAD2','LONGH',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_longh.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
