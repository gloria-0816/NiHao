from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'BFSIP/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('    __aicore__ inline void ComputeWholeRow(');z=base.index('    __aicore__ inline float ComputeInvRms(',a)
s=base[a:z]
old='''        Brcb(work, scalar, 1, {1, 8});
        PipeBarrier<PIPE_V>();
        Div(y, y, work, static_cast<uint64_t>(64), static_cast<uint8_t>(padded / 64),
            {1, 1, 0, 8, 8, 0});'''
new='''        if(SingleSlotWholePrefetchType<T>::value) {
            // One FP32 reciprocal division per row replaces a full row Div.
            Duplicate(work,1.0f,8);PipeBarrier<PIPE_V>();
            Div(scalar,work,scalar,1);PipeBarrier<PIPE_V>();
            Brcb(work,scalar,1,{1,8});PipeBarrier<PIPE_V>();
            Mul(y,y,work,static_cast<uint64_t>(64),static_cast<uint8_t>(padded/64),{1,1,0,8,8,0});
        } else {
            Brcb(work,scalar,1,{1,8});PipeBarrier<PIPE_V>();
            Div(y,y,work,static_cast<uint64_t>(64),static_cast<uint8_t>(padded/64),{1,1,0,8,8,0});
        }'''
assert s.count(old)==1;s=s.replace(old,new);code=base[:a]+s+base[z:]
name='BFINV';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFSIP',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='BF16 generic whole-row normalization replaces vector Div with one FP32 reciprocal Div then broadcast Mul, retaining Sqrt, queues, reduction and separate affine Mul/Add',numerical_change=True),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='bfinvquick'" not in s:
 s+='''
if mode=='bfinvquick':
 items=[small[14]]+[('bfa8_'+str(d),161,d,'bfloat16') for d in [4097,6144,8191]]
 check('bfinv_check',items,['BFSIP','BFINV'])
 pairs('bfinv_pairs',[small[14]],'BFSIP','BFINV',blocks=1)
if mode=='bfinvedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='bfinv_'+pattern;case(cid,161,8192,'bfloat16',pattern);items.append((cid,161,8192,'bfloat16'))
 check('bfinv_edge',items,['BFSIP','BFINV'])
if mode=='bfinvlarge':
 items=[('bf8_large',8192,8192,'bfloat16')]
 check('bfinv_large_check',items,['BFSIP','BFINV'])
 pairs('bfinv_large_pairs',items,'BFSIP','BFINV',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_bfinv.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
