from pathlib import Path
import tarfile,json,hashlib
root=Path('/mnt/workspace/addrms_results/E026');target=root.parent/'E026_evidence.tar.gz'
paths=[p for p in root.rglob('*') if p.is_file() and p.suffix in {'.json','.csv','.log','.txt'}]
manifest=[]
with tarfile.open(target,'w:gz') as archive:
 for path in sorted(paths):
  relative=path.relative_to(root);archive.add(path,arcname=str(relative))
  manifest.append({'path':str(relative),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(root.parent/'E026_evidence_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(paths),'bytes':target.stat().st_size,'archive':str(target)}))
