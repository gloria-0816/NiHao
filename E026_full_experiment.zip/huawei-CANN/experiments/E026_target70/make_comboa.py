from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent
code=(H/'COMBO3/code/kernel.asc').read_text()
aff=(H/'HALFAFF2/code/kernel.asc').read_text()
a=code.index('class PipelineBatch9Kernel {');z=code.index('template <typename T,bool BlockReduction>',a)
b=aff.index('class PipelineBatch9Kernel {');e=aff.index('template <typename T,bool BlockReduction>',b)
code=code[:a]+aff[b:e]+code[z:]
# Restrict the recast capacity optimization to its measured D512 domain.
# Keep that kernel's FP32 affine until an independently tested native variant.
short=(H/'SHORTADD/code/kernel.asc').read_text()
a=code.index('class StaticHalfRowsKernel {');z=code.index('__global__ __vector__ void static_half_rows_custom',a)
b=short.index('class StaticHalfRowsKernel {');e=short.index('__global__ __vector__ void static_half_rows_custom',b)
code=code[:a]+short[b:e]+code[z:]
single=(H/'SINGLEOV/code/kernel.asc').read_text()
a=code.index('__global__ __vector__ void single_row_64_custom');z=code.index('template <typename T>\n__global__ __vector__ void single_row_custom',a)
b=single.index('__global__ __vector__ void single_row_64_custom');e=single.index('template <typename T>\n__global__ __vector__ void single_row_custom',b)
code=code[:a]+single[b:e]+code[z:]
split=(H/'SPLITAFF/code/kernel.asc').read_text()
a=split.index('template <typename T>\n__schedmode__(1) __global__ __mix__(0,1) void split_long_custom');z=split.index('class StaticHalfRowsKernel {',a)
code=code.replace('class StaticHalfRowsKernel {',split[a:z]+'\nclass StaticHalfRowsKernel {',1)
a=split.index('    if(input.dtype==1 && d>8192 && d<=32768 && rows<=');z=split.index('    if (input.dtype == 1 && d <= 256',a)
anchor='    if((input.dtype==1 || input.dtype==2) && d>8192 && d<=32768 && d%4096==0) {'
assert anchor in code;code=code.replace(anchor,split[a:z]+anchor,1)
name='COMBOA';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'HALFAFF2','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'merge FP32 static batch, recast D512, short native add, single overlap, split long FP16 and retained vertical sum','merged':['COMBO3','HALFAFF2','SHORTADD','SINGLEOV','SPLITAFF']},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='comboaquick'" not in s:
 s+='''
if mode=='comboaquick':
 check('comboa_check',small,['HALFAFF2','COMBOA'])
 pairs('comboa_pairs',[small[i] for i in [0,3,4,7,10,12]],'HALFAFF2','COMBOA',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
