from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent;base=(H/'COMBO2/code/kernel.asc').read_text()
a=base.index('class PipelineBatch9Kernel {');z=base.index('template <typename T,bool BlockReduction>',a);s=base[a:z]
old='        ToFloat<T>(gamma_,gh_,d_); ToFloat<T>(bias_,bh_,d_);'
new='        if(!CompactParameterType<T>::value){ToFloat<T>(gamma_,gh_,d_);ToFloat<T>(bias_,bh_,d_);}'
assert old in s;s=s.replace(old,new,1)
old='''                for(uint32_t i=0;i<count;++i)
                    FusedMulAdd(y_[i*stride_],gamma_,bias_,d_);'''
new='''                if(!CompactParameterType<T>::value)
                    for(uint32_t i=0;i<count;++i)FusedMulAdd(y_[i*stride_],gamma_,bias_,d_);'''
assert old in s;s=s.replace(old,new,1)
old='''                for(uint32_t col=0;col<d_;col+=64)
                    FusedMulAdd(y_[col],gamma_[col],bias_[col],Min(64,d_-col),count,{1,1,1,step,0,0});'''
new='''                if(!CompactParameterType<T>::value)
                    for(uint32_t col=0;col<d_;col+=64)
                        FusedMulAdd(y_[col],gamma_[col],bias_[col],Min(64,d_-col),count,{1,1,1,step,0,0});'''
assert old in s;s=s.replace(old,new,1)
anchor='            FromFloat<T>(out_,y_,active); PipeBarrier<PIPE_V>();'
extra='''
            if(CompactParameterType<T>::value) {
                const uint32_t halfParts=(d_+127)/128;
                if(count<=halfParts) {
                    for(uint32_t i=0;i<count;++i)FusedMulAdd(out_[i*stride_],gh_,bh_,d_);
                } else {
                    for(uint32_t col=0;col<d_;col+=128)
                        FusedMulAdd(out_[col],gh_[col],bh_[col],Min(128,d_-col),count,
                            {1,1,1,static_cast<uint8_t>(stride_/16),0,0});
                }
                PipeBarrier<PIPE_V>();
            }'''
assert anchor in s;s=s.replace(anchor,anchor+extra,1)
code=base[:a]+s+base[z:];name='HALFAFF';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'COMBO2','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'FP16 affine FMA after FP32 RMS normalization; retains FP32 reduction','numerical_change':True},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='halfaffquick'" not in s:
 s+='''
if mode=='halfaffquick':
 check('halfaff_check',[small[i] for i in [5,6,7,9,13]],['COMBO2','HALFAFF'])
 pairs('halfaff_pairs',[small[i] for i in [5,6,7,9]],'COMBO2','HALFAFF',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
