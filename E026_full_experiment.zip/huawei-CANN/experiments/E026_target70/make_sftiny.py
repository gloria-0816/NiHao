from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'SFACC/code/kernel.asc').read_text(encoding='utf-8')
single=(H/'HSFAST2/code/kernel.asc').read_text(encoding='utf-8')
a=single.index('__global__ __vector__ void half_single_fast_custom');z=single.index('class FloatBroadTripleKernel {',a)
part=single[a:z]
code=base.replace('class FloatBroadTripleKernel {',part+'\nclass FloatBroadTripleKernel {',1)
anchor='    if (rows == 1 && d == 64) {'
assert code.count(anchor)==1
code=code.replace(anchor,'''    if(input.dtype==1 && rows==1 && d==64) {
        half_single_fast_custom<<<1,nullptr,stream>>>(x,residual,gamma,bias,output,epsilon);
        return;
    }
'''+anchor)
a=code.index('class SmallRowsStaticKernel {');z=code.index('// Many whole rows use manual ping/pong',a)
part=code[a:z]
old='''        } else {
            WholeReduceSum(partials_,tmp_,64,parts,1,1,8);PipeBarrier<PIPE_V>();
            WholeReduceSum(sum_,partials_,parts,1,1,1,8);
        }'''
new='''        } else if(parts==1) {
            WholeReduceSum(sum_,tmp_,64,1,1,1,8);
        } else {
            WholeReduceSum(partials_,tmp_,64,parts,1,1,8);PipeBarrier<PIPE_V>();
            WholeReduceSum(sum_,partials_,parts,1,1,1,8);
        }'''
assert part.count(old)==1;part=part.replace(old,new)
old='''        SetFlag<HardEvent::MTE3_MTE2>(3);
        WaitFlag<HardEvent::MTE3_MTE2>(3);'''
new='''        if(sizeof(T)!=sizeof(float)) {
            SetFlag<HardEvent::MTE3_MTE2>(3);WaitFlag<HardEvent::MTE3_MTE2>(3);
        }'''
assert part.count(old)==1;part=part.replace(old,new)
code=code[:a]+part+code[z:]
name='SFTINY';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
sha=hashlib.sha256(code.encode()).hexdigest()
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='SFACC',source_sha256=sha,
 change='Integrate verified HSFAST2 single FP16 D64 into small FP32 direct/lane sum candidate; retain low dtype one-part reduction and skip MTE3_MTE2 only when output uses independent float Y',numerical_change=True),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='sftinyquick'" not in s:
 s+='''
if mode=='sftinyquick':
 items=[small[i] for i in [0,1]]+[('m64_float',1,64,'float32'),('m64_bf16',1,64,'bfloat16'),('sftiny_h64',2,64,'float16'),('sftiny_h193',7,193,'float16'),('sfdir_4095',7,4095,'float32')]
 check('sftiny_check',items,['FACC','SFTINY'])
 pairs('sftiny_pairs',[small[i] for i in [0,1]],'FACC','SFTINY',blocks=2)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_sftiny.tar.gz','w:gz') as t:
 for q in [H/name,p]:t.add(q,arcname=q.relative_to(H.parents[1]))
print(name,sha)
