from pathlib import Path
import hashlib, json, shutil, tarfile
H = Path(__file__).resolve().parent
code = (H / 'BROAD1/code/kernel.asc').read_text(encoding='utf-8')
launch = '''    if(input.dtype==2 && d>4096 && d<=8192 && rows>=static_cast<uint64_t>(blockNum)*4) {
        bf_static8_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert code.count(launch) == 1
code = code.replace(launch, '')
dest = H / 'BROAD2/code'
shutil.copytree(H / 'BASE/code', dest, dirs_exist_ok=True)
(dest / 'kernel.asc').write_text(code, encoding='utf-8', newline='\n')
digest = hashlib.sha256(code.encode()).hexdigest()
(H / 'BROAD2/manifest.json').write_text(json.dumps(dict(variant='BROAD2', parent='HALFAFF2', source_sha256=digest, merged=['FPBROAD', 'HALFWIDE', 'SINGLEOV'], change='Broader FP32 triple-buffer and FP16 pipeline routes with D64 DMA overlap; retain baseline BF16 route because BFS8 showed no gain'), indent=2)+'\n', encoding='utf-8')
p = H / 'run_round.py'
s = p.read_text(encoding='utf-8')
if "mode=='broad2quick'" not in s:
    s += '''
if mode=='broad2quick':
 check('broad2_check',small+[('halfwide_1536',257,1536,'float16'),('halfwide_4095',257,4095,'float16'),('fpbroad_4095',257,4095,'float32')],['HALFAFF2','BROAD2'])
 pairs('broad2_pairs',[small[10],small[12]],'HALFAFF2','BROAD2',blocks=1)
'''
    p.write_text(s, encoding='utf-8', newline='\n')
root = H.parents[1]
with tarfile.open(H / 'upload_bank_broad2.tar.gz', 'w:gz') as tar:
    for target in [H/'BANKH', H/'BROAD2', p]:
        tar.add(target, arcname=target.relative_to(root))
print('BROAD2', digest)
