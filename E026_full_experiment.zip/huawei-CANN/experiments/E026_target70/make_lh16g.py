from pathlib import Path
import hashlib, json, shutil, tarfile

H=Path(__file__).resolve().parent
base=(H/'BFSIP/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class LongHalfRetainedKernel {');z=base.index('class HalfSharedResidualKernel {',a)
s=base[a:z]
start=s.index('                Cast(tmp_,y_[col]');end=s.index('\n            }\n            WholeReduceSum(sum_',start)
original=s[start:end]
fast='''                // Keep the row in half; convert only the reduction results.
                // Bound each 128-element half sum before choosing this path.
                const uint32_t paddedH=(n+127)/128*128,partsH=paddedH/128;
                auto halfTmp=tmp_.ReinterpretCast<half>();
                auto halfParts=halfTmp[8192];auto halfMax=halfTmp[8320];
                Abs(halfTmp,y_[col],n);PipeBarrier<PIPE_V>();
                if(n!=paddedH) {
                    const uint32_t tailPos=n%128;
                    uint64_t tailH[2]={tailPos<64?(~static_cast<uint64_t>(0)<<tailPos):0,
                        tailPos<64?~static_cast<uint64_t>(0):(~static_cast<uint64_t>(0)<<(tailPos-64))};
                    Duplicate(halfTmp[n/128*128],static_cast<half>(0),tailH,1,1,8);PipeBarrier<PIPE_V>();
                }
                WholeReduceMax(halfParts,halfTmp,128,partsH,1,1,8);PipeBarrier<PIPE_V>();
                WholeReduceMax(halfMax,halfParts,partsH,1,1,1,8);PipeBarrier<PIPE_V>();
                SetFlag<HardEvent::V_S>(3);WaitFlag<HardEvent::V_S>(3);
                const float maximum=static_cast<float>(halfMax.GetValue(0));
                SetFlag<HardEvent::S_V>(3);WaitFlag<HardEvent::S_V>(3);
                if(maximum<=16.0f) {
                    Mul(halfTmp,y_[col],y_[col],n);PipeBarrier<PIPE_V>();
                    if(n!=paddedH) {
                        const uint32_t tailPos=n%128;
                        uint64_t tailH[2]={tailPos<64?(~static_cast<uint64_t>(0)<<tailPos):0,
                            tailPos<64?~static_cast<uint64_t>(0):(~static_cast<uint64_t>(0)<<(tailPos-64))};
                        Duplicate(halfTmp[n/128*128],static_cast<half>(0),tailH,1,1,8);PipeBarrier<PIPE_V>();
                    }
                    WholeReduceSum(halfParts,halfTmp,128,partsH,1,1,8);PipeBarrier<PIPE_V>();
                    Cast(work_,halfParts,RoundMode::CAST_NONE,partsH);PipeBarrier<PIPE_V>();
                    WholeReduceSum(partial_[c*8],work_,partsH,1,1,1,8);PipeBarrier<PIPE_V>();
                } else {
'''+original+'''
                }'''
s=s[:start]+fast+s[end:]
code=base[:a]+s+base[z:]
dest=H/'LH16G/code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
sha=hashlib.sha256(code.encode()).hexdigest()
(H/'LH16G/manifest.json').write_text(json.dumps(dict(variant='LH16G',parent='BFSIP',source_sha256=sha,
    change='FP16 retained long rows: bound chunk absolute max<=16, square and first 128-value sum in half, cast only partials to FP32; larger/nonfinite max falls back to original FP32 square/reduction',
    numerical_change=True,static_ub_end=169632),indent=2)+'\n')
p=H/'run_round.py';q=p.read_text(encoding='utf-8')
if "mode=='lh16gquick'" not in q:
 q+='''
if mode=='lh16gquick':
 items=[small[4]]+[('lh16g_'+str(d),3,d,'float16') for d in [8193,8448,16384,24576,32767]]
 check('lh16g_check',items,['BFSIP','LH16G'])
 pairs('lh16g_pairs',[small[4],items[3]],'BFSIP','LH16G',blocks=1)
if mode=='lh16gedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='lh16g_edge_'+pattern;case(cid,3,32768,'float16',pattern)
  items.append((cid,3,32768,'float16'))
 check('lh16g_edge_check',items,['BFSIP','LH16G'])
'''
 p.write_text(q,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_lh16g.tar.gz','w:gz') as tar:
 for target in [H/'LH16G',p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(sha)
