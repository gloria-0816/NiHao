from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'HSHORTN/code/kernel.asc').read_text(encoding='utf-8')
long=(H/'LONGH2/code/kernel.asc').read_text(encoding='utf-8')
a=long.index('class LongHalfRetainedKernel {');z=long.index('class StaticHalfRowsKernel {',a)
code=base.replace('class StaticHalfRowsKernel {',long[a:z]+'class StaticHalfRowsKernel {',1)
launch='''    if(input.dtype==1 && d>8192 && d<=32768) {
        long_half_retained_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
anchor='    if (d > limit && d <= 32768) {'
assert code.count(anchor)==1;code=code.replace(anchor,launch+anchor)
name='BROAD3';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BROAD2',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='Merge independently measured HSHORTN and corrected LONGH2; preserve BROAD2 other routes',merged=['HSHORTN','LONGH2'],numerical_change=True),indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='broad3quick'" not in s:
 s+='''
if mode=='broad3quick':
 check('broad3_check',small+[('longh_8193',3,8193,'float16')],['BROAD2','BROAD3'])
 pairs('broad3_pairs',[small[3],small[4]],'BROAD2','BROAD3',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_broad3.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
