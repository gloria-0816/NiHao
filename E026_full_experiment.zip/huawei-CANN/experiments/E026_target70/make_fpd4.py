from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'BFP3/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class FloatBroadTripleKernel {');z=base.index('__global__ __vector__ void float_broad_triple_custom',a)
s=base[a:z].replace('FloatBroadTripleKernel','FloatDoubleResidualKernel').replace('batch_=12288/stride_','batch_=9600/stride_')
init='''        x_[0]=LocalTensor<float>(TPosition::VECIN,0,12288);
        x_[1]=LocalTensor<float>(TPosition::VECIN,49280,12288);
        r_=LocalTensor<float>(TPosition::VECIN,98560,12288);
        gf_=LocalTensor<float>(TPosition::VECIN,147840,4096);
        bf_=LocalTensor<float>(TPosition::VECIN,164352,4096);
        work_=LocalTensor<float>(TPosition::VECCALC,180864,1536);
        sums_=LocalTensor<float>(TPosition::VECCALC,187136,32);'''
new='''        x_[0]=LocalTensor<float>(TPosition::VECIN,0,9600);
        x_[1]=LocalTensor<float>(TPosition::VECIN,38528,9600);
        r_[0]=LocalTensor<float>(TPosition::VECIN,77056,9600);
        r_[1]=LocalTensor<float>(TPosition::VECIN,115584,9600);
        gf_=LocalTensor<float>(TPosition::VECIN,154112,4096);
        bf_=LocalTensor<float>(TPosition::VECIN,170624,4096);
        work_=LocalTensor<float>(TPosition::VECCALC,187136,1200);
        sums_=LocalTensor<float>(TPosition::VECCALC,192064,32);'''
assert s.count(init)==1;s=s.replace(init,new)
old='''        Copy(r_,rgm_,begin_);SetFlag<HardEvent::MTE2_V>(2);
        if(begin_+batch_<end_) {Copy(x_[1],xgm_,begin_+batch_);SetFlag<HardEvent::MTE2_V>(1);}'''
new='''        Copy(r_[0],rgm_,begin_);SetFlag<HardEvent::MTE2_V>(2);
        if(begin_+batch_<end_) {
            Copy(x_[1],xgm_,begin_+batch_);SetFlag<HardEvent::MTE2_V>(1);
            Copy(r_[1],rgm_,begin_+batch_);SetFlag<HardEvent::MTE2_V>(3);
        }'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('WaitFlag<HardEvent::MTE2_V>(slot);WaitFlag<HardEvent::MTE2_V>(2);','WaitFlag<HardEvent::MTE2_V>(slot);WaitFlag<HardEvent::MTE2_V>(slot+2);')
s=s.replace('auto y=x_[slot];auto tmp=r_;','auto y=x_[slot];auto tmp=r_[slot];')
old='''            if(row+batch_<end_) {
                SetFlag<HardEvent::V_MTE2>(2);WaitFlag<HardEvent::V_MTE2>(2);
                Copy(r_,rgm_,row+batch_);SetFlag<HardEvent::MTE2_V>(2);
            }'''
new='''            if(row+2*batch_<end_) {
                SetFlag<HardEvent::V_MTE2>(slot+2);WaitFlag<HardEvent::V_MTE2>(slot+2);
                Copy(r_[slot],rgm_,row+2*batch_);SetFlag<HardEvent::MTE2_V>(slot+2);
            }'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('LocalTensor<float> x_[2],r_,gf_,bf_,work_,sums_;','LocalTensor<float> x_[2],r_[2],gf_,bf_,work_,sums_;')
entry='''__global__ __vector__ void float_double_residual_custom(GM_ADDR x,GM_ADDR r,GM_ADDR g,GM_ADDR b,GM_ADDR out,
    uint64_t rows,uint32_t d,float invD,float eps) {
    InitSocState();FloatDoubleResidualKernel op;op.Init(x,r,g,b,out,rows,d,invD,eps);op.Process();
}
'''
code=base[:a]+s+entry+'\n'+base[a:]
anchor='    if(input.dtype==0 && d>1536 && d<=4096'
assert code.count(anchor)==1
code=code.replace(anchor,'''    if(input.dtype==0 && d>3072 && d<=3200 && rows>=static_cast<uint64_t>(blockNum)*4) {
        float_double_residual_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''+anchor)
name='FPD4';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFP3',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='FP32 padded row widths 3136 and 3200 use two residual slots and two X/output slots; residual prefetch two batches ahead after reduction; arithmetic unchanged',numerical_change=False,ub_end_bytes=192192),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='fpd4quick'" not in s:
 s+='''
if mode=='fpd4quick':
 items=[small[10],small[12]]+[('fpd4_'+str(d),321,d,'float32') for d in [3073,3136,3137,3200]]
 check('fpd4_check',items,['BFP3','FPD4'])
 pairs('fpd4_pairs',[small[10],small[12]],'BFP3','FPD4',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_fpd4.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
