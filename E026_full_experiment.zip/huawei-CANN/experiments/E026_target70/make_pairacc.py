from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
code=(H/'PAIR2/code/kernel.asc').read_text(encoding='utf-8')
a=code.index('class LongHalfPair2Kernel {');z=code.index('class LongHalfRetainedKernel {',a)
part=code[a:z]
part=part.replace('TPosition::VECIN,32768,16384','TPosition::VECIN,32896,16384')
part=part.replace('TPosition::VECCALC,65536,16384','TPosition::VECCALC,65792,8192')
part=part.replace('TPosition::VECIN,131072,16384','TPosition::VECIN,98688,16384')
part=part.replace('TPosition::VECIN,163840,16384','TPosition::VECIN,131584,16384')
part=part.replace('Duplicate(square_,0.0f,n_);','Duplicate(square_,0.0f,8192);')
part=part.replace('MulAddDst(square_[col],x_[col],x_[col],64,size/64,{1,1,1,8,4,4});','MulAddDst(square_,x_[col],x_[col],64,size/64,{1,1,1,8,4,4});')
x=part.index('        const uint32_t parts=n_/64;');y=part.index('        Duplicate(partial_',x)
part=part[:x]+'''        const uint32_t parts=(n_<8192?n_:8192)/64;
        WholeReduceSum(work_,square_,64,parts,1,1,8);PipeBarrier<PIPE_V>();
        if(parts>64){Add(work_,work_,work_[64],parts-64);PipeBarrier<PIPE_V>();}
        const uint32_t reduced=parts;
'''+part[y:]
code=code[:a]+part+code[z:]
name='PAIRACC';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n');sha=hashlib.sha256(code.encode()).hexdigest()
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='PAIR2',source_sha256=sha,change='Pairwise long FP16: retain one 8192-element FP32 square accumulator over both half-row chunks, reduce once; phase UB regions by 128 bytes; same two mode-1 synchronization points',static_ub_end=164352,numerical_change=True),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='pairaccquick'" not in s:
 s+='''
if mode=='pairaccquick':
 items=[('split_one',1,32768,'float16'),('split_two',2,16384,'float16'),small[4],('sync2_8448',3,8448,'float16'),('sync2_24576',20,24576,'float16'),('sync2_fallback',21,32768,'float16')]
 check('pairacc_check',items,['FACC','PAIRACC'])
 pairs('pairacc_pairs',[small[4],items[0],items[1]],'FACC','PAIRACC',blocks=1)
if mode=='pairaccedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='pair2_edge_'+pattern;case(cid,8,32768,'float16',pattern);items.append((cid,8,32768,'float16'))
 check('pairacc_edge_check',items,['FACC','PAIRACC'])
if mode=='pairsinglequick':
 items=[('pairsingle_'+str(r)+'_'+str(d),r,d,'float16') for r,d in [(1,16384),(1,24576),(1,32768),(2,24576),(2,32768),(4,32768)]]
 check('pairsingle_check',items,['FACC','PAIRACC'])
 pairs('pairsingle_pairs',items,'FACC','PAIRACC',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_pairacc.tar.gz','w:gz') as t:
 for q in [H/name,p]:t.add(q,arcname=q.relative_to(H.parents[1]))
print(name,sha)
