from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'LSQM/code/kernel.asc').read_text(encoding='utf-8')
src=(H/'HMACC/code/kernel.asc').read_text(encoding='utf-8')
a=src.index('class HalfLaneAccKernel {');z=src.index('class BFloatShortInplaceKernel {',a)
inc=src[a:z].replace('HalfLaneAccKernel','HalfWideLaneAccKernel').replace('half_lane_acc_custom','half_wide_lane_acc_custom')
old='''        gh_=LocalTensor<half>(TPosition::VECIN,166272,1024);
        bh_=LocalTensor<half>(TPosition::VECIN,168448,1024);
        square_=LocalTensor<float>(TPosition::VECCALC,170624,4608);
        work_=LocalTensor<float>(TPosition::VECCALC,189184,1536);
        sums_=LocalTensor<float>(TPosition::VECCALC,195456,128);'''
new='''        gh_=LocalTensor<half>(TPosition::VECIN,166272,4096);
        bh_=LocalTensor<half>(TPosition::VECIN,174592,4096);
        square_=LocalTensor<float>(TPosition::VECCALC,182912,1600);
        work_=LocalTensor<float>(TPosition::VECCALC,189440,1536);
        sums_=LocalTensor<float>(TPosition::VECCALC,195712,32);'''
assert inc.count(old)==1;inc=inc.replace(old,new)
old='                Duplicate(x_[slot][d_/128*128],static_cast<half>(0),tail,count,1,stride_/16);PipeBarrier<PIPE_V>();'
new='''                for(uint32_t i=0;i<count;++i)
                    Duplicate(x_[slot][i*stride_+d_/128*128],static_cast<half>(0),tail,1,1,8);
                PipeBarrier<PIPE_V>();'''
assert inc.count(old)==1;inc=inc.replace(old,new)
a=inc.index('            const uint8_t step=stride_/16;');z=inc.index('            WholeReduceSum(sums_,square_',a)
inc=inc[:a]+'''            const uint32_t parts=stride_/64;
            for(uint32_t i=0;i<count;++i)
                MulAddDst<float,half>(square_[i*64],x_[slot][i*stride_],x_[slot][i*stride_],64,parts,{1,1,1,0,4,4});
            PipeBarrier<PIPE_V>();
'''+inc[z:]
a=inc.index('            const uint8_t rb=stride_/16;');z=inc.index('            SetFlag<HardEvent::V_MTE3>(slot);',a)
inc=inc[:a]+'''            const uint32_t full=d_/128,tailCount=d_%128;
            for(uint32_t i=0;i<count;++i) {
                if(full)Mul(x_[slot][i*stride_],x_[slot][i*stride_],broadcast[i*16],128,full,{1,1,0,8,8,0});
                if(tailCount)Mul(x_[slot][i*stride_+full*128],x_[slot][i*stride_+full*128],broadcast[i*16],tailCount,1,{1,1,0,8,8,0});
            }
            PipeBarrier<PIPE_V>();
            for(uint32_t i=0;i<count;++i)
                FusedMulAdd(x_[slot][i*stride_],gh_,bh_,d_);
            PipeBarrier<PIPE_V>();
'''+inc[z:]
code=base.replace('class BFloatShortInplaceKernel {',inc+'\nclass BFloatShortInplaceKernel {',1)
old='half_wide_pipeline_custom<half,false><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'
assert code.count(old)==1
code=code.replace(old,'half_wide_lane_acc_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);')
name='HWACC';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
sha=hashlib.sha256(code.encode()).hexdigest()
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='LSQM',source_sha256=sha,change='FP16 D1025..4096 many rows: native residual retained in half, mixed VMLA lane accumulation, capacity 27648, per-row half normalization and affine, deferred output drains',static_ub_end=195840,numerical_change=True),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='hwaccquick'" not in s:
 s+='''
if mode=='hwaccquick':
 items=[('hwacc_'+str(d),3408,d,'float16') for d in [1536,2048,3072,4096]]+[('hwacc_'+str(d),257,d,'float16') for d in [1025,1537,3079,4095]]
 check('hwacc_check',items,['LSQM','HWACC'])
 pairs('hwacc_pairs',items[:4],'LSQM','HWACC',blocks=1)
if mode=='hwaccedge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='hwacc_edge_'+pattern;case(cid,257,4096,'float16',pattern)
  items.append((cid,257,4096,'float16'))
 check('hwacc_edge_check',items,['LSQM','HWACC'])
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_hwacc.tar.gz','w:gz') as t:
 for q in [H/name,p]:t.add(q,arcname=q.relative_to(H.parents[1]))
print(name,sha)
