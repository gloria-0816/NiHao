from pathlib import Path
import shutil,json,hashlib
H=Path(__file__).resolve().parent
inc=(H/'split_long.inc').read_text()
a=inc.index('    DataCopyPad(xt,xgm[offset],copy,pad);')
b=inc.index('    Mul(y,y,work,64,n/64',a)
inc=inc[:a]+'''    // Each output core computes a complete RMS independently. Rotated
    // chunks avoid simultaneous requests for the same input cache lines.
    // The core's output chunk is processed last and retained in y.
    const uint32_t pieces=n/64;
    for(uint32_t turn=0;turn<splits;++turn) {
        const uint32_t col=((part+turn+1)%splits)*n;
        const uint64_t at=static_cast<uint64_t>(row)*d+col;
        DataCopyPad(xt,xgm[at],copy,pad);DataCopyPad(rt,rgm[at],copy,pad);
        SetFlag<HardEvent::MTE2_V>(0);WaitFlag<HardEvent::MTE2_V>(0);
        ToFloat<T>(y,xt,n);ToFloat<T>(tmp,rt,n);PipeBarrier<PIPE_V>();
        Add(y,y,tmp,n);PipeBarrier<PIPE_V>();
        Mul(tmp,y,y,n);PipeBarrier<PIPE_V>();
        WholeReduceSum(work,tmp,64,pieces,1,1,8);PipeBarrier<PIPE_V>();
        if(pieces>64){Add(work,work,work[64],pieces-64);PipeBarrier<PIPE_V>();}
        WholeReduceSum(partial[turn*8],work,static_cast<int32_t>(pieces>64?64:pieces),1,1,1,8);
        PipeBarrier<PIPE_V>();
        SetFlag<HardEvent::V_MTE2>(0);WaitFlag<HardEvent::V_MTE2>(0);
    }
    DataCopyPad(xt,ggm[part*n],copy,pad);DataCopyPad(rt,bgm[part*n],copy,pad);
    SetFlag<HardEvent::MTE2_V>(1);
    uint64_t mask[2]={0,0};
    for(uint32_t p=0;p<splits;++p)mask[0]|=static_cast<uint64_t>(1)<<(p*8);
    WholeReduceSum(sum,partial,mask,1,1,1,8);PipeBarrier<PIPE_V>();
    Muls(sum,sum,invD,1);PipeBarrier<PIPE_V>();
    Adds(sum,sum,eps,1);PipeBarrier<PIPE_V>();
    Sqrt(sum,sum,1);Duplicate(work,1.0f,8);PipeBarrier<PIPE_V>();
    Div(sum,work,sum,1);PipeBarrier<PIPE_V>();
    Brcb(work,sum,1,{1,8});PipeBarrier<PIPE_V>();
    WaitFlag<HardEvent::MTE2_V>(1);
    ToFloat<T>(gf,xt,n);ToFloat<T>(bf,rt,n);PipeBarrier<PIPE_V>();
'''+inc[b:]
inc=inc.replace('__schedmode__(1) __global__ __mix__(0,1)','__global__ __vector__').replace('split_long_custom','duplicated_long_custom')
inc=inc.replace('// Small row counts cannot fill all vector cores with row-only partitioning.\n// Split one long row over several AIVs. Temporary partials live in output\n// storage, then two hardware barriers protect their write/read lifetime.\n// No extra device allocation, host tensor arithmetic, or second launch.','// Replicated RMS reductions trade extra cached reads for synchronization-free\n// parallel output. Every tensor value is computed in the current invocation.')
base=(H/'BASE/code/kernel.asc').read_text()
code=base.replace('class StaticHalfRowsKernel {',inc+'\nclass StaticHalfRowsKernel {',1)
split=(H/'SPLIT/code/kernel.asc').read_text()
a=split.index('    if(input.dtype==1 && d>8192')
b=split.index('    if (input.dtype == 1 && d <= 256',a)
launch=split[a:b].replace('split_long_custom','duplicated_long_custom')
anchor='    if (input.dtype == 1 && d <= 256'
code=code.replace(anchor,launch+anchor,1)
d=H/'DUP/code';shutil.copytree(H/'BASE/code',d,dirs_exist_ok=True)
(d/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'DUP/manifest.json').write_text(json.dumps({'variant':'DUP','source_sha256':hashlib.sha256(code.encode()).hexdigest()},indent=2)+'\n')
f=H/'run_round.py';s=f.read_text()
if "mode=='dupquick'" not in s:
 s+='''
if mode=='dupquick':
 check('dup_check',[small[4],('split_one',1,32768,'float16'),('split_two',2,16384,'float16')],['BASE','DUP'])
 pairs('dup_pairs',[small[4]],'BASE','DUP',blocks=1)
'''
 f.write_text(s,encoding='utf-8',newline='\n')
print(hashlib.sha256(code.encode()).hexdigest())
