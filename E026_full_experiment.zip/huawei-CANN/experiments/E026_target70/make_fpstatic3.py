from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent
code=(H/'COMBOA/code/kernel.asc').read_text()
a=code.index('class FloatStaticBatchKernel {');z=code.index('class RetainedAccKernel {',a)
s=code[a:z]
s=s.replace('FloatStaticBatchKernel','FloatStaticTripleKernel').replace('float_static_batch_custom','float_static_triple_custom')
s=s.replace('batch_=9984/stride_;','batch_=13312/stride_;')
ia=s.index('        x_[0]=LocalTensor');iz=s.index('    }\n    __aicore__ inline void Process()',ia)
s=s[:ia]+'''        x_[0]=LocalTensor<float>(TPosition::VECIN,0,13312);
        x_[1]=LocalTensor<float>(TPosition::VECIN,53376,13312);
        r_=LocalTensor<float>(TPosition::VECIN,106752,13312);
        gf_=LocalTensor<float>(TPosition::VECIN,160128,3136);
        bf_=LocalTensor<float>(TPosition::VECIN,172800,3136);
        work_=LocalTensor<float>(TPosition::VECCALC,185472,1664);
        sums_=LocalTensor<float>(TPosition::VECCALC,192256,32);
'''+s[iz:]
s=s.replace('SetFlag<HardEvent::MTE2_V>(2);WaitFlag<HardEvent::MTE2_V>(2);','SetFlag<HardEvent::MTE2_V>(3);WaitFlag<HardEvent::MTE2_V>(3);',1)
old='        Prefetch(begin_,0);if(begin_+batch_<end_)Prefetch(begin_+batch_,1);'
new='''        Copy(x_[0],xgm_,begin_);SetFlag<HardEvent::MTE2_V>(0);
        Copy(r_,rgm_,begin_);SetFlag<HardEvent::MTE2_V>(2);
        if(begin_+batch_<end_) {Copy(x_[1],xgm_,begin_+batch_);SetFlag<HardEvent::MTE2_V>(1);}'''
assert old in s;s=s.replace(old,new,1)
s=s.replace('            WaitFlag<HardEvent::MTE2_V>(slot);','            WaitFlag<HardEvent::MTE2_V>(slot);WaitFlag<HardEvent::MTE2_V>(2);',1)
s=s.replace('auto y=x_[slot];auto tmp=r_[slot];','auto y=x_[slot];auto tmp=r_;',1)
old='''            if(row+2*batch_<end_) {
                SetFlag<HardEvent::V_MTE2>(slot);WaitFlag<HardEvent::V_MTE2>(slot);
                Copy(r_[slot],rgm_,row+2*batch_);
            }'''
new='''            if(row+batch_<end_) {
                SetFlag<HardEvent::V_MTE2>(2);WaitFlag<HardEvent::V_MTE2>(2);
                Copy(r_,rgm_,row+batch_);SetFlag<HardEvent::MTE2_V>(2);
            }'''
assert old in s;s=s.replace(old,new,1)
ia=s.index('    __aicore__ inline void Prefetch');iz=s.index('    GlobalTensor<float>',ia)
s=s[:ia]+s[iz:]
s=s.replace('LocalTensor<float> x_[2],r_[2],gf_,bf_,work_,sums_;','LocalTensor<float> x_[2],r_,gf_,bf_,work_,sums_;',1)
# The extraction includes the following retained kernel template declaration.
assert s.endswith('template <typename T>\n')
s=s[:-len('template <typename T>\n')]
code=code[:a]+s+'template <typename T>\n'+code[z:]
code=code.replace('float_static_batch_custom<<<','float_static_triple_custom<<<',1)
name='FPSTATIC3';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'COMBOA','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'FP32 shared residual buffer with next-batch prefetch after reduction; batch capacity 13312; direct X output','ub_end_bytes':192384},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='fpstatic3quick'" not in s:
 s+='''
if mode=='fpstatic3quick':
 check('fpstatic3_check',[small[10],small[12],('fps_2048',161,2048,'float32'),('fps_3136',257,3136,'float32')],['COMBOA','FPSTATIC3'])
 pairs('fpstatic3_pairs',[small[10],small[12]],'COMBOA','FPSTATIC3',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
