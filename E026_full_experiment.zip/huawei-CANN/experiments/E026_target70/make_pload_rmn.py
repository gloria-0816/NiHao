from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'FACC/code/kernel.asc').read_text(encoding='utf-8')
pload=base
old='''        SetFlag<HardEvent::MTE2_V>(0); WaitFlag<HardEvent::MTE2_V>(0);
        if(!CompactParameterType<T>::value){ToFloat<T>(gamma_,gh_,d_);ToFloat<T>(bias_,bh_,d_);}
        PipeBarrier<PIPE_V>();
        Prefetch(begin_,0);'''
new='''        // Independent parameter slots are covered by the first input event.
        if(!CompactParameterType<T>::value) {
            SetFlag<HardEvent::MTE2_V>(0);WaitFlag<HardEvent::MTE2_V>(0);
            ToFloat<T>(gamma_,gh_,d_);ToFloat<T>(bias_,bh_,d_);PipeBarrier<PIPE_V>();
        }
        Prefetch(begin_,0);'''
assert pload.count(old)==2
pload=pload.replace(old,new)
a=pload.index('class FloatBroadTripleKernel {');z=pload.index('class HalfWidePipelineKernel {',a)
part=pload[a:z]
old='        SetFlag<HardEvent::MTE2_V>(3);WaitFlag<HardEvent::MTE2_V>(3);'
assert part.count(old)==1
part=part.replace(old,'        // First X event also covers earlier gamma/bias DMA; slots are independent.')
pload=pload[:a]+part+pload[z:]

helper='''
__aicore__ inline void MaskedInvRmsSmall(LocalTensor<float> sums,LocalTensor<float> work,
    uint32_t n,float invD,float eps) {
    if(n<=64) {
        SetMaskNorm();SetVectorMask<float,MaskMode::NORMAL>(n);
        Muls<float,false>(sums,sums,invD,static_cast<uint64_t>(0),1,{1,1,8,8});PipeBarrier<PIPE_V>();
        Adds<float,false>(sums,sums,eps,static_cast<uint64_t>(0),1,{1,1,8,8});PipeBarrier<PIPE_V>();
        Sqrt<float,false>(sums,sums,static_cast<uint64_t>(0),1,{1,1,8,8});
        Duplicate<float,false>(work,1.0f,static_cast<uint64_t>(0),1,1,8);PipeBarrier<PIPE_V>();
        Div<float,false>(sums,work,sums,static_cast<uint64_t>(0),1,{1,1,1,8,8,8});PipeBarrier<PIPE_V>();
        ResetMask();
    } else {
        Muls(sums,sums,invD,n);PipeBarrier<PIPE_V>();
        Adds(sums,sums,eps,n);PipeBarrier<PIPE_V>();
        Sqrt(sums,sums,n);Duplicate(work,1.0f,n);PipeBarrier<PIPE_V>();
        Div(sums,work,sums,n);PipeBarrier<PIPE_V>();
    }
}
'''
rmn=base.replace('using namespace AscendC;','using namespace AscendC;\n'+helper,1)
old='''            Muls(sums_,sums_,invD_,count); PipeBarrier<PIPE_V>();
            Adds(sums_,sums_,eps_,count); PipeBarrier<PIPE_V>();
            Sqrt(sums_,sums_,count); Duplicate(work_,1.0f,count); PipeBarrier<PIPE_V>();
            Div(sums_,work_,sums_,count); PipeBarrier<PIPE_V>();'''
assert rmn.count(old)>=2,rmn.count(old)
rmn=rmn.replace(old,'            MaskedInvRmsSmall(sums_,work_,count,invD_,eps_);')
old='''        Muls(sums_,sums_,invD_,rms); PipeBarrier<PIPE_V>();
        Adds(sums_,sums_,eps_,rms); PipeBarrier<PIPE_V>();
        Sqrt(sums_,sums_,rms);
        Duplicate(work_,1.0f,rms); PipeBarrier<PIPE_V>();
        Div(sums_,work_,sums_,rms); PipeBarrier<PIPE_V>();'''
assert rmn.count(old)==1
rmn=rmn.replace(old,'        MaskedInvRmsSmall(sums_,work_,rms,invD_,eps_);')
for name,code in [('PLOAD',pload),('RMN',rmn)]:
 dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
 sha=hashlib.sha256(code.encode()).hexdigest()
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='FACC',source_sha256=sha,
  change='Independent parameters and first input share first MTE2 completion event in FP16 pipelines and FP32 wide' if name=='PLOAD' else 'Normal vector mask reused for RMS scale/epsilon/sqrt/ones/divide when batch <=64; no counter-mode transitions',numerical_change=False),indent=2)+'\n')
 print(name,sha)
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='ploadrmnquick'" not in s:
 s+='''
if mode=='ploadrmnquick':
 items=[small[i] for i in [3,5,6,7,9,10]]+[('hwacc_1536',3408,1536,'float16'),('facc_1537',641,1537,'float32')]
 check('ploadrmn_check',items,['FACC','PLOAD','RMN'])
 for v in ['PLOAD','RMN']:
  pairs(v.lower()+'_pairs',[small[i] for i in ([5,6,7,9,10] if v=='PLOAD' else [3,5,6,7,9])],'FACC',v,blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_pload_rmn.tar.gz','w:gz') as t:
 for q in [H/'PLOAD',H/'RMN',p]:t.add(q,arcname=q.relative_to(H.parents[1]))
