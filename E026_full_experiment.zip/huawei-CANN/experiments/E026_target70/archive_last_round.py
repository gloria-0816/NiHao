from pathlib import Path
import json,hashlib,tarfile,io,sys
root=Path('/mnt/workspace/addrms_results/E026')
target=Path('/home/developer/addrms_archived')/sys.argv[1]
assert target.name.startswith('E026_final_') and target.suffixes==['.tar','.gz'] and not target.exists()
required=['pairtail_edge_check/complete.json','singleasy_pairs/summary.json','hsm63_edge_check/complete.json','bffull15_rr_pairs/summary.json','bffull_op/complete.json','sched1_pairs/summary.json','bfv_check/complete.json','bfv80_full14_pairs/summary.json','bfv80_full15_pairs/summary.json','bfv160_full14_pairs/summary.json','bfv160_full15_pairs/summary.json']
for rel in required:assert (root/rel).exists(),rel
prefixes=('pairsingle','pairasync','pairasy_multi','singleasy','pairtail','hsm63','bffull','sched1','bfv','build_SCHED1','build_BFV','build_HSM63','build_PAIRTAIL','build_SINGLEASY','build_PAIRASY','build_PAIRSINGLE')
files=[]
for group in root.iterdir():
    if group.is_dir() and group.name.startswith(prefixes):
        files.extend(p for p in group.rglob('*') if p.is_file() and p.suffix in {'.json','.csv','.log','.txt'})
files.extend(root.glob('*.json'))
for p in Path('/home/developer').glob('*.log'):
    if p.name.startswith(('pairasync','pairsingle','pairtail','singleasy','hsm63','bffull','schedule')):files.append(p)
manifest=[];skipped=[]
with tarfile.open(target,'w:gz') as archive:
    for path in sorted(set(files)):
        data=path.read_bytes()
        relative=path.relative_to(root).as_posix() if path.is_relative_to(root) else '_queue_logs/'+path.name
        if path.suffix=='.json':
            try:json.loads(data)
            except (ValueError,UnicodeError):skipped.append(relative);continue
        entry=tarfile.TarInfo(relative);entry.size=len(data);entry.mode=0o600
        archive.addfile(entry,io.BytesIO(data));manifest.append(dict(path=relative,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    data=(json.dumps(dict(description='Final queued round, complete raw records excluding tensors',files=manifest,skipped_invalid_json=skipped),indent=2)+'\n').encode()
    entry=tarfile.TarInfo('_snapshot_manifest.json');entry.size=len(data);archive.addfile(entry,io.BytesIO(data))
print(json.dumps(dict(files=len(manifest),bytes=target.stat().st_size,archive=str(target),sha256=hashlib.sha256(target.read_bytes()).hexdigest())))
