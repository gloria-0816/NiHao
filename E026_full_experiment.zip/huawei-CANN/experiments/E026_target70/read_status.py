from pathlib import Path
import json,sys
O=Path('/mnt/workspace/addrms_results/E026')
for name in sys.argv[1:]:
 p=O/name
 for f in sorted(p.glob('*/record.json')):
  x=json.loads(f.read_text());s=x.get('strict',{})
  if not s.get('pass',True):print(f.parent.name,{k:s.get(k) for k in ['failed_elements','classification_failures','max_abs_error','examples']},flush=True)
 for name in ['summary.json','complete.json']:
  f=p/name
  if f.exists():print(f,json.loads(f.read_text()),flush=True)
