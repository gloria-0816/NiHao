from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent
code=(H/'COMBO2/code/kernel.asc').read_text()
recast=(H/'half_recast.inc').read_text()
fp=(H/'FPSTATIC2/code/kernel.asc').read_text()
a=fp.index('class FloatStaticBatchKernel {');z=fp.index('class StaticHalfRowsKernel {',a)
fp=fp[a:z]
ret=(H/'RETACC2/code/kernel.asc').read_text()
a=ret.index('template <typename T>\nclass RetainedAccKernel {');z=ret.index('class StaticHalfRowsKernel {',a)
ret=ret[a:z]
code=code.replace('class StaticHalfRowsKernel {',recast+'\n'+fp+'\n'+ret+'\nclass StaticHalfRowsKernel {',1)
anchor='    if (rows >= static_cast<uint64_t>(blockNum)*4 && ((input.dtype==1'
launch='''    if(input.dtype==1 && d==512 && rows>=static_cast<uint64_t>(blockNum)*4) {
        half_recast_batch_custom<half,true><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
    if(input.dtype==0 && d>=2048 && d<=3136 && rows>=static_cast<uint64_t>(blockNum)*4) {
        float_static_batch_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
    if((input.dtype==1 || input.dtype==2) && d>8192 && d<=32768 && d%4096==0) {
        if(input.dtype==1)retained_acc_custom<half><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        else retained_acc_custom<bfloat16_t><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert anchor in code;code=code.replace(anchor,launch+anchor,1)
name='COMBO3';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'COMBO2','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'D512 recast capacity 12288; FP32 medium-wide static buffering; retained long vertical accumulation','merged':['RECAST restricted D512','FPSTATIC2','RETACC2']},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='combo3quick'" not in s:
 s+='''
if mode=='combo3quick':
 check('combo3_check',small+[('combo3_longbf',3,16384,'bfloat16')],['COMBO2','COMBO3'])
 pairs('combo3_pairs',[small[i] for i in [4,7,10,12]],'COMBO2','COMBO3',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
