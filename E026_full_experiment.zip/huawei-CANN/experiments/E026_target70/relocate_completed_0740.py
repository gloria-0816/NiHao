from pathlib import Path
import shutil,json
root=Path('/mnt/workspace/addrms_results/E026').resolve()
target=Path('/home/developer/addrms_archived/E026').resolve()
target.mkdir(parents=True,exist_ok=True)
groups=['hwacc_check','hwacc_pairs','hwacc_edge_check','fwacc_check','flong_check','flong_edge_check','fdir_pairs','fdacc_pairs','hslane_check','hslane_edge_check','hslane_pairs','ploadrmn_check','pload_pairs','rmn_pairs','sfdir_check','sfdir_pairs','sfacc_pairs','sfdir_edge_check','cpart_check','cpart_pairs','hostp_check','hostp_pairs','coal64_check','coal64_pairs','sftiny_check','sftiny_pairs']
events=[]
for name in groups:
 src=root/name;dst=target/name
 assert src.parent.resolve()==root and dst.parent.resolve()==target
 if src.is_symlink():
  assert src.resolve()==dst.resolve();continue
 assert (src/'complete.json').exists() or (src/'summary.json').exists(),name
 assert not dst.exists(),dst
 size=sum(p.stat().st_size for p in src.rglob('*') if p.is_file() and not p.is_symlink())
 shutil.move(str(src),str(dst));src.symlink_to(dst,target_is_directory=True)
 assert src.resolve()==dst.resolve()
 events.append(dict(group=name,original=str(src),new=str(dst),bytes=size))
 print(json.dumps(events[-1]),flush=True)
(root/'relocate_completed_0740.json').write_text(json.dumps(dict(description='Reversible relocation; complete tensors and records preserved',events=events),indent=2)+'\n')
print(json.dumps(dict(free_bytes=shutil.disk_usage(root).free)))
