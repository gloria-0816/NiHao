from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent;base=(H/'HALFAFF2/code/kernel.asc').read_text()
inc=(H/'bf_static8.inc').read_text()
code=base.replace('class StaticHalfRowsKernel {',inc+'\nclass StaticHalfRowsKernel {',1)
anchor='    if (rows >= static_cast<uint64_t>(blockNum)*4 && ((input.dtype==1'
launch='''    if(input.dtype==2 && d>4096 && d<=8192 && rows>=static_cast<uint64_t>(blockNum)*4) {
        bf_static8_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert anchor in code;code=code.replace(anchor,launch+anchor,1)
name='BFS8';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'HALFAFF2','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'BF16 4097..8192 static single-input prefetch; vector inverse and FMA; cached FP32 parameters','ub_end_bytes':189472,'numerical_change':True},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='bfs8quick'" not in s:
 s+='''
if mode=='bfs8quick':
 check('bfs8_check',[small[14],('bfs8_4097',161,4097,'bfloat16'),('bfs8_8191',161,8191,'bfloat16')],['HALFAFF2','BFS8'])
 pairs('bfs8_pairs',[small[14]],'HALFAFF2','BFS8',blocks=2)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
