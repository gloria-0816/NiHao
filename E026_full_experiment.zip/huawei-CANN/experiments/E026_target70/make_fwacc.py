from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'FACC/code/kernel.asc').read_text(encoding='utf-8')
wide=(H/'HWACC/code/kernel.asc').read_text(encoding='utf-8')
a=wide.index('class HalfWideLaneAccKernel {')
z=wide.index('class BFloatShortInplaceKernel {',a)
part=wide[a:z]
code=base.replace('class BFloatShortInplaceKernel {',part+'\nclass BFloatShortInplaceKernel {',1)
old='half_wide_pipeline_custom<half,false><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'
assert code.count(old)==1
code=code.replace(old,'half_wide_lane_acc_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);')
name='FWACC';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
sha=hashlib.sha256(code.encode()).hexdigest()
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='FACC',source_sha256=sha,change='Integrate independently tested HWACC FP16 wide lane accumulation into official best FACC',numerical_change=True),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='fwaccquick'" not in s:
 s+='''
if mode=='fwaccquick':
 items=[('hwacc_1536',3408,1536,'float16'),('hwacc_4095',257,4095,'float16'),('facc_1537',641,1537,'float32'),small[4]]
 check('fwacc_check',items,['FACC','FWACC'])
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_fwacc.tar.gz','w:gz') as t:
 for q in [H/name,p]:t.add(q,arcname=q.relative_to(H.parents[1]))
print(name,sha)
