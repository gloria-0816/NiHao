from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent
code=(H/'SPLIT/code/kernel.asc').read_text()
a=code.index('__schedmode__(1) __global__ __mix__(0,1) void split_long_custom');z=code.index('class StaticHalfRowsKernel {',a);s=code[a:z]
old='''    ToFloat<T>(y,xt,n);ToFloat<T>(tmp,rt,n);PipeBarrier<PIPE_V>();'''
new='''    Add(xt,xt,rt,n);PipeBarrier<PIPE_V>();
    ToFloat<T>(y,xt,n);PipeBarrier<PIPE_V>();'''
assert old in s;s=s.replace(old,new,1)
s=s.replace('    Add(y,y,tmp,n);PipeBarrier<PIPE_V>();','',1)
s=s.replace('    ToFloat<T>(gf,xt,n);ToFloat<T>(bf,rt,n);PipeBarrier<PIPE_V>();','',1)
old='''    Mul(y,y,gf,n);PipeBarrier<PIPE_V>();
    Add(y,y,bf,n);PipeBarrier<PIPE_V>();
    FromFloat<T>(xt,y,n);PipeBarrier<PIPE_V>();'''
new='''    // tmp float storage is dead after reduction; use its low half for output.
    auto oh=tmp.template ReinterpretCast<T>();
    FromFloat<T>(oh,y,n);PipeBarrier<PIPE_V>();
    FusedMulAdd(oh,xt,rt,n);PipeBarrier<PIPE_V>();'''
assert old in s;s=s.replace(old,new,1)
s=s.replace('DataCopyPad(outgm[offset],xt,copy);','DataCopyPad(outgm[offset],tmp.template ReinterpretCast<T>(),copy);',1)
code=code[:a]+s+code[z:]
# Carry the current best short and regular rows from COMBO2, then insert split.
parent=(H/'COMBO2/code/kernel.asc').read_text()
inc='template <typename T>\n'+s
parent=parent.replace('class StaticHalfRowsKernel {',inc+'\nclass StaticHalfRowsKernel {',1)
launchStart=code.index('    if(input.dtype==1 && d>8192 && d<=32768 && rows<=')
launchEnd=code.index('    if (input.dtype == 1 && d <= 256',launchStart)
parent=parent.replace('    if (input.dtype == 1 && d <= 256',code[launchStart:launchEnd]+'    if (input.dtype == 1 && d <= 256',1)
name='SPLITAFF';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(parent,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'COMBO2','source_sha256':hashlib.sha256(parent.encode()).hexdigest(),'change':'split long rows across cores with FP16 add and affine, FP32 reduction; same 2 hardware barriers','numerical_change':True},indent=2)+'\n')
print(name,hashlib.sha256(parent.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='splitaffquick'" not in s:
 s+='''
if mode=='splitaffquick':
 check('splitaff_check',[small[4],('split_one',1,32768,'float16'),('split_two',2,16384,'float16')],['COMBO2','SPLITAFF'])
 pairs('splitaff_pairs',[small[4]],'COMBO2','SPLITAFF',blocks=2)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
