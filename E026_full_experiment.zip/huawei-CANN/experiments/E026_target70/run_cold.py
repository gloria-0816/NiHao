import sys,json,importlib.util
from pathlib import Path
H=Path(__file__).resolve().parent
mode=sys.argv[1] if len(sys.argv)>1 else 'first'
sys.argv=[str(H/'run_round.py'),'no_action']
spec=importlib.util.spec_from_file_location('round_driver',H/'run_round.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
previous=r.core.run_logged
def logged(cmd,*args,**kw):
 if cmd[:2]==['msprof','op']:
  cmd=[x.replace('--launch-skip-before-match=11','--launch-skip-before-match=0').replace('--launch-count=5','--launch-count=1') for x in cmd]
  cmd[2:2]=['--replay-mode=kernel','--warm-up=5']
 return previous(cmd,*args,**kw)
r.core.run_logged=logged
out=r.OUT/('cold_'+mode if mode!='first' else 'cold_first');out.mkdir(exist_ok=True)
items=[(r.small[7],['BROAD3','SHAREDA']), (r.small[9],['SHAREDA','BROAD3']), (r.small[11],['BROAD3','BFP3']), (r.small[12],['BROAD3'])]
if mode=='fpc4':items=[(r.small[10],['BROAD3','FPC4','FPC4','BROAD3']),(r.small[12],['FPC4','BROAD3','BROAD3','FPC4'])]
if mode=='fpd4':items=[(r.small[10],['BFP3','FPD4','FPD4','BFP3']),(r.small[12],['FPD4','BFP3','BFP3','FPD4'])]
if mode=='bfstripe':items=[(r.small[11],['BFP3','BFPN4','BFPN4','BFP3']),(r.small[10],['BFP3','FPSTRIPE','FPSTRIPE','BFP3']),(r.small[12],['FPSTRIPE','BFP3','BFP3','FPSTRIPE'])]
if mode=='short':items=[(r.small[0],['BFPN4']),(r.small[3],['BFPN4']),(r.small[5],['BFPN4','HIP15','HIP15','BFPN4']),(r.small[6],['HIP15','BFPN4','BFPN4','HIP15'])]
if mode=='hipaligned':items=[(r.small[7],['BFPN4','HIP15','HIP15','BFPN4']),(r.small[9],['HIP15','BFPN4','BFPN4','HIP15'])]
if mode=='flatnh':items=[(r.small[3],['BFPN4','FLATNH','FLATNH','BFPN4'])]
if mode=='hcore':items=[(r.small[3],['BFPN4','HCORE24','HCORE32','BFPN4','HCORE32','HCORE24'])]
if mode=='flatw':items=[(r.small[5],['BFSIP','FLATW','FLATW','BFSIP']),(r.small[6],['FLATW','BFSIP','BFSIP','FLATW'])]
if mode=='fpflat':items=[(r.small[10],['BFSIP','FPFLAT','FPFLAT','BFSIP']),(r.small[12],['FPFLAT','BFSIP','BFSIP','FPFLAT'])]
if mode=='facc':items=[(r.small[10],['LSQM','FACC','FACC','LSQM']),(r.small[12],['FACC','LSQM','LSQM','FACC'])]
records=[]
for item,variants in items:
 cid=r.case(*item)
 for position,v in enumerate(variants):
  dest=out/(f'{cid}_{position}_{v}' if mode!='first' else f'{cid}_{v}')
  rec=json.loads((dest/'record.json').read_text()) if (dest/'record.json').exists() else r.core.run_case(dest,cid,v,dict(warmup=0,repeats=1,batch=1,timing='host'),profile='op')
  records.append(rec);r.core.save(out/'records.json',records)
  if rec['status'] not in ('measured_strict_pass','measured_strict_fail_retained'):raise RuntimeError(rec)
r.core.save(out/'complete.json',dict(runs=len(records),settings='first launch; kernel replay; five profiler frequency warmups; cache cleared by documented replay mode',profiler_version=r.orig(['msprof','--version'],out/'version.txt',out/'version.stderr.txt',30)))
