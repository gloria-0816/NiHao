from pathlib import Path
import json,hashlib
H=Path(__file__).resolve().parent
official=json.loads((H/'official_results.json').read_text(encoding='utf-8'))
last=next(x for x in official if x['variant']=='HSM63')
assert last['submission_id']==744352 and last['score']==64.30 and len(last['points'])==15 and all(p['status']=='Pass' for p in last['points'])
last['source_sha256']=hashlib.sha256((H/'HSM63/code/kernel.asc').read_bytes()).hexdigest()
last['url']=(H/'HSM63/submission_url.txt').read_text().strip()
(H/'last_round_result.json').write_text(json.dumps(last,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(H/'stop_state.json').write_text(json.dumps(dict(stopped=True,date='2026-10-12',reason='用户要求本轮完成评分后停止，最佳完整方案整理至私人仓库',goal=70,goal_achieved=False,last_score=last['score'],best_score=64.98,cloud_queues_finished=True,publication_destination='gloria-0816/CANN_HuaiWei'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(last_score=last['score'],best_score=64.98,stopped=True),ensure_ascii=False))
