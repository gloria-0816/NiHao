from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent;base=(H/'COMBO1/code/kernel.asc').read_text()
a=base.index('class PipelineBatch9Kernel {');z=base.index('template <typename T,bool BlockReduction>',a);s=base[a:z]
old='''            ToFloat<T>(y_,x_[slot],active); ToFloat<T>(tmp_,r_[slot],active);
            PipeBarrier<PIPE_V>();'''
new='''            if(CompactParameterType<T>::value) {
                Add(x_[slot],x_[slot],r_[slot],active);PipeBarrier<PIPE_V>();
                ToFloat<T>(y_,x_[slot],active);PipeBarrier<PIPE_V>();
            } else {
                ToFloat<T>(y_,x_[slot],active);ToFloat<T>(tmp_,r_[slot],active);PipeBarrier<PIPE_V>();
            }'''
assert old in s;s=s.replace(old,new,1)
s=s.replace('            Add(y_,y_,tmp_,active); PipeBarrier<PIPE_V>();','            if(!CompactParameterType<T>::value){Add(y_,y_,tmp_,active);PipeBarrier<PIPE_V>();}',1)
code=base[:a]+s+base[z:]
name='HALFADD';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'COMBO1','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'FP16 residual addition before conversion; retains FP32 squared norm and affine stages','numerical_change':True},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='halfaddquick'" not in s:
 s+='''
if mode=='halfaddquick':
 check('halfadd_check',[small[i] for i in [5,6,7,9,13]],['COMBO1','HALFADD'])
 pairs('halfadd_pairs',[small[i] for i in [5,6,7,9]],'COMBO1','HALFADD',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
