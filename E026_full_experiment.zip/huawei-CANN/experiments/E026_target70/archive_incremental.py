from pathlib import Path
import tarfile,json,hashlib,io
root=Path('/mnt/workspace/addrms_results/E026')
target=root.parent/'E026_incremental_20261012_0600.tar.gz'
prefixes=('shorttree','build_SHORTTREE','hinv','build_HINV','hip15','build_HIP15','hipa15','build_HIPA15','hip16s','build_HIP16S','bfsip','build_BFSIP','flatnh','build_FLATNH','hcore','build_HCORE','hcb32','build_HCB32','bfa8','build_BFA8','sync4','build_SYNC4','bfinv','build_BFINV','flatw','build_FLATW','fpflat','build_FPFLAT','bfdb8','build_BFDB8','wcore','build_WCORE','bfs125','build_BFS125','bfs127','build_BFS127','bfsmax','shape0','build_SHAPE0','lh16g','build_LH16G','par64','build_PAR64','lconst','build_LCONST','lsqm','build_LSQM','cold_')
files=[p for group in root.iterdir() if group.is_dir() and group.name.startswith(prefixes) for p in group.rglob('*') if p.is_file() and p.suffix in {'.json','.csv','.log','.txt'}]
manifest=[];skipped=[]
with tarfile.open(target,'w:gz') as archive:
 for path in sorted(files):
  data=path.read_bytes();relative=path.relative_to(root).as_posix()
  if path.suffix=='.json':
   try:json.loads(data)
   except (ValueError,UnicodeError):skipped.append(relative);continue
  entry=tarfile.TarInfo(relative);entry.size=len(data);entry.mode=0o600
  archive.addfile(entry,io.BytesIO(data));manifest.append(dict(path=relative,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 data=(json.dumps(dict(description='Incremental completed experiment record snapshot; raw output tensors excluded',files=manifest,skipped_invalid_json=skipped),indent=2)+'\n').encode()
 entry=tarfile.TarInfo('_snapshot_manifest.json');entry.size=len(data);archive.addfile(entry,io.BytesIO(data))
print(json.dumps(dict(files=len(manifest),bytes=target.stat().st_size,archive=str(target),sha256=hashlib.sha256(target.read_bytes()).hexdigest())))
