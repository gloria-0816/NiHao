from pathlib import Path
import hashlib, json, shutil, tarfile

H = Path(__file__).resolve().parent
base = (H / 'BFSIP/code/kernel.asc').read_text(encoding='utf-8')
assert 'SetShapeInfo' not in base and 'GetShapeInfo' not in base
code = '#define K_MAX_SHAPE_DIM 0\n' + base
anchor = '#include "kernel_operator.h"\n'
assert code.count(anchor) == 1
code = code.replace(anchor, anchor + 'static_assert(sizeof(AscendC::ShapeInfo) <= 16, "ShapeInfo metadata must be disabled before Ascend C includes");\n')
dest = H / 'SHAPE0/code'
shutil.copytree(H / 'BASE/code', dest, dirs_exist_ok=True)
(dest / 'kernel.asc').write_text(code, encoding='utf-8', newline='\n')
sha = hashlib.sha256(code.encode()).hexdigest()
(H / 'SHAPE0/manifest.json').write_text(json.dumps(dict(
    variant='SHAPE0', parent='BFSIP', source_sha256=sha,
    change='Define K_MAX_SHAPE_DIM=0 before Ascend C headers, with compile-time ShapeInfo size verification; all arithmetic, buffers and launch geometry retained',
    numerical_change=False,
    reference='https://www.hiascend.com/document/detail/zh/canncommercial/900/programug/Ascendcopdevg/atlas_ascendc_best_practices_10_0019.html'), indent=2) + '\n')
p = H / 'run_round.py'
s = p.read_text(encoding='utf-8')
if "mode=='shape0quick'" not in s:
    s += """
if mode=='shape0quick':
 check('shape0_check',small,['BFSIP','SHAPE0'])
 pairs('shape0_pairs',[small[i] for i in [0,1,2,3,4,5,6,10,13,14]],'BFSIP','SHAPE0',blocks=1)
"""
    p.write_text(s, encoding='utf-8', newline='\n')
with tarfile.open(H / 'upload_shape0.tar.gz', 'w:gz') as tar:
    for target in [H / 'SHAPE0', p]:
        tar.add(target, arcname=target.relative_to(H.parents[1]))
print(sha)
