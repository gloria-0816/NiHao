from pathlib import Path
import json
O=Path('/mnt/workspace/addrms_results/E026').resolve()
group=O/'fmacc_check';target=O/'interrupted_fmacc_diskfull_0645'
target.mkdir(exist_ok=True)
saved=[]
for folder in group.iterdir():
 if not folder.is_dir():continue
 try:r=json.loads((folder/'record.json').read_text())
 except (FileNotFoundError,ValueError):r={}
 if r.get('status') in ['measured_strict_pass','measured_strict_fail_retained']:continue
 dest=target/folder.name
 assert folder.resolve().is_relative_to(group.resolve())
 assert not dest.exists()
 folder.rename(dest);saved.append(dict(original=str(folder),preserved=str(dest),status=r.get('status','invalid-or-missing-record')))
print(json.dumps(saved))
(O/'recovery_diskfull_0645.json').write_text(json.dumps(saved,indent=2)+'\n')
