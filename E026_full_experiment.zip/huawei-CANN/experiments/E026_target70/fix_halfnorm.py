from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
code=(H/'HALFNORM/code/kernel.asc').read_text(encoding='utf-8')
old='''                    for(uint32_t i=0;i<count;++i)
                        Mul(out_[i*stride_].template ReinterpretCast<half>(),out_[i*stride_].template ReinterpretCast<half>(),br[i*16],128,halfParts,{1,1,0,8,8,0});'''
new='''                    for(uint32_t i=0;i<count;++i) {
                        auto v=out_[i*stride_].template ReinterpretCast<half>();
                        if(d_>=128)Mul(v,v,br[i*16],128,static_cast<uint8_t>(d_/128),{1,1,0,8,8,0});
                        if(d_%128)Mul(v[d_/128*128],v[d_/128*128],br[i*16],d_%128,1,{1,1,0,8,8,0});
                    }'''
assert code.count(old)==1;code=code.replace(old,new)
name='HALFNORM2';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BROAD2',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='FP32 square reduction and FP16 normalization; corrected 128-lane tail for widths that are padded to 64 lanes',numerical_change=True,fix_of='HALFNORM'),indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='halfnorm2quick'" not in s:
 s+='''
if mode=='halfnorm2quick':
 items=[small[i] for i in [5,6,7,9,13]]+[('hn_321',257,321,'float16'),('hn_1023',257,1023,'float16')]
 check('halfnorm2_check',items,['BROAD2','HALFNORM2'])
 pairs('halfnorm2_pairs',[small[i] for i in [5,6,7,9]],'BROAD2','HALFNORM2',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_halfnorm2.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
