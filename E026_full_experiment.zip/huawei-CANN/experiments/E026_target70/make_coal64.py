from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'FACC/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('__global__ __vector__ void single_row_64_custom(');z=base.index('template <typename T>\n__global__ __vector__ void single_row_custom',a)
part=base[a:z]
part=part.replace('    float epsilon)\n{','    float epsilon,uint32_t inputGap,uint32_t parameterGap,uint32_t quadGap)\n{',1)
old='''    DataCopy(xt, xgm, copy);
    DataCopy(rt, rgm, copy);
    SetFlag<HardEvent::MTE2_V>(0);
    DataCopy(gt, ggm, copy);
    DataCopy(bt, bgm, copy);
    SetFlag<HardEvent::MTE2_V>(1);'''
new='''    constexpr uint32_t bytes=64*sizeof(T);
    if(quadGap!=0xffffffffU && quadGap%32==0 && quadGap/32<=65535) {
        DataCopyParams four={4,static_cast<uint16_t>(bytes/32),static_cast<uint16_t>(quadGap/32),static_cast<uint16_t>((256-bytes)/32)};
        DataCopy(xt,xgm,four);
        SetFlag<HardEvent::MTE2_V>(0);SetFlag<HardEvent::MTE2_V>(1);
    } else {
        if(inputGap!=0xffffffffU && inputGap%32==0 && inputGap/32<=65535) {
            DataCopyParams pair={2,static_cast<uint16_t>(bytes/32),static_cast<uint16_t>(inputGap/32),static_cast<uint16_t>((256-bytes)/32)};
            DataCopy(xt,xgm,pair);
        } else {DataCopy(xt,xgm,copy);DataCopy(rt,rgm,copy);}
        SetFlag<HardEvent::MTE2_V>(0);
        if(parameterGap!=0xffffffffU && parameterGap%32==0 && parameterGap/32<=65535) {
            DataCopyParams pair={2,static_cast<uint16_t>(bytes/32),static_cast<uint16_t>(parameterGap/32),static_cast<uint16_t>((256-bytes)/32)};
            DataCopy(gt,ggm,pair);
        } else {DataCopy(gt,ggm,copy);DataCopy(bt,bgm,copy);}
        SetFlag<HardEvent::MTE2_V>(1);
    }'''
assert part.count(old)==1;part=part.replace(old,new)
code=base[:a]+part+base[z:]
a=code.index('    if (rows == 1 && d == 64) {',code.index('extern "C" void run_kernel'))
z=code.index('    if (rows == 1',a+15)
part=code[a:z]
helper='''        const uint64_t bytes=input.dtype==0?256:128;
        const auto pairGap=[](GM_ADDR first,GM_ADDR second,uint64_t n)->uint32_t {
            const uintptr_t p=reinterpret_cast<uintptr_t>(first),q=reinterpret_cast<uintptr_t>(second);
            if(q<p || static_cast<uint64_t>(q-p)<n || static_cast<uint64_t>(q-p)-n>=0xffffffffULL)return 0xffffffffU;
            return static_cast<uint32_t>(static_cast<uint64_t>(q-p)-n);
        };
        const uint32_t inputGap=pairGap(x,residual,bytes),parameterGap=pairGap(gamma,bias,bytes);
        const uint32_t middleGap=pairGap(residual,gamma,bytes);
        const uint32_t quadGap=(inputGap==parameterGap && inputGap==middleGap)?inputGap:0xffffffffU;
'''
part=part.replace('    if (rows == 1 && d == 64) {','    if (rows == 1 && d == 64) {\n'+helper,1)
assert part.count('x, residual, gamma, bias, output, epsilon);')==3
part=part.replace('x, residual, gamma, bias, output, epsilon);','x, residual, gamma, bias, output, epsilon,inputGap,parameterGap,quadGap);')
code=code[:a]+part+code[z:]
name='COAL64';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
sha=hashlib.sha256(code.encode()).hexdigest()
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='FACC',source_sha256=sha,change='Single D64: combine 2 or 4 GM reads with strided DMA only when actual pointer gaps satisfy all limits; fallback to independent reads; tensor arithmetic identical',numerical_change=False),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='coal64quick'" not in s:
 s+='''
if mode=='coal64quick':
 items=[small[0],('m64_float',1,64,'float32'),('m64_bf16',1,64,'bfloat16')]
 check('coal64_check',items,['FACC','COAL64'])
 pairs('coal64_pairs',items,'FACC','COAL64',blocks=2)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_coal64.tar.gz','w:gz') as t:
 for q in [H/name,p]:t.add(q,arcname=q.relative_to(H.parents[1]))
print(name,sha)
