from pathlib import Path
import json,sys
O=Path('/mnt/workspace/addrms_results/E026')
for name in sys.argv[1:]:
 print(name)
 for r in json.loads((O/name/'records.json').read_text()):
  if not r['strict']['pass']:print(json.dumps({k:r.get(k) for k in ['case_id','variant','strict']},ensure_ascii=False))
