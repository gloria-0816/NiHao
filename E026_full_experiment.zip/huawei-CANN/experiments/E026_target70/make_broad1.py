from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent
code=(H/'FPBROAD/code/kernel.asc').read_text()
half=(H/'HALFWIDE/code/kernel.asc').read_text()
a=half.index('template <typename T,bool BlockReduction>\nclass HalfWidePipelineKernel {');z=half.index('class StaticHalfRowsKernel {',a)
inc=half[a:z]+(H/'bf_static8.inc').read_text()
code=code.replace('class StaticHalfRowsKernel {',inc+'\nclass StaticHalfRowsKernel {',1)
anchor='    if(input.dtype==0 && d>1536 && d<=4096'
launch='''    if(input.dtype==1 && d>1024 && d<=4096 && rows>=static_cast<uint64_t>(blockNum)*4) {
        half_wide_pipeline_custom<half,false><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
    if(input.dtype==2 && d>4096 && d<=8192 && rows>=static_cast<uint64_t>(blockNum)*4) {
        bf_static8_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert anchor in code;code=code.replace(anchor,launch+anchor,1)
single=(H/'SINGLEOV/code/kernel.asc').read_text()
a=code.index('__global__ __vector__ void single_row_64_custom');z=code.index('template <typename T>\n__global__ __vector__ void single_row_custom',a)
b=single.index('__global__ __vector__ void single_row_64_custom');e=single.index('template <typename T>\n__global__ __vector__ void single_row_custom',b)
code=code[:a]+single[b:e]+code[z:]
name='BROAD1';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'HALFAFF2','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'FP32 medium-wide triple buffering; FP16 wider batch pipeline; BF16 static 8K; D64 overlap','merged':['FPBROAD','HALFWIDE','BFS8','SINGLEOV'],'numerical_change':True},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='broad1quick'" not in s:
 s+='''
if mode=='broad1quick':
 check('broad1_check',small+[('halfwide_1536',257,1536,'float16'),('halfwide_4095',257,4095,'float16'),('fpbroad_4095',257,4095,'float32')],['HALFAFF2','BROAD1'])
 pairs('broad1_pairs',[small[10],small[14]],'HALFAFF2','BROAD1',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
