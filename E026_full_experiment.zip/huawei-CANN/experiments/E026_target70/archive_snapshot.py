from pathlib import Path
import tarfile,json,hashlib,io
root=Path('/mnt/workspace/addrms_results/E026')
target=root.parent/'E026_snapshot_20261012_0308.tar.gz'
manifest=[];skipped=[]
with tarfile.open(target,'w:gz') as archive:
    for path in sorted(root.rglob('*')):
        if not path.is_file() or path.suffix not in {'.json','.csv','.log','.txt'}:continue
        data=path.read_bytes()
        if path.suffix=='.json':
            try:json.loads(data)
            except (ValueError,UnicodeError):
                skipped.append(str(path.relative_to(root)));continue
        relative=str(path.relative_to(root))
        entry=tarfile.TarInfo(relative);entry.size=len(data);entry.mode=0o600
        archive.addfile(entry,io.BytesIO(data))
        manifest.append(dict(path=relative,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    obj=dict(description='Consistent byte snapshot; a running group may be incomplete. Read group complete/summary files to establish completion.',files=manifest,skipped_invalid_json=skipped)
    data=(json.dumps(obj,indent=2)+'\n').encode()
    entry=tarfile.TarInfo('_snapshot_manifest.json');entry.size=len(data);entry.mode=0o600
    archive.addfile(entry,io.BytesIO(data))
print(json.dumps(dict(files=len(manifest),skipped=skipped,bytes=target.stat().st_size,archive=str(target))))
