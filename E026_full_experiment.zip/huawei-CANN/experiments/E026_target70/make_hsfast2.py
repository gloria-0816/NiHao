from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'HSFAST/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('__global__ __vector__ void half_single_fast_custom');z=base.index('class FloatBroadTripleKernel {',a)
s=base[a:z]
s=s.replace('LocalTensor<float> sum(TPosition::VECCALC,1536,8),one(TPosition::VECCALC,1568,8);\n    LocalTensor<half> inv(TPosition::VECCALC,1600,16),broadcast(TPosition::VECCALC,1632,16);','LocalTensor<float> sum(TPosition::VECCALC,1536,8),work(TPosition::VECCALC,1568,64);')
start=s.index('    Sqrt<float,false>');end=s.index('    WaitFlag<HardEvent::MTE2_V>(1);',start)
s=s[:start]+'''    Sqrt<float,false>(sum,sum,static_cast<uint64_t>(0),1,{1,1,0,0});PipeBarrier<PIPE_V>();
    ResetMask();SetMaskNorm();Brcb(work,sum,1,{1,8});PipeBarrier<PIPE_V>();
    SetVectorMask<float,MaskMode::NORMAL>(64);
    Div<float,false>(y,y,work,static_cast<uint64_t>(0),1,{1,1,0,8,8,0});PipeBarrier<PIPE_V>();
    ResetMask();SetMaskNorm();Cast(xt,y,RoundMode::CAST_RINT,64);PipeBarrier<PIPE_V>();
    SetVectorMask<half,MaskMode::NORMAL>(64);
'''+s[end:]
code=base[:a]+s+base[z:]
name='HSFAST2';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFP3',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='Single-row FP16 D64; FP32 normalization; native half affine FMA avoids gamma and bias casts; mask reuse; avoids rounding RMS inverse to half',numerical_change=True,ub_end_bytes=1824),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='hsfast2quick'" not in s:
 s+='''
if mode=='hsfast2quick':
 items=[small[0]]+[('hsfast_seed_'+str(seed),1,64,'float16') for seed in [1,2,3,7,11,19,23,31,53,101,202,303,404,505,606,707,808,909,1001,1021]]
 items += [('hsfast_'+p,1,64,'float16',p) for p in ['zeros','checkerboard','cancel','wide_range','specials']]
 check('hsfast2_check',items,['BFP3','HSFAST2'])
 pairs('hsfast2_pairs',[small[0]],'BFP3','HSFAST2',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_hsfast2.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
