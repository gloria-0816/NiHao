from pathlib import Path
import hashlib,json,re,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'BROAD3/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class PipelineBatch9Kernel {');z=base.index('template <typename T,bool BlockReduction>',a)
s=base[a:z].replace('PipelineBatch9Kernel','HalfSharedResidualKernel')
s=re.sub(r'\bT\b','half',s);s=s.replace('BlockReduction','true')
s=s.replace('batch_=9408/stride_;','batch_=12800/stride_;')
start=s.index('        x_[0]=LocalTensor');end=s.index('    }\n    __aicore__ inline void Process()',start)
s=s[:start]+'''        x_[0]=LocalTensor<half>(TPosition::VECIN,0,12800);
        x_[1]=LocalTensor<half>(TPosition::VECIN,25728,12800);
        r_[0]=LocalTensor<half>(TPosition::VECIN,51456,12800);
        r_[1]=r_[0];
        tmp_=LocalTensor<float>(TPosition::VECCALC,51456,12800);
        y_=LocalTensor<float>(TPosition::VECCALC,102784,12800);
        out_=LocalTensor<half>(TPosition::VECOUT,154112,12800);
        gh_=LocalTensor<half>(TPosition::VECIN,179840,1024);
        bh_=LocalTensor<half>(TPosition::VECIN,182016,1024);
        work_=LocalTensor<float>(TPosition::VECCALC,184192,1600);
        sums_=LocalTensor<float>(TPosition::VECCALC,190720,128);
'''+s[end:]
old='''        Prefetch(begin_,0);
        if(begin_+batch_<end_) Prefetch(begin_+batch_,1);'''
new=old+'\n        PrefetchResidual(begin_);'
assert s.count(old)==1;s=s.replace(old,new)
old='            WaitFlag<HardEvent::MTE2_V>(slot);'
assert s.count(old)==1;s=s.replace(old,old+'\n            WaitFlag<HardEvent::MTE2_V>(2);')
old='''            Muls(sums_,sums_,invD_,count); PipeBarrier<PIPE_V>();'''
new='''            // Square reduction is the last reader of the residual/square
            // alias. Refill it while the independent affine stage runs.
            if(row+batch_<end_) {
                SetFlag<HardEvent::V_MTE2>(2);WaitFlag<HardEvent::V_MTE2>(2);
                PrefetchResidual(row+batch_);
            }
'''+old
assert s.count(old)==1;s=s.replace(old,new)
old='''        DataCopyPad(r_[slot],rgm_[row*d_],copy,pad);
        SetFlag<HardEvent::MTE2_V>(slot);'''
new='''        SetFlag<HardEvent::MTE2_V>(slot);'''
assert s.count(old)==1;s=s.replace(old,new)
anchor='    GlobalTensor<half> xgm_,rgm_,ggm_,bgm_,outgm_;'
fun='''    __aicore__ inline void PrefetchResidual(uint64_t row) {
        const uint32_t count=Min(batch_,static_cast<uint32_t>(end_-row));
        DataCopyExtParams copy={static_cast<uint16_t>(count),d_*2,0,Gap(),0};
        DataCopyPadExtParams<half> pad={};pad.isPad=false;
        DataCopyPad(r_[0],rgm_[row*d_],copy,pad);
        SetFlag<HardEvent::MTE2_V>(2);
    }
'''
assert s.count(anchor)==1;s=s.replace(anchor,fun+anchor)
entry='''__global__ __vector__ void half_shared_residual_custom(GM_ADDR x,GM_ADDR r,GM_ADDR g,
    GM_ADDR b,GM_ADDR out,uint64_t rows,uint32_t d,float invD,float eps) {
    InitSocState();HalfSharedResidualKernel op;op.Init(x,r,g,b,out,rows,d,invD,eps);op.Process();
}
'''
code=base.replace('class StaticHalfRowsKernel {',s+entry+'\nclass StaticHalfRowsKernel {',1)
anchor='    if (rows >= static_cast<uint64_t>(blockNum)*4 && ((input.dtype==1'
launch='''    if(input.dtype==1 && d>=321 && d<=1024 && rows>=static_cast<uint64_t>(blockNum)*4) {
        half_shared_residual_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert code.count(anchor)==1;code=code.replace(anchor,launch+anchor)
name='SHAREDH';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BROAD3',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='FP16 321..1024 width shares residual DMA and float square scratch after reduction, retains two X slots and increases capacity 9408 to 12800',numerical_change=False,ub_end_bytes=191232,intentional_alias='r_[0], r_[1], tmp_ share bytes 51456..102656 with explicit V_MTE2/MTE2_V lifetime fences'),indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='sharedhquick'" not in s:
 s+='''
if mode=='sharedhquick':
 items=[small[i] for i in [5,6,7,9]]+[('sharedh_321',257,321,'float16'),('sharedh_1023',257,1023,'float16')]
 check('sharedh_check',items,['BROAD3','SHAREDH'])
 pairs('sharedh_pairs',[small[i] for i in [5,6,7,9]],'BROAD3','SHAREDH',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_sharedh.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
