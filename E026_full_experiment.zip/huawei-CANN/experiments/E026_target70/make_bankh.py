from pathlib import Path
import json,hashlib,shutil,re
H=Path(__file__).resolve().parent;base=(H/'HALFAFF2/code/kernel.asc').read_text()
a=base.index('class PipelineBatch9Kernel {');z=base.index('template <typename T,bool BlockReduction>',a);s=base[a:z]
sites={37888:38144,56832:57088,75776:76288,113536:114048,151296:151808,170240:170752,174464:174976,178688:179200,180864:181376,183040:183552,191360:191872}
for old,new in sites.items():
 pattern=re.compile(r'(LocalTensor<[^>]+>\(TPosition::\w+,)'+str(old)+r'(,)')
 s,n=pattern.subn(lambda m:m.group(1)+str(new)+m.group(2),s)
 assert n==1,(old,n)
code=base[:a]+s+base[z:]
name='BANKH';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'HALFAFF2','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'move FP16 residual input start by 256B; X and R occupy different modulo-512 bank groups; preserve affine and arithmetic','ub_end_bytes':192384,'numerical_change':False,'offset_changes':sites},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='bankhquick'" not in s:
 s+='''
if mode=='bankhquick':
 check('bankh_check',[small[i] for i in [5,6,7,9,13]],['HALFAFF2','BANKH'])
 pairs('bankh_pairs',[small[i] for i in [5,6,7,9]],'HALFAFF2','BANKH',blocks=2)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
