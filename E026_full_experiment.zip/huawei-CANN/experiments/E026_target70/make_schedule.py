from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'FACC/code/kernel.asc').read_text(encoding='utf-8')
old='''    const uint32_t blockNum = static_cast<uint32_t>(
        rows < static_cast<uint64_t>(availableCoreNum) ? rows : availableCoreNum);'''
assert base.count(old)==1
variants=[('SCHED1',base.replace('__global__ __vector__','__schedmode__(1) __global__ __vector__'),
           'Batch-mode launch for existing pure vector kernels, retain launch counts and all arithmetic')]
for factor in [2,4]:
 name='BFV'+str(factor*40)
 new='''    const uint32_t physicalBlocks = static_cast<uint32_t>(
        rows < static_cast<uint64_t>(availableCoreNum) ? rows : availableCoreNum);
    // Independent rows only; no cross-core synchronization in these paths.
    const bool bfVirtual = input.dtype==2 && (d==128 || (d>4096 && d<=8192)) &&
        rows>=static_cast<uint64_t>(physicalBlocks)*32 && physicalBlocks<=65535/FACTOR;
    const uint32_t blockNum=bfVirtual?physicalBlocks*FACTOR:physicalBlocks;'''.replace('FACTOR',str(factor))
 variants.append((name,base.replace(old,new),f'For large independent BF16 rows only, launch {factor} times physical AIV count as logical blocks; no batch mode or cross-core sync; preserve per-row arithmetic and prefetch'))
for name,code,change in variants:
 dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n');sha=hashlib.sha256(code.encode()).hexdigest()
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='FACC',source_sha256=sha,change=change,numerical_change=False,references=['https://www.hiascend.com/doc_center/source/en/CANNCommunityEdition/900/programug/Ascendcopdevg/atlas_ascendc_10_00021.html','https://asc.gitcode.com/guide/programming_guide/language_extension/simd_builtin_keywords.html']),indent=2)+'\n')
 print(name,sha)
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='sched1quick'" not in s:
 s+='''
if mode=='sched1quick':
 check('sched1_check',small,['FACC','SCHED1'])
 pairs('sched1_pairs',[small[i] for i in [0,1,3,4,10,13]],'FACC','SCHED1',blocks=1)
if mode=='bfvquick':
 items=[('bfv_'+str(r)+'_'+str(d),r,d,'bfloat16') for r,d in [(1279,128),(1280,128),(1281,128),(3841,128),(1280,8192),(1281,8192),(161,8192)]]
 check('bfv_check',items,['FACC','BFV80','BFV160'])
if mode=='bfvfull':
 for v in ['BFV80','BFV160']:
  for i,r,d in [(14,3317760,128),(15,117760,8192)]:
   group=v.lower()+'_full'+str(i)+'_pairs';target=Path('/home/developer/addrms_archived/E026')/group
   target.mkdir(exist_ok=True);link=OUT/group
   if link.exists():assert link.is_symlink() and link.resolve()==target.resolve()
   else:link.symlink_to(target,target_is_directory=True)
   pairs(group,[('bffull'+str(i),r,d,'bfloat16')],'FACC',v,blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_schedule.tar.gz','w:gz') as t:
 for q in [H/'SCHED1',H/'BFV80',H/'BFV160',p]:t.add(q,arcname=q.relative_to(H.parents[1]))
