from pathlib import Path
import shutil,json,hashlib
H=Path(__file__).resolve().parent
base=(H/'BASE/code/kernel.asc').read_text()
a=base.index('__global__ __vector__ void single_row_64_custom')
b=base.index('template <typename T>\n__global__ __vector__ void single_row_custom',a)
s=base[a:b]
ops={
 '    Add(y, y, tmp, 64);':'    SetMaskNorm();SetVectorMask<float,MaskMode::NORMAL>(64);\n    Add<float,false>(y,y,tmp,0,1,{1,1,1,8,8,8});',
 '    Mul(tmp, y, y, 64);':'    Mul<float,false>(tmp,y,y,0,1,{1,1,1,8,8,8});',
 '    WholeReduceSum(sum, tmp, 64, 1, 1, 1, 8);':'    WholeReduceSum<float,false>(sum,tmp,0,1,1,1,8);',
 '    Muls(sum, sum, 0.015625f, 1);':'    SetVectorMask<float,MaskMode::NORMAL>(1);\n    Muls<float,false>(sum,sum,0.015625f,0,1,{1,1,0,0});',
 '    Adds(sum, sum, epsilon, 1);':'    Adds<float,false>(sum,sum,epsilon,0,1,{1,1,0,0});',
 '    Sqrt(sum, sum, 1);':'    Sqrt<float,false>(sum,sum,0,1,{1,1,0,0});',
 '    Div(y, y, work, static_cast<uint64_t>(64), static_cast<uint8_t>(1),\n        {1, 1, 0, 8, 8, 0});':'    SetVectorMask<float,MaskMode::NORMAL>(64);\n    Div<float,false>(y,y,work,0,1,{1,1,0,8,8,0});',
 '    Mul(y, y, gf, 64);':'    Mul<float,false>(y,y,gf,0,1,{1,1,1,8,8,8});',
 '    Add(y, y, bf, 64);':'    Add<float,false>(y,y,bf,0,1,{1,1,1,8,8,8});\n    ResetMask();SetMaskNorm();',
}
for old,new in ops.items():
 assert old in s,old
 s=s.replace(old,new,1)
code=base[:a]+s+base[b:]
d=H/'MASK64/code';shutil.copytree(H/'BASE/code',d,dirs_exist_ok=True)
(d/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'MASK64/manifest.json').write_text(json.dumps({'variant':'MASK64','source_sha256':hashlib.sha256(code.encode()).hexdigest()},indent=2)+'\n')
f=H/'run_round.py';s=f.read_text()
if "mode=='mask64quick'" not in s:
 s+='''
if mode=='mask64quick':
 check('mask64_check',[small[0],('m64_float',1,64,'float32'),('m64_bf16',1,64,'bfloat16')],['BASE','MASK64'])
 pairs('mask64_pairs',[small[0]],'BASE','MASK64',blocks=2)
'''
 f.write_text(s,encoding='utf-8',newline='\n')
print(hashlib.sha256(code.encode()).hexdigest())
