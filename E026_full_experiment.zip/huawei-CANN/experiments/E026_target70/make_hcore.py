from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'BFPN4/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class StaticHalfRowsKernel {');z=base.index('// At most four FP32',a);s=base[a:z]
start=s.index('        x_ = LocalTensor<half>');end=s.index('\n    }',start)
s=s[:start]+'''        x_ = LocalTensor<half>(TPosition::VECIN,0,16384);
        r_ = LocalTensor<half>(TPosition::VECIN,32896,16384);
        y_ = LocalTensor<float>(TPosition::VECCALC,65792,16384);
        tmp_ = y_;
        gh_ = LocalTensor<half>(TPosition::VECIN,131456,256);
        bh_ = LocalTensor<half>(TPosition::VECIN,132096,256);
        work_ = LocalTensor<float>(TPosition::VECCALC,132736,2048);
        sums_ = LocalTensor<float>(TPosition::VECCALC,141056,64);'''+s[end:]
s=s.replace('LocalTensor<float> y_,tmp_,gamma_,bias_,work_,sums_;','LocalTensor<float> y_,tmp_,work_,sums_;')
common=base[:a]+s+base[z:]
anchor='''        static_half_rows_custom<<<blockNum,nullptr,stream>>>(
            x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'''
assert common.count(anchor)==1
names=[]
for cores in [16,24,32,40]:
 name='HCORE'+str(cores);names.append(name)
 new=f'''        const uint32_t preferred=blockNum<{cores}?blockNum:{cores};
        // Keep at most 63 rows: 64 rows at D256 would need 256 reduction repeats.
        const uint32_t shortCores=rows<=static_cast<uint64_t>(preferred)*63?preferred:blockNum;
        static_half_rows_custom<<<shortCores,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'''
 code=common.replace(anchor,new)
 dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFPN4',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change=f'FP16 short static rows use one in-place FP32 square tile, larger UB capacity, prefer {cores} cores when <=63 rows/core; retain original row-range route guard',static_ub_end=141312,numerical_change=False),indent=2)+'\n')
 print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='hcorequick'" not in s:
 s+='''
if mode=='hcorequick':
 items=[small[3],('hc_65',257,65,'float16'),('hc_1008',1008,255,'float16'),('hc_1009',1009,255,'float16'),('hc_1280',1280,256,'float16')]
 for v in ['HCORE16','HCORE24','HCORE32','HCORE40']:
  check(v.lower()+'_check',items,['BFPN4',v])
  pairs(v.lower()+'_pairs',[small[3]],'BFPN4',v,blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
c=H/'run_cold.py';s=c.read_text(encoding='utf-8')
if "mode=='flatnh'" not in s:
 s=s.replace("records=[]", "if mode=='flatnh':items=[(r.small[3],['BFPN4','FLATNH','FLATNH','BFPN4'])]\nrecords=[]",1)
 c.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_hcore.tar.gz','w:gz') as tar:
 for target in [*[H/n for n in names],p,c]:tar.add(target,arcname=target.relative_to(H.parents[1]))
