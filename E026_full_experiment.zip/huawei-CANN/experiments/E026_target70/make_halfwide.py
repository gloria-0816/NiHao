from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent;base=(H/'HALFAFF2/code/kernel.asc').read_text()
a=base.index('class PipelineBatch9Kernel {');z=base.index('template <typename T,bool BlockReduction>',a)
s=base[a:z].replace('PipelineBatch9Kernel','HalfWidePipelineKernel').replace('batch_=9408/stride_;','batch_=9216/stride_;')
ia=s.index('        x_[0]=LocalTensor');iz=s.index('    }\n    __aicore__ inline void Process()',ia)
s=s[:ia]+'''        x_[0]=LocalTensor<T>(TPosition::VECIN,0,9216);
        x_[1]=LocalTensor<T>(TPosition::VECIN,18560,9216);
        r_[0]=LocalTensor<T>(TPosition::VECIN,37120,9216);
        r_[1]=LocalTensor<T>(TPosition::VECIN,55680,9216);
        y_=LocalTensor<float>(TPosition::VECCALC,74240,9216);
        tmp_=LocalTensor<float>(TPosition::VECCALC,111232,9216);
        out_=LocalTensor<T>(TPosition::VECOUT,148224,9216);
        gh_=LocalTensor<T>(TPosition::VECIN,166784,4096);
        bh_=LocalTensor<T>(TPosition::VECIN,175104,4096);
        work_=LocalTensor<float>(TPosition::VECCALC,183424,1152);
        sums_=LocalTensor<float>(TPosition::VECCALC,188160,128);
        // This kernel is instantiated only for half, whose affine uses gh/bh.
        // Float parameter fields are never read in that compile-time branch.
        gamma_=y_;bias_=tmp_;
'''+s[iz:]
old='                Duplicate(y_[d_/64*64],0.0f,tail,count,1,stride_/8);'
new='                for(uint32_t i=0;i<count;++i)Duplicate(y_[i*stride_+d_/64*64],0.0f,tail,1,1,8);'
assert old in s;s=s.replace(old,new,1)
inc='template <typename T,bool BlockReduction>\n'+s+'''template <typename T,bool BlockReduction>
__global__ __vector__ void half_wide_pipeline_custom(GM_ADDR x,GM_ADDR r,GM_ADDR g,GM_ADDR b,GM_ADDR out,
    uint64_t rows,uint32_t d,float invD,float eps)
{
    InitSocState();HalfWidePipelineKernel<T,BlockReduction> op;op.Init(x,r,g,b,out,rows,d,invD,eps);op.Process();
}
'''
code=base.replace('class StaticHalfRowsKernel {',inc+'\nclass StaticHalfRowsKernel {',1)
anchor='    if (rows >= static_cast<uint64_t>(blockNum)*4 && ((input.dtype==1'
launch='''    if(input.dtype==1 && d>1024 && d<=4096 && rows>=static_cast<uint64_t>(blockNum)*4) {
        half_wide_pipeline_custom<half,false><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert anchor in code;code=code.replace(anchor,launch+anchor,1)
name='HALFWIDE';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'HALFAFF2','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'FP16 width 1025..4096 batch pipeline, 9216 capacity, native affine, no float parameter buffers','ub_end_bytes':188672,'numerical_change':True},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='halfwidequick'" not in s:
 s+='''
if mode=='halfwidequick':
 items=[('halfwide_'+str(d),257,d,'float16') for d in [1025,1536,2048,2049,4095,4096]]
 check('halfwide_check',items,['HALFAFF2','HALFWIDE'])
 pairs('halfwide_pairs',[items[i] for i in [1,2,4,5]],'HALFAFF2','HALFWIDE',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
