from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent;base=(H/'HALFAFF2/code/kernel.asc').read_text()
code=(H/'FPSTATIC3/code/kernel.asc').read_text()
a=code.index('class FloatStaticTripleKernel {');z=code.index('template <typename T>\nclass RetainedAccKernel {',a);s=code[a:z]
s=s.replace('FloatStaticTripleKernel','FloatBroadTripleKernel').replace('float_static_triple_custom','float_broad_triple_custom')
s=s.replace('batch_=13312/stride_;','batch_=12288/stride_;')
ia=s.index('        x_[0]=LocalTensor');iz=s.index('    }\n    __aicore__ inline void Process()',ia)
s=s[:ia]+'''        x_[0]=LocalTensor<float>(TPosition::VECIN,0,12288);
        x_[1]=LocalTensor<float>(TPosition::VECIN,49280,12288);
        r_=LocalTensor<float>(TPosition::VECIN,98560,12288);
        gf_=LocalTensor<float>(TPosition::VECIN,147840,4096);
        bf_=LocalTensor<float>(TPosition::VECIN,164352,4096);
        work_=LocalTensor<float>(TPosition::VECCALC,180864,1536);
        sums_=LocalTensor<float>(TPosition::VECCALC,187136,32);
'''+s[iz:]
code=base.replace('class StaticHalfRowsKernel {',s+'\nclass StaticHalfRowsKernel {',1)
anchor='    if (rows >= static_cast<uint64_t>(blockNum)*4 && ((input.dtype==1'
launch='''    if(input.dtype==0 && d>1536 && d<=4096 && rows>=static_cast<uint64_t>(blockNum)*4) {
        float_broad_triple_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert anchor in code;code=code.replace(anchor,launch+anchor,1)
name='FPBROAD';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'HALFAFF2','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'FP32 broad width 1537..4096 shared residual and direct X output, capacity 12288; FP16/BF16 unchanged','ub_end_bytes':187264},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='fpbroadquick'" not in s:
 s+='''
if mode=='fpbroadquick':
 items=[small[10],small[12]]+[('fpbroad_'+str(d),257,d,'float32') for d in [1537,2048,3136,3200,4095,4096]]
 check('fpbroad_check',items,['HALFAFF2','FPBROAD'])
 pairs('fpbroad_pairs',[small[10],small[12],('fpbroad_4095',257,4095,'float32')],'HALFAFF2','FPBROAD',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
