from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'BROAD2/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class StaticHalfRowsKernel {');z=base.index('class ShortFloatPartitionKernel {',a);s=base[a:z]
old='''        ToFloat<half>(y_,x_,active); ToFloat<half>(tmp_,r_,active);
        ToFloat<half>(gamma_,gh_,d_); ToFloat<half>(bias_,bh_,d_);
        PipeBarrier<PIPE_V>();
        Add(y_,y_,tmp_,active); PipeBarrier<PIPE_V>();'''
new='''        Add(x_,x_,r_,active);PipeBarrier<PIPE_V>();
        ToFloat<half>(y_,x_,active);PipeBarrier<PIPE_V>();'''
assert s.count(old)==1;s=s.replace(old,new)
start=s.index('        Brcb(work_,sums_');end=s.index('        SetFlag<HardEvent::V_MTE3>(1);',start)
s=s[:start]+'''        auto scales=work_[768].ReinterpretCast<half>();
        auto broadcast=work_.ReinterpretCast<half>();
        Cast(scales,sums_,RoundMode::CAST_RINT,count_);PipeBarrier<PIPE_V>();
        Brcb(broadcast,scales,static_cast<uint8_t>(rms/8),{1,8});PipeBarrier<PIPE_V>();
        const uint8_t repeats=static_cast<uint8_t>(count_);
        const uint8_t rb=static_cast<uint8_t>(stride_/16);
        for(uint32_t col=0;col<d_;col+=128)
            Mul(x_[col],x_[col],broadcast,static_cast<uint64_t>(d_-col<128?d_-col:128),repeats,{1,1,0,rb,rb,1});
        PipeBarrier<PIPE_V>();
        for(uint32_t col=0;col<d_;col+=128)
            FusedMulAdd(x_[col],gh_[col],bh_[col],static_cast<uint64_t>(d_-col<128?d_-col:128),repeats,{1,1,1,rb,0,0});
        PipeBarrier<PIPE_V>();
'''+s[end:]
s=s.replace('DataCopyPad(outgm_[begin_*d_],r_,out);','DataCopyPad(outgm_[begin_*d_],x_,out);')
code=base[:a]+s+base[z:];name='HSHORTN';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BROAD2',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='FP16 short rows retain half residual; FP32 square/norm reduction and native half scale/Mul/FMA; remove input parameter casts and final output cast',numerical_change=True),indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='hshortnquick'" not in s:
 s+='''
if mode=='hshortnquick':
 items=[small[3]]+[('hshortn_'+str(d),767,d,'float16') for d in [64,65,127,128,129,192,255,256]]
 check('hshortn_check',items,['BROAD2','HSHORTN'])
 pairs('hshortn_pairs',[small[3]],'BROAD2','HSHORTN',blocks=2)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_hshortn.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
