from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'BFPN4/code/kernel.asc').read_text(encoding='utf-8')
code=base.replace('class StaticHalfRowsKernel {',(H/'flat_native_half.inc').read_text(encoding='utf-8')+'\nclass StaticHalfRowsKernel {',1)
old='''        static_half_rows_custom<<<blockNum,nullptr,stream>>>(
            x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'''
new='''        const uint32_t stride=(d+63)/64*64;
        if(d%64!=0 && (stride&(stride-1))==0)
            flat_native_half_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        else static_half_rows_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'''
assert code.count(old)==1;code=code.replace(old,new)
name='FLATNH';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFPN4',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='FP16 short non-aligned rows: continuous GM input, native packed residual Add, one half Gather, in-place FP32 square, native half affine and row output DMA',static_ub_end=153856,numerical_change=False),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='flatnhquick'" not in s:
 s+='''
if mode=='flatnhquick':
 items=[small[3]]+[('flatnh_'+str(d),767,d,'float16') for d in [65,97,127,193,197,241,255]]
 check('flatnh_check',items,['BFPN4','FLATNH'])
 pairs('flatnh_pairs',[small[3]],'BFPN4','FLATNH',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_flatnh.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
