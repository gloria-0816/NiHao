from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'BFSIP/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class LongHalfRetainedKernel {');z=base.index('__global__ __vector__ void long_half_retained_custom',a)
s=base[a:z].replace('class LongHalfRetainedKernel {','template <uint32_t FixedD>\nclass FixedLongHalfRetainedKernel {')
s=s.replace('rows_=rows;d_=d;invD_=invD;eps_=eps;','rows_=rows;d_=FixedD;invD_=FixedD==16384?0.00006103515625f:0.000030517578125f;eps_=eps;')
s=s.replace('const uint32_t chunks=(d_+8191)/8192;','constexpr uint32_t chunks=FixedD/8192;')
s=s.replace('DataCopyExtParams cp={1,n*2,0,0,0};DataCopyPad(outgm_[row*d_+col],y_[col],cp);','DataCopy(outgm_[row*FixedD+col],y_[col],8192);')
old='''        const uint32_t n=Min(8192,d_-col);DataCopyExtParams cp={1,n*2,0,0,0};
        DataCopyPadExtParams<half> pad={};pad.isPad=false;
        if(parameter) {
            DataCopyPad(x_[slot],ggm_[col],cp,pad);DataCopyPad(r_[slot],bgm_[col],cp,pad);
        } else {
            DataCopyPad(x_[slot],xgm_[row*d_+col],cp,pad);DataCopyPad(r_[slot],rgm_[row*d_+col],cp,pad);
        }
'''
new='''        if(parameter) {
            DataCopy(x_[slot],ggm_[col],8192);DataCopy(r_[slot],bgm_[col],8192);
        } else {
            DataCopy(x_[slot],xgm_[row*FixedD+col],8192);DataCopy(r_[slot],rgm_[row*FixedD+col],8192);
        }
'''
assert s.count(old)==1;s=s.replace(old,new)
s+='''template <uint32_t FixedD>
__global__ __vector__ void fixed_long_half_custom(GM_ADDR x,GM_ADDR r,GM_ADDR g,GM_ADDR b,GM_ADDR out,
    uint64_t rows,float eps) {
    InitSocState();FixedLongHalfRetainedKernel<FixedD> op;
    op.Init(x,r,g,b,out,rows,FixedD,FixedD==16384?0.00006103515625f:0.000030517578125f,eps);op.Process();
}

'''
code=base[:a]+s+base[a:]
anchor='    if(input.dtype==1 && d>8192 && d<=32768) {'
assert code.count(anchor)==1
code=code.replace(anchor,'''    if(input.dtype==1 && (d==16384 || d==32768)) {
        if(d==16384) fixed_long_half_custom<16384><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,epsilon);
        else fixed_long_half_custom<32768><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,epsilon);
        return;
    }
'''+anchor)
dest=H/'LCONST2/code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
sha=hashlib.sha256(code.encode()).hexdigest()
(H/'LCONST2/manifest.json').write_text(json.dumps(dict(variant='LCONST2',parent='BFSIP',source_sha256=sha,
 change='Compile-time D16384/D32768 retained FP16 paths with fixed 8192-element aligned DataCopy; arithmetic and synchronization retained',numerical_change=False),indent=2)+'\n')
p=H/'run_round.py';q=p.read_text(encoding='utf-8')
if "mode=='lconst2quick'" not in q:
 q+='''
if mode=='lconst2quick':
 items=[small[4],('lconst_16k',3,16384,'float16'),('lconst_32k_many',41,32768,'float16'),('lconst_fallback',3,24576,'float16')]
 check('lconst2_check',items,['BFSIP','LCONST2'])
 pairs('lconst2_pairs',items[:2],'BFSIP','LCONST2',blocks=1)
'''
 p.write_text(q,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_lconst2.tar.gz','w:gz') as tar:
 for target in [H/'LCONST2',p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(sha)
