from pathlib import Path,PurePosixPath
import tarfile,json,hashlib
H=Path(__file__).resolve().parent
arc=H/'E026_incremental_20261012_0655.tar.gz'
out=H/'cloud_results';out.mkdir(exist_ok=True)
new=same=0
with tarfile.open(arc,'r:gz') as t:
 manifest=json.load(t.extractfile('_snapshot_manifest.json'))
 for e in manifest['files']:
  rel=PurePosixPath(e['path']);assert not rel.is_absolute() and '..' not in rel.parts
  dst=out.joinpath(*rel.parts)
  data=t.extractfile(e['path']).read()
  assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256']
  if dst.exists() and hashlib.sha256(dst.read_bytes()).hexdigest()==e['sha256']:same+=1;continue
  dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data);new+=1
 (H/'archive_0655_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
result=dict(archive=arc.name,archive_sha256=hashlib.sha256(arc.read_bytes()).hexdigest(),files=len(manifest['files']),new=new,unchanged=same)
(H/'archive_0655_verified.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
