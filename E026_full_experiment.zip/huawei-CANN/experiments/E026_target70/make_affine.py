from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent
base=(H/'BASE/code/kernel.asc').read_text()
a=base.index('class PipelineBatch9Kernel {');z=base.index('template <typename T,bool BlockReduction>',a)
s=base[a:z]
start=s.index('            const uint8_t step=stride_/8;')
end=s.index('            if(pendingOutput)',start)
replacement='''            if(count<=parts) {
                for(uint32_t i=0;i<count;++i)
                    Mul(y_[i*stride_],y_[i*stride_],work_[i*8],64,parts,{1,1,0,8,8,0});
                PipeBarrier<PIPE_V>();
                for(uint32_t i=0;i<count;++i)
                    FusedMulAdd(y_[i*stride_],gamma_,bias_,d_);
            } else {
                const uint8_t step=stride_/8;
                for(uint32_t col=0;col<d_;col+=64)
                    Mul(y_[col],y_[col],work_,Min(64,d_-col),count,{1,1,0,step,step,1});
                PipeBarrier<PIPE_V>();
                for(uint32_t col=0;col<d_;col+=64)
                    FusedMulAdd(y_[col],gamma_[col],bias_[col],Min(64,d_-col),count,{1,1,1,step,0,0});
            }
            PipeBarrier<PIPE_V>();
'''
code=base[:a]+s[:start]+replacement+s[end:]+base[z:]
name='AFFROW';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'source_sha256':hashlib.sha256(code.encode()).hexdigest()},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
inc=(H/'long_acc.inc').read_text().replace('class LongAccKernel','class LongAccSerialKernel').replace('long_acc_custom','long_acc_serial_custom').replace('LongAccKernel<T>','LongAccSerialKernel<T>')
inc=inc.replace('            Prefetch(start,0,0);Prefetch(start,4096,1);','')
inc=inc.replace('                WaitFlag<HardEvent::MTE2_V>(slot);','                PipeBarrier<PIPE_ALL>();\n                Prefetch(start,col,slot);\n                WaitFlag<HardEvent::MTE2_V>(slot);',1)
ia=inc.index('                if(col+8192<d_)');ib=inc.index('                Add(y,y,tmp_,4096);',ia)
inc=inc[:ia]+inc[ib:]
inc=inc.replace('            Parameter(0);','')
inc=inc.replace('                WaitFlag<HardEvent::MTE2_V>(0);','                PipeBarrier<PIPE_ALL>();\n                Parameter(col);\n                WaitFlag<HardEvent::MTE2_V>(0);',1)
ia=inc.index('                if(col+4096<d_)');ib=inc.index('                auto y=y_[col];',ia)
inc=inc[:ia]+inc[ib:]
inc=inc.replace('SetFlag<HardEvent::MTE3_V>(3);pending=true;','SetFlag<HardEvent::MTE3_V>(3);WaitFlag<HardEvent::MTE3_V>(3);pending=false;')
(H/'long_acc_serial.inc').write_text(inc,encoding='utf-8',newline='\n')
code=base.replace('class StaticHalfRowsKernel {',inc+'\nclass StaticHalfRowsKernel {',1)
anchor='    if (input.dtype == 1 && d <= 256'
launch='''    if((input.dtype==1 || input.dtype==2) && d>8192 && d<=32768 && d%4096==0) {
        if(input.dtype==1)long_acc_serial_custom<half><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        else long_acc_serial_custom<bfloat16_t><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
code=code.replace(anchor,launch+anchor,1)
name='LONGACC2';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'source_sha256':hashlib.sha256(code.encode()).hexdigest(),'notes':'serial fences to diagnose overlapping raw input/output storage'},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='affrowquick'" not in s:
 s+='''
if mode=='affrowquick':
 check('affrow_check',[small[i] for i in [5,6,7,9]],['BASE','AFFROW'])
 pairs('affrow_pairs',[small[9]],'BASE','AFFROW',blocks=1)
if mode=='longacc2quick':
 check('longacc2_check',[small[4],('longacc_16',41,16384,'float16'),('longacc_24',3,24576,'float16')],['BASE','LONGACC2'])
 pairs('longacc2_pairs',[small[4]],'BASE','LONGACC2',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
