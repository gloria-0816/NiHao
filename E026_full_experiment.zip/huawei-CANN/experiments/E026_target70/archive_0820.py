from pathlib import Path
import tarfile,json,hashlib,io
root=Path('/mnt/workspace/addrms_results/E026')
target=Path('/home/developer/addrms_archived/E026_incremental_20261012_0820.tar.gz')
assert not target.exists()
prefixes=('bfstripe','bfs1','bfs32','bfs128','bfrr','bfsb','bsbc','flati','pair2','sync2','pairacc','pairsingle','build_BFS','build_BFRR','build_BSBC','build_FLATI','build_PAIR2','build_SYNC2','build_PAIRACC')
files=[]
for group in root.iterdir():
 if group.is_dir() and group.name.startswith(prefixes):
  files.extend(p for p in group.rglob('*') if p.is_file() and p.suffix in {'.json','.csv','.log','.txt'})
files.extend(p for p in root.glob('*.json'))
for base in [Path('/mnt/workspace'),Path('/home/developer')]:
 for p in base.glob('*.log'):
  if p.name.startswith(('bfstripe','bfrr','bfsb','bsbc','flati','pair2','pairacc')):files.append(p)
manifest=[];skipped=[]
with tarfile.open(target,'w:gz') as archive:
 for path in sorted(set(files)):
  data=path.read_bytes()
  relative=path.relative_to(root).as_posix() if path.is_relative_to(root) else '_queue_logs/'+path.name
  if path.suffix=='.json':
   try:json.loads(data)
   except (ValueError,UnicodeError):skipped.append(relative);continue
  entry=tarfile.TarInfo(relative);entry.size=len(data);entry.mode=0o600
  archive.addfile(entry,io.BytesIO(data))
  manifest.append(dict(path=relative,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 data=(json.dumps(dict(description='BF16 scheduling, gather, paired synchronization and accumulator records; raw tensors retained on cloud',files=manifest,skipped_invalid_json=skipped),indent=2)+'\n').encode()
 entry=tarfile.TarInfo('_snapshot_manifest.json');entry.size=len(data);archive.addfile(entry,io.BytesIO(data))
print(json.dumps(dict(files=len(manifest),bytes=target.stat().st_size,archive=str(target),sha256=hashlib.sha256(target.read_bytes()).hexdigest())))
