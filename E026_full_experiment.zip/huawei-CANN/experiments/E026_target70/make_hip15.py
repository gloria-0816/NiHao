from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'BFPN4/code/kernel.asc').read_text(encoding='utf-8')
code=base.replace('class StaticHalfRowsKernel {',(H/'half_inplace.inc').read_text(encoding='utf-8')+'\nclass StaticHalfRowsKernel {',1)
old='        if(input.dtype==1) pipeline_batch9_custom<half,true><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'
new='        if(input.dtype==1) half_inplace_rows_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'
assert code.count(old)==1;code=code.replace(old,new)
name='HIP15';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFPN4',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='FP16 row batches retain native half residual in input/output ping/pong slots, square in one in-place FP32 tile, increase batch capacity to 14848, prefetch residual early and refill X after its output DMA',static_ub_end=192000,numerical_change=True),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='hip15quick'" not in s:
 s+='''
if mode=='hip15quick':
 items=[small[i] for i in [5,6,7,9]]+[('hip_'+str(d),257,d,'float16') for d in [321,383,384,447,511,512,513,767,1023,1024]]
 check('hip15_check',items,['BFPN4','HIP15'])
 pairs('hip15_pairs',[small[i] for i in [5,6,7,9]],'BFPN4','HIP15',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_hip15.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
