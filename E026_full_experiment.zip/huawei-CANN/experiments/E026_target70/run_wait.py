from pathlib import Path
import sys,json,subprocess,time
H=Path(__file__).resolve().parent;O=Path('/mnt/workspace/addrms_results/E026')
for arg in sys.argv[1:]:
 v,phase=arg.split(':',1)
 if v=='AFTER':
  signal=O/phase if phase.endswith('.json') else O/phase/'summary.json';start=time.monotonic()
  while not signal.exists():
   if time.monotonic()-start>1800:raise TimeoutError(phase)
   time.sleep(5)
  continue
 record=O/f'build_{v}'/'record.json'
 start=time.monotonic()
 while not record.exists():
  if time.monotonic()-start>900:raise TimeoutError(v)
  time.sleep(5)
 assert json.loads(record.read_text())['returncode']==0
 subprocess.run(['python3',str(H/'run_round.py'),phase],check=True)
