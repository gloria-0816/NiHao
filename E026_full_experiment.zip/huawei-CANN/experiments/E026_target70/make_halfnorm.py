from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'BROAD2/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class PipelineBatch9Kernel {');z=base.index('template <typename T,bool BlockReduction>',a);s=base[a:z]
old='''                Add(x_[slot],x_[slot],r_[slot],active);PipeBarrier<PIPE_V>();
                ToFloat<T>(y_,x_[slot],active);PipeBarrier<PIPE_V>();'''
new='''                if(pendingOutput) WaitFlag<HardEvent::MTE3_V>(3);
                Add(out_,x_[slot],r_[slot],active);PipeBarrier<PIPE_V>();
                ToFloat<T>(y_,out_,active);PipeBarrier<PIPE_V>();'''
assert s.count(old)==1;s=s.replace(old,new)
start=s.index('            const uint32_t rms=(count+7)/8*8;')
end=s.index('            SetFlag<HardEvent::V_MTE3>(2);',start)
s=s[:start]+'''            const uint32_t rms=(count+7)/8*8;
            if(CompactParameterType<T>::value) {
                auto scales=work_[1536].template ReinterpretCast<half>();
                auto br=work_.template ReinterpretCast<half>();
                Cast(scales,sums_,RoundMode::CAST_RINT,count);PipeBarrier<PIPE_V>();
                Brcb(br,scales,rms/8,{1,8});PipeBarrier<PIPE_V>();
                const uint32_t halfParts=(d_+127)/128;
                if(count<=halfParts) {
                    for(uint32_t i=0;i<count;++i)
                        Mul(out_[i*stride_].template ReinterpretCast<half>(),out_[i*stride_].template ReinterpretCast<half>(),br[i*16],128,halfParts,{1,1,0,8,8,0});
                } else {
                    for(uint32_t col=0;col<d_;col+=128)
                        Mul(out_[col].template ReinterpretCast<half>(),out_[col].template ReinterpretCast<half>(),br,Min(128,d_-col),count,
                            {1,1,0,static_cast<uint8_t>(stride_/16),static_cast<uint8_t>(stride_/16),1});
                }
                PipeBarrier<PIPE_V>();
                if(count<=halfParts) {
                    for(uint32_t i=0;i<count;++i)FusedMulAdd(out_[i*stride_].template ReinterpretCast<half>(),gh_.template ReinterpretCast<half>(),bh_.template ReinterpretCast<half>(),d_);
                } else {
                    for(uint32_t col=0;col<d_;col+=128)
                        FusedMulAdd(out_[col].template ReinterpretCast<half>(),gh_[col].template ReinterpretCast<half>(),bh_[col].template ReinterpretCast<half>(),Min(128,d_-col),count,
                            {1,1,1,static_cast<uint8_t>(stride_/16),0,0});
                }
                PipeBarrier<PIPE_V>();
            } else {
                Brcb(work_,sums_,rms/8,{1,8});PipeBarrier<PIPE_V>();
                if(count<=parts) {
                    for(uint32_t i=0;i<count;++i)
                        Mul(y_[i*stride_],y_[i*stride_],work_[i*8],64,parts,{1,1,0,8,8,0});
                    PipeBarrier<PIPE_V>();
                    for(uint32_t i=0;i<count;++i)FusedMulAdd(y_[i*stride_],gamma_,bias_,d_);
                } else {
                    const uint8_t step=stride_/8;
                    for(uint32_t col=0;col<d_;col+=64)
                        Mul(y_[col],y_[col],work_,Min(64,d_-col),count,{1,1,0,step,step,1});
                    PipeBarrier<PIPE_V>();
                    for(uint32_t col=0;col<d_;col+=64)
                        FusedMulAdd(y_[col],gamma_[col],bias_[col],Min(64,d_-col),count,{1,1,1,step,0,0});
                }
                PipeBarrier<PIPE_V>();
                if(pendingOutput)WaitFlag<HardEvent::MTE3_V>(3);
                FromFloat<T>(out_,y_,active);PipeBarrier<PIPE_V>();
            }
'''+s[end:]
code=base[:a]+s+base[z:];name='HALFNORM';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BROAD2',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='FP32 norm reduction retained; FP16 reciprocal scale and normalization with retained half residual in output buffer; remove full float normalization and output conversion',numerical_change=True),indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='halfnormquick'" not in s:
 s+='''
if mode=='halfnormquick':
 items=[small[i] for i in [5,6,7,9,13]]+[('hn_321',257,321,'float16'),('hn_1023',257,1023,'float16')]
 check('halfnorm_check',items,['BROAD2','HALFNORM'])
 pairs('halfnorm_pairs',[small[i] for i in [5,6,7,9]],'BROAD2','HALFNORM',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_halfnorm.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
