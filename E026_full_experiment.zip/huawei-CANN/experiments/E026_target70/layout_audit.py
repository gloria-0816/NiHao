import re,json
from pathlib import Path
H=Path(__file__).resolve().parent
cases=[('SHORT8B','ShortFloatPartitionKernel',4),('SHORT16B','ShortFloatPartitionKernel',4),('SHORT32B','ShortFloatPartitionKernel',4),('FPSTATIC2','FloatStaticBatchKernel',4),('RES1','PipelineBatch9Kernel',2),('BANKH','PipelineBatch9Kernel',2),('FPBROAD','FloatBroadTripleKernel',4),('BFS8','BFloatStatic8Kernel',2),('HALFNORM2','PipelineBatch9Kernel',2),('HSHORTN','StaticHalfRowsKernel',2),('LONGH','LongHalfRetainedKernel',2)]
results=[]
for variant,cls,tbytes in cases:
 s=(H/variant/'code/kernel.asc').read_text();a=s.index('class '+cls+' {');z=s.index('inline void Process()',a);s=s[a:z]
 regions=[]
 for name,dtype,start,count in re.findall(r'(\w+(?:\[[01]\])?)\s*=\s*LocalTensor<(float|T|half|bfloat16_t)>\(TPosition::\w+,\s*(\d+),\s*(\d+)\)',s):
  start=int(start);end=start+int(count)*(4 if dtype=='float' else tbytes)
  regions.append(dict(name=name,start=start,end=end))
 assert regions,(variant,cls)
 regions.sort(key=lambda r:r['start'])
 for x,y in zip(regions,regions[1:]):assert x['end']<=y['start'],(variant,x,y)
 assert regions[-1]['end']<=196608,(variant,regions[-1])
 results.append(dict(variant=variant,regions=regions,disjoint=True,within_192_KiB=True))
(H/'static_layout_audit.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ['variant','disjoint','within_192_KiB']} for r in results]))
