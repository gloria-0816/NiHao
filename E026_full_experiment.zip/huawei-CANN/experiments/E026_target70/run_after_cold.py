import time,sys,subprocess
from pathlib import Path
H=Path(__file__).resolve().parent;O=Path('/mnt/workspace/addrms_results/E026')
group,mode=sys.argv[1:]
signal=O/group/('complete.json' if group.startswith('cold_') else 'summary.json');start=time.monotonic()
while not signal.exists():
 if time.monotonic()-start>1800:raise TimeoutError(group)
 time.sleep(5)
subprocess.run(['python3',str(H/'run_cold.py'),mode],check=True)
