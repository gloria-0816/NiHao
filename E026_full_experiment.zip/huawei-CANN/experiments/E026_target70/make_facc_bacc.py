from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'LSQM/code/kernel.asc').read_text(encoding='utf-8')
a=base.index('class FloatBroadTripleKernel {');z=base.index('template <typename T,bool BlockReduction>',a)
s=base[a:z]
old='''            const uint32_t parts=stride_/64,partialStride=(parts+7)/8*8;
            for(uint32_t i=0;i<count;++i)
                WholeReduceSum(work_[i*partialStride],tmp[i*stride_],64,parts,1,1,8);
            PipeBarrier<PIPE_V>();
            WholeReduceSum(sums_,work_,parts,count,1,1,partialStride/8);PipeBarrier<PIPE_V>();'''
new='''            const uint32_t parts=stride_/64;
            // Accumulate corresponding lanes across chunks before the final
            // within-vector reduction, as in the installed RMSNorm helper.
            Duplicate(work_,0.0f,count*64);PipeBarrier<PIPE_V>();
            for(uint32_t i=0;i<count;++i)
                Add(work_[i*64],tmp[i*stride_],work_[i*64],64,parts,{1,1,1,0,8,0});
            PipeBarrier<PIPE_V>();
            WholeReduceSum(sums_,work_,64,count,1,1,8);PipeBarrier<PIPE_V>();'''
assert s.count(old)==1;s=s.replace(old,new)
facc=base[:a]+s+base[z:]
a=base.index('    __aicore__ inline void ComputeWholeRow(');z=base.index('    __aicore__ inline float ComputeInvRms(',a)
s=base[a:z]
old='        ReduceSum(scalar, tmp, work, padded);'
new='''        if(SingleSlotWholePrefetchType<T>::value && d_>4096) {
            Duplicate(work,0.0f,64);PipeBarrier<PIPE_V>();
            Add(work,tmp,work,64,padded/64,{1,1,1,0,8,0});PipeBarrier<PIPE_V>();
            WholeReduceSum(scalar,work,64,1,1,1,8);
        } else ReduceSum(scalar,tmp,work,padded);'''
assert s.count(old)==1;s=s.replace(old,new)
bacc=base[:a]+s+base[z:]
for name,code,change in [('FACC',facc,'FP32 wide rows use cross-repeat lane accumulation followed by one WholeReduceSum'),('BACC8',bacc,'BF16 whole rows D4097..8192 use cross-repeat lane accumulation in the existing queue path')]:
 dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
 sha=hashlib.sha256(code.encode()).hexdigest()
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='LSQM',source_sha256=sha,change=change,numerical_change=True,reference='Installed CANN rms_norm_base.h ReduceSumFP32: Add repeats to same 64-lane accumulator, then WholeReduceSum'),indent=2)+'\n')
 print(name,sha)
p=H/'run_round.py';q=p.read_text(encoding='utf-8')
if "mode=='faccquick'" not in q:
 q+='''
if mode=='faccquick':
 items=[small[i] for i in [10,12]]+[('facc_'+str(d),641,d,'float32') for d in [1537,2048,3073,3136,4095,4096]]
 check('facc_check',items,['LSQM','FACC'])
 pairs('facc_pairs',[small[i] for i in [10,12]],'LSQM','FACC',blocks=1)
if mode=='baccquick':
 items=[small[14]]+[('bacc_'+str(d),161,d,'bfloat16') for d in [4097,6144,8191]]
 check('bacc_check',items,['LSQM','BACC8'])
 pairs('bacc_pairs',[small[14]],'LSQM','BACC8',blocks=1)
if mode=='bacclarge':
 check('bacc_large_check',[('bf8large',8192,8192,'bfloat16')],['LSQM','BACC8'])
 pairs('bacc_large_pairs',[('bf8large',8192,8192,'bfloat16')],'LSQM','BACC8',blocks=1)
'''
 p.write_text(q,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_facc_bacc.tar.gz','w:gz') as t:
 for target in [H/'FACC',H/'BACC8',p]:t.add(target,arcname=target.relative_to(H.parents[1]))
