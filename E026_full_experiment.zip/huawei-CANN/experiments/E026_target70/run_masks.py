from pathlib import Path
import json,subprocess,time
H=Path(__file__).resolve().parent;O=Path('/mnt/workspace/addrms_results/E026')
for v,phase in [('MASK64B','mask64bquick'),('MASKBATCH','maskbatchquick')]:
    record=O/f'build_{v}'/'record.json'
    while not record.exists():time.sleep(5)
    assert json.loads(record.read_text())['returncode']==0
    subprocess.run(['python3',str(H/'run_round.py'),phase],check=True)
