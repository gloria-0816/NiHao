from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent
base=(H/'LSQM/code/kernel.asc').read_text(encoding='utf-8')
inc=(H/'half_native_mixed.inc').read_text(encoding='utf-8')
inc=inc.replace('HalfNativeMixedKernel','HalfLaneAccKernel').replace('half_native_mixed_custom','half_lane_acc_custom')
inc=inc.replace('batch_=23040/stride_','batch_=27648/stride_')
old='''        x_[0]=LocalTensor<half>(TPosition::VECIN,0,23040);
        x_[1]=LocalTensor<half>(TPosition::VECIN,46208,23040);
        square_=LocalTensor<float>(TPosition::VECCALC,92416,23040);r_=square_.ReinterpretCast<half>();
        gh_=LocalTensor<half>(TPosition::VECIN,184704,1024);
        bh_=LocalTensor<half>(TPosition::VECIN,186880,1024);
        work_=LocalTensor<float>(TPosition::VECCALC,189056,1536);
        sums_=LocalTensor<float>(TPosition::VECCALC,195328,128);'''
new='''        x_[0]=LocalTensor<half>(TPosition::VECIN,0,27648);
        x_[1]=LocalTensor<half>(TPosition::VECIN,55424,27648);
        r_=LocalTensor<half>(TPosition::VECIN,110848,27648);
        gh_=LocalTensor<half>(TPosition::VECIN,166272,1024);
        bh_=LocalTensor<half>(TPosition::VECIN,168448,1024);
        square_=LocalTensor<float>(TPosition::VECCALC,170624,4608);
        work_=LocalTensor<float>(TPosition::VECCALC,189184,1536);
        sums_=LocalTensor<float>(TPosition::VECCALC,195456,128);'''
assert inc.count(old)==1;inc=inc.replace(old,new)
a=inc.index('            // The raw residual is dead.');z=inc.index('            if(row+batch_<end_) {',a)
inc=inc[:a]+'''            Duplicate(square_,0.0f,count*64);PipeBarrier<PIPE_V>();
            const uint8_t step=stride_/16;
            // Each row keeps a 64-lane FP32 accumulator. Mixed VMLA reads
            // one half-precision chunk per row, without a full square tile.
            for(uint32_t col=0;col<stride_;col+=64) {
                MulAddDst<float,half>(square_,x_[slot][col],x_[slot][col],64,count,{1,1,1,8,step,step});
                PipeBarrier<PIPE_V>();
            }
            WholeReduceSum(sums_,square_,64,count,1,1,8);PipeBarrier<PIPE_V>();
'''+inc[z:]
anchor='class BFloatShortInplaceKernel {';assert base.count(anchor)==1
hmacc=base.replace(anchor,inc+'\n'+anchor)
old='if(input.dtype==1) pipeline_batch9_custom<half,true><<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);'
assert hmacc.count(old)==1
hmacc=hmacc.replace(old,'if(input.dtype==1) half_lane_acc_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);')
# Mixed multiply-add accumulation for native FP32 wide rows.
a=base.index('class FloatBroadTripleKernel {');z=base.index('template <typename T,bool BlockReduction>',a)
s=base[a:z]
a1=s.index('            Mul(tmp,y,y,active);');z1=s.index('            if(row+batch_<end_) {',a1)
s=s[:a1]+'''            const uint32_t parts=stride_/64;
            Duplicate(work_,0.0f,count*64);PipeBarrier<PIPE_V>();
            for(uint32_t i=0;i<count;++i)
                MulAddDst<float,float>(work_[i*64],y[i*stride_],y[i*stride_],64,parts,{1,1,1,0,8,8});
            PipeBarrier<PIPE_V>();
            WholeReduceSum(sums_,work_,64,count,1,1,8);PipeBarrier<PIPE_V>();
'''+s[z1:]
fmacc=base[:a]+s+base[z:]
for name,code,change,ub in [('HMACC',hmacc,'FP16 D321..1024: mixed VMLA accumulates directly to 64 FP32 lanes per row; no full square tile, capacity 27648',195968),('FMACC',fmacc,'FP32 wide rows: direct VMLA accumulation to 64 lanes per row replaces full square tile and partial-reduction levels',187264)]:
 dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
 (dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
 sha=hashlib.sha256(code.encode()).hexdigest()
 (H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='LSQM',source_sha256=sha,change=change,static_ub_end=ub,numerical_change=True),indent=2)+'\n')
 print(name,sha)
p=H/'run_round.py';q=p.read_text(encoding='utf-8')
if "mode=='hmaccquick'" not in q:
 q+='''
if mode=='hmaccquick':
 items=[small[i] for i in [5,6,7,9]]+[('hip_'+str(d),257,d,'float16') for d in [321,383,384,447,511,512,513,767,1023,1024]]
 check('hmacc_check',items,['LSQM','HMACC'])
 pairs('hmacc_pairs',[small[i] for i in [5,6,7,9]],'LSQM','HMACC',blocks=1)
if mode=='fmaccquick':
 items=[small[i] for i in [10,12]]+[('facc_'+str(d),641,d,'float32') for d in [1537,2048,3073,3136,4095,4096]]
 check('fmacc_check',items,['LSQM','FMACC'])
 pairs('fmacc_pairs',[small[i] for i in [10,12]],'LSQM','FMACC',blocks=1)
'''
 p.write_text(q,encoding='utf-8',newline='\n')
c=H/'run_cold.py';q=c.read_text(encoding='utf-8')
if "mode=='facc'" not in q:
 q=q.replace('records=[]',"if mode=='facc':items=[(r.small[10],['LSQM','FACC','FACC','LSQM']),(r.small[12],['FACC','LSQM','LSQM','FACC'])]\nrecords=[]",1)
 c.write_text(q,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_macc.tar.gz','w:gz') as t:
 for target in [H/'HMACC',H/'FMACC',p,c]:t.add(target,arcname=target.relative_to(H.parents[1]))
