from pathlib import Path
import shutil,json,hashlib
H=Path(__file__).resolve().parent
base=(H/'HALFBR/code/kernel.asc').read_text()
a=base.index('class StaticHalfRowsKernel {')
b=base.index('__global__ __vector__ void static_half_rows_custom',a)
section=base[a:b].replace('StaticHalfRowsKernel','FlatInputHalfKernel').replace('8192','6144')
offsets={'16512':12416,'33024':37248,'65920':61952,'98816':86656,'100096':87936,
         '101248':89088,'101888':89728,'102528':139776,'106752':144000}
for key,val in offsets.items():section=section.replace(', '+key+',',', '+str(val)+',')
section=section.replace('        y_ = LocalTensor<float>', '''        padded_ = LocalTensor<half>(TPosition::VECCALC,24832,6144);
        indices_ = LocalTensor<int32_t>(TPosition::VECCALC,90368,6144);
        rowindex_ = LocalTensor<int32_t>(TPosition::VECCALC,115072,6144);
        y_ = LocalTensor<float>''',1)
old='''        DataCopyExtParams batch = {static_cast<uint16_t>(count_),d_*2,0,gap,0};'''
assert old in section
section=section.replace(old,'        DataCopyExtParams batch = {1,count_*d_*2,0,0,0};',1)
old='''        SetFlag<HardEvent::MTE2_V>(0); WaitFlag<HardEvent::MTE2_V>(0);
        ToFloat<half>(y_,x_,active); ToFloat<half>(tmp_,r_,active);
        ToFloat<half>(gamma_,gh_,d_); ToFloat<half>(bias_,bh_,d_);
        PipeBarrier<PIPE_V>();'''
new='''        SetFlag<HardEvent::MTE2_V>(0);
        // Build byte offsets with integer vector operations while DMA runs.
        // Dispatch ensures stride is a power of two.
        uint32_t shift=0;for(uint32_t s=stride_;s>1;s>>=1)++shift;
        CreateVecIndex(indices_,static_cast<int32_t>(0),active);PipeBarrier<PIPE_V>();
        ShiftRight(rowindex_,indices_,static_cast<int32_t>(shift),active);PipeBarrier<PIPE_V>();
        Muls(rowindex_,rowindex_,static_cast<int32_t>(stride_-d_),active);PipeBarrier<PIPE_V>();
        Sub(indices_,indices_,rowindex_,active);PipeBarrier<PIPE_V>();
        ShiftLeft(indices_,indices_,static_cast<int32_t>(1),active);PipeBarrier<PIPE_V>();
        WaitFlag<HardEvent::MTE2_V>(0);
        auto addresses=indices_.ReinterpretCast<uint32_t>();
        Gather(padded_,x_,addresses,0,active);PipeBarrier<PIPE_V>();
        ToFloat<half>(y_,padded_,active);PipeBarrier<PIPE_V>();
        Gather(padded_,r_,addresses,0,active);PipeBarrier<PIPE_V>();
        ToFloat<half>(tmp_,padded_,active);
        ToFloat<half>(gamma_,gh_,d_);ToFloat<half>(bias_,bh_,d_);
        PipeBarrier<PIPE_V>();'''
assert old in section
section=section.replace(old,new,1)
old='''        DataCopyExtParams out = {static_cast<uint16_t>(count_),d_*2,gap,0,0};
        DataCopyPad(outgm_[begin_*d_],r_,out);'''
new='''        uint64_t kept=0;
        GatherMask(x_,r_,static_cast<uint8_t>(7),true,d_,
            {1,static_cast<uint16_t>(count_),static_cast<uint16_t>(stride_/16),0},kept);
        PipeBarrier<PIPE_V>();
        SetFlag<HardEvent::V_MTE3>(1); WaitFlag<HardEvent::V_MTE3>(1);
        DataCopyExtParams out = {1,count_*d_*2,0,0,0};
        DataCopyPad(outgm_[begin_*d_],x_,out);'''
assert old in section
section=section.replace(old,new,1)
section=section.replace('LocalTensor<half> x_,r_,gh_,bh_;','LocalTensor<half> x_,r_,gh_,bh_,padded_;\n    LocalTensor<int32_t> indices_,rowindex_;')
entry='''__global__ __vector__ void flat_input_half_custom(GM_ADDR x,GM_ADDR r,GM_ADDR g,
    GM_ADDR b,GM_ADDR out,uint64_t rows,uint32_t d,float invD,float eps)
{
    InitSocState();FlatInputHalfKernel op;op.Init(x,r,g,b,out,rows,d,invD,eps);op.Process();
}
'''
code=base[:a]+section+entry+'\n'+base[a:]
anchor='    if (input.dtype == 1 && d <= 256'
launch='''    const uint32_t flatStride=(d+63)/64*64;
    if(input.dtype==1 && d<=256 && (flatStride&(flatStride-1))==0 &&
        rows>=static_cast<uint64_t>(blockNum)*4 && rows<=static_cast<uint64_t>(blockNum)*24) {
        flat_input_half_custom<<<blockNum,nullptr,stream>>>(x,residual,gamma,bias,output,rows,d,inverseD,epsilon);
        return;
    }
'''
assert anchor in code
code=code.replace(anchor,launch+anchor,1)
d=H/'FLATH/code';shutil.copytree(H/'BASE/code',d,dirs_exist_ok=True)
(d/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/'FLATH/manifest.json').write_text(json.dumps({'variant':'FLATH','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'ub_end_bytes':144128},indent=2)+'\n')
f=H/'run_round.py';s=f.read_text()
if "mode=='flathquick'" not in s:
 s+='''
if mode=='flathquick':
 check('flath_check',[small[3],('flath_65',767,65,'float16'),('flath_255',767,255,'float16')],['BASE','FLATH'])
 pairs('flath_pairs',[small[3]],'BASE','FLATH',blocks=1)
'''
 f.write_text(s,encoding='utf-8',newline='\n')
print(hashlib.sha256(code.encode()).hexdigest())
