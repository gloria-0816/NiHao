from pathlib import Path
import json,hashlib,shutil,tarfile
H=Path(__file__).resolve().parent;base=(H/'BFSIP/code/kernel.asc').read_text(encoding='utf-8')
code=base.replace('class LongHalfRetainedKernel {',(H/'long_sync4.inc').read_text(encoding='utf-8')+'\nclass LongHalfRetainedKernel {',1)
anchor='    if(input.dtype==1 && d>8192 && d<=32768) {'
branch='''    if(input.dtype==1 && d>8192 && d<=32768 && d%256==0 &&
        rows<=static_cast<uint64_t>(availableCoreNum)/4) {
        long_half_sync4_custom<<<static_cast<uint32_t>(rows*4),nullptr,stream>>>(x,residual,gamma,bias,output,d,inverseD,epsilon);
        return;
    }
'''
assert code.count(anchor)==1;code=code.replace(anchor,branch+anchor)
name='SYNC4';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps(dict(variant=name,parent='BFSIP',source_sha256=hashlib.sha256(code.encode()).hexdigest(),change='FP16 aligned long rows use 4 cores per row in one batch-mode launch and two hardware SyncAll barriers; temporary FP32 partials occupy 128 bytes inside allocated output row, then are overwritten after all readers finish',static_ub_end=117504,numerical_change=True,references=['https://www.hiascend.com/doc_center/source/zh/canncommercial/900/API/ascendcopapi/atlasascendc_api_07_0204.html','https://asc.gitcode.com/guide/programming_guide/language_extension/simd_builtin_keywords.html']),indent=2)+'\n')
p=H/'run_round.py';s=p.read_text(encoding='utf-8')
if "mode=='sync4quick'" not in s:
 s+='''
if mode=='sync4quick':
 items=[('split_one',1,32768,'float16'),('split_two',2,16384,'float16'),small[4],('sync4_8448',3,8448,'float16'),('sync4_24576',10,24576,'float16'),('sync4_fallback',11,32768,'float16')]
 check('sync4_check',items,['BFSIP','SYNC4'])
 pairs('sync4_pairs',[small[4],items[0],items[1]],'BFSIP','SYNC4',blocks=1)
if mode=='sync4edge':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='sync4_'+pattern;case(cid,8,32768,'float16',pattern);items.append((cid,8,32768,'float16'))
 check('sync4_edge',items,['BFSIP','SYNC4'])
'''
 p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(H/'upload_sync4.tar.gz','w:gz') as tar:
 for target in [H/name,p]:tar.add(target,arcname=target.relative_to(H.parents[1]))
print(name,hashlib.sha256(code.encode()).hexdigest())
