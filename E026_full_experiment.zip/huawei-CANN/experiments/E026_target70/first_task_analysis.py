from pathlib import Path
import csv,json,statistics
O=Path('/mnt/workspace/addrms_results/E026')
result={}
for group in ['fpbroad_pairs','broad2_pairs','fpstatic3_pairs','comboa_pairs']:
    rows=[]
    for p in sorted((O/group).glob('*/record.json')):
        rec=json.loads(p.read_text());tasks=[]
        for f in (p.parent/'profile').rglob('op_summary*.csv'):
            with f.open(encoding='utf-8-sig') as h:tasks.extend(csv.DictReader(h))
        tasks.sort(key=lambda x:float(x['Task Start Time(us)']))
        if tasks:
            t=[float(x['Task Duration(us)']) for x in tasks]
            rows.append(dict(run=p.parent.name,case=rec['case_id'],variant=rec['variant'],first_task_us=t[0],warm_median_us=statistics.median(t[-20:]),all_task_times_us=t))
    result[group]=rows
(O/'first_task_analysis.json').write_text(json.dumps(result,indent=2)+'\n')
for g,records in result.items():
    print(g)
    for r in records:print({k:v for k,v in r.items() if k!='all_task_times_us'})
