from pathlib import Path
import shutil,hashlib,json
H=Path(__file__).resolve().parent
code=(H/'SHORT8B/code/kernel.asc').read_text();half=(H/'HALFADD/code/kernel.asc').read_text()
a=code.index('class PipelineBatch9Kernel {');z=code.index('template <typename T,bool BlockReduction>',a)
ha=half.index('class PipelineBatch9Kernel {');hz=half.index('template <typename T,bool BlockReduction>',ha)
code=code[:a]+half[ha:hz]+code[z:]
name='COMBO2';dest=H/name/'code';shutil.copytree(H/'BASE/code',dest,dirs_exist_ok=True)
(dest/'kernel.asc').write_text(code,encoding='utf-8',newline='\n')
(H/name/'manifest.json').write_text(json.dumps({'variant':name,'parent':'SHORT8B','source_sha256':hashlib.sha256(code.encode()).hexdigest(),'change':'FP16 native residual addition; FP32 norm and affine retained'},indent=2)+'\n')
print(name,hashlib.sha256(code.encode()).hexdigest())
p=H/'run_round.py';s=p.read_text()
if "mode=='combo2quick'" not in s:
 s+='''
if mode=='combo2quick':
 check('combo2_check',small,['SHORT8B','COMBO2'])
 pairs('combo2_pairs',[small[5],small[6],small[7],small[9]],'SHORT8B','COMBO2',blocks=1)
'''
 p.write_text(s,encoding='utf-8',newline='\n')
