#!/usr/bin/env bash
set -euo pipefail
bench_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -z "${ASCEND_HOME_PATH:-}" ]]; then
    printf '%s\n' 'ASCEND_HOME_PATH is unset. Source the installed CANN toolkit set_env.sh first.' >&2
    exit 1
fi
# The vendor environment script reads optional variables that may be unset.
set +u
source "${ASCEND_HOME_PATH}/set_env.sh"
set -u
build_dir="${BUILD_DIR:-${bench_dir}/build}"
kernel_source="${KERNEL_SOURCE:-${bench_dir}/../snapshots/addrmsnormbias_submission_681290/code/kernel.asc}"
cmake -S "${bench_dir}" -B "${build_dir}" -DNPU_ARCH="${NPU_ARCH:-dav-2201}" -DKERNEL_SOURCE="${kernel_source}"
cmake --build "${build_dir}" --parallel "${BUILD_JOBS:-4}"
