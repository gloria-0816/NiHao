#!/usr/bin/env python3
"""Write representative manifests, or generate their cases one at a time."""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

from case_data import DTYPES, generate, parse_shape


def manifest(suite, cases, description):
    for index, case in enumerate(cases):
        case.setdefault("seed", 42 + index)
        case.setdefault("epsilon", 1e-5)
        case.setdefault("pattern", "uniform")
        case["tensor_bytes"] = math.prod(case["shape"]) * DTYPES[case["dtype"]].itemsize
    return {"schema_version": 1, "suite": suite, "description": description,
            "source": "Our representative workloads; shapes of the 15 official hidden tests are unknown",
            "cases": cases}


def smoke_matrix():
    cases = []
    # A small, single-row pass crosses every current D-dependent branch and its
    # boundaries. 2D/3D/4D alternate while flattened R remains one.
    dimensions = [64, 65, 127, 128, 129, 192, 255, 256, 257, 511, 512, 513,
                  576, 1023, 1024, 1025, 2048, 4095, 4096, 4097,
                  8191, 8192, 8193, 16384, 32768]
    for dtype in DTYPES:
        for i, d in enumerate(dimensions):
            shape = [1, d] if i % 3 == 0 else ([1, 1, d] if i % 3 == 1 else [1, 1, 1, d])
            cases.append({"id": f"{dtype}_r1_d{d}", "shape": shape, "dtype": dtype,
                          "purpose": "Single-row branch and D boundary coverage"})
        # Small-row static, grouped short rows, static DB, generic low-precision
        # whole rows and retained long rows. 512 rows reaches >=4 rows/core for
        # typical A2 configurations; actual core count is recorded by runner.
        for rows, d in [(2, 64), (2, 513), (2, 4096), (2, 4097), (2, 8193),
                        (512, 64), (512, 512), (512, 513), (512, 576),
                        (512, 1024), (512, 1025), (512, 4096),
                        (128, 4097), (128, 8192), (128, 8193)]:
            cases.append({"id": f"{dtype}_r{rows}_d{d}", "shape": [rows, d], "dtype": dtype,
                          "purpose": "Multiple-row branch coverage and parameter reuse"})
    # A documented, reproducible public template case; never claimed as a hidden case.
    cases.insert(0, {"id": "public_template_fp16_1x64", "shape": [1, 64], "dtype": "float16",
                     "seed": 42, "purpose": "Reproduce the supplied template data recipe"})
    # Append additions to preserve indices/seeds of all pre-existing cases.
    for dtype in DTYPES:
        for rows in (2, 512):
            for d in (65, 4095):
                cases.append({"id": f"{dtype}_r{rows}_d{d}", "shape": [rows, d], "dtype": dtype,
                              "purpose": "Non-aligned small-row reuse, grouped stride and static DB tails"})
    return manifest("smoke", cases, f"{len(cases)} bounded-size cases crossing current dispatch thresholds")


def correctness_matrix():
    cases = []
    for dtype in DTYPES:
        for pattern in ("zeros", "cancel", "checkerboard", "wide_range", "specials"):
            for d in (65, 513, 4097, 8193, 32768):
                for eps in (1e-5, 1e-6):
                    cases.append({"id": f"{dtype}_{pattern}_d{d}_eps{eps:g}",
                                  "shape": [2, 2, d], "dtype": dtype, "pattern": pattern,
                                  "epsilon": eps,
                                  "purpose": "Cancellation, tails, epsilon and special-value propagation"})
    for dtype in DTYPES:
        for d in (65, 513, 4095, 4097, 8193):
            cases.append({"id": f"{dtype}_tail_impulse_d{d}", "shape": [2, 2, d],
                          "dtype": dtype, "pattern": "tail_impulse",
                          "purpose": "Only last valid lane is nonzero; gamma=1, bias=0"})
    return manifest("correctness", cases, f"{len(cases)} numerical and special-value checks; these are not ranking benchmarks")


def stress_matrix():
    cases = []
    # The largest single tensor is 256 MiB; inputs and golden files can occupy
    # substantially more disk. Generator/reference are chunked, not whole-case.
    workloads = [[8192, 64], [8192, 513], [8192, 4096],
                 [8192, 8192], [2048, 32768], [1, 32768, 512],
                 [8, 128, 16, 4096]]
    for dtype in DTYPES:
        for shape in workloads:
            cases.append({"id": f"{dtype}_" + "x".join(map(str, shape)),
                          "shape": shape, "dtype": dtype,
                          "purpose": "Sustained bandwidth, large R and 2D/3D/4D equivalence"})
    return manifest("stress", cases, f"{len(cases)} cases; max 256 MiB per tensor, generate/run/delete one case at a time if space is limited")


def core_boundary_matrix(cores):
    if cores < 1:
        raise ValueError("vector-cores must be positive")
    cases = []
    for dtype in DTYPES:
        for rows in sorted({max(1, cores-1), cores, cores+1, 4*cores-1, 4*cores, 4*cores+1}):
            for d in (64, 512, 513, 1024, 1025, 4096, 4097, 8192, 8193):
                cases.append({"id": f"{dtype}_r{rows}_d{d}", "shape": [rows, d], "dtype": dtype,
                              "purpose": f"Core-count-dependent branch boundary for {cores} vector cores"})
    # Keep original cases first so regeneration does not change their seeds.
    for dtype in DTYPES:
        for rows in sorted({max(1, cores-1), cores, cores+1, 4*cores-1, 4*cores, 4*cores+1}):
            for d in (65, 4095):
                cases.append({"id": f"{dtype}_r{rows}_d{d}", "shape": [rows, d], "dtype": dtype,
                              "purpose": f"Non-aligned R branch and slot-reuse boundary for {cores} vector cores"})
    return manifest("core_boundaries", cases, f"{len(cases)} R threshold cases using the observed device vector-core count {cores}")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    plan = sub.add_parser("manifests", help="write JSON manifests without allocating test tensors")
    plan.add_argument("--cases-dir", type=Path, default=Path(__file__).resolve().parents[1] / "cases")
    plan.add_argument("--vector-cores", type=int, help="add a matrix calibrated to actual device info")
    gen = sub.add_parser("generate", help="generate all or selected cases from a manifest")
    gen.add_argument("--manifest", type=Path, required=True)
    gen.add_argument("--output-root", type=Path, required=True)
    gen.add_argument("--case-id", action="append", help="select IDs; can be repeated")
    gen.add_argument("--limit", type=int, help="generate at most this many selected cases")
    gen.add_argument("--chunk-rows", type=int, default=256)
    gen.add_argument("--max-work-mib", type=float, default=128)
    gen.add_argument("--max-tensor-mib", type=float, default=256)
    gen.add_argument("--diagnostic-fp64", action="store_true")
    gen.add_argument("--overwrite", action="store_true")
    args = parser.parse_args(argv)
    try:
        if args.command == "manifests":
            args.cases_dir.mkdir(parents=True, exist_ok=True)
            suites = [smoke_matrix(), correctness_matrix(), stress_matrix()]
            if args.vector_cores is not None:
                suites.append(core_boundary_matrix(args.vector_cores))
            for suite in suites:
                path = args.cases_dir / (suite["suite"] + ".json")
                path.write_text(json.dumps(suite, indent=2, allow_nan=False) + "\n", encoding="utf-8")
                print(f"{path}: {len(suite['cases'])} cases; max single tensor {max(c['tensor_bytes'] for c in suite['cases'])} bytes")
            return 0
        if args.chunk_rows < 1 or args.max_work_mib <= 0 or (args.limit is not None and args.limit < 1):
            parser.error("chunk-rows/max-work-mib/limit must be positive")
        suite = json.loads(args.manifest.read_text(encoding="utf-8"))
        cases = suite["cases"]
        ids = [case["id"] for case in cases]
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate case IDs in manifest")
        if args.case_id:
            missing = set(args.case_id) - set(ids)
            if missing:
                raise ValueError(f"unknown case IDs: {sorted(missing)}")
            cases = [case for case in cases if case["id"] in args.case_id]
        if args.limit:
            cases = cases[:args.limit]
        for case in cases:
            case_id = case["id"]
            if Path(case_id).name != case_id or case_id in (".", "..") or "/" in case_id or "\\" in case_id:
                raise ValueError(f"unsafe case ID: {case_id}")
            shape = parse_shape(",".join(map(str, case["shape"])))
            generate(args.output_root / case_id, shape, case["dtype"], case.get("seed", 42),
                     case.get("epsilon", 1e-5), case.get("pattern", "uniform"),
                     args.chunk_rows, args.max_work_mib, args.max_tensor_mib,
                     args.diagnostic_fp64, args.overwrite, case_id)
            print(json.dumps({"generated": case_id, "shape": shape, "dtype": case["dtype"]}), flush=True)
        return 0
    except (OSError, ValueError, KeyError, argparse.ArgumentTypeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
