#!/usr/bin/env python3
"""CPU-only tests for BF16 output diagnostics; no NPU intermediate inference."""
import json
import shutil
import tempfile
import unittest
from pathlib import Path

import numpy as np

from case_data import generate, verify
from diagnose_rounding import diagnose, ordered_bf16


class RoundingDiagnosticTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="cann_rounding_diagnostic_")
        self.case = Path(self.temp.name) / "case"
        generate(self.case, [1, 64], "bfloat16", pattern="tail_impulse")
        shutil.copyfile(self.case / "golden_output.bin", self.case / "output.bin")

    def tearDown(self):
        self.temp.cleanup()

    def verdict(self):
        result = verify(self.case)
        (self.case / "verification.json").write_text(json.dumps(result, allow_nan=False), encoding="utf-8")
        return result

    def change_last_word(self, ulps):
        output = np.fromfile(self.case / "output.bin", dtype="<u2")
        output[-1] += ulps
        output.tofile(self.case / "output.bin")

    def test_equal_output_is_strict_pass(self):
        self.verdict()
        result = diagnose(self.case, chunk_elements=7)
        self.assertTrue(result["strict_pass"] and result["verification_matches_rescan"])
        self.assertEqual(result["bitwise_differences"], 0)
        self.assertEqual(result["examples"], [])
        json.dumps(result, allow_nan=False)

    def test_adjacent_difference_keeps_strict_failure_and_midpoint(self):
        self.change_last_word(1)
        self.assertFalse(self.verdict()["pass"])
        result = diagnose(self.case, chunk_elements=7)
        self.assertFalse(result["strict_pass"])
        self.assertTrue(result["verification_matches_rescan"])
        self.assertEqual(result["strict_failed_elements"], 1)
        self.assertEqual(result["strict_failure_fraction"], 1/64)
        self.assertEqual(result["finite_difference_ulp_histogram"], {"1": 1})
        example = result["examples"][0]
        self.assertEqual(example["flat_index"], 63)
        self.assertEqual(example["finite_ulp_distance"], 1)
        self.assertTrue(example["golden_fp32_rounds_to_stored_bf16"])
        self.assertEqual(example["midpoint"], (example["actual_bf16"]+example["expected_bf16"])/2)
        self.assertAlmostEqual(example["reference_to_midpoint_abs"], abs(example["golden_fp32"]-example["midpoint"]))

    def test_two_ulp_difference_is_not_a_single_boundary(self):
        self.change_last_word(2)
        self.verdict()
        result = diagnose(self.case)
        self.assertFalse(result["all_finite_value_differences_are_adjacent"])
        self.assertEqual(result["nonadjacent_finite_differences"], 1)
        self.assertEqual(result["finite_difference_ulp_histogram"], {"2": 1})
        self.assertIsNone(result["examples"][0]["midpoint"])

    def test_ordered_codes_for_negative_and_zero_neighbors(self):
        words = np.array([0xBF81, 0xBF80, 0x8001, 0x8000, 0, 1, 0x3F80, 0x3F81], np.uint16)
        ordered = ordered_bf16(words)
        self.assertEqual(int(ordered[1]-ordered[0]), 1)
        self.assertEqual(int(ordered[3]-ordered[2]), 1)
        self.assertEqual(int(ordered[4]-ordered[3]), 0)
        self.assertEqual(int(ordered[5]-ordered[4]), 1)
        self.assertEqual(int(ordered[7]-ordered[6]), 1)

    def test_special_classification_is_not_neighbor_rounding(self):
        output = np.fromfile(self.case / "output.bin", dtype="<u2")
        output[0] = 0x7F80  # +Inf where the reference is finite zero.
        output.tofile(self.case / "output.bin")
        self.verdict()
        result = diagnose(self.case)
        self.assertEqual(result["classification_failures"], 1)
        self.assertFalse(result["all_value_differences_are_adjacent_finite"])
        self.assertIsNone(result["examples"][0]["finite_ulp_distance"])
        json.dumps(result, allow_nan=False)

    def test_stale_verification_is_reported(self):
        self.verdict()
        self.change_last_word(1)
        result = diagnose(self.case)
        self.assertFalse(result["verification_matches_rescan"])
        self.assertFalse(result["strict_pass"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
