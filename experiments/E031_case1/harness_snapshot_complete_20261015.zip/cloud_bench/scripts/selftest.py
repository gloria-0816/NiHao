#!/usr/bin/env python3
"""CPU-only encoding/verification checks; no claim of NPU kernel validation."""
from __future__ import annotations

import json
import shutil
import tempfile
import unittest
from pathlib import Path

import numpy as np

from case_data import bf16_encode, compare_arrays, decode, encode, generate, reference, verify
from make_matrix import core_boundary_matrix, correctness_matrix, smoke_matrix, stress_matrix


class EncodingTests(unittest.TestCase):
    def test_bf16_round_ties_even_signs_and_nan_payloads(self):
        bits = np.array([0x3F808000, 0x3F818000, 0xBF808000, 0xBF818000,
                         0x00008000, 0x00018000, 0x80008000,
                         0x7F800000, 0xFF800000, 0x7F800001, 0x7FFFFFFF,
                         0xFF800001, 0x7F7FFFFF], np.uint32)
        expected = np.array([0x3F80, 0x3F82, 0xBF80, 0xBF82, 0x0000, 0x0002,
                             0x8000, 0x7F80, 0xFF80, 0x7FC0, 0x7FFF, 0xFFC0, 0x7F80], np.uint16)
        np.testing.assert_array_equal(bf16_encode(bits.view(np.float32)), expected)
        decoded = decode(expected, "bfloat16")
        self.assertTrue(np.isnan(decoded[9:12]).all())
        self.assertTrue(np.isposinf(decoded[7]) and np.isneginf(decoded[8]))

    def test_bf16_all_finite_representable_values_roundtrip(self):
        words = np.arange(65536, dtype=np.uint16)
        values = decode(words, "bfloat16")
        finite = np.isfinite(values)
        np.testing.assert_array_equal(bf16_encode(values[finite]), words[finite])

    def test_comparator_specials_and_tolerance(self):
        expected = np.array([1.0, 0.0, np.nan, np.inf, -np.inf])
        self.assertEqual(compare_arrays(expected, expected, 1e-4, 1e-4)["failed_elements"], 0)
        got = np.array([1.001, 0.001, np.inf, -np.inf, np.nan])
        report = compare_arrays(got, expected, 1e-4, 1e-4)
        self.assertEqual(report["finite_failures"], 2)
        self.assertEqual(report["classification_failures"], 3)
        json.dumps(report, allow_nan=False)


class FileTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="cann_case_selftest_")
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_public_template_recipe_and_operation_order(self):
        directory = self.root / "template"
        generate(directory, [1, 64], "float16", seed=42, diagnostic_fp64=True)
        rng = np.random.RandomState(42)
        x = rng.uniform(-2, 2, (1, 64)).astype(np.float16)
        residual = rng.uniform(-2, 2, (1, 64)).astype(np.float16)
        gamma = rng.uniform(0.8, 1.2, 64).astype(np.float16)
        bias = rng.uniform(-0.3, 0.3, 64).astype(np.float16)
        for name, expected in (("x", x), ("residual", residual), ("gamma", gamma), ("bias", bias)):
            self.assertEqual((directory / f"{name}.bin").read_bytes(), expected.tobytes())
        xf, rf, gf, bf = (v.astype(np.float32) for v in (x, residual, gamma, bias))
        y = xf + rf
        out = y / np.sqrt(np.mean(y*y, axis=-1, keepdims=True) + 1e-5) * gf
        out = out + bf
        self.assertEqual((directory / "golden_output.bin").read_bytes(), out.astype(np.float16).tobytes())
        self.assertEqual((directory / "golden_output_fp32.bin").read_bytes(), out.tobytes())
        self.assertEqual((directory / "golden_output_fp64.bin").stat().st_size, 64*8)

    def test_uniform_reproducible_across_chunk_sizes(self):
        for dtype in ("float32", "float16", "bfloat16"):
            a, b = self.root / (dtype+"a"), self.root / (dtype+"b")
            generate(a, [2, 3, 129], dtype, chunk_rows=1)
            generate(b, [2, 3, 129], dtype, chunk_rows=5)
            for name in ("x", "residual", "gamma", "bias", "golden_output", "golden_output_fp32"):
                self.assertEqual((a / (name+".bin")).read_bytes(), (b / (name+".bin")).read_bytes())

    def test_missing_truncated_corrupt_and_hash_fail(self):
        directory = self.root / "verify"
        generate(directory, [2, 2, 1, 65], "float32")
        self.assertFalse(verify(directory)["pass"])
        output = directory / "output.bin"
        shutil.copyfile(directory / "golden_output.bin", output)
        self.assertTrue(verify(directory, verify_hashes=True)["pass"])
        output.write_bytes(output.read_bytes()[:-1])
        self.assertFalse(verify(directory)["pass"])
        shutil.copyfile(directory / "golden_output.bin", output)
        got = np.fromfile(output, np.float32)
        got[0] += 0.1
        got.tofile(output)
        result = verify(directory)
        self.assertFalse(result["pass"])
        self.assertEqual(result["failed_elements"], 1)
        self.assertEqual(result["examples"][0]["flat_index"], 0)
        shutil.copyfile(directory / "golden_output.bin", output)
        (directory / "x.bin").write_bytes(b"corrupted")
        self.assertFalse(verify(directory, verify_hashes=True)["pass"])

    def test_cancel_and_specials_all_dtypes(self):
        for dtype in ("float32", "float16", "bfloat16"):
            for pattern in ("cancel", "specials"):
                directory = self.root / (dtype+pattern)
                generate(directory, [5, 65], dtype, pattern=pattern, chunk_rows=2)
                shutil.copyfile(directory / "golden_output.bin", directory / "output.bin")
                self.assertTrue(verify(directory, chunk_rows=1)["pass"])
                if pattern == "specials":
                    output = decode(np.fromfile(directory / "output.bin", dtype=np.dtype("<f4") if dtype == "float32" else np.dtype("<f2") if dtype == "float16" else np.dtype("<u2")), dtype).reshape(5, 65)
                    self.assertTrue(np.isnan(output[0]).all())
                    self.assertTrue(np.isfinite(output[4]).all())

    def test_memory_bound_rejects_before_case_creation(self):
        directory = self.root / "too_large"
        with self.assertRaises(ValueError):
            generate(directory, [8192, 8192], "float32", max_tensor_mib=1)
        self.assertFalse(directory.exists())

    def test_tail_impulse_all_types_and_neighbor_boundaries(self):
        for dtype in ("float32", "float16", "bfloat16"):
            for d in (65, 513, 4095, 4097, 8193):
                directory = self.root / f"{dtype}_impulse_{d}"
                generate(directory, [2, 2, d], dtype, pattern="tail_impulse", chunk_rows=1)
                from case_data import DTYPES
                x = decode(np.fromfile(directory / "x.bin", DTYPES[dtype]), dtype).reshape(4, d)
                residual = decode(np.fromfile(directory / "residual.bin", DTYPES[dtype]), dtype)
                gamma = decode(np.fromfile(directory / "gamma.bin", DTYPES[dtype]), dtype)
                bias = decode(np.fromfile(directory / "bias.bin", DTYPES[dtype]), dtype)
                self.assertTrue(np.all(x[:, :-1] == 0) and np.all(x[:, -1] == 1))
                self.assertTrue(np.all(residual == 0) and np.all(gamma == 1) and np.all(bias == 0))
                golden = decode(np.fromfile(directory / "golden_output.bin", DTYPES[dtype]), dtype).reshape(4, d)
                expected_last = encode(np.float32(1.0) / np.sqrt(np.float32(1.0 / d) + np.float32(1e-5)), dtype)
                self.assertTrue(np.all(golden[:, :-1] == 0))
                np.testing.assert_array_equal(golden[:, -1], np.repeat(decode(expected_last, dtype), 4))
                shutil.copyfile(directory / "golden_output.bin", directory / "output.bin")
                self.assertTrue(verify(directory)["pass"])


class MatrixTests(unittest.TestCase):
    def test_manifests_unique_ids_public_shapes_and_memory_cap(self):
        for matrix in (smoke_matrix(), correctness_matrix(), stress_matrix()):
            cases = matrix["cases"]
            self.assertEqual(len(cases), len({c["id"] for c in cases}))
            self.assertEqual({c["dtype"] for c in cases}, {"float32", "float16", "bfloat16"})
            self.assertTrue(all(64 <= c["shape"][-1] <= 32768 for c in cases))
            self.assertLessEqual(max(c["tensor_bytes"] for c in cases), 256*1024*1024)

    def test_new_cases_append_and_original_seed_order_stays_stable(self):
        smoke = smoke_matrix()["cases"]
        correct = correctness_matrix()["cases"]
        self.assertEqual(len(smoke), 133)
        self.assertEqual(len(correct), 165)
        self.assertEqual(smoke[0]["seed"], 42)
        self.assertEqual([c["seed"] for c in smoke[1:121]], list(range(43, 163)))
        self.assertEqual([c["seed"] for c in correct[:150]], list(range(42, 192)))
        self.assertTrue(all(c["pattern"] == "tail_impulse" for c in correct[150:]))
        core = core_boundary_matrix(40)["cases"]
        self.assertEqual(len(core), 198)
        self.assertTrue(all(c["shape"][-1] not in (65, 4095) for c in core[:162]))
        self.assertTrue(all(c["shape"][-1] in (65, 4095) for c in core[162:]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
