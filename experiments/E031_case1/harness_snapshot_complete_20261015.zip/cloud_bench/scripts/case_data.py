#!/usr/bin/env python3
"""Bounded-memory data generation and validation for AddRmsNormBias.

Only NumPy is required. These cases are our representative workloads, not the
15 undisclosed CANNJudge workloads. All binary files use little-endian storage.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np


DTYPES = {"float32": np.dtype("<f4"), "float16": np.dtype("<f2"),
          "bfloat16": np.dtype("<u2")}
PATTERNS = ("uniform", "zeros", "cancel", "checkerboard", "wide_range", "specials", "tail_impulse")
VERSION = 1


def bf16_encode(value):
    """IEEE BF16 round-to-nearest, ties-to-even, preserving NaN classification.

    NaNs are handled before integer rounding: a tiny FP32 NaN payload must not
    become infinity, and a high payload must not wrap into a signed finite zero.
    """
    value = np.asarray(value, dtype=np.float32)
    bits = value.view(np.uint32)
    with np.errstate(over="ignore"):
        rounded = ((bits + np.uint32(0x7FFF) + ((bits >> 16) & 1)) >> 16).astype("<u2")
    nan = ((bits & np.uint32(0x7F800000)) == np.uint32(0x7F800000)) & (
        (bits & np.uint32(0x007FFFFF)) != 0)
    return np.where(nan, ((bits >> 16) | np.uint32(0x0040)).astype("<u2"), rounded)


def encode(value, dtype):
    if dtype == "bfloat16":
        return bf16_encode(value)
    with np.errstate(over="ignore", invalid="ignore"):
        return np.asarray(value).astype(DTYPES[dtype])


def decode(value, dtype):
    if dtype == "bfloat16":
        return (np.asarray(value, dtype=np.uint16).astype(np.uint32) << np.uint32(16)).view(np.float32)
    return np.asarray(value).astype(np.float32)


def reference(x, residual, gamma, bias, epsilon, precision=np.float32):
    """Same sequence as official scripts/AddRmsNormBias.py; optional F64 diagnostic."""
    x, residual = x.astype(precision), residual.astype(precision)
    gamma, bias = gamma.astype(precision), bias.astype(precision)
    with np.errstate(over="ignore", invalid="ignore", divide="ignore", under="ignore"):
        y = x + residual
        rms = np.sqrt(np.mean(y * y, axis=-1, keepdims=True, dtype=precision)
                      + precision(epsilon))
        out = y / rms * gamma
        return out + bias


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_shape(text):
    try:
        shape = [int(n.strip()) for n in text.lower().replace("x", ",").split(",")]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("shape must contain comma- or x-separated integers") from exc
    if len(shape) not in (2, 3, 4) or any(n <= 0 for n in shape):
        raise argparse.ArgumentTypeError("shape must have 2, 3 or 4 positive dimensions")
    if not 64 <= shape[-1] <= 32768:
        raise argparse.ArgumentTypeError("D must lie in the public range [64, 32768]")
    if shape[0] > 8192 or (len(shape) >= 3 and shape[1] > 32768):
        raise argparse.ArgumentTypeError("batch <=8192 and sequence length <=32768 required")
    return shape


def validate_metadata(meta):
    shape = meta.get("shape")
    if not isinstance(shape, list) or any(type(n) is not int for n in shape):
        raise ValueError("meta.shape must be an integer array")
    parse_shape(",".join(map(str, shape)))
    dtype = meta.get("dtype")
    if dtype not in DTYPES:
        raise ValueError("unknown dtype")
    epsilon = meta.get("epsilon")
    if type(epsilon) not in (int, float) or not math.isfinite(epsilon) or epsilon <= 0:
        raise ValueError("epsilon must be finite and positive")
    elements, d = math.prod(shape), shape[-1]
    expected = elements * DTYPES[dtype].itemsize
    if meta.get("expected_bytes") != expected or meta.get("vector_bytes") != d * DTYPES[dtype].itemsize:
        raise ValueError("metadata byte counts do not match shape/dtype")
    return shape, dtype, np.float32(epsilon), elements // d, d


def _chunks(rows, d, wanted, max_work_mib):
    # Conservative F64 calculation bound: 128 bytes/element plus parameter space.
    if type(wanted) is not int or wanted < 1 or not math.isfinite(max_work_mib) or max_work_mib <= 0:
        raise ValueError("chunk-rows and max-work-mib must be finite and positive")
    budget = int(max_work_mib * 1024 * 1024)
    if budget < d * 128:
        raise ValueError("max-work-mib cannot fit one row")
    return max(1, min(rows, wanted, budget // (d * 128)))


def _input_chunk(pattern, which, start, nrows, d, rng, case_dir, dtype):
    size = (nrows, d)
    if pattern == "tail_impulse":
        result = np.zeros(size, np.float32)
        if which == "x":
            result[:, -1] = 1.0
        return result
    if pattern == "zeros":
        return np.zeros(size, np.float32)
    if pattern == "checkerboard":
        columns = np.arange(d)[None, :]
        rows = np.arange(start, start + nrows)[:, None]
        sign = np.where((columns + rows) % 2, -1.0, 1.0).astype(np.float32)
        return sign * (np.float32(2.0) if which == "x" else np.float32(0.25))
    if pattern == "cancel" and which == "residual":
        count = (case_dir / "x.bin").stat().st_size // DTYPES[dtype].itemsize // d
        x = np.memmap(case_dir / "x.bin", dtype=DTYPES[dtype], mode="r", shape=(count, d))
        # Residual starts from the values actually represented in x.bin.
        return -decode(x[start:start + nrows], dtype) + rng.uniform(-1e-3, 1e-3, size)
    if pattern == "wide_range":
        # All inputs remain finite even in FP16; FP32 square/reduction is safe.
        return rng.uniform(-1, 1, size) * np.power(10.0, rng.uniform(-5, 3, size))
    result = rng.uniform(-2, 2, size)
    if pattern == "specials":
        # Distinct rows exercise propagation for NaN, positive/negative infinity
        # and opposing infinities, without polluting every ordinary finite row.
        for row, value in ((0, np.nan), (1, np.inf), (2, -np.inf), (3, np.inf)):
            if start <= row < start + nrows:
                result[row - start, 0] = -np.inf if which == "residual" and row == 3 else value
    return result


def generate(case_dir, shape, dtype, seed=42, epsilon=1e-5, pattern="uniform",
             chunk_rows=256, max_work_mib=128, max_tensor_mib=256,
             diagnostic_fp64=False, overwrite=False, case_id=None):
    case_dir = Path(case_dir)
    shape = parse_shape(",".join(map(str, shape)))
    if dtype not in DTYPES or pattern not in PATTERNS:
        raise ValueError("unknown dtype/pattern")
    if not math.isfinite(max_tensor_mib) or max_tensor_mib <= 0:
        raise ValueError("max-tensor-mib must be finite and positive")
    eps = np.float32(epsilon)
    if not np.isfinite(eps) or eps <= 0:
        raise ValueError("epsilon must remain finite and positive in float32")
    elements, d = math.prod(shape), shape[-1]
    rows, expected = elements // d, elements * DTYPES[dtype].itemsize
    if expected > max_tensor_mib * 1024 * 1024:
        raise ValueError(f"single tensor needs {expected} bytes, exceeding max-tensor-mib")
    chunk = _chunks(rows, d, chunk_rows, max_work_mib)
    case_dir.mkdir(parents=True, exist_ok=True)
    names = ["meta.json", "x.bin", "residual.bin", "gamma.bin", "bias.bin",
             "golden_output.bin", "golden_output_fp32.bin", "golden_output_fp64.bin"]
    if not overwrite and any((case_dir / name).exists() for name in names):
        raise ValueError("case already contains generated files; use --overwrite deliberately")
    # An incomplete generation cannot retain metadata from a prior valid case.
    (case_dir / "meta.json").unlink(missing_ok=True)
    if not diagnostic_fp64:
        (case_dir / "golden_output_fp64.bin").unlink(missing_ok=True)
    rng = np.random.RandomState(seed)
    for name in ("x", "residual"):
        with (case_dir / f"{name}.bin").open("wb") as handle:
            for start in range(0, rows, chunk):
                block = _input_chunk(pattern, name, start, min(chunk, rows-start),
                                     d, rng, case_dir, dtype)
                encode(block, dtype).tofile(handle)
    if pattern == "tail_impulse":
        gamma = encode(np.ones(d, np.float32), dtype)
        bias = encode(np.zeros(d, np.float32), dtype)
    else:
        gamma = encode(rng.uniform(0.8, 1.2, d), dtype)
        bias = encode(rng.uniform(-0.3, 0.3, d), dtype)
    gamma.tofile(case_dir / "gamma.bin")
    bias.tofile(case_dir / "bias.bin")
    gamma_f, bias_f = decode(gamma, dtype), decode(bias, dtype)
    x = np.memmap(case_dir / "x.bin", dtype=DTYPES[dtype], mode="r", shape=(rows, d))
    residual = np.memmap(case_dir / "residual.bin", dtype=DTYPES[dtype], mode="r", shape=(rows, d))
    with (case_dir / "golden_output.bin").open("wb") as quantized, \
            (case_dir / "golden_output_fp32.bin").open("wb") as raw:
        precise = (case_dir / "golden_output_fp64.bin").open("wb") if diagnostic_fp64 else None
        try:
            for start in range(0, rows, chunk):
                xf, rf = decode(x[start:start+chunk], dtype), decode(residual[start:start+chunk], dtype)
                result = reference(xf, rf, gamma_f, bias_f, eps)
                encode(result, dtype).tofile(quantized)
                result.astype("<f4", copy=False).tofile(raw)
                if precise is not None:
                    reference(xf, rf, gamma_f, bias_f, eps, np.float64).astype("<f8").tofile(precise)
        finally:
            if precise is not None:
                precise.close()
    meta = {
        "schema_version": VERSION, "case_id": case_id or case_dir.name,
        "shape": shape, "dtype": dtype, "epsilon": float(eps), "seed": seed,
        "pattern": pattern, "rows": rows, "expected_bytes": expected,
        "vector_bytes": d * DTYPES[dtype].itemsize,
        "generator": "numpy.RandomState/MT19937; x then residual then gamma then bias",
        "numpy_version": np.__version__, "chunk_rows": chunk,
        "reference": "official operation order; FP32 intermediates; output dtype RNE",
        "diagnostic_fp64": bool(diagnostic_fp64),
        "source": "representative workload; not an undisclosed official test",
        "file_sha256": {name: sha256(case_dir / name) for name in names[1:]
                        if (case_dir / name).exists()},
    }
    (case_dir / "meta.json").write_text(json.dumps(meta, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    return meta


def compare_arrays(got, expected, atol, rtol, offset=0, max_examples=8):
    got, expected = np.asarray(got, np.float64).reshape(-1), np.asarray(expected, np.float64).reshape(-1)
    if got.shape != expected.shape:
        raise ValueError("array lengths differ")
    finite = np.isfinite(expected) & np.isfinite(got)
    classes = ((np.isnan(expected) & np.isnan(got)) |
               (np.isposinf(expected) & np.isposinf(got)) |
               (np.isneginf(expected) & np.isneginf(got)))
    with np.errstate(invalid="ignore", over="ignore"):
        absolute = np.abs(got[finite] - expected[finite])
        bad_finite = absolute > atol + rtol * np.abs(expected[finite])
    passed = classes.copy()
    passed[finite] = ~bad_finite
    bad_indices = np.flatnonzero(~passed)
    # JSON diagnostics encode specials as text rather than non-standard NaN/Infinity literals.
    def scalar(v):
        return float(v) if math.isfinite(v) else str(v)
    return {
        "elements": int(got.size), "failed_elements": int(bad_indices.size),
        "classification_failures": int(np.count_nonzero(~finite & ~classes)),
        "finite_failures": int(np.count_nonzero(bad_finite)),
        "max_abs_error": float(np.max(absolute)) if absolute.size else 0.0,
        "max_relative_error": float(np.max(absolute / np.maximum(np.abs(expected[finite]), 1e-30)))
        if absolute.size else 0.0,
        "examples": [{"flat_index": int(i+offset), "actual": scalar(got[i]),
                      "expected": scalar(expected[i])} for i in bad_indices[:max_examples]],
    }


def verify(case_dir, output=None, chunk_rows=256, max_work_mib=128, verify_hashes=False):
    case_dir = Path(case_dir)
    meta = json.loads((case_dir / "meta.json").read_text(encoding="utf-8"))
    shape, dtype, eps, rows, d = validate_metadata(meta)
    output = Path(output) if output is not None else case_dir / "output.bin"
    result = {"case_id": meta.get("case_id", case_dir.name), "shape": shape,
              "dtype": dtype, "output": str(output), "pass": False,
              "criterion": "finite abs(actual-reference) <= atol + rtol*abs(reference); NaN/+Inf/-Inf classes equal",
              "atol": 1e-4 if dtype == "float32" else 1e-3,
              "rtol": 1e-4 if dtype == "float32" else 1e-3}
    if verify_hashes:
        for name, digest in meta.get("file_sha256", {}).items():
            if Path(name).name != name:
                raise ValueError("unsafe filename in hash manifest")
            file = case_dir / name
            if not file.is_file() or sha256(file) != digest:
                result["error"] = f"generated file hash mismatch/missing: {name}"
                return result
    for file in (output, case_dir / "golden_output.bin"):
        if not file.is_file():
            result["error"] = f"missing file: {file}"
            return result
        if file.stat().st_size != meta["expected_bytes"]:
            result["error"] = f"incorrect file size: {file}; expected {meta['expected_bytes']}, actual {file.stat().st_size}"
            return result
    actual = np.memmap(output, dtype=DTYPES[dtype], mode="r", shape=(rows, d))
    golden = np.memmap(case_dir / "golden_output.bin", dtype=DTYPES[dtype], mode="r", shape=(rows, d))
    chunk = _chunks(rows, d, chunk_rows, max_work_mib)
    result.update({"elements": 0, "failed_elements": 0, "classification_failures": 0,
                   "finite_failures": 0, "max_abs_error": 0.0, "max_relative_error": 0.0, "examples": []})
    for start in range(0, rows, chunk):
        part = compare_arrays(decode(actual[start:start+chunk], dtype), decode(golden[start:start+chunk], dtype),
                              result["atol"], result["rtol"], offset=start*d)
        for key in ("elements", "failed_elements", "classification_failures", "finite_failures"):
            result[key] += part[key]
        for key in ("max_abs_error", "max_relative_error"):
            result[key] = max(result[key], part[key])
        result["examples"].extend(part["examples"][:max(0, 8-len(result["examples"]))])
    result["pass"] = result["failed_elements"] == 0
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    gen = commands.add_parser("generate", help="generate one case with FP32 and quantized golden")
    gen.add_argument("--case-dir", required=True, type=Path)
    gen.add_argument("--shape", required=True, type=parse_shape)
    gen.add_argument("--dtype", choices=DTYPES, required=True)
    gen.add_argument("--seed", type=int, default=42)
    gen.add_argument("--epsilon", type=float, default=1e-5)
    gen.add_argument("--pattern", choices=PATTERNS, default="uniform")
    gen.add_argument("--max-tensor-mib", type=float, default=256)
    gen.add_argument("--diagnostic-fp64", action="store_true")
    gen.add_argument("--overwrite", action="store_true")
    check = commands.add_parser("verify", help="strictly verify output.bin, failing missing/short files")
    check.add_argument("--case-dir", required=True, type=Path)
    check.add_argument("--output", type=Path)
    check.add_argument("--report", type=Path)
    check.add_argument("--verify-hashes", action="store_true")
    for command in (gen, check):
        command.add_argument("--chunk-rows", type=int, default=256)
        command.add_argument("--max-work-mib", type=float, default=128)
    args = parser.parse_args(argv)
    if args.chunk_rows < 1 or args.max_work_mib <= 0:
        parser.error("chunk-rows and max-work-mib must be positive")
    try:
        if args.command == "generate":
            result = generate(args.case_dir, args.shape, args.dtype, args.seed, args.epsilon,
                              args.pattern, args.chunk_rows, args.max_work_mib,
                              args.max_tensor_mib, args.diagnostic_fp64, args.overwrite)
            print(json.dumps({key: result[key] for key in ("case_id", "shape", "dtype", "expected_bytes", "chunk_rows")}, indent=2))
            return 0
        result = verify(args.case_dir, args.output, args.chunk_rows, args.max_work_mib, args.verify_hashes)
        encoded = json.dumps(result, indent=2, allow_nan=False) + "\n"
        print(encoded, end="")
        if args.report:
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(encoded, encoding="utf-8")
        return 0 if result["pass"] else 1
    except (OSError, ValueError, argparse.ArgumentTypeError, OverflowError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
