#!/usr/bin/env python3
"""Diagnose BF16 output differences without relaxing strict verification.

The FP32 reference is observable; the NPU's intermediate FP32 values are not.
Adjacent BF16 outputs alone do not establish the cause of a precision failure.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np

from case_data import bf16_encode, decode, validate_metadata


def ordered_bf16(words):
    """Monotonic BF16 codes for finite values, identifying +0 and -0.

    A distance of 1 represents neighboring finite BF16 values, including the
    smallest subnormal next to zero. NaN/Inf are classified separately.
    """
    words = np.asarray(words, np.uint16)
    magnitude = (words & np.uint16(0x7FFF)).astype(np.int32)
    return np.where(words & np.uint16(0x8000), 0x8000 - magnitude, 0x8000 + magnitude)


def safe_number(value):
    value = float(value)
    return value if math.isfinite(value) else str(value)


def same_number(a, b):
    try:
        a, b = float(a), float(b)
    except (ValueError, TypeError):
        return False
    return (math.isnan(a) and math.isnan(b)) or a == b


def strict_mask(actual, expected):
    finite = np.isfinite(actual) & np.isfinite(expected)
    same_special = ((np.isnan(actual) & np.isnan(expected)) |
                    (np.isposinf(actual) & np.isposinf(expected)) |
                    (np.isneginf(actual) & np.isneginf(expected)))
    absolute = np.zeros(actual.size, np.float64)
    absolute[finite] = np.abs(actual[finite].astype(np.float64) - expected[finite].astype(np.float64))
    bad_finite = finite & (absolute > 1e-3 + 1e-3 * np.abs(expected.astype(np.float64)))
    classification_bad = ~finite & ~same_special
    return finite, same_special, bad_finite, classification_bad


def example_detail(index, actual_words, expected_words, fp32, supplied=None):
    a_word, e_word = int(actual_words[index]), int(expected_words[index])
    actual = float(decode(np.array([a_word], np.uint16), "bfloat16")[0])
    expected = float(decode(np.array([e_word], np.uint16), "bfloat16")[0])
    reference_fp32 = float(fp32[index])
    finite = math.isfinite(actual) and math.isfinite(expected)
    ulps = int(abs(int(ordered_bf16(np.array([a_word]))[0]) -
                   int(ordered_bf16(np.array([e_word]))[0]))) if finite else None
    adjacent = finite and actual != expected and ulps == 1
    strict_fail = bool((strict_mask(np.array([actual]), np.array([expected]))[2] |
                        strict_mask(np.array([actual]), np.array([expected]))[3])[0])
    reencoded = int(bf16_encode(np.array([reference_fp32], np.float32))[0])
    detail = {
        "flat_index": int(index), "actual_bf16": safe_number(actual),
        "expected_bf16": safe_number(expected), "actual_bits_hex": f"0x{a_word:04x}",
        "expected_bits_hex": f"0x{e_word:04x}", "finite_ulp_distance": ulps,
        "adjacent_finite_values": bool(adjacent), "currently_strict_failure": strict_fail,
        "golden_fp32": safe_number(reference_fp32),
        "golden_fp32_rounds_to_stored_bf16": reencoded == e_word or
            (math.isnan(reference_fp32) and math.isnan(expected)),
        "bf16_spacing_between_endpoints": None, "midpoint": None,
        "reference_to_midpoint_signed": None, "reference_to_midpoint_abs": None,
        "reference_to_midpoint_in_bf16_ulps": None,
    }
    if supplied is not None:
        detail["matches_supplied_verification_values"] = (
            same_number(supplied.get("actual"), actual) and
            same_number(supplied.get("expected"), expected))
    if adjacent and math.isfinite(reference_fp32):
        spacing = abs(actual - expected)
        midpoint = (actual + expected) / 2.0  # float64: exact midpoint of FP32 endpoints.
        signed_distance = reference_fp32 - midpoint
        detail.update({"bf16_spacing_between_endpoints": spacing, "midpoint": midpoint,
                       "reference_to_midpoint_signed": signed_distance,
                       "reference_to_midpoint_abs": abs(signed_distance),
                       "reference_to_midpoint_in_bf16_ulps": abs(signed_distance)/spacing})
    return detail


def diagnose(case_dir, verification=None, output=None, chunk_elements=262144,
             max_work_mib=128, max_examples=8):
    case_dir = Path(case_dir)
    verification = Path(verification) if verification else case_dir / "verification.json"
    output = Path(output) if output else case_dir / "output.bin"
    if type(chunk_elements) is not int or chunk_elements < 1 or \
            not math.isfinite(max_work_mib) or max_work_mib <= 0:
        raise ValueError("chunk-elements and max-work-mib must be finite and positive")
    if not 0 <= max_examples <= 8:
        raise ValueError("max-examples must lie in [0,8]")
    chunk = min(chunk_elements, int(max_work_mib * 1024 * 1024) // 128)
    if chunk < 1:
        raise ValueError("memory budget cannot fit one element")
    meta = json.loads((case_dir / "meta.json").read_text(encoding="utf-8"))
    shape, dtype, epsilon, rows, d = validate_metadata(meta)
    if dtype != "bfloat16":
        raise ValueError("this diagnostic is specifically for bfloat16 cases")
    verdict = json.loads(verification.read_text(encoding="utf-8"))
    if not isinstance(verdict, dict):
        raise ValueError("verification must be a JSON object")
    elements = rows * d
    golden = case_dir / "golden_output.bin"
    golden_fp32 = case_dir / "golden_output_fp32.bin"
    for file, expected_bytes in ((output, elements*2), (golden, elements*2), (golden_fp32, elements*4)):
        if not file.is_file() or file.stat().st_size != expected_bytes:
            raise ValueError(f"missing/incorrect-size file: {file}; expected {expected_bytes} bytes")
    actual_words = np.memmap(output, mode="r", dtype="<u2", shape=(elements,))
    expected_words = np.memmap(golden, mode="r", dtype="<u2", shape=(elements,))
    fp32 = np.memmap(golden_fp32, mode="r", dtype="<f4", shape=(elements,))
    counts = {"bitwise_differences": 0, "finite_value_differences": 0,
              "adjacent_finite_differences": 0, "nonadjacent_finite_differences": 0,
              "signed_zero_bit_differences": 0, "nan_payload_bit_differences": 0,
              "classification_failures": 0, "strict_finite_failures": 0,
              "strict_failed_elements": 0, "strict_failed_finite_nonadjacent_count": 0,
              "nonadjacent_finite_strict_pass_count": 0}
    histogram, strict_histogram, fallback_indices = {}, {}, []
    for start in range(0, elements, chunk):
        stop = min(elements, start+chunk)
        aw, ew = actual_words[start:stop], expected_words[start:stop]
        actual, expected = decode(aw, dtype), decode(ew, dtype)
        finite, same_special, bad_finite, classification_bad = strict_mask(actual, expected)
        bitwise_diff = aw != ew
        value_diff = finite & (actual != expected)
        distance = np.abs(ordered_bf16(aw) - ordered_bf16(ew))
        counts["bitwise_differences"] += int(np.count_nonzero(bitwise_diff))
        counts["finite_value_differences"] += int(np.count_nonzero(value_diff))
        counts["adjacent_finite_differences"] += int(np.count_nonzero(value_diff & (distance == 1)))
        counts["nonadjacent_finite_differences"] += int(np.count_nonzero(value_diff & (distance > 1)))
        counts["signed_zero_bit_differences"] += int(np.count_nonzero(bitwise_diff & finite & (actual == 0) & (expected == 0)))
        counts["nan_payload_bit_differences"] += int(np.count_nonzero(bitwise_diff & np.isnan(actual) & np.isnan(expected)))
        counts["classification_failures"] += int(np.count_nonzero(classification_bad))
        counts["strict_finite_failures"] += int(np.count_nonzero(bad_finite))
        counts["strict_failed_finite_nonadjacent_count"] += int(np.count_nonzero(bad_finite & (distance > 1)))
        counts["nonadjacent_finite_strict_pass_count"] += int(np.count_nonzero(value_diff & (distance > 1) & ~bad_finite))
        bad = bad_finite | classification_bad
        counts["strict_failed_elements"] += int(np.count_nonzero(bad))
        if len(fallback_indices) < max_examples:
            fallback_indices.extend((np.flatnonzero(bad)[:max_examples-len(fallback_indices)] + start).tolist())
        values, frequencies = np.unique(distance[value_diff], return_counts=True)
        for value, count in zip(values, frequencies):
            key = str(int(value))
            histogram[key] = histogram.get(key, 0) + int(count)
        values, frequencies = np.unique(distance[bad_finite], return_counts=True)
        for value, count in zip(values, frequencies):
            key = str(int(value))
            strict_histogram[key] = strict_histogram.get(key, 0) + int(count)
    examples = verdict.get("examples", [])
    if not isinstance(examples, list):
        raise ValueError("verification examples must be an array")
    examples = examples[:max_examples]
    details = []
    if examples:
        for example in examples:
            if not isinstance(example, dict) or type(example.get("flat_index")) is not int or \
                    not 0 <= example["flat_index"] < elements:
                raise ValueError("invalid index in verification example")
            details.append(example_detail(example["flat_index"], actual_words, expected_words, fp32, example))
        origin = "first examples supplied by strict verification.json"
    else:
        details = [example_detail(i, actual_words, expected_words, fp32) for i in fallback_indices]
        origin = "first strict failures from rescan (verification contained no examples)"
    strict_pass = counts["strict_failed_elements"] == 0
    consistency = (verdict.get("pass") is strict_pass and
                   verdict.get("failed_elements") == counts["strict_failed_elements"] and
                   verdict.get("classification_failures") == counts["classification_failures"] and
                   ("case_id" not in verdict or verdict["case_id"] == meta.get("case_id")) and
                   ("dtype" not in verdict or verdict["dtype"] == dtype) and
                   ("shape" not in verdict or verdict["shape"] == shape) and
                   ("elements" not in verdict or verdict["elements"] == elements) and
                   ("atol" not in verdict or verdict["atol"] == 1e-3) and
                   ("rtol" not in verdict or verdict["rtol"] == 1e-3) and
                   all(detail.get("matches_supplied_verification_values", True) and
                       detail["currently_strict_failure"] for detail in details))
    return {
        "schema_version": 1, "case_id": meta.get("case_id", case_dir.name),
        "shape": shape, "dtype": dtype, "elements": elements,
        "output_path": str(output), "verification_path": str(verification),
        "chunk_elements": chunk, "strict_atol": 1e-3, "strict_rtol": 1e-3,
        "strict_criterion": "abs(actual-reference) <= atol+rtol*abs(reference); NaN/+Inf/-Inf classes match",
        "strict_pass": strict_pass, "verification_reported_pass": verdict.get("pass"),
        "verification_matches_rescan": bool(consistency), **counts,
        "strict_failure_fraction": counts["strict_failed_elements"] / elements,
        "strict_failure_percent": counts["strict_failed_elements"] * 100.0 / elements,
        "finite_difference_ulp_histogram": histogram,
        "max_finite_ulp_distance": max(map(int, histogram), default=0),
        "strict_failed_finite_ulp_histogram": strict_histogram,
        "strict_failed_finite_max_ulp_distance": max(map(int, strict_histogram), default=0),
        "all_finite_value_differences_are_adjacent": counts["nonadjacent_finite_differences"] == 0,
        "all_value_differences_are_adjacent_finite":
            counts["nonadjacent_finite_differences"] == 0 and counts["classification_failures"] == 0,
        "examples_origin": origin, "examples": details,
        "reference_fp32_sha256_from_metadata": meta.get("file_sha256", {}).get("golden_output_fp32.bin"),
        "interpretation": "Adjacent BF16 differences and reference values close to rounding midpoints support, but do not establish, a rounding-boundary explanation. NPU internal FP32 values are not observed. Strict failures remain failures; no official hidden-test tolerance is inferred.",
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case-dir", type=Path, required=True)
    parser.add_argument("--verification", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--report", type=Path)
    parser.add_argument("--chunk-elements", type=int, default=262144)
    parser.add_argument("--max-work-mib", type=float, default=128)
    parser.add_argument("--max-examples", type=int, default=8)
    args = parser.parse_args(argv)
    try:
        result = diagnose(args.case_dir, args.verification, args.output,
                          args.chunk_elements, args.max_work_mib, args.max_examples)
        encoded = json.dumps(result, indent=2, allow_nan=False) + "\n"
        if args.report:
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(encoded, encoding="utf-8")
        print(encoded, end="")
        # A successfully diagnosed strict failure still returns failure to callers.
        return 0 if result["strict_pass"] and result["verification_matches_rescan"] else 1
    except (OSError, ValueError, KeyError, TypeError, OverflowError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
