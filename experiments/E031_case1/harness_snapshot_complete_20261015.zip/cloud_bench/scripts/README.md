# 代表性数据与精度校验工具

这些工具用于在云机上复现公开模板、覆盖实现分支及构造性能场景。`smoke.json`、`correctness.json`、`stress.json` 是我们自己的测试矩阵，**不是官方 15 个隐藏测试点的配置**。执行器的耗时与此处的精度结果要同时保留；程序成功执行不能直接记作精度 Pass。

依赖 Python 3.9+ 与 NumPy，无需 PyTorch 或 `ml_dtypes`。运行目录不影响脚本路径解析。

## 单个用例

```sh
python3 cloud_bench/scripts/case_data.py generate \
  --case-dir /mnt/workspace/addrms_cases/public_template \
  --shape 1,64 --dtype float16 --seed 42 --epsilon 1e-5
```

这会按官方模板的随机数顺序生成 `x.bin`、`residual.bin`、`gamma.bin`、`bias.bin`，并生成两个基准文件：

- `golden_output.bin`：与输入相同的数据类型，实际精度判定使用此文件。
- `golden_output_fp32.bin`：转换回输出类型之前的 FP32 结果，用于诊断舍入误差。

加 `--diagnostic-fp64` 可生成 `golden_output_fp64.bin`。它基于已量化的输入和参数进行 FP64 运算，仅用于分析 FP32 归约误差；不能用它替换官方的 FP32 数学基准。

FP32 基准按官方脚本顺序执行：转换输入到 FP32 → `y=x+residual` → `sqrt(mean(y*y)+epsilon)` → `y/rms*gamma` → `+bias` → 转换回输出类型。没有将低精度残差和先行截断到 FP16/BF16。

所有二进制均按小端存储：FP32 为 float32、FP16 为 IEEE float16、BF16 为存放 BF16 位模式的 uint16。BF16 编码采用 round-to-nearest、ties-to-even，并单独处理 NaN 位模式，以防 NaN 被误舍入为 Inf。输入先量化，再由这些实际输入计算基准。

执行 NPU runner 后校验：

```sh
python3 cloud_bench/scripts/case_data.py verify \
  --case-dir /mnt/workspace/addrms_cases/public_template \
  --verify-hashes --report /mnt/workspace/addrms_cases/public_template/verification.json
```

默认读取同目录 `output.bin`；`--output PATH` 可验证独立的运行产物。退出码为 0（Pass）、1（精度或输出文件失败）、2（配置/IO 错误）。缺失文件、字节数不符均失败。

有限值逐元素要求 `abs(actual-reference) <= atol + rtol*abs(reference)`：FP32 的 atol/rtol 均为 `1e-4`，FP16/BF16 均为 `1e-3`。NaN、正 Inf、负 Inf 必须与基准分别匹配类别；NaN 与 Inf 互换或 Inf 符号不符均失败。报告包含失败元素数、分类失败、最大误差及最多 8 个失败位置。

## 元数据契约

`meta.json` 顶层包含：

```json
{
  "schema_version": 1,
  "case_id": "public_template",
  "shape": [1, 64],
  "dtype": "float16",
  "epsilon": 0.000009999999747378752,
  "seed": 42,
  "pattern": "uniform",
  "rows": 1,
  "expected_bytes": 128,
  "vector_bytes": 128
}
```

`expected_bytes` 是单个 x/residual/output 的长度；`vector_bytes` 是单个 gamma/bias 的长度。完整文件还包含生成算法、NumPy 版本、分块行数、golden 描述及输入/golden SHA256。epsilon 记录实际传入 kernel 的 FP32 数值。形状仅允许公开范围内的 2D/3D/4D 正维度，D 为 64..32768。

runner 只有一个输出 `output.bin`，没有额外的残差和 y 输出。`benchmark.json` 是执行器生成的性能证据；此脚本不生成 NPU 时间。

## 测试矩阵

```sh
# 仅写清单，不分配 tensor；给出实测向量核数时额外生成 R 阈值清单。
python3 cloud_bench/scripts/make_matrix.py manifests --vector-cores 40

# 一次只生成少量 smoke，或通过 --case-id 多次指定特定用例。
python3 cloud_bench/scripts/make_matrix.py generate \
  --manifest cloud_bench/cases/smoke.json \
  --output-root /mnt/workspace/addrms_cases/smoke --limit 5
```

向量核数示例 40 需替换成当前设备实际值，不假设所有 A2 都有相同可用向量核数。

| 清单 | 用例数 | 目的 | 最大单 tensor |
|---|---:|---|---:|
| smoke.json | 133 | 三类型、2D/3D/4D、单行/多行、D 分派门槛及非对齐相邻尺寸 | 8 MiB |
| correctness.json | 165 | 两个 epsilon、零值、抵消、交替符号、多数量级、NaN/Inf、有效尾部 impulse | 512 KiB |
| stress.json | 21 | 多行带宽、宽行及较大张量 | 256 MiB |
| core_boundaries.json | 按核数生成 | `R≈cores`、`R≈4*cores` 的分核和分派边界 | 按当前配置 |

默认 `uniform` 按旧式 `numpy.RandomState(seed)`，依次生成完整 x、完整 residual、gamma、bias。均匀用例改变分块大小不改变输入字节；`wide_range` 的两次随机抽样交织方式与分块大小有关，因此完整复现应同时保留 meta 中的 `chunk_rows`。其余 pattern：

- `zeros`：x/residual 全零，检查 epsilon 路径及 bias 输出。
- `cancel`：residual 从已量化 x 的相反数加小扰动生成。
- `checkerboard`：行列交替符号，测试抵消和归约。
- `wide_range`：正负数覆盖约 `1e-5..1e3`，保持 FP16 输入有限且 FP32 平方安全。
- `specials`：前四行分别含 NaN、+Inf、-Inf、相反 Inf；后续行保持普通有限值。
- `tail_impulse`：x 仅最后一个有效元素为 1、residual 全零、gamma 全 1、bias 全零。输出也只有最后一列非零，用于检查有效尾部被误清、无效 padding 混入归约等问题。

新增用例追加到清单末尾，已有 ID 的索引、随机种子和数据生成规则保持不变。smoke 额外覆盖 R=2/512、D65/4095，按核数生成的矩阵也包含这两个 D。

生成和校验按行分块，默认 `--max-work-mib 128` 限制临时数组的保守估算；`--chunk-rows 256` 会进一步被该预算缩小。预算不包括操作系统文件缓存、Python 固定开销或 NPU runner 的设备内存。`--max-tensor-mib 256` 在分配前拒绝超限单 tensor。

stress 与 smoke 分开运行。大用例有两份输入、参数、多份 golden 和输出，磁盘与设备占用均大于“最大单 tensor”；存储不足时按用例生成、执行、归档结果，然后清理该用例的数据。不要一次生成所有 stress 并假设只占 256 MiB。

已有生成文件默认拒绝覆盖，`--overwrite` 明确允许重新生成；重生成后必须重新运行 runner，旧的 output/benchmark 不能作为本次运行证据。

## CPU 工具自测

```sh
python3 cloud_bench/scripts/selftest.py
```

自测检查 BF16 舍入边界/NaN 编码及所有有限 BF16 值往返、官方模板随机 recipe、均匀输入分块一致性、特殊值类别、缺失/截断/污染输出、输入哈希及内存上限提前拒绝。它验证数据工具，**不验证 NPU kernel、计时或官方隐藏测试点**。
