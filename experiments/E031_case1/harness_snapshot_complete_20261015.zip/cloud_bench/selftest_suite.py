#!/usr/bin/env python3
"""Re-run orchestration failure/plan checks without executing an NPU kernel.

Children are ordinary Python processes deliberately failing, timing out or
omitting required output. No successful NPU result or timing is fabricated.
"""
from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
import tempfile
from pathlib import Path

import run_suite as suite


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, help="optional JSON report to retain after temporary files are removed")
    parser.add_argument("--tmp-root", type=Path, default=suite.BENCH_DIR / "results",
                        help="parent directory for this test's new, isolated temporary directory")
    args = parser.parse_args(argv)
    args.tmp_root = args.tmp_root.expanduser().resolve()
    args.tmp_root.mkdir(parents=True, exist_ok=True)
    checks = []
    target = suite.BENCH_DIR / "run_suite.py"

    def check(label, function):
        try:
            function()
            checks.append({"check": label, "status": "check_passed"})
        except Exception as exc:
            checks.append({"check": label, "status": "check_failed",
                           "error": f"{type(exc).__name__}: {exc}"})

    def invoke(arguments, expected_code):
        child = subprocess.run([sys.executable, str(target), *arguments],
                               capture_output=True, text=True, timeout=60)
        assert child.returncode == expected_code, (child.returncode, child.stderr, child.stdout)

    def reports(directory):
        summary = suite.read_json(directory / "summary.json")
        records = [json.loads(line) for line in (directory / "results.jsonl").read_text(encoding="utf-8").splitlines()]
        with (directory / "results.csv").open(encoding="utf-8", newline="") as source:
            rows = list(csv.DictReader(source))
        return summary, records, rows

    # This exclusively owned newly created directory is the only recursive
    # cleanup target, and its resolved absolute parent is checked before use.
    with tempfile.TemporaryDirectory(prefix="suite-selftest-", dir=args.tmp_root) as temporary:
        workspace = Path(temporary).resolve()
        if workspace.parent != args.tmp_root or not workspace.name.startswith("suite-selftest-"):
            raise RuntimeError("temporary workspace escaped the intended test root")

        def planned():
            directory = workspace / "planned"
            invoke(["--dry-run", "--limit", "3", "--run-dir", str(directory)], 0)
            summary, records, rows = reports(directory)
            assert summary["passed_cases"] == 0 and summary["planned_cases"] == 3
            assert all(item["status"] == "planned" and not item["executed"]
                       and item["verification"] is None and item["benchmark"] is None for item in records)
            assert all(row["accuracy_pass"] == "" and row["host_queued_batch_median_us"] == "" for row in rows)
            assert not (directory / "data").exists()

        def missing():
            directory = workspace / "missing"
            data = directory / "data/public_template_fp16_1x64"
            data.mkdir(parents=True)
            (data / "output.bin").write_bytes(b"stale output")
            (data / "benchmark.json").write_text("corrupt stale benchmark", encoding="utf-8")
            invoke(["--runner", str(workspace / "absent-runner"), "--limit", "2", "--run-dir", str(directory)], 1)
            summary, records, rows = reports(directory)
            assert summary["counts"] == {"runner_missing": 2} and summary["passed_cases"] == 0
            assert all(item["verification"] is None and item["benchmark"] is None for item in records)
            assert all(row["accuracy_pass"] == "" and row["event_queued_batch_median_us"] == "" for row in rows)
            assert not (data / "output.bin").exists() and not (data / "benchmark.json").exists()

        def real_nonzero():
            directory = workspace / "nonzero"
            # Python refuses runner-specific --case-dir; it is not an NPU runner.
            invoke(["--runner", sys.executable, "--limit", "1", "--run-dir", str(directory)], 1)
            summary, records, rows = reports(directory)
            assert summary["counts"] == {"execution_failed": 1}
            assert records[0]["returncode"] != 0 and records[0]["executed"]
            assert records[0]["metadata"] is not None
            assert records[0]["verification"] is None and records[0]["benchmark"] is None
            assert records[0]["runner_process_elapsed_s"] > 0
            assert records[0]["case_workflow_elapsed_s"] >= records[0]["runner_process_elapsed_s"]
            assert records[0]["elapsed_s"] == records[0]["case_workflow_elapsed_s"]
            assert rows[0]["accuracy_pass"] == ""
            assert float(rows[0]["runner_process_elapsed_s"]) > 0
            assert rows[0]["case_workflow_elapsed_s"] == rows[0]["elapsed_s"]

        def real_timeout():
            directory = workspace / "timeout"
            directory.mkdir()
            result = suite.run_process([sys.executable, "-c", "import time; time.sleep(5)"], directory, 0.05)
            assert result["timed_out"] and result["returncode"] != 0
            assert result["runner_process_elapsed_s"] > 0
            assert result["runner_process_elapsed_s"] == result["elapsed_s"]

        def observed_dispersion():
            # Numeric fixtures only: these are neither NPU timings nor Pass results.
            outlier = suite.timing_dispersion([1, 1, 1, 1, 1, 1, 100])
            assert outlier == {"n": 7, "min_us": 1, "max_us": 100, "iqr_us": 0, "mad_us": 0}
            assert suite.timing_dispersion([4]) == {"n": 1, "min_us": 4, "max_us": 4, "iqr_us": 0, "mad_us": 0}
            interpolated = suite.timing_dispersion([1, 3, 5, 7])
            assert interpolated == {"n": 4, "min_us": 1, "max_us": 7, "iqr_us": 3, "mad_us": 2}

        def failed_artifact_checks():
            options = suite.parse_args(["--run-dir", str(workspace / "partial"), "--limit", "1"])
            _, cases = suite.load_manifest(options.manifest, options.selection, options.limit)
            base = {"run_id": "failure-injection-only", "kernel_sha256": suite.case_data.sha256(options.kernel_source),
                    "runner_sha256": None, "settings": {"device": options.device, "timing": options.timing}}
            original = suite.runner_command
            try:
                suite.runner_command = lambda opts, path: [sys.executable, "-c",
                    'import pathlib,sys; p=pathlib.Path(sys.argv[1]); (p/"output.bin").write_bytes(b"partial"); '
                    '(p/"benchmark.json").write_text("corrupt"); sys.exit(7)', str(path)]
                record = suite.run_case(cases[0], options, base, None)
                assert record["status"] == "execution_failed" and record["returncode"] == 7
                assert record["verification"] is None and record["benchmark"] is None
                suite.runner_command = lambda opts, path: [sys.executable, "-c", "pass"]
                options.run_dir = workspace / "zero-without-output"
                record = suite.run_case(cases[0], options, base, None)
                assert record["status"] == "verification_failed" and record["returncode"] == 0
                assert record["verification"]["pass"] is False
                assert "missing file" in record["verification"]["error"]
            finally:
                suite.runner_command = original

        def selection_checks():
            directory = workspace / "selected"
            invoke(["--dry-run", "--case-regex", "^bfloat16_r1_d(64|65)$", "--run-dir", str(directory)], 0)
            _, records, _ = reports(directory)
            assert [item["case"]["id"] for item in records] == ["bfloat16_r1_d64", "bfloat16_r1_d65"]
            for label, expression in (("empty", "^no_such_case$"), ("invalid", "[")):
                directory = workspace / label
                invoke(["--case-regex", expression, "--run-dir", str(directory)], 2)
                assert not directory.exists()

        def invalid_json():
            for label, encoded in (("duplicate", '{"a":1,"a":2}'), ("nonfinite", '{"a":NaN}')):
                source = workspace / (label + ".json")
                source.write_text(encoded, encoding="utf-8")
                try:
                    suite.read_json(source)
                except ValueError:
                    continue
                raise AssertionError(f"{label} JSON accepted")

        check("dry-run produces only plans, no data/accuracy/timing", planned)
        check("missing runner clears stale artifacts and writes failure JSONL/CSV", missing)
        check("real nonzero child remains unverified", real_nonzero)
        check("real timeout kills child", real_timeout)
        check("observed-round dispersion handles outliers, one round and interpolated quartiles", observed_dispersion)
        check("partial nonzero artifacts ignored; zero exit without output fails", failed_artifact_checks)
        check("regex selection, empty selection and malformed regex", selection_checks)
        check("duplicate/nonfinite JSON rejected", invalid_json)

    report = {"schema_version": 1, "status": "checks_passed" if all(item["status"] == "check_passed" for item in checks) else "checks_failed",
              "npu_kernel_executions": 0, "npu_precision_pass_claimed": False,
              "source": "CPU-only orchestration tests; no NPU performance or precision evidence",
              "python_version": sys.version.split()[0], "numpy_version": suite.case_data.np.__version__, "checks": checks}
    if args.report:
        args.report = args.report.expanduser().resolve()
        args.report.parent.mkdir(parents=True, exist_ok=True)
        suite.write_json(args.report, report)
    print(json.dumps(report, indent=2))
    return 0 if report["status"] == "checks_passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
