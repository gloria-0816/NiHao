#!/usr/bin/env bash
set -eo pipefail
if [[ -z "${ASCEND_HOME_PATH:-}" ]]; then
    printf '%s\n' 'Set ASCEND_HOME_PATH to the installed CANN toolkit directory.' >&2
    exit 1
fi
source "${ASCEND_HOME_PATH}/set_env.sh"
exec "$@"
