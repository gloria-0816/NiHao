#!/usr/bin/env python3
"""Run fixed baseline/candidate blocks serially; preserve every suite outcome."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('baseline-runner', 'baseline-source', 'candidate-runner', 'candidate-source', 'manifest', 'run-root'):
        p.add_argument('--' + name, required=True, type=Path)
    p.add_argument('--blocks', type=int, default=3)
    p.add_argument('--environment-report', type=Path)
    args = p.parse_args()
    if not 2 <= args.blocks <= 10:
        p.error('blocks must be 2..10')
    for path in (args.baseline_runner, args.baseline_source, args.candidate_runner, args.candidate_source, args.manifest):
        if not path.is_file():
            p.error('missing input: ' + str(path))
    args.run_root.mkdir(parents=True, exist_ok=False)
    metadata = {
        'schema_version': 1, 'status': 'running',
        'baseline_source_sha256': sha(args.baseline_source),
        'candidate_source_sha256': sha(args.candidate_source),
        'manifest_sha256': sha(args.manifest),
        'order': [], 'runs': [],
        'conditions': {'warmup': 10, 'repeats': 9, 'batch': 50, 'timing': 'both', 'same_buffers_warm': True},
        'note': 'All blocks preserved. Strict failures remain failures. No official score inferred.'
    }
    def save():
        (args.run_root / 'paired_runs.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
    save()
    suite = Path(__file__).resolve().with_name('run_suite.py')
    for block in range(args.blocks):
        labels = ('baseline', 'candidate') if block % 2 == 0 else ('candidate', 'baseline')
        for label in labels:
            folder = args.run_root / ('block%02d_%s' % (block + 1, label))
            runner = getattr(args, label + '_runner')
            source = getattr(args, label + '_source')
            cmd = [sys.executable, str(suite), '--runner', str(runner), '--kernel-source', str(source),
                   '--manifest', str(args.manifest), '--run-dir', str(folder),
                   '--warmup', '10', '--repeats', '9', '--batch', '50', '--timing', 'both']
            if args.environment_report:
                cmd.extend(['--environment-report', str(args.environment_report)])
            begin = time.monotonic()
            with (args.run_root / (folder.name + '.log')).open('w', encoding='utf-8') as log:
                result = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT)
            record = {'block': block + 1, 'label': label, 'run_dir': str(folder), 'command': cmd,
                      'returncode': result.returncode, 'wall_seconds': time.monotonic() - begin}
            metadata['order'].append(label)
            metadata['runs'].append(record)
            save()
            print(json.dumps(record), flush=True)
    metadata['status'] = 'completed' if all(r['returncode'] == 0 for r in metadata['runs']) else 'completed_with_failures'
    save()
    return 0 if metadata['status'] == 'completed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
