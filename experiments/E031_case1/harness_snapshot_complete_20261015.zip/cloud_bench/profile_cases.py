#!/usr/bin/env python3
"""Serial real profiler collections with fresh copied inputs and bounded processes."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent / 'scripts'))
import case_data
import run_suite

FILES = ('x.bin', 'residual.bin', 'gamma.bin', 'bias.bin', 'golden_output.bin', 'golden_output_fp32.bin', 'meta.json')


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(2 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def save(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    temporary.replace(path)


def run_logged(command, stdout, stderr, timeout_s):
    start = time.monotonic()
    with stdout.open('w', encoding='utf-8') as out, stderr.open('w', encoding='utf-8') as err:
        process = subprocess.Popen(command, stdout=out, stderr=err, start_new_session=(os.name == 'posix'))
        timed_out = False
        try:
            returncode = process.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            timed_out = True
            if os.name == 'posix':
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            else:
                process.kill()
            returncode = process.wait()
    return {'returncode': returncode, 'timed_out': timed_out, 'wall_seconds': time.monotonic() - start}


def copy_case(origin, copied, case_id):
    meta = run_suite.read_json(origin / 'meta.json')
    if meta['case_id'] != case_id:
        raise ValueError('Input case_id mismatch')
    if meta['dtype'] not in case_data.DTYPES or not meta['shape'] or any(type(n) is not int or n < 1 for n in meta['shape']):
        raise ValueError('Input dtype/shape invalid')
    if meta['expected_bytes'] != math.prod(meta['shape']) * case_data.DTYPES[meta['dtype']].itemsize:
        raise ValueError('Input expected_bytes mismatch')
    copied.mkdir(mode=0o700)
    copied.chmod(0o700)
    for name in FILES:
        source = origin / name
        if not source.is_file() or source.is_symlink() or source.resolve().parent != origin:
            raise ValueError('Missing or unsafe input file: ' + str(source))
        if name != 'meta.json' and sha(source) != meta['file_sha256'][name]:
            raise ValueError('Input SHA mismatch: ' + str(source))
        shutil.copy2(source, copied / name)
        if sha(copied / name) != sha(source):
            raise ValueError('Copied input SHA mismatch: ' + name)
    return meta


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runner', type=Path, required=True)
    p.add_argument('--kernel-source', type=Path, required=True)
    p.add_argument('--case-root', type=Path, required=True)
    p.add_argument('--case', action='append', required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--blocks', type=int, default=2)
    p.add_argument('--metrics', default='BasicInfo,PipeUtilization,Memory,MemoryUB,L2Cache')
    p.add_argument('--op-only', action='store_true')
    p.add_argument('--objdump', type=Path)
    p.add_argument('--profiler-timeout-s', type=float, default=600)
    p.add_argument('--objdump-timeout-s', type=float, default=60)
    args = p.parse_args()
    if args.blocks < 1 or len(set(args.case)) != len(args.case):
        p.error('--blocks must be positive; --case values must be distinct')
    if any(not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,160}', case) or case.endswith('.') for case in args.case):
        p.error('Unsafe case ID')
    if any(not math.isfinite(value) or value <= 0 for value in (args.profiler_timeout_s, args.objdump_timeout_s)):
        p.error('Timeouts must be finite and positive')
    for key in ('runner', 'kernel_source', 'case_root', 'objdump', 'output'):
        value = getattr(args, key)
        if value is not None:
            setattr(args, key, value.expanduser().resolve())
    for path in (args.runner, args.kernel_source):
        if not path.is_file():
            p.error('Missing file: ' + str(path))
    if os.name == 'posix' and not os.access(args.runner, os.X_OK):
        p.error('Runner is not executable')
    if not args.case_root.is_dir():
        p.error('Missing case-root directory')
    if args.objdump and (not args.objdump.is_file() or (os.name == 'posix' and not os.access(args.objdump, os.X_OK))):
        p.error('objdump is missing or not executable')
    args.output.mkdir(parents=True, exist_ok=False, mode=0o700)
    args.output.chmod(0o700)
    records = {'schema_version': 1, 'status': 'running', 'runner': str(args.runner), 'kernel_source': str(args.kernel_source),
               'runner_sha256': sha(args.runner), 'kernel_sha256': sha(args.kernel_source), 'case_root': str(args.case_root), 'cases': args.case,
               'blocks': args.blocks, 'op_only': args.op_only, 'metrics': args.metrics, 'op_skip': 11, 'op_launch_count': 5,
               'ordinary_last_tasks': 20, 'ordinary_expected_total_tasks': 31,
               'profiler_timeout_s': args.profiler_timeout_s, 'objdump_timeout_s': args.objdump_timeout_s,
               'sampling_note': 'Independent serial blocks. Retain every CSV task; ordinary measured tasks are final 20 after one initial plus ten warmup launches. Op replay conditions need actual CLI metadata.',
               'harness_sources': {str(path.relative_to(Path(__file__).resolve().parent)): sha(path)
                                   for path in (Path(__file__).resolve(), Path(run_suite.__file__), Path(case_data.__file__))},
               'captures': []}
    report = args.output / 'captures.json'
    save(report, records)
    for block in range(args.blocks):
        order = args.case if block % 2 == 0 else list(reversed(args.case))
        for position, case in enumerate(order, 1):
            for mode in (('op',) if args.op_only else ('ordinary', 'op')):
                folder = args.output / ('block%02d_%s_%s' % (block + 1, case, mode))
                folder.mkdir(mode=0o700)
                folder.chmod(0o700)
                copied = folder / 'case'
                runner_args = [str(args.runner), '--case-dir', str(copied), '--metadata', str(copied / 'meta.json'),
                               '--result', str(folder / 'benchmark.json'), '--warmup', '10', '--repeats', '1',
                               '--batch', '5' if mode == 'op' else '20', '--timing', 'host']
                if mode == 'op':
                    cmd = ['msprof', 'op', '--output=' + str(folder / 'profile'), '--aic-metrics=' + args.metrics,
                           '--launch-skip-before-match=11', '--launch-count=5'] + runner_args
                else:
                    cmd = ['msprof', '--output=' + str(folder / 'profile'), '--task-time=on', '--ai-core=off',
                           '--runtime-api=on'] + runner_args
                record = {'block': block + 1, 'position': position, 'case_id': case, 'mode': mode, 'directory': str(folder),
                          'command': cmd, 'status': 'setup_pending', 'returncode': None, 'timed_out': None,
                          'verification': None, 'disassemblies': []}
                records['captures'].append(record)
                save(report, records)
                try:
                    origin = (args.case_root / case).resolve(strict=True)
                    if origin.parent != args.case_root or (args.case_root / case).is_symlink():
                        raise ValueError('Input case directory resolves outside case-root')
                    record['input_meta'] = copy_case(origin, copied, case)
                    record['input_meta_sha256'] = sha(copied / 'meta.json')
                    record['status'] = 'profiler_running'
                    save(report, records)
                    record.update(run_logged(cmd, folder / 'stdout.log', folder / 'stderr.log', args.profiler_timeout_s))
                    if record['timed_out'] or record['returncode'] != 0:
                        record['status'] = 'timeout' if record['timed_out'] else 'profiler_failed'
                        record['error'] = 'Profiler did not finish successfully; output/benchmark are not consumed.'
                        continue
                    record['status'] = 'verification_failed'
                    verification = case_data.verify(copied, verify_hashes=True)
                    record['verification'] = verification
                    save(folder / 'verification.json', verification)
                    if not verification.get('pass'):
                        record['error'] = verification.get('error', 'Strict precision failed')
                        continue
                    record['status'] = 'benchmark_invalid'
                    settings = SimpleNamespace(device=0, warmup=10, repeats=1, batch=5 if mode == 'op' else 20,
                                               timeout_ms=30000, timing='host')
                    raw = run_suite.read_json(folder / 'benchmark.json')
                    record['benchmark'] = run_suite.validate_benchmark(raw, record['input_meta'], settings, records['kernel_sha256'])
                    record['benchmark_sha256'] = sha(folder / 'benchmark.json')
                    record['status'] = 'passed'
                    if mode == 'op' and args.objdump:
                        binaries = sorted((folder / 'profile').rglob('aicore_binary.o'))
                        if not binaries:
                            record['disassembly_error'] = 'No aicore_binary.o exported; no instructions inferred.'
                        for index, binary in enumerate(binaries):
                            if folder.resolve() not in binary.resolve().parents:
                                raise ValueError('Device binary resolves outside capture directory')
                            disasm = folder / ('device_disassembly_%02d.txt' % index)
                            objcmd = [str(args.objdump), '--disassemble-aicore', '--demangle', str(binary)]
                            assembly = {'binary': str(binary), 'sha256': sha(binary), 'command': objcmd,
                                        'output': str(disasm), 'status': 'running'}
                            record['disassemblies'].append(assembly)
                            save(report, records)
                            try:
                                assembly.update(run_logged(objcmd, disasm, folder / ('objdump_%02d.stderr.log' % index), args.objdump_timeout_s))
                                assembly['output_sha256'] = sha(disasm)
                                assembly['status'] = 'passed' if assembly['returncode'] == 0 and not assembly['timed_out'] else 'failed'
                            except (OSError, ValueError) as exc:
                                assembly.update(status='failed', error=f'{type(exc).__name__}: {exc}')
                except (OSError, ValueError, KeyError, TypeError, OverflowError) as exc:
                    record.update(status='capture_failed', error=f'{type(exc).__name__}: {exc}')
                finally:
                    save(report, records)
                    print(json.dumps({'block': block + 1, 'case': case, 'mode': mode, 'status': record['status'],
                                      'returncode': record['returncode'], 'strict_pass': (record.get('verification') or {}).get('pass')}), flush=True)
    failures = sum(record['status'] != 'passed' for record in records['captures'])
    tool_failures = sum(bool(record.get('disassembly_error')) or any(item['status'] != 'passed' for item in record['disassemblies'])
                        for record in records['captures'])
    records.update(status='completed_with_failures' if failures else ('completed_with_tool_failures' if tool_failures else 'completed'),
                   counts=dict(Counter(record['status'] for record in records['captures'])), failed_captures=failures,
                   disassembly_tool_failures=tool_failures)
    save(report, records)
    return 1 if failures or tool_failures else 0


if __name__ == '__main__':
    raise SystemExit(main())
