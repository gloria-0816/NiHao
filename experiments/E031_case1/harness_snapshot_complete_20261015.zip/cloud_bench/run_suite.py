#!/usr/bin/env python3
"""Generate, run and strictly verify representative AddRmsNormBias workloads.

These are self-built cases, not the undisclosed official 15-test suite. A dry run
only writes a plan. Missing NPU executables and failed processes never produce
accuracy Pass or timing evidence.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import platform
import re
import signal
import statistics
import subprocess
import sys
import time
import uuid
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


BENCH_DIR = Path(__file__).resolve().parent
REPO_DIR = BENCH_DIR.parent
sys.path.insert(0, str(BENCH_DIR / "scripts"))
import case_data  # noqa: E402

BASELINE_SHA = "5e48f7f6c505f140e0e9ead0ac90457600323a21e55e182e560142f55dd447e3"
BASELINE_SOURCE = REPO_DIR / "snapshots/addrmsnormbias_submission_681290/code/kernel.asc"
DTYPE_CODES = {"float32": 0, "float16": 1, "bfloat16": 2}
ARTIFACTS = ("output.bin", "benchmark.json", "verification.json", "runner.stdout.log", "runner.stderr.log")
DATA_FILES = ("x.bin", "residual.bin", "gamma.bin", "bias.bin", "golden_output.bin",
              "golden_output_fp32.bin", "golden_output_fp64.bin", "output.bin")
TIMING_STAT_NAMES = ("n", "min_us", "max_us", "iqr_us", "mad_us")
TIMING_STAT_FIELDS = tuple(prefix + "_queued_batch_" + name
                          for prefix in ("host", "event") for name in TIMING_STAT_NAMES)
CSV_FIELDS = ("run_id", "case_id", "status", "shape", "rows", "D", "dtype", "pattern", "seed",
              "epsilon", "kernel_sha256", "runner_sha256", "device", "vector_cores", "timing_mode",
              "host_queued_batch_median_us", "event_queued_batch_median_us", "accuracy_pass",
              "failed_elements", "classification_failures", "finite_failures", "max_abs_error",
              "max_relative_error", "returncode", "runner_process_elapsed_s", "case_workflow_elapsed_s",
              "elapsed_s", "error") + TIMING_STAT_FIELDS


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def write_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def read_json(path):
    def reject_constant(value):
        raise ValueError(f"nonstandard JSON numeric constant: {value}")

    def unique_object(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                raise ValueError(f"duplicate JSON field: {key}")
            value[key] = item
        return value

    return json.loads(Path(path).read_text(encoding="utf-8"),
                      parse_constant=reject_constant, object_pairs_hook=unique_object)


def load_manifest(path, pattern, limit):
    manifest = read_json(path)
    if not isinstance(manifest, dict) or manifest.get("schema_version") != 1:
        raise ValueError("manifest schema_version must be 1")
    cases = manifest.get("cases")
    if not isinstance(cases, list) or not cases:
        raise ValueError("manifest must contain a nonempty cases array")
    seen = set()
    normalized = []
    for raw in cases:
        if not isinstance(raw, dict):
            raise ValueError("each manifest case must be an object")
        item = dict(raw)
        name = item.get("id")
        if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,160}", name) or name.endswith("."):
            raise ValueError(f"unsafe case ID: {name!r}")
        if name in seen:
            raise ValueError(f"duplicate case ID: {name}")
        seen.add(name)
        shape = item.get("shape")
        if not isinstance(shape, list) or any(type(n) is not int for n in shape):
            raise ValueError(f"{name}: shape must be an integer array")
        item["shape"] = case_data.parse_shape(",".join(map(str, shape)))
        if item.get("dtype") not in case_data.DTYPES:
            raise ValueError(f"{name}: unknown dtype")
        item.setdefault("seed", 42)
        item.setdefault("epsilon", 1e-5)
        item.setdefault("pattern", "uniform")
        if type(item["seed"]) is not int or not 0 <= item["seed"] < 2**32:
            raise ValueError(f"{name}: seed must be an integer in [0, 2**32)")
        epsilon = item["epsilon"]
        if type(epsilon) not in (int, float) or not math.isfinite(epsilon) or epsilon <= 0:
            raise ValueError(f"{name}: epsilon must be finite and positive")
        # The kernel receives an FP32 epsilon. Refuse underflow/overflow here.
        with case_data.np.errstate(over="ignore", under="ignore"):
            eps32 = case_data.np.float32(epsilon)
        if not case_data.np.isfinite(eps32) or eps32 <= 0:
            raise ValueError(f"{name}: epsilon must remain finite and positive in FP32")
        if item["pattern"] not in case_data.PATTERNS:
            raise ValueError(f"{name}: unknown input pattern")
        expected = math.prod(item["shape"]) * case_data.DTYPES[item["dtype"]].itemsize
        if "tensor_bytes" in item and (type(item["tensor_bytes"]) is not int or item["tensor_bytes"] != expected):
            raise ValueError(f"{name}: tensor_bytes does not match shape/dtype")
        item["tensor_bytes"] = expected
        normalized.append(item)
    selected = [item for item in normalized if pattern.search(item["id"])]
    if limit is not None:
        selected = selected[:limit]
    if not selected:
        raise ValueError("case selection is empty")
    return manifest, selected


def runner_command(args, directory):
    return [str(args.runner), "--case-dir", str(directory), "--metadata", str(directory / "meta.json"),
            "--result", str(directory / "benchmark.json"), "--device", str(args.device),
            "--warmup", str(args.warmup), "--repeats", str(args.repeats), "--batch", str(args.batch),
            "--timing", args.timing, "--timeout-ms", str(args.timeout_ms),
            "--max-device-bytes", str(args.max_device_bytes)]


def run_process(command, directory, timeout_s):
    """Log to disk and kill only this process group on timeout; no shell involved."""
    start = time.monotonic()
    with (directory / "runner.stdout.log").open("wb") as stdout, \
            (directory / "runner.stderr.log").open("wb") as stderr:
        process = subprocess.Popen(command, stdout=stdout, stderr=stderr,
                                   start_new_session=(os.name == "posix"))
        try:
            returncode = process.wait(timeout=timeout_s)
            elapsed = time.monotonic() - start
            return {"returncode": returncode, "timed_out": False,
                    "runner_process_elapsed_s": elapsed, "elapsed_s": elapsed}
        except subprocess.TimeoutExpired:
            if os.name == "posix":
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            else:
                process.kill()
            process.wait()
            elapsed = time.monotonic() - start
            return {"returncode": process.returncode, "timed_out": True,
                    "runner_process_elapsed_s": elapsed, "elapsed_s": elapsed}


def timing_dispersion(samples):
    """Describe observed rounds; no confidence interval or task-time inference."""
    ordered = sorted(samples)
    center = statistics.median(ordered)

    def quantile(fraction):
        position = (len(ordered) - 1) * fraction
        left = int(math.floor(position))
        right = int(math.ceil(position))
        return ordered[left] + (ordered[right] - ordered[left]) * (position - left)

    return {"n": len(ordered), "min_us": ordered[0], "max_us": ordered[-1],
            "iqr_us": quantile(0.75) - quantile(0.25),
            "mad_us": statistics.median(abs(value - center) for value in ordered)}


def validate_benchmark(value, meta, args, expected_sha):
    """Reject mismatched/stale metadata and nonfinite/incomplete timing arrays."""
    if not isinstance(value, dict) or value.get("schema_version") != 1:
        raise ValueError("benchmark must be an object with schema_version 1")
    if not isinstance(value.get("shape"), list) or any(type(n) is not int for n in value["shape"]):
        raise ValueError("benchmark shape must be an integer array")
    for key in ("device", "dtype", "warmup", "repeats", "batch", "timeout_ms"):
        if type(value.get(key)) is not int:
            raise ValueError(f"benchmark {key} must be an integer")
    expected_fields = {"kernel_sha256": expected_sha, "shape": meta["shape"],
                       "dtype": DTYPE_CODES[meta["dtype"]], "device": args.device,
                       "warmup": args.warmup, "repeats": args.repeats, "batch": args.batch,
                       "timeout_ms": args.timeout_ms, "timing_mode": args.timing,
                       "cache_mode": "same_buffers_warm"}
    for key, expected in expected_fields.items():
        if value.get(key) != expected:
            raise ValueError(f"benchmark {key} mismatch: expected {expected!r}, got {value.get(key)!r}")
    if value.get("status") != "executed_not_yet_verified":
        raise ValueError("benchmark runner status must be executed_not_yet_verified")
    epsilon = value.get("epsilon")
    if type(epsilon) not in (int, float) or not math.isclose(epsilon, meta["epsilon"], rel_tol=2e-7, abs_tol=0):
        raise ValueError("benchmark epsilon mismatch")
    cores = value.get("vector_cores")
    if type(cores) is not int or cores < 1:
        raise ValueError("benchmark has invalid vector_cores")
    required = 3 * meta["expected_bytes"] + 2 * meta["vector_bytes"]
    if type(value.get("required_device_bytes")) is not int or value["required_device_bytes"] != required:
        raise ValueError("benchmark required_device_bytes mismatch")
    for key in ("free_hbm_before_allocation", "total_hbm"):
        if type(value.get(key)) is not int or value[key] < 0:
            raise ValueError(f"benchmark {key} must be a nonnegative integer")
    if value["free_hbm_before_allocation"] > value["total_hbm"]:
        raise ValueError("benchmark free HBM exceeds total HBM")
    if not isinstance(value.get("timing_definition"), str) or not value["timing_definition"]:
        raise ValueError("benchmark lacks timing_definition")
    prefixes = ["host"] + (["event"] if args.timing != "host" else [])
    enriched = dict(value)
    for prefix in prefixes:
        samples = value.get(prefix + "_queued_batch_us")
        center = value.get(prefix + "_queued_batch_median_us")
        if not isinstance(samples, list) or len(samples) != args.repeats:
            raise ValueError(f"benchmark {prefix} timing sample count mismatch")
        if any(type(n) not in (int, float) or not math.isfinite(n) or n < 0 for n in samples):
            raise ValueError(f"benchmark {prefix} timing sample invalid")
        if type(center) not in (int, float) or not math.isfinite(center) or center < 0:
            raise ValueError(f"benchmark {prefix} median invalid")
        if not math.isclose(center, statistics.median(samples), rel_tol=1e-8, abs_tol=1e-8):
            raise ValueError(f"benchmark {prefix} median disagrees with samples")
        enriched.update({prefix + "_queued_batch_" + name: statistic
                         for name, statistic in timing_dispersion(samples).items()})
    enriched["timing_statistics_definition"] = (
        "Observed round range; IQR uses linear interpolation at (n-1)*q; MAD is unscaled "
        "median absolute deviation from the median. No device task time or confidence interval inferred.")
    return enriched


def csv_row(record):
    spec, meta = record["case"], record.get("metadata") or {}
    benchmark = record.get("benchmark") or {}
    verification = record.get("verification") or {}
    row = {key: record.get(key, "") for key in CSV_FIELDS}
    row.update({"case_id": spec["id"], "shape": "x".join(map(str, spec["shape"])),
                "rows": math.prod(spec["shape"][:-1]), "D": spec["shape"][-1],
                "dtype": spec["dtype"], "pattern": spec["pattern"], "seed": spec["seed"],
                "epsilon": meta.get("epsilon", spec["epsilon"]), "device": record["settings"]["device"],
                "timing_mode": record["settings"]["timing"],
                "accuracy_pass": verification.get("pass", "")})
    for key in ("vector_cores", "host_queued_batch_median_us", "event_queued_batch_median_us") + TIMING_STAT_FIELDS:
        row[key] = benchmark.get(key, "")
    for key in ("failed_elements", "classification_failures", "finite_failures", "max_abs_error", "max_relative_error"):
        row[key] = verification.get(key, "")
    return row


def run_case(spec, args, base, runner_error):
    directory = args.run_dir / "data" / spec["id"]
    record = dict(base)
    record.update({"case": spec, "case_dir": str(directory), "started_at_utc": utc_now(),
                   "status": "planned" if args.dry_run else "setup_failed", "metadata": None,
                   "verification": None, "benchmark": None,
                   "command": runner_command(args, directory)})
    if args.dry_run:
        record["executed"] = False
        return record
    record["executed"] = False
    start = time.monotonic()
    safe_directory = False
    try:
        # Do not follow a preexisting case-directory symlink outside this run.
        if args.run_dir not in directory.resolve().parents:
            raise ValueError("case directory resolves outside run-dir")
        safe_directory = True
        directory.mkdir(parents=True, exist_ok=True)
        # Exactly scoped files only. A failed current launch cannot consume old
        # output, timing or verifier reports from an earlier launch.
        for name in ARTIFACTS:
            (directory / name).unlink(missing_ok=True)
        if runner_error:
            record.update(status="runner_missing", error=runner_error)
            return record
        record["status"] = "generation_failed"
        meta = case_data.generate(directory, spec["shape"], spec["dtype"], spec["seed"],
                                  spec["epsilon"], spec["pattern"], args.chunk_rows,
                                  args.max_work_mib, args.max_tensor_mib,
                                  args.diagnostic_fp64, overwrite=True, case_id=spec["id"])
        record["metadata"] = meta
        record["status"] = "execution_failed"
        process = run_process(record["command"], directory, args.timeout_s)
        record.update(process)
        record["executed"] = True
        if process["timed_out"]:
            record.update(status="timeout", error=f"runner exceeded {args.timeout_s:g} seconds")
            return record
        if process["returncode"] != 0:
            record["error"] = f"runner exited with code {process['returncode']}; see runner.stderr.log"
            return record
        # Do not read any output after a timeout or nonzero exit.
        record["status"] = "verification_failed"
        verification = case_data.verify(directory, chunk_rows=args.chunk_rows,
                                        max_work_mib=args.max_work_mib, verify_hashes=True)
        record["verification"] = verification
        write_json(directory / "verification.json", verification)
        if not verification["pass"]:
            record["error"] = verification.get("error", f"{verification.get('failed_elements')} inaccurate elements")
            return record
        record["status"] = "benchmark_invalid"
        value = read_json(directory / "benchmark.json")
        record["benchmark"] = validate_benchmark(value, meta, args, record["kernel_sha256"])
        record["status"] = "passed"
        return record
    except (OSError, ValueError, OverflowError, argparse.ArgumentTypeError) as exc:
        record["error"] = f"{type(exc).__name__}: {exc}"
        return record
    finally:
        record["case_workflow_elapsed_s"] = time.monotonic() - start
        record["elapsed_s"] = record["case_workflow_elapsed_s"]
        record["finished_at_utc"] = utc_now()
        if args.discard_case_data and safe_directory and directory.is_dir():
            # Preserve metadata, reports and logs; delete only these named binary
            # artifacts in the exact case directory, never recursively delete.
            for name in DATA_FILES:
                try:
                    (directory / name).unlink(missing_ok=True)
                except OSError as exc:
                    record.setdefault("cleanup_errors", []).append(f"{name}: {exc}")


def parse_args(argv):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=BENCH_DIR / "cases/smoke.json")
    parser.add_argument("--runner", type=Path, default=BENCH_DIR / "build/cloud_addrmsnormbias")
    parser.add_argument("--kernel-source", type=Path, default=BASELINE_SOURCE,
                        help="must match the source compiled into --runner; runner SHA is checked")
    parser.add_argument("--run-dir", type=Path, help="report/data directory; named current case outputs are replaced")
    parser.add_argument("--case-regex", default=".*", help="Python regex searched against manifest case IDs")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--repeats", type=int, default=7)
    parser.add_argument("--batch", type=int, default=100)
    parser.add_argument("--timing", choices=("both", "host", "event"), default="both")
    parser.add_argument("--timeout-ms", type=int, default=30000, help="runner stream synchronization timeout")
    parser.add_argument("--timeout-s", type=float, default=180, help="wall timeout for a complete case process")
    parser.add_argument("--max-device-bytes", type=int, default=2 << 30)
    parser.add_argument("--chunk-rows", type=int, default=256)
    parser.add_argument("--max-work-mib", type=float, default=128)
    parser.add_argument("--max-tensor-mib", type=float, default=256)
    parser.add_argument("--diagnostic-fp64", action="store_true")
    parser.add_argument("--discard-case-data", action="store_true", help="delete named binary case files after reporting")
    parser.add_argument("--environment-report", type=Path, help="optional collect_env.sh output to identify by path/hash")
    parser.add_argument("--dry-run", action="store_true", help="write plans only; do not generate/run/verify tensors")
    args = parser.parse_args(argv)
    for key in ("device", "warmup", "repeats", "batch", "timeout_ms"):
        value = getattr(args, key)
        if value < (0 if key in ("device", "warmup") else 1) or value > 1000000:
            parser.error(f"{key.replace('_', '-')} is outside the runner's supported integer range")
    for key in ("timeout_s", "max_work_mib", "max_tensor_mib"):
        if not math.isfinite(getattr(args, key)) or getattr(args, key) <= 0:
            parser.error(f"{key.replace('_', '-')} must be finite and positive")
    if args.chunk_rows < 1 or args.max_device_bytes < 1 or (args.limit is not None and args.limit < 1):
        parser.error("chunk-rows/max-device-bytes/limit must be positive")
    try:
        args.selection = re.compile(args.case_regex)
    except re.error as exc:
        parser.error(f"invalid case-regex: {exc}")
    for key in ("manifest", "runner", "kernel_source", "environment_report"):
        path = getattr(args, key)
        if path is not None:
            setattr(args, key, path.expanduser().resolve())
    if args.run_dir is None:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        args.run_dir = BENCH_DIR / "results" / (stamp + "-" + uuid.uuid4().hex[:8])
    args.run_dir = args.run_dir.expanduser().resolve()
    return args


def main(argv=None):
    args = parse_args(argv)
    try:
        manifest, cases = load_manifest(args.manifest, args.selection, args.limit)
        source_sha = case_data.sha256(args.kernel_source)
        runner_error = None
        if not args.runner.is_file():
            runner_error = f"runner executable does not exist: {args.runner}"
        elif os.name == "posix" and not os.access(args.runner, os.X_OK):
            runner_error = f"runner is not executable: {args.runner}"
        runner_sha = case_data.sha256(args.runner) if args.runner.is_file() else None
        if args.environment_report is not None and not args.environment_report.is_file():
            raise ValueError("environment-report does not exist")
        args.run_dir.mkdir(parents=True, exist_ok=True)
        run_id = uuid.uuid4().hex
        settings = {key: getattr(args, key) for key in ("device", "warmup", "repeats", "batch", "timing",
                    "timeout_ms", "timeout_s", "max_device_bytes", "chunk_rows", "max_work_mib",
                    "max_tensor_mib", "diagnostic_fp64", "discard_case_data")}
        base = {"schema_version": 1, "run_id": run_id, "kernel_sha256": source_sha,
                "kernel_source": str(args.kernel_source), "runner": str(args.runner), "runner_sha256": runner_sha,
                "manifest": str(args.manifest), "manifest_sha256": case_data.sha256(args.manifest),
                "suite": manifest.get("suite"), "settings": settings,
                "source": "representative workloads; not the undisclosed official 15 tests",
                "duration_definitions": {
                    "runner_process_elapsed_s": "Child process wall time, including initialization, transfers, warmup, all batches, output writing and cleanup; excludes Python generation/verification.",
                    "case_workflow_elapsed_s": "Case workflow wall time, including data generation, child process and verification; excludes optional data-discard cleanup.",
                    "elapsed_s": "Compatibility alias for case_workflow_elapsed_s in case records; not per-launch or device task duration."}}
        meta = dict(base, created_at_utc=utc_now(), python_version=platform.python_version(),
                    numpy_version=case_data.np.__version__, host_platform=platform.platform(),
                    dry_run=args.dry_run, selected_case_ids=[case["id"] for case in cases],
                    reference_baseline_submission=681290, reference_baseline_sha256=BASELINE_SHA,
                    runner_preflight_error=runner_error)
        meta["harness_sources"] = {
            str(path.relative_to(BENCH_DIR)): case_data.sha256(path)
            for path in (BENCH_DIR / "runner.asc", BENCH_DIR / "CMakeLists.txt",
                         BENCH_DIR / "run_suite.py", BENCH_DIR / "scripts" / "case_data.py")
            if path.is_file()
        }
        if args.environment_report is not None:
            meta["environment_report"] = {"path": str(args.environment_report),
                                          "sha256": case_data.sha256(args.environment_report)}
        write_json(args.run_dir / "run_meta.json", meta)
        counts = Counter()
        start = time.monotonic()
        with (args.run_dir / "results.jsonl").open("w", encoding="utf-8") as jsonl, \
                (args.run_dir / "results.csv").open("w", encoding="utf-8", newline="") as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=CSV_FIELDS)
            writer.writeheader()
            for index, spec in enumerate(cases, 1):
                record = run_case(spec, args, base, runner_error)
                counts[record["status"]] += 1
                jsonl.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
                jsonl.flush()
                writer.writerow(csv_row(record))
                csv_file.flush()
                print(f"[{index}/{len(cases)}] {spec['id']}: {record['status']}" +
                      (f" ({record['error']})" if record.get("error") else ""), flush=True)
        failures = len(cases) - counts["passed"] - counts["planned"]
        summary = {"schema_version": 1, "run_id": run_id, "status": "planned" if args.dry_run else ("failed" if failures else "passed"),
                   "dry_run": args.dry_run, "selected_cases": len(cases), "passed_cases": counts["passed"],
                   "failed_cases": failures, "planned_cases": counts["planned"], "counts": dict(counts),
                   "elapsed_s": time.monotonic() - start, "finished_at_utc": utc_now(),
                   "kernel_sha256": source_sha, "reports": {name: str(args.run_dir / name)
                    for name in ("results.jsonl", "results.csv", "run_meta.json")},
                   "note": "No official score is calculated. Pass requires precision validation and matched runner timing metadata; planned is unexecuted."}
        write_json(args.run_dir / "summary.json", summary)
        print(json.dumps(summary, indent=2), flush=True)
        return 1 if failures else 0
    except (OSError, ValueError, KeyError, OverflowError, argparse.ArgumentTypeError) as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
