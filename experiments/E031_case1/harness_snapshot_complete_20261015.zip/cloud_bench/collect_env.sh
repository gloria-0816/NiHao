#!/usr/bin/env bash
# Read-only device/tool inventory. Do not collect full environment or credentials.
set -u
report="${1:-}"
if [[ $# -gt 1 ]]; then
    printf 'Usage: bash collect_env.sh [report.txt]\n' >&2
    exit 2
fi
if [[ -n "${report}" ]]; then
    mkdir -p "$(dirname -- "${report}")" || exit 1
    exec > "${report}" 2>&1
fi
section() { printf '\n== %s ==\n' "$1"; }
run_limited() {
    if command -v timeout >/dev/null 2>&1; then
        timeout 20s "$@"
    else
        "$@"
    fi
    local code=$?
    if [[ ${code} -ne 0 ]]; then printf '[exit %s]\n' "${code}"; fi
    return 0
}
section 'Report identity'
printf 'UTC: '; date -u '+%Y-%m-%dT%H:%M:%SZ'
printf 'Inventory only; no cloud credentials or full environment collected.\n'
section 'OS and architecture'
uname -srmo
if [[ -r /etc/os-release ]]; then
    # The OS release file is system metadata, not an environment dump.
    sed -n '/^\(NAME\|VERSION\|ID\|VERSION_ID\|PRETTY_NAME\)=/p' /etc/os-release
fi
section 'Whitelisted Ascend paths'
printf 'ASCEND_HOME_PATH=%s\n' "${ASCEND_HOME_PATH:-<unset>}"
printf 'ASCEND_TOOLKIT_HOME=%s\n' "${ASCEND_TOOLKIT_HOME:-<unset>}"
printf 'ASCEND_CANN_PACKAGE_PATH=%s\n' "${ASCEND_CANN_PACKAGE_PATH:-<unset>}"
section 'Tool locations and versions'
for tool in npu-smi msprof msprof-op msopprof bisheng ccec cmake make python3 git; do
    if command -v "${tool}" >/dev/null 2>&1; then
        printf '%s: %s\n' "${tool}" "$(command -v "${tool}")"
        case "${tool}" in
            npu-smi) ;;
            msprof|msprof-op|msopprof) run_limited "${tool}" --help ;;
            *) run_limited "${tool}" --version ;;
        esac
    else
        printf '%s: <not on PATH>\n' "${tool}"
    fi
done
section 'NPU inventory'
if command -v npu-smi >/dev/null 2>&1; then
    run_limited npu-smi info
else
    printf 'npu-smi unavailable; hardware identity is not verified.\n'
fi
section 'Python and NumPy'
if command -v python3 >/dev/null 2>&1; then
    run_limited python3 -c 'import sys, platform; print("executable:", sys.executable); print("python:", platform.python_version()); import numpy; print("numpy:", numpy.__version__)'
fi
section 'Installed Ascend version metadata'
for version_file in \
    /usr/local/Ascend/driver/version.info \
    /usr/local/Ascend/firmware/version.info \
    /usr/local/Ascend/ascend-toolkit/latest/version.cfg \
    /usr/local/Ascend/ascend-toolkit/latest/aarch64-linux/ascend_toolkit_install.info \
    /usr/local/Ascend/ascend-toolkit/latest/x86_64-linux/ascend_toolkit_install.info; do
    if [[ -f "${version_file}" && -r "${version_file}" ]]; then
        printf '%s\n' "${version_file}"
        # Select version/package/architecture fields, not arbitrary install data.
        sed -n '/^[[:space:]]*\(Version\|version\|version_dir\|runtime_version\|compiler_version\|package_name\|arch\|Architecture\)[[:space:]]*[=:]/p' "${version_file}"
    fi
done
if [[ -n "${ASCEND_HOME_PATH:-}" ]]; then
    for version_file in "${ASCEND_HOME_PATH}/version.cfg" "${ASCEND_HOME_PATH}/version.info" \
        "${ASCEND_HOME_PATH}/compiler/version.info" "${ASCEND_HOME_PATH}/opp/version.info" \
        "${ASCEND_HOME_PATH}/aarch64-linux/ascend_toolkit_install.info"; do
        if [[ -f "${version_file}" && -r "${version_file}" ]]; then
            printf '%s\n' "${version_file}"
            sed -n '/^[[:space:]]*\(Version\|version\|version_dir\|runtime_version\|compiler_version\|package_name\|arch\|Architecture\)[[:space:]]*[=:]/p' "${version_file}"
        fi
    done
fi
section 'Interpretation'
printf 'Confirm the actual chip, vector-core count, CANN version and architecture before building.\n'
printf 'A2 label alone does not prove an exact match with the official judge device.\n'
