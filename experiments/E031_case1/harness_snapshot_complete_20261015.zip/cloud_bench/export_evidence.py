#!/usr/bin/env python3
"""Export explicitly selected report files, never tensors or executable files.

Suite roots require a finished summary. Profiler roots are consistent file
snapshots; exporter success does not assert that a profiler job has completed.
No source files are changed or removed. A ZIP is published only after CRC and
SHA256 read-back verification.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import stat
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path


ALLOWED_SUFFIXES = frozenset((".json", ".jsonl", ".csv", ".txt", ".log", ".md"))
TERMINAL_STATUSES = frozenset(("passed", "failed", "planned", "complete", "completed", "finished"))
CHUNK_BYTES = 2 * 1024 * 1024


class ExportError(ValueError):
    pass


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(CHUNK_BYTES), b""):
            digest.update(block)
    return digest.hexdigest()


def stat_identity(value):
    return (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns,
            # Windows path stat/handle fstat can disagree on creation/change
            # time for an unchanged file. POSIX ctime is a useful extra check.
            value.st_ctime_ns if os.name == "posix" else None, stat.S_IMODE(value.st_mode))


def inspect_path(path, kind):
    original = Path(path).expanduser().absolute()
    if original.is_symlink():
        raise ExportError(f"explicit {kind} root must not be a symlink: {original}")
    resolved = original.resolve(strict=True)
    if any(part.casefold() == ".ssh" for part in resolved.parts):
        raise ExportError("SSH directories and their contents are outside the export scope")
    if resolved == Path(resolved.anchor) or resolved == Path.home().resolve():
        raise ExportError("select a report directory, not a filesystem root or an entire home directory")
    # Parent directories containing multiple user homes are not report roots.
    if kind == "directory" and (resolved == Path.home().resolve().parent
                                or str(resolved).rstrip("/") in ("/home", "/Users", "/root")):
        raise ExportError("user-home containers are outside the export scope")
    if kind == "directory" and not resolved.is_dir():
        raise ExportError(f"directory does not exist: {resolved}")
    if kind == "file" and not resolved.is_file():
        raise ExportError(f"file does not exist: {resolved}")
    return resolved


def read_json(path):
    def reject_constant(value):
        raise ExportError(f"nonstandard JSON value: {value}")

    def unique_object(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ExportError(f"duplicate JSON field: {key}")
            result[key] = value
        return result

    value = json.loads(Path(path).read_text(encoding="utf-8"), parse_constant=reject_constant,
                       object_pairs_hook=unique_object)
    if not isinstance(value, dict):
        raise ExportError(f"JSON report must be an object: {path}")
    return value


def suite_state(directory):
    summary_path = directory / "summary.json"
    if not summary_path.is_file() or summary_path.is_symlink():
        raise ExportError(f"suite requires a regular summary.json: {directory}")
    if summary_path.stat().st_size > 2 * 1024 * 1024:
        raise ExportError(f"suite summary exceeds 2 MiB: {summary_path}")
    before = summary_path.stat()
    summary = read_json(summary_path)
    if stat_identity(before) != stat_identity(summary_path.stat()):
        raise ExportError(f"suite summary changed while reading; retry after it finishes: {directory}")
    status = summary.get("status")
    if not isinstance(status, str) or status.casefold() not in TERMINAL_STATUSES:
        raise ExportError(f"suite summary is not finished: {directory}; status={status!r}")
    metadata_path = directory / "run_meta.json"
    if metadata_path.exists():
        if metadata_path.is_symlink() or not metadata_path.is_file():
            raise ExportError(f"suite run_meta.json must be a regular file: {directory}")
        metadata = read_json(metadata_path)
        if metadata.get("run_id") != summary.get("run_id"):
            raise ExportError(f"suite summary/run_meta run_id mismatch; old summary or active rerun: {directory}")
    return {"summary_status": status, "run_id": summary.get("run_id"),
            "completeness": "terminal_summary_present; exporter does not infer NPU correctness"}


def safe_relative(path, root):
    relative = path.relative_to(root)
    if any(part in ("", ".", "..") or "\\" in part for part in relative.parts):
        raise ExportError(f"unsafe archive relative path: {relative}")
    return relative.as_posix()


def executable_file(path, value):
    if os.name == "posix" and stat.S_IMODE(value.st_mode) & 0o111:
        return True
    # Also reject executable binaries renamed with an allowed text suffix.
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    with os.fdopen(os.open(path, flags), "rb") as source:
        if stat_identity(os.fstat(source.fileno())) != stat_identity(value):
            raise ExportError(f"source changed while inspecting: {path}")
        signature = source.read(4)
    return signature.startswith(b"\x7fELF") or signature.startswith(b"MZ")


def enumerate_root(directory, role):
    selected, omissions = [], []

    def walk_error(error):
        raise ExportError(f"cannot enumerate explicit report root: {error}")

    for current, directories, names in os.walk(directory, followlinks=False, onerror=walk_error):
        current = Path(current)
        for name in sorted(list(directories)):
            child = current / name
            reason = "SSH_directory_excluded" if name.casefold() == ".ssh" else (
                "symlink_directory_excluded" if child.is_symlink() else None)
            if reason:
                directories.remove(name)
                omissions.append({"role": role, "relative_path": safe_relative(child, directory), "reason": reason})
        directories.sort()
        for name in sorted(names):
            path = current / name
            relative = safe_relative(path, directory)
            value = path.lstat()
            if stat.S_ISLNK(value.st_mode):
                reason = "symlink_file_excluded"
            elif not stat.S_ISREG(value.st_mode):
                reason = "nonregular_file_excluded"
            elif path.suffix.casefold() not in ALLOWED_SUFFIXES:
                reason = "suffix_excluded"
            elif executable_file(path, value):
                reason = "executable_file_excluded"
            else:
                selected.append({"path": path, "role": role, "relative_path": relative,
                                 "archive_path": role + "/" + relative, "stat": stat_identity(value)})
                continue
            omissions.append({"role": role, "relative_path": relative, "reason": reason})
    return selected, omissions


def copy_payload(archive, item):
    path = item["path"]
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or stat_identity(before) != item["stat"]:
        raise ExportError(f"source changed before copying; retry after writers finish: {path}")
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(path, flags)
    digest = hashlib.sha256()
    copied = 0
    info = zipfile.ZipInfo(item["archive_path"])
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = (stat.S_IFREG | 0o644) << 16
    try:
        with os.fdopen(descriptor, "rb") as source:
            descriptor = None
            if stat_identity(os.fstat(source.fileno())) != item["stat"]:
                raise ExportError(f"source changed while opening: {path}")
            with archive.open(info, "w", force_zip64=True) as destination:
                for block in iter(lambda: source.read(CHUNK_BYTES), b""):
                    digest.update(block)
                    copied += len(block)
                    destination.write(block)
            if stat_identity(os.fstat(source.fileno())) != item["stat"]:
                raise ExportError(f"source changed while copying; retry after writers finish: {path}")
    finally:
        if descriptor is not None:
            os.close(descriptor)
    if stat_identity(path.lstat()) != item["stat"] or copied != before.st_size:
        raise ExportError(f"source changed after copying; retry after writers finish: {path}")
    return {"role": item["role"], "relative_path": item["relative_path"],
            "archive_path": item["archive_path"], "bytes": copied, "sha256": digest.hexdigest(),
            "source_mtime_ns": before.st_mtime_ns}


def verify_zip(path, records, manifest_bytes):
    expected = {item["archive_path"]: item for item in records}
    expected["manifest.json"] = {"bytes": len(manifest_bytes),
                                 "sha256": hashlib.sha256(manifest_bytes).hexdigest()}
    with zipfile.ZipFile(path, "r") as archive:
        entries = archive.infolist()
        if len(entries) != len(expected) or {item.filename for item in entries} != set(expected):
            raise ExportError("ZIP contains missing, duplicate or unexpected entries")
        corrupt = archive.testzip()
        if corrupt is not None:
            raise ExportError(f"ZIP CRC verification failed: {corrupt}")
        for name, wanted in expected.items():
            digest, count = hashlib.sha256(), 0
            with archive.open(name) as source:
                for block in iter(lambda: source.read(CHUNK_BYTES), b""):
                    digest.update(block)
                    count += len(block)
            if count != wanted["bytes"] or digest.hexdigest() != wanted["sha256"]:
                raise ExportError(f"ZIP SHA256/byte read-back verification failed: {name}")


def export(suite_dirs, profile_dirs, extra_files, output):
    if not suite_dirs and not profile_dirs and not extra_files:
        raise ExportError("give at least one --suite-dir, --profile-dir or --extra-file")
    output = Path(output).expanduser().absolute()
    if output.suffix.casefold() != ".zip":
        raise ExportError("--output must end in .zip to avoid replacing report files")
    roots, items, omissions = [], [], []
    directories = []
    for kind, paths in (("suite", suite_dirs), ("profile", profile_dirs)):
        for index, path in enumerate(paths):
            directory = inspect_path(path, "directory")
            role = f"{kind}_{index}"
            state = suite_state(directory) if kind == "suite" else {
                "completeness": "consistent_snapshot_only; profiler completion not asserted"}
            roots.append({"role": role, "kind": kind, "source_root": str(directory),
                          "archive_prefix": role, **state})
            selected, excluded = enumerate_root(directory, role)
            directories.append((directory, role, {item["relative_path"] for item in selected}))
            items.extend(selected)
            omissions.extend(excluded)
    for index, path in enumerate(extra_files):
        source = inspect_path(path, "file")
        role = "extra"
        relative = f"file_{index}/" + source.name
        if "\\" in source.name or source.name in (".", ".."):
            raise ExportError(f"unsafe extra filename: {source.name}")
        roots.append({"role": role, "kind": "file", "index": index,
                      "source_root": str(source), "archive_prefix": f"extra/file_{index}",
                      "completeness": "consistent_snapshot_only"})
        value = source.lstat()
        if source.suffix.casefold() not in ALLOWED_SUFFIXES:
            reason = "suffix_excluded"
        elif executable_file(source, value):
            reason = "executable_file_excluded"
        else:
            items.append({"path": source, "role": role, "relative_path": relative,
                          "archive_path": "extra/" + relative, "stat": stat_identity(value)})
            continue
        omissions.append({"role": role, "relative_path": relative, "reason": reason})
    if not items:
        raise ExportError("no eligible report files were found; nothing exported")
    archive_names = [item["archive_path"] for item in items]
    if len(archive_names) != len(set(archive_names)):
        raise ExportError("duplicate archive paths")
    output.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix="." + output.name + "-", suffix=".tmp", dir=output.parent)
    os.close(descriptor)
    temporary = Path(temporary_name)
    try:
        records = []
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for item in items:
                records.append(copy_payload(archive, item))
            for item in items:
                if stat_identity(item["path"].lstat()) != item["stat"]:
                    raise ExportError(f"report changed before snapshot finished: {item['path']}")
            for directory, role, initial_names in directories:
                selected, _ = enumerate_root(directory, role)
                if {item["relative_path"] for item in selected} != initial_names:
                    raise ExportError(f"report file set changed during export: {directory}")
                if role.startswith("suite_"):
                    current = suite_state(directory)
                    initial = next(root for root in roots if root["role"] == role)
                    if current["run_id"] != initial["run_id"] or current["summary_status"] != initial["summary_status"]:
                        raise ExportError(f"suite completion metadata changed during export: {directory}")
            manifest = {"schema_version": 1, "created_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                        "purpose": "report evidence snapshot; no tensors, executables or SSH directories",
                        "snapshot_consistency": "source identities and report file sets unchanged during copying",
                        "allowed_suffixes": sorted(ALLOWED_SUFFIXES), "input_roots": roots,
                        "payload_file_count": len(records), "payload_bytes": sum(item["bytes"] for item in records),
                        "files": records, "omissions": omissions,
                        "manifest_note": "Payload files have SHA256/byte entries. manifest.json is CRC/SHA read-back checked separately; its SHA is returned by the CLI."}
            manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")
            archive.writestr("manifest.json", manifest_bytes)
        verify_zip(temporary, records, manifest_bytes)
        archive_sha = sha256_file(temporary)
        archive_bytes = temporary.stat().st_size
        temporary.replace(output)
        return {"status": "exported_and_verified", "output": str(output), "zip_sha256": archive_sha,
                "zip_bytes": archive_bytes, "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
                "payload_files": len(records), "payload_bytes": sum(item["bytes"] for item in records),
                "profile_completion_asserted": False, "source_files_deleted": False,
                "verification": "complete ZIP CRC and every entry SHA256/byte read-back"}
    finally:
        temporary.unlink(missing_ok=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite-dir", action="append", type=Path, default=[])
    parser.add_argument("--profile-dir", action="append", type=Path, default=[])
    parser.add_argument("--extra-file", action="append", type=Path, default=[])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        result = export(args.suite_dir, args.profile_dir, args.extra_file, args.output)
        print(json.dumps(result, indent=2))
        return 0
    except (OSError, ValueError, RuntimeError, zipfile.BadZipFile) as exc:
        print(f"Export failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
