import sys,json,hashlib,subprocess,statistics,csv,time,os,importlib.util
from pathlib import Path
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[1]
spec=importlib.util.spec_from_file_location('core',ROOT/'experiments/E006A_probe/cloud_driver.py');core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
core.PROTOCOL=dict(timeout_ms=30000,process_timeout_s=240)
OUT=Path('/home/developer/addrms_experiments/E027');OUT.mkdir(exist_ok=True)
def source(v):
 if v=='BASE':return HERE/'BASE/code/kernel.asc'
 return ROOT/'experiments/E014_crossrow_cast/source/C/kernel.asc' if v=='C' else HERE/v/'code/kernel.asc'
def runner(v):
 if v=='BASE':return ROOT/'experiments/E026_target70/build_FACC/cloud_addrmsnormbias'
 return ROOT/'experiments/E014_crossrow_cast/build_C/cloud_addrmsnormbias' if v=='C' else HERE/f'build_{v}/cloud_addrmsnormbias'
core.version=lambda v:(runner(v),core.sha(source(v)))
core.origin=lambda cid: next((q/cid for q in [Path('/mnt/workspace/addrms_results/E021/inputs'),Path('/mnt/workspace/addrms_results/E023/inputs'),Path('/mnt/workspace/addrms_results/E026/inputs')] if (q/cid/'meta.json').exists()),OUT/'inputs'/cid)
orig=core.run_logged
def logged(cmd,*a,**k):
 if '--case-dir' in cmd:cmd.extend(['--max-device-bytes','8589934592'])
 return orig(cmd,*a,**k)
core.run_logged=logged

def build(names):
 for v in names:
  folder=OUT/f'build_{v}';folder.mkdir(exist_ok=True)
  cmd=['env','ASCEND_HOME_PATH=/home/developer/Ascend/cann-9.0.0','KERNEL_SOURCE='+str(source(v)),'BUILD_DIR='+str(runner(v).parent),'bash',str(ROOT/'cloud_bench/build.sh')]
  r=orig(cmd,folder/'stdout.log',folder/'stderr.log',600);r.update(source_sha256=core.sha(source(v)))
  if r['returncode']==0:r['runner_sha256']=core.sha(runner(v))
  core.save(folder/'record.json',r);print(v,r,flush=True)
  assert r['returncode']==0

def case(cid,r,d,dt,pattern='uniform'):
 dest=core.origin(cid)
 if not dest.exists():
  dest.parent.mkdir(exist_ok=True)
  if r<=32768: shape=[1,r,d]
  else:
   factors=[b for b in range(1,8193) if r%b==0 and r//b<=32768]
   if not factors: raise ValueError('Cannot represent rows as a legal batch/sequence product')
   b=factors[0];shape=[b,r//b,d]
  core.case_data.generate(dest,shape,dt,seed=42,pattern=pattern,case_id=cid,max_tensor_mib=2048)
 return cid

def run(cid,v,folder,profile=False):
 rec=core.run_case(folder,cid,v,dict(warmup=10 if profile else 0,repeats=1,batch=20 if profile else 1,timing='host'),'ordinary' if profile else None)
 assert rec['status'] in ('measured_strict_pass','measured_strict_fail_retained'),rec
 # Retain all numerical outcomes, including the approximate Rsqrt probe.
 if profile:
  rows=[]
  for f in (folder/'profile').rglob('op_summary*.csv'):
   with f.open(encoding='utf-8-sig') as h:rows+=list(csv.DictReader(h))
  rows.sort(key=lambda x:float(x['Task Start Time(us)']));assert len(rows)==31,len(rows)
  rec['task_times_us']=[float(x['Task Duration(us)']) for x in rows[-20:]];rec['median_us']=statistics.median(rec['task_times_us'])
  core.save(folder/'record.json',rec)
 return rec

def check(group,items,variants):
 dest=OUT/group;dest.mkdir(exist_ok=True);records=[]
 for cid,r,d,dt in items:
  case(cid,r,d,dt);pair=[]
  for v in variants:
   f=dest/f'{cid}_{v}'
   rec=json.loads((f/'record.json').read_text()) if (f/'record.json').exists() else run(cid,v,f)
   pair.append(rec);records.append(rec)
  
  for x in pair:x['bitwise_equal_parent']=x['output_sha256']==pair[0]['output_sha256']
  core.save(dest/'records.json',records)
 core.save(dest/'complete.json',dict(cases=len(items),runs=len(records),bitwise_equal=all(x.get('bitwise_equal_parent',True) for x in records),strict_fail=sum(not x['strict']['pass'] for x in records)))

def pairs(group,items,base,cand,blocks=2):
 dest=OUT/group;dest.mkdir(exist_ok=True);records=[]
 for block in range(blocks):
  for cid,r,d,dt in items:
   case(cid,r,d,dt)
   for pos,v in enumerate([base,cand,cand,base] if block%2==0 else [cand,base,base,cand]):
    f=dest/f'b{block}_{cid}_{pos}_{v}'
    rec=json.loads((f/'record.json').read_text()) if (f/'record.json').exists() else run(cid,v,f,True)
    records.append(rec);core.save(dest/'records.json',records)
 summary={}
 for cid,*_ in items:
  b=[x['median_us'] for x in records if x['case_id']==cid and x['variant']==base];c=[x['median_us'] for x in records if x['case_id']==cid and x['variant']==cand]
  summary[cid]=dict(base=base,candidate=cand,base_us=b,candidate_us=c,gain_pct=100*(statistics.median(b)-statistics.median(c))/statistics.median(b))
 core.save(dest/'summary.json',summary);print(json.dumps(summary),flush=True)

small=[('s1',1,64,'float16'),('s2',7,197,'float32'),('s3',128,256,'float32'),('s4',767,193,'float16'),('s5',8,32768,'float16'),('s6',1513,577,'float16'),('s7',3113,397,'float16'),('s8',10240,512,'float16'),('s9',4096,1536,'float32'),('s10',8192,1024,'float16'),('s11',3749,3083,'float32'),('s12',3408,4096,'bfloat16'),('s13',10300,3079,'float32'),('s14_reduced',3841,128,'bfloat16'),('s15_reduced',161,8192,'bfloat16')]




def copied_case_readonly(case_id,destination):
 src=core.origin(case_id)
 destination.mkdir(mode=0o700)
 for name in core.FILES:
  (destination/name).symlink_to((src/name).resolve())
 meta=json.loads((destination/'meta.json').read_text())
 old=src/'output.bin'
 return meta,core.sha(old) if old.is_file() else None
core.copied_case=copied_case_readonly
mode=sys.argv[1]
if mode=='build':build(sys.argv[2:])
if mode=='check':
 items=[small[10],small[12]]+[(f'e027_f{d}',161,d,'float32') for d in [1537,2048,3073,3136,4095,4096]]
 check('initial_check',items,['BASE','TREE','BTREE'])
if mode=='measure':
 for v in ['TREE','BTREE']:
  pairs(v.lower()+'_pairs',[small[10],small[12]],'BASE',v,blocks=2)
if mode=='dblock':
 items=[small[10],small[12]]+[(f'e027_f{d}',161,d,'float32') for d in [1537,2048,3073,3136,4095,4096]]
 check('dblock_check',items,['BASE','DBLOCK'])
 pairs('dblock_pairs',[small[10],small[12]],'BASE','DBLOCK',blocks=2)
if mode=='constant':
 items=[small[7],small[9]]+[(f'e027_dense_{r}_{d}',r,d,'float16') for r,d in [(160,512),(161,512),(161,1024),(321,1024),(17,512)]]
 check('constant_check',items,['BASE','CONST'])
 pairs('constant_pairs',[small[7],small[9]],'BASE','CONST',blocks=2)
if mode=='edges':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_edge_'+pattern;case(cid,161,3079,'float32',pattern)
  items.append((cid,161,3079,'float32'))
 check('edge_check',items,['BASE','TREE','BTREE'])

if mode=='library':
 items=[small[2]]+[(f'e027_lib_{r}_{d}',r,d,'float32') for r,d in [(128,64),(128,128),(256,256),(128,512),(161,256),(128,255)]]
 check('library_check',items,['BASE','LIBRARY'])
 pairs('library_pairs',[small[2]],'BASE','LIBRARY',blocks=2)
if mode=='dblock_edges':
 items=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_dblock_edge_'+pattern;case(cid,161,3079,'float32',pattern)
  items.append((cid,161,3079,'float32'))
 check('dblock_edge_check',items,['BASE','DBLOCK'])

if mode=='rsmall':
 items=[small[0],small[1],small[2]]+[(f'e027_rs_{r}_{d}_{dt}',r,d,dt) for r,d,dt in [(1,64,'float32'),(1,64,'bfloat16'),(1,197,'float32'),(7,255,'float32'),(128,512,'float32'),(8,4096,'float16')]]
 check('rsmall_check',items,['BASE','RSMALL'])
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_rs_edge_'+pattern;case(cid,7,197,'float32',pattern)
  check('rsmall_edge_check',[(cid,7,197,'float32')],['BASE','RSMALL'])
 pairs('rsmall_pairs',small[:3],'BASE','RSMALL',blocks=2)

if mode=='fres8':
 items=[(f'e027_fres_{r}_{d}',r,d,'float32') for r,d in [(1,4097),(7,4097),(81,5001),(161,6144),(161,8191),(128,8192),(17,4096)]]
 check('fres8_check',items,['BASE','FRES8'])
 edges=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_fres_edge_'+pattern;case(cid,81,5001,'float32',pattern);edges.append((cid,81,5001,'float32'))
 check('fres8_edge_check',edges,['BASE','FRES8'])
 pairs('fres8_pairs',[(f'e027_fres_perf_{r}_{d}',r,d,'float32') for r,d in [(1024,4097),(1024,8192)]],'BASE','FRES8',blocks=2)

if mode=='freslong':
 items=[(f'e027_flong_{r}_{d}',r,d,'float32') for r,d in [(1,8193),(7,16383),(81,16384),(81,24575),(161,32767),(128,32768),(17,8192)]]
 check('freslong_check',items,['BASE','FRESLONG'])
 edges=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_flong_edge_'+pattern;case(cid,81,16383,'float32',pattern);edges.append((cid,81,16383,'float32'))
 check('freslong_edge_check',edges,['BASE','FRESLONG'])
 pairs('freslong_pairs',[(f'e027_flong_perf_{r}_{d}',r,d,'float32') for r,d in [(1024,16384),(1024,32768)]],'BASE','FRESLONG',blocks=2)

if mode=='affearly':
 items=[small[10],small[12]]+[(f'e027_f{d}',161,d,'float32') for d in [1537,2048,3073,3136,4095,4096]]
 check('affearly_check',items,['BASE','AFFEARLY'])
 edges=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_aff_edge_'+pattern;case(cid,161,3079,'float32',pattern);edges.append((cid,161,3079,'float32'))
 check('affearly_edge_check',edges,['BASE','AFFEARLY'])
 pairs('affearly_pairs',[small[10],small[12]],'BASE','AFFEARLY',blocks=2)

if mode=='fresw':
 items=[small[8],small[10],small[12]]+[(f'e027_fwide_{r}_{d}',r,d,'float32') for r,d in [(161,1025),(161,1537),(161,2048),(161,4096),(159,3079)]]
 check('fresw_check',items,['BASE','FRESW'])
 pairs('fresw_pairs',[small[8],small[10],small[12]],'BASE','FRESW',blocks=2)

if mode=='merged':
 v=sys.argv[2]
 if v=='AFFLONG':
  items=[small[10],small[12],('e027_flong_81_16384',81,16384,'float32')]
  check('afflong_check',items,['BASE',v])
  pairs('afflong_pairs',[small[10],small[12]],'BASE',v,blocks=1)
 else:
  assert v=='FRESWL'
  items=[small[8],small[10],small[12],('e027_flong_81_16384',81,16384,'float32')]+[(f'e027_fwide_{r}_{d}',r,d,'float32') for r,d in [(161,1025),(161,1537),(161,2048),(161,4096),(159,3079)]]
  check('freswl_check',items,['BASE',v])
  pairs('freswl_pairs',[small[8],small[10],small[12]],'BASE',v,blocks=2)

if mode=='rsmallf':
 items=[small[0],small[1],small[2]]+[(f'e027_rs_{r}_{d}_{dt}',r,d,dt) for r,d,dt in [(1,64,'float32'),(1,64,'bfloat16'),(1,197,'float32'),(7,255,'float32'),(128,512,'float32'),(8,4096,'float16')]]
 check('rsmallf_check',items,['BASE','RSMALLF'])
 edges=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_rs_edge_'+pattern;case(cid,7,197,'float32',pattern);edges.append((cid,7,197,'float32'))
 check('rsmallf_edge_check',edges,['BASE','RSMALLF'])
 pairs('rsmallf_pairs',small[:3],'BASE','RSMALLF',blocks=2)

if mode=='rfmaw':
 check('rfmaw_check',small,['BASE','RFMAW'])
 edges=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  for r,d,dt in [(161,193,'float16'),(161,3079,'float32'),(161,128,'bfloat16')]:
   cid=f'e027_rf_{d}_{pattern}';case(cid,r,d,dt,pattern);edges.append((cid,r,d,dt))
 check('rfmaw_edge_check',edges,['BASE','RFMAW'])
 pairs('rfmaw_pairs',[small[3],small[5],small[10],small[13]],'BASE','RFMAW',blocks=1)

if mode=='fres15':
 items=[small[8],small[10],small[12],('e027_fres_perf_1024_8192',1024,8192,'float32')]+[(f'e027_f15_{r}_{d}',r,d,'float32') for r,d in [(161,1025),(161,1535),(161,1536),(161,1537),(159,1536)]]
 check('fres15_check',items,['BASE','FRES15'])
 pairs('fres15_pairs',[small[8]],'BASE','FRES15',blocks=1)

if mode=='hvar':
 items=[small[i] for i in [5,6,7,9]]+[(f'e027_hv_{r}_{d}',r,d,'float16') for r,d in [(161,321),(161,383),(161,397),(161,512),(161,577),(161,1023),(159,577)]]
 check('hvar_check',items,['BASE','HVAR128'])
 edges=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_hv_edge_'+pattern;case(cid,161,577,'float16',pattern);edges.append((cid,161,577,'float16'))
 check('hvar_edge_check',edges,['BASE','HVAR128'])
 pairs('hvar_pairs',[small[i] for i in [5,6,7,9]],'BASE','HVAR128',blocks=1)

if mode=='hwaves':
 items=[small[i] for i in [5,6,7,9]]+[(f'e027_wave_{r}_{d}',r,d,'float16') for r,d in [(160,321),(161,577),(319,1024),(321,1536),(161,4095),(159,577)]]
 check('hwave_check',items,['BASE','HWAVE2','HWAVE4'])
 for v in ['HWAVE2','HWAVE4']:
  pairs(v.lower()+'_pairs',[small[5],small[6]],'BASE',v,blocks=1)
if mode=='late_queue':
 for args in [['merged','AFFLONG'],['hvar'],['hwaves']]:
  subprocess.run([sys.executable,__file__]+args,check=True)

if mode=='hfast':
 items=[small[i] for i in [5,6,7,9]]+[(f'e027_hv_{r}_{d}',r,d,'float16') for r,d in [(161,321),(161,383),(161,397),(161,512),(161,577),(161,1023),(159,577)]]
 check('hfast_check',items,['BASE','HFAST128'])
 edges=[]
 for pattern in ['zeros','checkerboard','cancel','wide_range','specials']:
  cid='e027_hv_edge_'+pattern;case(cid,161,577,'float16',pattern);edges.append((cid,161,577,'float16'))
 check('hfast_edge_check',edges,['BASE','HFAST128'])
 pairs('hfast_pairs',[small[i] for i in [5,6,7,9]],'BASE','HFAST128',blocks=1)

if mode=='cached_rms':
 v=sys.argv[2];assert v in ['RMSCF','HFRMSCF']
 check(v.lower()+'_check',small,['BASE',v])
 pairs(v.lower()+'_pairs',[small[i] for i in [3,5,7,10]],'BASE',v,blocks=1)
