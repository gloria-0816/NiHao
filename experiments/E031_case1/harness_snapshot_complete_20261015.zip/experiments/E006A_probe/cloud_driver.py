"""Serial, resumable-by-phase E006-A driver. Never writes old baseline data."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
sys.path.insert(0,str(REPO/'cloud_bench'))
sys.path.insert(0,str(REPO/'cloud_bench/scripts'))
import case_data
from profile_cases import run_logged, copy_case

RESULT=Path('/mnt/workspace/addrms_results/E006A')
ORIGINAL=Path('/mnt/workspace/addrms_results/phase0_baseline/data')
PROTOCOL=json.loads((HERE/'protocol.json').read_text())
SOURCES=json.loads((HERE/'source_manifest.json').read_text())
VARIANTS=PROTOCOL['variants']
FILES=('x.bin','residual.bin','gamma.bin','bias.bin','golden_output.bin','golden_output_fp32.bin','meta.json')

def sha(path):
    d=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(8<<20),b''):
            d.update(block)
    return d.hexdigest()

def save(path,obj):
    path=Path(path)
    temporary=path.with_name(path.name+'.tmp')
    temporary.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    temporary.replace(path)

def version(name):
    if name=='B':
        return REPO/'cloud_bench/build/cloud_addrmsnormbias',SOURCES['baseline_sha256']
    return HERE/f'build_{name}/cloud_addrmsnormbias',SOURCES['variants'][name]['source_sha256']

def initialize():
    RESULT.mkdir(exist_ok=True)
    own=RESULT/'holdout_inputs'
    own.mkdir(exist_ok=True)
    for item in PROTOCOL['holdout']:
        destination=own/item['case_id']
        if not (destination/'meta.json').exists():
            case_data.generate(destination,item['shape'],item['dtype'],seed=item['seed'],case_id=item['case_id'])
    return own

def origin(case):
    return (RESULT/'holdout_inputs'/case) if case.startswith('hold_') else ORIGINAL/case

def copied_case(case,destination):
    src=origin(case)
    destination.mkdir(mode=0o700)
    for name in FILES:
        # All links point to read-only inputs; output.bin is ALWAYS a new file.
        os.link(src/name,destination/name)
    meta=json.loads((destination/'meta.json').read_text())
    old=src/'output.bin'
    return meta,sha(old) if old.is_file() else None

def validate(raw,meta,expected_sha,settings):
    wanted={'kernel_sha256':expected_sha,'shape':meta['shape'],
            'dtype':{'float32':0,'float16':1,'bfloat16':2}[meta['dtype']],
            'vector_cores':40,'timing_mode':settings['timing'],
            'warmup':settings['warmup'],'repeats':settings['repeats'],'batch':settings['batch']}
    errors={k:{'wanted':v,'observed':raw.get(k)} for k,v in wanted.items() if raw.get(k)!=v}
    if errors:
        raise ValueError('Benchmark identity/settings mismatch: '+json.dumps(errors))

def run_case(folder,case,name,settings,profile=None):
    folder.mkdir(parents=True,mode=0o700)
    meta,old_sha=copied_case(case,folder/'case')
    runner,source_sha=version(name)
    cmd=[str(runner),'--case-dir',str(folder/'case'),'--result',str(folder/'benchmark.json'),
         '--warmup',str(settings['warmup']),'--repeats',str(settings['repeats']),
         '--batch',str(settings['batch']),'--timing',settings['timing'],
         '--timeout-ms',str(PROTOCOL['timeout_ms'])]
    if profile=='ordinary':
        cmd=['msprof','--output='+str(folder/'profile'),'--task-time=on','--ai-core=off','--runtime-api=on']+cmd
    elif profile=='op':
        cmd=['msprof','op','--output='+str(folder/'profile'),
             '--aic-metrics=BasicInfo,PipeUtilization,Memory,MemoryUB,L2Cache',
             '--launch-skip-before-match=11','--launch-count=5']+cmd
    record={'case_id':case,'variant':name,'kernel_sha256':source_sha,'runner_sha256':sha(runner),
            'shape':meta['shape'],'dtype':meta['dtype'],'input_meta_sha256':sha(folder/'case/meta.json'),
            'input_file_sha256':{n:sha(folder/'case'/n) for n in FILES},
            'preserved_old_output_sha256':old_sha,'command':cmd,'directory':str(folder),
            'settings':settings,'profile':profile,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
            'status':'running'}
    save(folder/'record.json',record)
    record.update(run_logged(cmd,folder/'stdout.log',folder/'stderr.log',600 if profile else PROTOCOL['process_timeout_s']))
    if record['returncode']!=0 or record['timed_out']:
        record['status']='timeout' if record['timed_out'] else 'execution_failed'
    else:
        try:
            raw=json.loads((folder/'benchmark.json').read_text())
            validate(raw,meta,source_sha,settings)
            record['benchmark']=raw
            record['strict']=case_data.verify(folder/'case',verify_hashes=True)
            save(folder/'strict.json',record['strict'])
            record['output_sha256']=sha(folder/'case/output.bin')
            record['output_bytes']=(folder/'case/output.bin').stat().st_size
            record['status']='measured_strict_pass' if record['strict'].get('pass') else 'measured_strict_fail_retained'
            record['old_output_unchanged']=old_sha is None or sha(origin(case)/'output.bin')==old_sha
            record['output_matches_preserved_baseline']=None if old_sha is None else record['output_sha256']==old_sha
        except Exception as exc:
            record['status']='verification_or_metadata_error'
            record['error']=str(exc)
    save(folder/'record.json',record)
    print(json.dumps({k:record.get(k) for k in ('case_id','variant','profile','status','output_matches_preserved_baseline')},ensure_ascii=False),flush=True)
    return record

def build():
    folder=RESULT/'build'
    folder.mkdir(exist_ok=False)
    records=[]
    for name in VARIANTS[1:]:
        source=HERE/'source'/name/'kernel.asc'
        if sha(source)!=SOURCES['variants'][name]['source_sha256']:
            raise ValueError('Uploaded source changed')
        cmd=['env','ASCEND_HOME_PATH=/home/developer/Ascend/cann-9.0.0','KERNEL_SOURCE='+str(source),
             'BUILD_DIR='+str(HERE/f'build_{name}'),'bash',str(REPO/'cloud_bench/build.sh')]
        record={'variant':name,'command':cmd,'kernel_sha256':sha(source),
                'build_tool_sha256':sha(REPO/'cloud_bench/build.sh')}
        record.update(run_logged(cmd,folder/f'{name}.stdout.log',folder/f'{name}.stderr.log',600))
        runner,_=version(name)
        record['status']='compiled' if record['returncode']==0 and not record['timed_out'] and runner.is_file() else 'build_failed'
        if record['status']=='compiled':
            record['runner_sha256']=sha(runner)
        records.append(record)
        save(folder/'records.json',records)
        print(json.dumps(record),flush=True)
    return records

def phase(name):
    root=RESULT/name
    root.mkdir(exist_ok=False,mode=0o700)
    root.chmod(0o700)
    cases=PROTOCOL['calibration'] if name=='calibration' else [i['case_id'] for i in PROTOCOL['holdout']] if name=='holdout' else PROTOCOL[name]
    blocks=PROTOCOL['blocks'] if name in ('calibration','holdout') else 1
    records=[]
    for block in range(blocks):
        case_order=cases if block%2==0 else list(reversed(cases))
        for position,case in enumerate(case_order):
            shift=(block+position)%4
            order=VARIANTS[shift:]+VARIANTS[:shift]
            if block%2:
                order=list(reversed(order))
            settings={k:PROTOCOL[k] for k in ('warmup','repeats','batch','timing')}
            if name in ('smoke','additional_correctness'):
                settings.update(warmup=2 if name=='smoke' else 0,repeats=3 if name=='smoke' else 1,batch=2 if name=='smoke' else 1)
            block_records=[]
            for variant in order:
                folder=root/f'block{block+1:02d}_{case}_{variant}'
                record=run_case(folder,case,variant,settings)
                record.update(block=block+1,position=position+1)
                records.append(record)
                block_records.append(record)
                save(root/'records.json',records)
            base=next(r for r in block_records if r['variant']=='B')
            for record in block_records:
                record['paired_B_output_sha256']=base.get('output_sha256')
                record['output_matches_paired_B']=bool(base.get('output_sha256')) and record.get('output_sha256')==base['output_sha256']
                record['paired_B_strict_pass']=base.get('strict',{}).get('pass')
                save(Path(record['directory'])/'record.json',record)
            save(root/'records.json',records)
    return records

def profiles():
    root=RESULT/'profiles'
    root.mkdir(exist_ok=False,mode=0o700)
    root.chmod(0o700)
    records=[]
    for mode,cases in [('ordinary',['float32_r1_d64','float32_r512_d513','bfloat16_r2_d65']),('op',['float32_r512_d513'])]:
        for position,case in enumerate(cases):
            order=VARIANTS if position%2==0 else list(reversed(VARIANTS))
            for name in order:
                settings={'warmup':10,'repeats':1,'batch':5 if mode=='op' else 20,'timing':'host'}
                record=run_case(root/f'{mode}_{case}_{name}',case,name,settings,profile=mode)
                records.append(record)
                save(root/'records.json',records)
    return records

def main():
    p=argparse.ArgumentParser()
    p.add_argument('phase',choices=['build','smoke','calibration','holdout','additional_correctness','profiles'])
    args=p.parse_args()
    initialize()
    save(RESULT/'tool_identity.json',{'driver_sha256':sha(__file__),'protocol_sha256':sha(HERE/'protocol.json'),
          'source_manifest_sha256':sha(HERE/'source_manifest.json'),'runner_source_sha256':sha(REPO/'cloud_bench/runner.asc'),
          'case_data_sha256':sha(case_data.__file__),'source_manifest':SOURCES})
    records=build() if args.phase=='build' else profiles() if args.phase=='profiles' else phase(args.phase)
    bad=[r for r in records if r['status'] in ('build_failed','execution_failed','timeout','verification_or_metadata_error')]
    print(json.dumps({'phase':args.phase,'records':len(records),'tool_failures':len(bad)}),flush=True)
    return int(bool(bad))

if __name__=='__main__':
    raise SystemExit(main())
